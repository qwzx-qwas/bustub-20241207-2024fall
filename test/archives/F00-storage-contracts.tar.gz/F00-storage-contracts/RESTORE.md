# F00-storage-contracts

Source revision: `78c0bdd353036c8907d675ad27b9ed80c253e842`.

Extract outside the repository test tree. Verify SHA-256 values in MANIFEST.json before use.
Use an isolated checkout of the recorded source revision for dependencies and production paths.
The original source paths are retained inside this module directory. Copy only the selected tests into the isolated checkout when needed.
Tests and tools must be reviewed before new runs; old passing runs do not resolve the known gaps.
See test/archives/README.md in the current repository for recovery commands and current ownership.
