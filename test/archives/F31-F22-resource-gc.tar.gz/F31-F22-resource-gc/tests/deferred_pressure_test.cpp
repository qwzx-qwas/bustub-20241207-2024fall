// Reuse the twelve original workloads and their syscall gate; no production
// hook.
#include "deferred-budgeted.cpp"
namespace {
TEST(S12Deferred, CompletionWaitsForRAMWithoutDroppingDurableTask) {
  Image image;
  auto o = Options(image);
  auto shared = std::make_shared<ResourceBudget>(
      ResourceBudgetOptions{512 * 1024, 4096, 0});
  o.io_.memory_budget_ = shared;
  o.metadata_.memory_budget_ = shared;
  NodeStorage node(o);
  node.Create(Layout(o));
  const auto key = New(node, 97);
  const auto body = Value(o.objects_->allocator_.allocation_bytes_, 93);
  BlockDevice other_device(image.path, {});
  IOExecutor competing(other_device, {1, 4096, 2 * MIB, shared});
  Cleanup
      cleanup; // Opens the gate before any owner joins its worker on failure.
  Arm(Gate::Write);
  Commit(node, {{Change(ObjectOperation::Write, key, 0, body)}, {}});
  ASSERT_TRUE(
      Entered()); // Durable object exists; its final Data write is paused.
  const auto chunk = other_device.Info().offset_alignment_;
  std::vector<IOBatch> held;
  for (;;) {
    auto p =
        competing.TryPrepare({{IOOperation::Read, Range(0, chunk)}}, false);
    if (p.admission_ == IOAdmission::Full)
      break;
    ASSERT_EQ(p.admission_, IOAdmission::Accepted);
    held.push_back(std::move(*p.batch_));
    ASSERT_LT(held.size(), 4095U);
  }
  ASSERT_FALSE(held.empty());
  // Restore exactly the same pressure, using successful admission to
  // distinguish the next failure (B's completion) from our own last failed
  // preparation.
  held.pop_back();
  auto last =
      competing.TryPrepare({{IOOperation::Read, Range(0, chunk)}}, false);
  ASSERT_EQ(last.admission_, IOAdmission::Accepted);
  held.push_back(std::move(*last.batch_));
  ASSERT_FALSE(shared->Pressure());
  Release();
  const auto deadline = std::chrono::steady_clock::now() + 15s;
  while (!shared->Pressure() && std::chrono::steady_clock::now() < deadline)
    std::this_thread::yield();
  ASSERT_TRUE(shared->Pressure())
      << "completion did not encounter the exhausted budget";
  // Pressure() is a hint set during admission, before its retry has returned.
  // A real B commit joins the same writer serialization; retaining the buffers
  // through this rejection prevents the failed completion from being rescued
  // in the middle of its admission attempt.
  try {
    auto rejected = node.Commit(node.Read(), {{{77, 1, 3}, Value(32, 31)}});
    if (rejected.error_)
      std::rethrow_exception(rejected.error_);
    FAIL() << "competing metadata unexpectedly admitted while RAM is exhausted";
  } catch (const MetadataError &error) {
    EXPECT_EQ(error.Code(), MetadataErrorCode::ResourceUnavailable);
  }
  // Data is durable but its completion record is still blocked. Both the
  // finished Data IO buffer and decoded body are now dead work, so another
  // real owner must be able to use that capacity without dropping this task.
  // Competing B retries may briefly hold credits; do not inspect private counts.
  std::optional<IOBatch> reclaimed;
  const auto reclaim_deadline = std::chrono::steady_clock::now() + 15s;
  while (!reclaimed && std::chrono::steady_clock::now() < reclaim_deadline) {
    auto p = competing.TryPrepare(
        {{IOOperation::Read, Range(0, 2 * body.size())}}, false);
    if (p.admission_ == IOAdmission::Accepted) {
      reclaimed = std::move(p.batch_);
    } else {
      ASSERT_EQ(p.admission_, IOAdmission::Full);
      std::this_thread::sleep_for(1ms);
    }
  }
  ASSERT_TRUE(reclaimed)
      << "durable Data retained dead writeback memory during completion retry";
  reclaimed.reset();
  held.clear();
  Settled(node, key, 0);
  EXPECT_FALSE(node.State().error_);
  EXPECT_EQ(Read(node, key, 0, body.size()), body);
  Reset();
  node.Close();
  node.Open();
  EXPECT_EQ(Read(node, key, 0, body.size()), body);
  node.Close();
}
// F14's transient admission is consumed by both foreground reads and F22.
// Pause an actual reclamation commit; do not edit counters or wait for a race.
TEST(S12Reclaim, ActiveOperationLimitReturnsBusyAndRecovers) {
  Image image;
  auto o = Options(image);
  o.memory_budget_ = ResourceBudgetOptions{8 * MIB, 64 * 1024, MIB};
  const auto body = Value(o.objects_->allocator_.allocation_bytes_, 121);
  ObjectKey retired{}, live{};
  uint64_t allocation = 0;
  {
    NodeStorage setup(o);
    setup.Create(Layout(o));
    retired = New(setup, 101);
    live = New(setup, 102);
    Commit(setup, {{Common(Change(ObjectOperation::Write, retired, 0, body))}, {}});
    Commit(setup, {{Common(Change(ObjectOperation::Write, live, 0, body))}, {}});
    allocation = setup.Objects().Resolve(retired, 0, body.size()).spans_.front().data_->allocation_;
    Durable(setup.RemoveObject(setup.Objects(), retired));
    setup.Close();
  }
  // The public S6 deployment allows deterministic control of the admitted
  // reclaim call. F22 invokes this same reference admission path in production.
  o.transactions_.reset();
  o.objects_->references_.max_active_operations_ = 1;
  NodeStorage node(o);
  node.Open();
  std::future<ObjectReclaimResult> reclaim;
  Cleanup cleanup; // Release the syscall gate before joining on assertion failure.
  Arm(Gate::JournalFlush);
  reclaim = std::async(std::launch::async, [&] {
    return node.ReclaimObject(node.Objects(), retired, allocation);
  });
  ASSERT_TRUE(Entered());
  try {
    node.ProtectObject(node.Objects(), live, 0, body.size());
    FAIL() << "active reference limit did not reject a competing operation";
  } catch (const ObjectReferenceError &e) {
    EXPECT_EQ(e.Code(), ObjectReferenceErrorCode::Busy);
  } catch (const std::exception &e) {
    FAIL() << "temporary reference admission must report Busy: " << e.what();
  }
  Release();
  ASSERT_EQ(reclaim.wait_for(15s), std::future_status::ready);
  const auto result = reclaim.get();
  ASSERT_TRUE(result.commit_);
  Durable(*result.commit_);
  EXPECT_EQ(result.released_bytes_, body.size());
  EXPECT_EQ(Read(node, live, 0, body.size()), body);
  EXPECT_FALSE(node.ReclaimObject(node.Objects(), retired, allocation).commit_);
  Reset();
  node.Close();
  node.Open();
  EXPECT_EQ(Read(node, live, 0, body.size()), body);
  EXPECT_FALSE(node.State().object_error_);
  node.Close();
}
} // namespace
