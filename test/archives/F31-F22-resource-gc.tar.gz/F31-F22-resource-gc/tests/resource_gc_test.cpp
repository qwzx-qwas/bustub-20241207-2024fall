#include "fixture.h"
#include "storage/disk/node_storage.h"
#include "gtest/gtest.h"
#include <chrono>
#include <cstring>
#include <thread>
using namespace std::chrono_literals;
namespace {
using namespace bustub;
using namespace s5;
size_t Unit(const BlockDevice &dev) {
  return std::lcm<size_t>(4096, 4 * std::max(dev.Info().offset_alignment_,
                                             dev.Info().memory_alignment_));
}
std::vector<IORequest> Requests(size_t n, size_t u, size_t offset = 0,
                                IOOperation op = IOOperation::Write) {
  std::vector<IORequest> r;
  for (size_t i = 0; i < n; ++i)
    r.push_back({op, Range(offset + i * u, u)});
  return r;
}
void Execute(IOExecutor &io, IOBatch &batch, bool write = true) {
  Require(io.TrySubmit(batch) == IOAdmission::Accepted, "batch submit");
  Require(batch.WaitFor(15s), "batch deadline");
  for (const auto &op : batch.Result().operations_) {
    if (op.error_)
      std::rethrow_exception(op.error_);
    Require(op.outcome_ == IOOutcome::Succeeded, "member failed");
  }
  Require(!write || batch.Result().writes_durable_, "durable completion");
}
void CheckBytes(IOExecutor &io, size_t off, const Bytes &expected) {
  auto r = io.TryPrepare(Requests(1, expected.size(), off, IOOperation::Read),
                         false);
  Require(r.admission_ == IOAdmission::Accepted, "read admission");
  Execute(io, *r.batch_, false);
  EXPECT_EQ(std::memcmp(r.batch_->Buffer(0), expected.data(), expected.size()),
            0);
}
TEST(S12Resources, OwnersShareRAMButBorrowingDoesNotChargeItTwice) {
  Image image;
  BlockDevice dev(image.path, {});
  const auto u = Unit(dev), q = u + dev.Info().memory_alignment_ - 1;
  auto budget =
      std::make_shared<ResourceBudget>(ResourceBudgetOptions{4 * q, q, q});
  IOExecutor a(dev, {2, 16, 16 * q, budget}, 16 * u),
      b(dev, {2, 16, 16 * q, budget}, 16 * u);
  auto first = a.TryPrepare(Requests(1, u), true);
  auto second = b.TryPrepare(Requests(2, u, u), true);
  ASSERT_EQ(first.admission_, IOAdmission::Accepted);
  ASSERT_EQ(second.admission_, IOAdmission::Accepted);
  auto denied = a.TryPrepare(Requests(1, u, 4 * u), true);
  EXPECT_EQ(denied.admission_, IOAdmission::Full);
  EXPECT_TRUE(denied.shared_memory_limited_);
  const auto data = Value(u, 19);
  std::memcpy(first.batch_->Buffer(0), data.data(), u);
  for (size_t i = 0; i < 2; ++i)
    std::memcpy(second.batch_->Buffer(i), data.data(), u);
  Execute(a, *first.batch_);
  auto owner = std::make_shared<IOBatch>(std::move(*first.batch_));
  first.batch_.reset();
  std::vector<IOBufferLease> leases;
  leases.push_back(IOBufferLease::ForWrite(owner->Buffer(0), u, [owner] {}));
  auto borrowed = b.TryPrepareExternal(Requests(1, u, 3 * u), leases, true);
  ASSERT_EQ(borrowed.admission_, IOAdmission::Accepted);
  owner.reset();
  Execute(b, *borrowed.batch_);
  Execute(b, *second.batch_);
  // The first buffer can now be released; the second result still owns two.
  auto retained = a.TryPrepare(Requests(1, u, 4 * u), true);
  ASSERT_EQ(retained.admission_, IOAdmission::Accepted);
  EXPECT_FALSE(budget->Pressure());
  EXPECT_TRUE(denied.shared_memory_limited_);
  EXPECT_EQ(a.TryPrepare(Requests(1, u, 5 * u), true).admission_,
            IOAdmission::Full);
  retained.batch_.reset();
  second.batch_.reset();
  borrowed.batch_.reset();
  CheckBytes(a, 0, data);
  CheckBytes(b, u, data);
  CheckBytes(a, 2 * u, data);
  CheckBytes(b, 3 * u, data);
  // Four buffers fit this executor and the total RAM, but not the ordinary
  // class's three-buffer capacity. Retrying cannot make that request fit.
  EXPECT_THROW(a.TryPrepare(Requests(4, u), true), std::invalid_argument);
  {
    ProgressWork finish(true);
    auto total = a.TryPrepare(Requests(4, u), true);
    ASSERT_EQ(total.admission_, IOAdmission::Accepted);
    for (size_t i = 0; i < 4; ++i)
      std::memcpy(total.batch_->Buffer(i), data.data(), u);
    Execute(a, *total.batch_);
  }
}
TEST(S12Resources, IdleCreditsCanMoveToAnotherOwner) {
  Image image;
  BlockDevice dev(image.path, {});
  const auto u = Unit(dev), q = u + dev.Info().memory_alignment_ - 1;
  auto budget =
      std::make_shared<ResourceBudget>(ResourceBudgetOptions{4 * q, q, q});
  IOExecutor a(dev, {2, 16, 16 * q, budget}), b(dev, {2, 16, 16 * q, budget});
  auto idle = a.TryPrepare(Requests(1, u), true);
  ASSERT_EQ(idle.admission_, IOAdmission::Accepted);
  idle.batch_.reset();
  auto moved = b.TryPrepare(Requests(3, u), true);
  ASSERT_EQ(moved.admission_, IOAdmission::Accepted);
  const auto data = Value(u, 38);
  for (size_t i = 0; i < 3; ++i)
    std::memcpy(moved.batch_->Buffer(i), data.data(), u);
  Execute(b, *moved.batch_);
  moved.batch_.reset();
  CheckBytes(a, 0, data);
  CheckBytes(a, 2 * u, data);
}
TEST(S12Resources, OrdinaryWorkCannotConsumeCompletionSlots) {
  Image image;
  BlockDevice dev(image.path, {});
  const auto u = Unit(dev), q = u + dev.Info().memory_alignment_ - 1;
  auto budget =
      std::make_shared<ResourceBudget>(ResourceBudgetOptions{8 * q, q, 2 * q});
  IOExecutor io(dev, {2, 4, 4 * q, budget, 1, q});
  auto normal = io.TryPrepare(Requests(3, u), true);
  ASSERT_EQ(normal.admission_, IOAdmission::Accepted);
  IOExecutor other(dev, {1, 16, 16 * q, budget});
  auto memory_full = other.TryPrepare(Requests(4, u), true);
  ASSERT_EQ(memory_full.admission_, IOAdmission::Full);
  ASSERT_TRUE(memory_full.shared_memory_limited_);
  ASSERT_TRUE(budget->Pressure());
  auto slots_full = io.TryPrepare(Requests(1, u, 3 * u), true);
  EXPECT_EQ(slots_full.admission_, IOAdmission::Full);
  EXPECT_FALSE(slots_full.shared_memory_limited_);
  const auto data = Value(u, 57);
  std::optional<IOBatch> progress;
  {
    ProgressWork finish(true);
    auto p = io.TryPrepare(Requests(1, u, 3 * u), true);
    ASSERT_EQ(p.admission_, IOAdmission::Accepted);
    progress = std::move(p.batch_);
  }
  // Both execution and release occur after the synchronous lane scope ended.
  std::memcpy(progress->Buffer(0), data.data(), u);
  Execute(io, *progress);
  progress.reset();
  EXPECT_EQ(io.TryPrepare(Requests(1, u, 4 * u), true).admission_,
            IOAdmission::Full);
  {
    ProgressWork finish(true);
    auto again = io.TryPrepare(Requests(1, u, 4 * u), true);
    ASSERT_EQ(again.admission_, IOAdmission::Accepted);
    std::memcpy(again.batch_->Buffer(0), data.data(), u);
    Execute(io, *again.batch_);
  }
  for (size_t i = 0; i < 3; ++i)
    std::memcpy(normal.batch_->Buffer(i), data.data(), u);
  Execute(io, *normal.batch_);
  normal.batch_.reset();
  CheckBytes(io, 3 * u, data);
  CheckBytes(io, 4 * u, data);
}
NodeStorageOptions Options(const Image &image) {
  BlockDevice dev(image.path, {});
  const auto u = static_cast<uint32_t>(Unit(dev));
  Require(u <= 16384, "alignment exceeds fixture budget");
  BootstrapIdentity id{};
  id.storage_.fill(11);
  id.device_.fill(31);
  JournalIdentity jid{};
  jid.fill(73);
  return {image.path,
          {},
          {3, 2048, 16 * MIB},
          id,
          jid,
          {4ULL * u, u, 32 * u, MIB, 128, 2 * MIB, 8, 32, 4 * MIB},
          {256, 2048, 16384, 64 * 1024},
          {1, 1ms, 1000ms},
          ObjectStorageOptions{{u, 64, MIB, 2 * MIB, 8, 1024, 4096},
                               {2, 512, 128 * 1024, 256, 32},
                               {64, 64, 1024, 8, 2 * MIB, 16},
                               2 * MIB,
                               2 * MIB},
          ObjectTransactionOptions{16, 16, 32 * u, 4 * MIB, 2ms, 2ms}};
}
BootstrapLayout Layout(const NodeStorageOptions &o,
                       size_t data_bytes = 2 * MIB) {
  return {o.identity_,
          8 * MIB,
          {Range(2 * MIB, MIB), Range(JOURNAL_START, 2 * MIB),
           Range(6 * MIB, data_bytes)}};
}
void Durable(const JournalResult &r) {
  if (r.error_)
    std::rethrow_exception(r.error_);
  Require(r.outcome_ == JournalOutcome::Durable, "expected durable commit");
}
TEST(S12Resources, OldMetadataViewsHoldCreditsUntilReleased) {
  Image image;
  auto o = Options(image);
  o.objects_.reset();
  o.transactions_.reset();
  o.memory_budget_ = ResourceBudgetOptions{384 * 1024, 8 * 1024, 64 * 1024};
  NodeStorage node(o);
  node.Create(Layout(o));
  const MetadataKey key{777, 1, 3};
  std::vector<std::pair<MetadataSnapshot, Bytes>> held;
  Bytes expected;
  bool full = false;
  for (unsigned i = 1; i <= 160; ++i) {
    if (!expected.empty())
      held.emplace_back(node.Read(), expected);
    auto next = Value(256, i);
    try {
      auto r = node.Commit(node.Read(), {{key, next}});
      if (r.error_)
        std::rethrow_exception(r.error_);
      Durable(r);
      expected = std::move(next);
    } catch (const MetadataError &e) {
      ASSERT_EQ(e.Code(), MetadataErrorCode::ResourceUnavailable);
      full = true;
      break;
    }
  }
  ASSERT_TRUE(full) << "old B views were not charged to the shared budget";
  ASSERT_GT(held.size(), 3U);
  EXPECT_EQ(node.Read().Get(key), std::optional<Bytes>(expected));
  for (const auto &entry : held)
    EXPECT_EQ(entry.first.Get(key), std::optional<Bytes>(entry.second));
  held.clear();
  expected = Value(256, 211);
  Durable(node.Commit(node.Read(), {{key, expected}}));
  node.Checkpoint(256);
  node.Close();
  node.Open();
  EXPECT_EQ(node.Read().Get(key), std::optional<Bytes>(expected));
  node.Close();
}
ObjectKey New(NodeStorage &node, uint64_t n) {
  auto s = node.CreateObjectSpace(node.Objects());
  Durable(s.result_);
  ObjectKey key{*s.space_, n};
  Durable(node.CreateObject(node.Objects(), key, 0, ObjectSizeMode::Variable));
  return key;
}
JournalResult Write(NodeStorage &node, ObjectKey key, Bytes data) {
  ObjectTransaction tx{{{ObjectOperation::Write, key, 0,
                         ObjectSizeMode::Variable, std::move(data)}},
                       {}};
  auto r = node.SubmitObjects(tx);
  Require(r.admission_ == IOAdmission::Accepted && r.ticket_,
          "object admission");
  Require(r.ticket_->WaitFor(15s), "object completion deadline");
  return r.ticket_->Result();
}
Bytes Read(NodeStorage &node, ObjectKey key, size_t bytes) {
  auto r = node.ReadObject(node.Objects(), key, 0, bytes);
  r.Wait();
  Bytes out(r.Size());
  r.CopyTo(out.data(), out.size());
  return out;
}
void EventuallyWrite(NodeStorage &node, ObjectKey key, const Bytes &data) {
  const auto deadline = std::chrono::steady_clock::now() + 5s;
  do {
    auto r = Write(node, key, data);
    if (r.outcome_ == JournalOutcome::Durable) {
      Durable(r);
      return;
    }
    Require(r.outcome_ == JournalOutcome::NotCommitted,
            "unsafe retry of uncertain write");
    Require(r.error_ != nullptr, "uncommitted write has no failure reason");
    try {
      std::rethrow_exception(r.error_);
    } catch (const AllocationError &e) {
      Require(e.Code() == AllocationErrorCode::NoSpace,
              "unexpected allocation error");
    }
    std::this_thread::sleep_for(5ms);
  } while (std::chrono::steady_clock::now() < deadline);
  FAIL()
      << "background reclaim did not make space for acknowledged object write";
}
TEST(S12Resources, PinnedGarbageDoesNotStarveOtherReclaimAndReuse) {
  Image image;
  auto o = Options(image);
  const auto u = o.objects_->allocator_.allocation_bytes_;
  o.memory_budget_ = ResourceBudgetOptions{8 * MIB, 64 * 1024, MIB};
  NodeStorage node(o);
  node.Create(Layout(o, 32 * u));
  const auto a = New(node, 1), b = New(node, 2), c = New(node, 3);
  const auto small = Value(8 * u, 89), big = Value(16 * u, 103),
             last = Value(8 * u, 149);
  Durable(Write(node, a, small));
  Durable(Write(node, b, small));
  Durable(Write(node, c, small));
  auto pin =
      std::make_optional(node.ProtectObject(node.Objects(), a, 0, 8 * u));
  Durable(node.RemoveObject(node.Objects(), a));
  Durable(node.RemoveObject(node.Objects(), b));
  const auto d = New(node, 4);
  ASSERT_NO_FATAL_FAILURE(EventuallyWrite(node, d, big));
  EXPECT_EQ(Read(node, c, small.size()), small);
  EXPECT_EQ(Read(node, d, big.size()), big);
  const auto e = New(node, 5);
  auto blocked = Write(node, e, last);
  EXPECT_EQ(blocked.outcome_, JournalOutcome::NotCommitted);
  ASSERT_TRUE(blocked.error_);
  try {
    std::rethrow_exception(blocked.error_);
  } catch (const AllocationError &x) {
    EXPECT_EQ(x.Code(), AllocationErrorCode::NoSpace);
  }
  pin.reset();
  ASSERT_NO_FATAL_FAILURE(EventuallyWrite(node, e, last));
  node.Close();
  node.Open();
  EXPECT_EQ(Read(node, c, small.size()), small);
  EXPECT_EQ(Read(node, d, big.size()), big);
  EXPECT_EQ(Read(node, e, last.size()), last);
  node.Close();
}
} // namespace
