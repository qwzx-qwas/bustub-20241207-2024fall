#include "integration_test.cpp"
namespace {
std::mutex sync_mutex;
std::condition_variable sync_changed;
bool sync_armed=false, sync_entered=false, sync_release=false, sync_error=false;
struct SyncGate {
  explicit SyncGate(bool error) { std::lock_guard lock(sync_mutex); sync_armed=true;sync_entered=false;sync_release=false;sync_error=error; }
  ~SyncGate() { Release(); }
  void Release() { std::lock_guard lock(sync_mutex);sync_release=true;sync_armed=false;sync_changed.notify_all(); }
  bool Entered() { std::unique_lock lock(sync_mutex);return sync_changed.wait_for(lock,10s,[]{return sync_entered;}); }
};
}
extern "C" int __real_fdatasync(int);
extern "C" int __wrap_fdatasync(int fd) {
  if (fcntl(fd,F_GETFL)&O_DIRECT) {
    std::unique_lock lock(sync_mutex);
    if(sync_armed) {
      sync_armed=false;sync_entered=true;sync_changed.notify_all();
      sync_changed.wait(lock,[]{return sync_release;});
      if(sync_error) { errno=EIO;return -1; }
    }
  }
  return __real_fdatasync(fd);
}
namespace {
struct RetiredStore {
  Image image;
  NodeStorageOptions options{Options(image)};
  std::shared_ptr<NodeStorage> node{std::make_shared<NodeStorage>(options)};
  std::shared_ptr<RaftObjectStorage> store;
  std::unique_ptr<LogStore> logs;
  uint64_t space;
  const RaftObjectOptions limits{1024,1024,MIB,1024,8,8192,MIB,4};
  RetiredStore() {
    node->Create(Layout(options));node->InitializeObjects();
    auto c=node->CreateObjectSpace(node->Objects());Durable(c.result_);space=*c.space_;
    store=RaftObjectStorage::Create(node,space,limits);logs=LogStore::OpenObjects(store,0,0,0);
    logs->Append({{1,1,3,EntryType::COMMAND_BATCH,Value(400,83)}});logs->InstallSnapshotBase(1,3,false);
  }
  void Schedule() { std::weak_ptr<RaftObjectStorage> weak=store;
    node->SetStoreMaintenance([weak]{if(auto owner=weak.lock()) owner->Collect(1);}); }
};
TEST(S12Integration, CloseDrainsAcceptedStoreIOBeforeDisablingItsStorageCalls) {
  RetiredStore h;
  std::future<void> closed;
  SyncGate gate(false);h.Schedule(); ASSERT_TRUE(gate.Entered());
  closed=std::async(std::launch::async,[&]{h.node->Close();});
  EXPECT_EQ(closed.wait_for(20ms),std::future_status::timeout);
  gate.Release();ASSERT_EQ(closed.wait_for(10s),std::future_status::ready);EXPECT_NO_THROW(closed.get());
  h.logs.reset();h.store.reset();h.node->Open();
  h.store=RaftObjectStorage::Open(h.node,h.space,h.limits);
  h.logs=LogStore::OpenObjects(h.store,1,1,3);
  const auto expected=Value(700,149);h.logs->Append({{1,2,3,EntryType::COMMAND_BATCH,expected}});
  EXPECT_EQ(h.logs->EntryAt(2)->payload_,expected);h.node->Close();
}
TEST(S12Integration, RealMaintenanceDurabilityFailureIsPublishedAndCanStillDetach) {
  RetiredStore h;SyncGate gate(true);h.Schedule();ASSERT_TRUE(gate.Entered());gate.Release();
  const auto deadline=std::chrono::steady_clock::now()+10s;
  while(!h.node->State().error_ && std::chrono::steady_clock::now()<deadline)
    std::this_thread::sleep_for(2ms);
  ASSERT_TRUE(h.node->State().error_) << "real maintenance IO failure was swallowed as pressure";
  try { std::rethrow_exception(h.node->State().error_); }
  catch (const std::system_error &e) { EXPECT_EQ(e.code().value(),EIO); }
  catch (...) { FAIL() << "maintenance did not preserve the device error"; }
  EXPECT_NO_THROW(h.node->SetStoreMaintenance({}));
  try { h.node->Close(); } catch (const std::exception &) { /* error already required above */ }
}
} // namespace
