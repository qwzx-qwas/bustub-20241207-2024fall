// Reuse the five existing resource scenarios, do not duplicate their fixtures/oracles.
#include "resource_gc_test.cpp"
#include "buffer/buffer_pool_manager.h"
#include "buffer/translation_directory.h"
#include "raft/log_store.h"
#include "raft/object_storage.h"
#include "raft/tcp_transport.h"
#include "snapshot_tasks.h"
#include <future>
namespace {
TEST(S12Integration, ObjectPageFramesShareBudgetAndGuardsKeepTheirMemory) {
  Image image;
  auto o = Options(image);
  o.external_buffer_bytes_ = 2 * MIB;
  o.memory_budget_ = ResourceBudgetOptions{2 * MIB, 16384, MIB / 2};
  auto node = std::make_shared<NodeStorage>(o);
  node->Create(Layout(o)); node->InitializeObjects();
  const auto space = node->CreateObjectSpace(node->Objects()); Durable(space.result_);
  auto pages = ObjectPageStorage::Create(node, {16, {*space.space_, 5}});
  BufferPoolOptions cache{MIB, 2 * MIB, 4, false, 0, node->MemoryBudget()};
  auto pool = std::make_unique<BufferPoolManager>(256, pages, cache);
  const auto p = pool->NewPage();
  const auto expected = Value(BUSTUB_PAGE_SIZE, 91);
  { auto w = pool->WritePage(p); std::memcpy(w.GetDataMut(), expected.data(), expected.size()); }
  ASSERT_TRUE(pool->FlushPage(p));
  auto held = pool->ReadPage(p);
  EXPECT_THROW((BufferPoolManager(256, pages, cache)), std::bad_alloc);
  pool.reset();
  EXPECT_EQ(std::memcmp(held.GetData(), expected.data(), expected.size()), 0);
  EXPECT_THROW((BufferPoolManager(256, pages, cache)), std::bad_alloc);
  held.Drop();
  { BufferPoolManager restored(256, pages, cache);
    const auto r = restored.ReadPage(p);
    EXPECT_EQ(std::memcmp(r.GetData(), expected.data(), expected.size()), 0); }
  pages.reset(); node->Close();
}
TEST(S12Integration, SparseDirectoryCompetesWithIOAndReturnsMemoryAfterLastAccess) {
  Image image; BlockDevice dev(image.path, {});
  const auto u = Unit(dev);
  ASSERT_LE(u, 16384U);
  auto memory = std::make_shared<ResourceBudget>(ResourceBudgetOptions{128 * 1024, 4096, 0});
  IOExecutor io(dev, {2, 32, MIB, memory});
  auto directory = std::make_unique<TranslationDirectory>(TranslationDirectoryOptions{MIB, memory});
  size_t entries = 0;
  bool full = false;
  for (; entries < 32; ++entries) {
    try { auto e = directory->Access(static_cast<page_id_t>((entries + 1) << 16)); e.SetFrame(entries + 7); }
    catch (const std::bad_alloc &) { full = true; break; }
  }
  ASSERT_TRUE(full) << "sparse translation allocations escaped the shared budget";
  ASSERT_GT(entries, 0U);
  for (size_t i = 0; i < entries; ++i) {
    auto e = directory->Access(static_cast<page_id_t>((i + 1) << 16));
    EXPECT_EQ(e.Frame(), std::optional<frame_id_t>(i + 7));
  }
  auto held = std::make_unique<TranslationAccess>(directory->Access(1 << 16));
  directory.reset();
  EXPECT_EQ(io.TryPrepare(Requests(1, 4 * u), true).admission_, IOAdmission::Full);
  held.reset();
  auto reclaimed = io.TryPrepare(Requests(1, 4 * u), true);
  ASSERT_EQ(reclaimed.admission_, IOAdmission::Accepted);
  const auto expected = Value(4 * u, 177);
  std::memcpy(reclaimed.batch_->Buffer(0), expected.data(), expected.size());
  Execute(io, *reclaimed.batch_); reclaimed.batch_.reset(); CheckBytes(io, 0, expected);
}
TEST(S12Integration, SnapshotResultRetainsCreditsAfterWorkerAndExecutorExit) {
  Image image; BlockDevice dev(image.path, {});
  const auto u = Unit(dev), size = 16 * u;
  ASSERT_LE(size, 65536U);
  auto memory = std::make_shared<ResourceBudget>(ResourceBudgetOptions{384 * 1024, 4096, 0});
  IOExecutor io(dev, {2, 32, MIB, memory});
  const auto expected = Value(size, 113);
  { auto w = io.TryPrepare(Requests(1, size), true);
    ASSERT_EQ(w.admission_, IOAdmission::Accepted);
    std::memcpy(w.batch_->Buffer(0), expected.data(), size); Execute(io, *w.batch_); }
  auto work = [&] {
    auto r = io.TryPrepare(Requests(1, size, 0, IOOperation::Read), false);
    Require(r.admission_ == IOAdmission::Accepted, "snapshot source read admission");
    Execute(io, *r.batch_, false);
    InstallSnapshotRequest out;
    out.data_.assign(reinterpret_cast<const std::byte *>(r.batch_->Buffer(0)),
                     reinterpret_cast<const std::byte *>(r.batch_->Buffer(0)) + size);
    return out;
  };
  std::shared_ptr<InstallSnapshotRequest> held;
  { SnapshotTasks tasks(memory); auto first = tasks.Submit(work); ASSERT_TRUE(first);
    ASSERT_EQ(first->wait_for(10s), std::future_status::ready); held = first->get();
    EXPECT_EQ(held->data_, expected);
    EXPECT_FALSE(tasks.Submit(work)) << "finished result released live snapshot credits"; }
  SnapshotTasks next(memory);
  EXPECT_FALSE(next.Submit(work));  // Original worker is gone; the result still owns bytes.
  held.reset();
  auto again = next.Submit(work); ASSERT_TRUE(again);
  ASSERT_EQ(again->wait_for(10s), std::future_status::ready);
  EXPECT_EQ(again->get()->data_, expected);
}
TEST(S12Integration, TCPPressureDropsWorkThenDeliversTheOriginalSnapshotBytes) {
  Image image; BlockDevice dev(image.path, {});
  const auto u = Unit(dev), q = u + dev.Info().memory_alignment_ - 1;
  auto memory = std::make_shared<ResourceBudget>(ResourceBudgetOptions{2 * MIB, 4096, 0});
  IOExecutor io(dev, {2, 4096, 4 * MIB, memory});
  TcpRaftTransport receiver(2, "s12-memory", {"127.0.0.1", 0}, {{1, {"127.0.0.1", 1}}}, 250, 8, memory);
  std::mutex mutex; std::condition_variable changed; std::optional<Bytes> received;
  receiver.Start([&](RaftEnvelope e) {
    if (const auto *r = std::get_if<InstallSnapshotRequest>(&e.message_)) {
      std::lock_guard lock(mutex); received = r->data_; changed.notify_all();
    }
  });
  TcpRaftTransport sender(1, "s12-memory", {"127.0.0.1", 0}, {{2, receiver.ListenEndpoint()}}, 250, 8, memory);
  sender.Start([](RaftEnvelope) {});
  struct Stop { TcpRaftTransport &a, &b; ~Stop(){a.Stop();b.Stop();} } stop{sender,receiver};
  auto occupied = io.TryPrepare(Requests((2 * MIB) / q - 1, u), false);
  ASSERT_EQ(occupied.admission_, IOAdmission::Accepted);
  InstallSnapshotRequest request;
  request.term_=1; request.leader_id_=1; request.request_id_=7; request.snapshot_id_="s12-nonempty";
  request.last_included_index_=9; request.last_included_term_=1;
  request.data_=Value(65536, 237); request.total_size_=request.data_.size(); request.done_=true;
  const auto expected = request.data_;
  sender.Send({1, 2, request, "s12-memory"});
  EXPECT_EQ(sender.DroppedMessages(), 1U);
  occupied.batch_.reset();
  sender.Send({1, 2, request, "s12-memory"});
  { std::unique_lock lock(mutex); ASSERT_TRUE(changed.wait_for(lock, 10s, [&] { return received.has_value(); }));
    EXPECT_EQ(*received, expected); }
  sender.Stop(); receiver.Stop();
}
TEST(S12Integration, StoreCollectionWaitsForItsSlotAndUsesProgressMemoryAcrossThreads) {
  Image image; auto o = Options(image);
  o.memory_budget_=ResourceBudgetOptions{4 * MIB, 16384, 2 * MIB};
  auto node=std::make_shared<NodeStorage>(o); node->Create(Layout(o)); node->InitializeObjects();
  auto creation=node->CreateObjectSpace(node->Objects()); Durable(creation.result_);
  const auto space=*creation.space_;
  RaftObjectOptions limits{1024,1024,MIB,1024,8,8192,MIB,4};
  auto store=RaftObjectStorage::Create(node,space,limits);
  auto logs=LogStore::OpenObjects(store,0,0,0);
  const auto body=Value(1500,171);
  logs->Append({{1,1,3,EntryType::COMMAND_BATCH,body}});
  logs->InstallSnapshotBase(1,3,false);
  std::vector<ObjectTransactionTicket> held;
  for (size_t i=0; i<o.transactions_->max_requests_; ++i) {
    ObjectTransaction control{{}, {{{space,9}, i+16, Value(64,29+i)}}};
    auto accepted=node->SubmitObjects(control);
    ASSERT_EQ(accepted.admission_,IOAdmission::Accepted);
    accepted.ticket_->Wait(); Durable(accepted.ticket_->Result());
    held.push_back(std::move(*accepted.ticket_));
  }
  ObjectTransaction maintenance{{}, {{{space,9}, 2, Value(64,31)}}};
  ObjectTransactionSubmission reserved;
  { ProgressWork progress(true); reserved=node->SubmitObjects(maintenance); }
  ASSERT_EQ(reserved.admission_,IOAdmission::Accepted); reserved.ticket_->Wait(); Durable(reserved.ticket_->Result());
  EXPECT_NO_THROW(EXPECT_EQ(store->Collect(8),0U));  // Busy yields the bounded turn, including direct callers.
  std::atomic<size_t> rounds{0}, removed{0};
  node->SetStoreMaintenance([&] { ++rounds; removed += store->Collect(1); });
  struct Detach { std::shared_ptr<NodeStorage> node; ~Detach(){ node->SetStoreMaintenance({}); } } detach{node};
  const auto deadline=std::chrono::steady_clock::now()+10s;
  while(rounds<12 && std::chrono::steady_clock::now()<deadline) std::this_thread::sleep_for(2ms);
  ASSERT_GE(rounds.load(),12U); EXPECT_EQ(removed.load(),0U);
  EXPECT_FALSE(node->State().object_error_); EXPECT_FALSE(node->State().error_);
  // Real IO buffers occupy ordinary memory; completion must use the reserved lane
  // in Submit, Drive and metadata Commit, not merely in the Store caller thread.
  BlockDevice dev(image.path,{}); const auto u=Unit(dev);
  IOExecutor io(dev,{2,4096,4*MIB,node->MemoryBudget()});
  std::vector<IOBatch> buffers;
  for (;;) { auto r=io.TryPrepare(Requests(1,u),false); if(r.admission_==IOAdmission::Full) break;
    ASSERT_EQ(r.admission_,IOAdmission::Accepted); buffers.push_back(std::move(*r.batch_)); }
  reserved.ticket_.reset();
  while(removed<2 && std::chrono::steady_clock::now()<deadline) std::this_thread::sleep_for(2ms);
  EXPECT_EQ(removed.load(),2U) << "Store could not retire under ordinary pressure";
  node->SetStoreMaintenance({});
  EXPECT_FALSE(node->State().object_error_);
  buffers.clear(); held.clear();
  logs->Append({{1,2,3,EntryType::COMMAND_BATCH,body}});
  EXPECT_EQ(logs->EntryAt(2)->payload_,body);
  logs.reset(); store.reset(); node->Close(); node->Open();
  store=RaftObjectStorage::Open(node,space,limits); logs=LogStore::OpenObjects(store,1,1,3);
  EXPECT_EQ(logs->EntryAt(2)->payload_,body);
  logs.reset();store.reset();node->Close();
}
} // namespace
namespace {
TEST(S12Integration, CapturedDirtyPagesKeepTheirOwnCreditsAfterCacheClose) {
  Image image;BlockDevice dev(image.path,{});const auto u=Unit(dev);
  auto budget=std::make_shared<ResourceBudget>(ResourceBudgetOptions{768*1024,4096,0});
  DiskManager disk(image.path);
  BufferPoolOptions options{MIB,MIB,4,false,0,budget};
  auto pool=std::make_unique<BufferPoolManager>(128,FilePageStorage(&disk),options);
  std::vector<page_id_t> ids;
  std::map<page_id_t,Bytes> contents;
  for(int i=0;i<8;++i) { const auto p=pool->NewPage();ids.push_back(p);auto w=pool->WritePage(p);
    auto bytes=Value(BUSTUB_PAGE_SIZE,i+3);contents.emplace(p,bytes);std::memcpy(w.GetDataMut(),bytes.data(),bytes.size()); }
  std::optional<PageCapture> saved(pool->CapturePages(ids,MIB));
  pool.reset();
  for(const auto &page:saved->dirty_) { const auto &expected=contents.at(page.page_);
    EXPECT_EQ(std::memcmp(page.bytes_.data(),expected.data(),expected.size()),0); }
  ASSERT_EQ(saved->dirty_.size(),8U);
  IOExecutor io(dev,{2,16,MIB,budget});
  const auto size=(768*1024/u-2)*u;
  EXPECT_EQ(io.TryPrepare(Requests(1,size),true).admission_,IOAdmission::Full);
  saved.reset();
  auto usable=io.TryPrepare(Requests(1,size),true);ASSERT_EQ(usable.admission_,IOAdmission::Accepted);
  auto expected=Value(size,73);std::memcpy(usable.batch_->Buffer(0),expected.data(),expected.size());
  Execute(io,*usable.batch_);usable.batch_.reset();CheckBytes(io,0,expected);
}
}
