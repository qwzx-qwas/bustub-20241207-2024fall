#!/usr/bin/env python3
"""S12 integration through real IO/Node APIs; dependencies reused unchanged."""
import argparse, pathlib, subprocess, tarfile, os, json, time, signal, resource
import xml.etree.ElementTree as ET
resource.setrlimit(resource.RLIMIT_CORE, (0,0))
p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--build',required=True);p.add_argument('--out',required=True);p.add_argument('--regressions',action='store_true');p.add_argument('--mutations',action='store_true')
a=p.parse_args();repo=pathlib.Path(a.repo).resolve();build=pathlib.Path(a.build).resolve();out=pathlib.Path(a.out).resolve();pkg=pathlib.Path(__file__).resolve().parent
if (pkg/'MANIFEST.json').exists():
 import hashlib
 manifest=json.loads((pkg/'MANIFEST.json').read_text())
 for base,key in [(repo,'production_sha256'),(repo,'dependency_sha256'),(pkg,'test_sha256')]:
  for name,digest in manifest[key].items():
   if hashlib.sha256((base/name).read_bytes()).hexdigest()!=digest:raise SystemExit('source mismatch: '+str(base/name))
out.mkdir(parents=True,exist_ok=False)
for name in ['S5-journal-recycling','F27-deferred','F19-common-pipeline','F26-array-buffer-pool']:
 with tarfile.open(repo/f'test/archives/{name}.tar.gz') as t:t.extractall(out,filter='data')
env={k:v for k,v in os.environ.items() if not k.startswith('GTEST_')};env.update(S5_WORKDIR=str(out),ASAN_OPTIONS='detect_leaks=0:abort_on_error=1')
flags=['clang++-14','-std=c++17','-pthread','-g','-O0','-Wall','-Wextra','-Werror','-Wno-unused-parameter','-Wno-attributes','-fsanitize=address','-fno-omit-frame-pointer','-fno-pie']
flags+=['-I'+str(x) for x in [out,repo/'src/include',repo/'src/buffer',repo/'src/storage/disk',repo/'src/raft',repo/'third_party',repo/'third_party/libfort/src',repo/'third_party/fmt/include',out/'S5-journal-recycling/test/storage_redesign']]
flags+=['-isystem',str(repo/'third_party/googletest/googletest/include')]
libs=[build/'lib'/('lib'+n+'.a') for n in ['bustub','bustub_lz4','bustub_murmur3','duckdb_pg_query','fmtd','fort','gmock_main','gmock','gtest']]
commands=[];counts={};evidence=[]
def run(cmd,name,expected=0,timeout=180):
 start=time.monotonic()
 with (out/(name+'.log')).open('w') as f:
  with subprocess.Popen(list(map(str,cmd)),cwd=repo,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True) as r:
   try:r.wait(timeout=timeout)
   except subprocess.TimeoutExpired:
    os.killpg(r.pid,signal.SIGKILL);r.wait();raise
 commands.append(dict(command=list(map(str,cmd)),exit=r.returncode,seconds=time.monotonic()-start,log=name+'.log'));(out/'commands.json').write_text(json.dumps(commands,indent=2))
 if r.returncode!=expected:raise RuntimeError((name,r.returncode,expected))
def check(name,count,failed=False):
 cases=ET.parse(out/(name+'.xml')).getroot().findall('.//testcase')
 assert len(cases)==count and all(c.attrib.get('status')=='run' and c.find('skipped') is None and c.find('error') is None for c in cases),(name,'coverage')
 failures=[f.text or '' for c in cases for f in c.findall('failure')]
 assert bool(failures)==failed,(name,failures)
 if not failed:counts[name]=count
 return failures
def suite(name,source,count,wrap=[]):
 run(flags+['-c',source,'-o',out/(name+'.o')],name+'-compile')
 run(flags+['-no-pie',out/(name+'.o')]+libs+wrap+['-o',out/name],name+'-link')
 run([out/name,'--gtest_output=xml:'+str(out/(name+'.xml'))],name);check(name,count)
suite('resource-gc',pkg/'tests/resource_gc_test.cpp',5)
if a.regressions:
 wrap=['-Wl,--wrap=pread','-Wl,--wrap=pwrite','-Wl,--wrap=fdatasync']
 # Same twelve workloads; configure the new production budget at deployment.
 src=(out/'F27-deferred/tests/deferred_test.cpp').read_text()
 old='  auto o = Options(image);';assert src.count(old)==12
 src=src.replace(old,old+'\n  o.memory_budget_ = ResourceBudgetOptions{32*MIB,64*1024,4*MIB};\n  o.io_.progress_operations_ = 32;\n  o.io_.progress_buffer_bytes_ = 2*MIB;')
 # Preserve the special case's original ordinary capacity; reserve is extra.
 old_limit='o.io_.max_buffer_bytes_ = 64 * u;';assert src.count(old_limit)==1
 src=src.replace(old_limit,'o.io_.max_buffer_bytes_ = 64 * u + o.io_.progress_buffer_bytes_;')
 (out/'deferred-budgeted.cpp').write_text(src)
 suite('deferred',pkg/'tests/deferred_pressure_test.cpp',14,wrap)
 suite('common',out/'F19-common-pipeline/tests/transaction_test.cpp',10,wrap)
 suite('pages',out/'F26-array-buffer-pool/tests/page_io_test.cpp',9,wrap+['-Wl,--wrap=madvise'])
 suite('lru-k',repo/'test/buffer/lru_k_replacer_test.cpp',1)
if a.mutations:
 changes=[
 ('ignore-owned-ram','io_executor.cpp','if (!memory_->Reserve(bytes, progress)) {', 'if (false && !memory_->Reserve(bytes, progress)) {', 'OwnersShareRAMButBorrowingDoesNotChargeItTwice'),
 ('ignore-progress-slots','io_executor.cpp','if (!progress && (operations > options_.max_operations_', 'if (false && !progress && (operations > options_.max_operations_', 'OrdinaryWorkCannotConsumeCompletionSlots'),
 ('lost-memory-cause','io_executor.cpp','shared_memory_limited = true;', 'shared_memory_limited = false;', 'OwnersShareRAMButBorrowingDoesNotChargeItTwice'),
 ('oversize-as-full','io_executor.cpp','if (!memory_->Reserve(bytes, progress)) {\n      shared_memory_limited = true;\n      return false;\n    }', 'try {\n      if (!memory_->Reserve(bytes, progress)) { shared_memory_limited = true; return false; }\n    } catch (const std::invalid_argument &) { return false; }', 'OwnersShareRAMButBorrowingDoesNotChargeItTwice'),
 ('disable-gc','object_transaction.cpp','const auto candidate = page.candidates_[next++];','continue; const auto candidate = page.candidates_[next++];','PinnedGarbageDoesNotStarveOtherReclaimAndReuse')]
 # First mutation must bypass Release too: it simulates loss of the entire
 # owner accounting connection, not invalid counter arithmetic/abort.
 for name,file,old,new,test in changes:
  source=(repo/'src/storage/disk'/file).read_text();assert source.count(old)==1,(name,'anchor')
  source=source.replace(old,new)
  if name=='ignore-owned-ram':source=source.replace('memory_->Release(bytes, progress);','/* mutated: no owner charge */')
  path=out/(name+'.cpp');path.write_text(source)
  run(flags+['-c',path,'-o',out/(name+'.o')],name+'-compile')
  run(flags+['-no-pie',out/'resource-gc.o',out/(name+'.o')]+libs+['-o',out/name],name+'-link')
  run([out/name,'--gtest_filter=S12Resources.'+test,'--gtest_output=xml:'+str(out/(name+'.xml'))],name,1)
  failures=check(name,1,True)
  marker={'ignore-owned-ram':'a.TryPrepare', 'ignore-progress-slots':'slots_full.admission_', 'disable-gc':'background reclaim did not make space', 'lost-memory-cause':'denied.shared_memory_limited_', 'oversize-as-full':'throws an exception of type std::invalid_argument'}[name]
  assert any(marker in failure for failure in failures),(name,'wrong failure',failures)
  evidence.append(dict(name=name,test=test,failures=failures))
  (out/'mutations.json').write_text(json.dumps(evidence,indent=2))
 if a.regressions:
  for name in ['pressure-is-fatal', 'retain-writeback-body']:
   source=(repo/'src/storage/disk/object_transaction.cpp').read_text()
   if name=='pressure-is-fatal':
    # Restore the former terminal classification at both exception boundaries.
    old='if (e.Code() != MetadataErrorCode::ResourceUnavailable) throw;';assert source.count(old)==1
    source=source.replace(old,'throw;')
    old='if (e.Code() != MetadataErrorCode::ResourceUnavailable) {';assert source.count(old)==1
    source=source.replace(old,'if (true) {')
   else:
    # Extend the decoded body's lifetime through completion retry, without
    # breaking its actual accounting or changing the successful IO result.
    old='            io_.FinishCommon(&done);\n          }';assert source.count(old)==1
    source=source.replace(old,'            io_.FinishCommon(&done);')
    old='        }\n      } catch (const JournalError &e) {';assert source.count(old)==1
    source=source.replace(old,'          }\n'+old)
   path=out/(name+'.cpp');path.write_text(source)
   run(flags+['-c',path,'-o',out/(name+'.o')],name+'-compile')
   run(flags+['-no-pie',out/'deferred.o',out/(name+'.o')]+libs+['-Wl,--wrap=pread','-Wl,--wrap=pwrite','-Wl,--wrap=fdatasync','-o',out/name],name+'-link')
   test='S12Deferred.CompletionWaitsForRAMWithoutDroppingDurableTask'
   run([out/name,'--gtest_filter='+test,'--gtest_output=xml:'+str(out/(name+'.xml'))],name,1)
   failures=check(name,1,True)
   markers=['shared metadata memory exhausted','node.State().error_','object IO is unavailable','ordinary object storage is not ready','error.Code()'] if name=='pressure-is-fatal' else ['durable Data retained dead writeback memory']
   assert any(marker in f for marker in markers for f in failures),(name,failures)
   evidence.append(dict(name=name,test=test,failures=failures))
   (out/'mutations.json').write_text(json.dumps(evidence,indent=2))
 if a.regressions:
  name='reference-busy-as-resource'
  source=(repo/'src/storage/disk/object_reference.cpp').read_text()
  old='ReferenceFail(ObjectReferenceErrorCode::Busy, "object reference operation budget full");'
  assert source.count(old)==1
  source=source.replace(old,'Fail(ObjectMappingErrorCode::ResourceUnavailable, "object reference operation budget full");')
  path=out/(name+'.cpp');path.write_text(source)
  run(flags+['-c',path,'-o',out/(name+'.o')],name+'-compile')
  run(flags+['-no-pie',out/'deferred.o',out/(name+'.o')]+libs+['-Wl,--wrap=pread','-Wl,--wrap=pwrite','-Wl,--wrap=fdatasync','-o',out/name],name+'-link')
  test='S12Reclaim.ActiveOperationLimitReturnsBusyAndRecovers'
  run([out/name,'--gtest_filter='+test,'--gtest_output=xml:'+str(out/(name+'.xml'))],name,1)
  failures=check(name,1,True)
  assert any('temporary reference admission must report Busy' in f for f in failures),(name,failures)
  evidence.append(dict(name=name,test=test,failures=failures))
  (out/'mutations.json').write_text(json.dumps(evidence,indent=2))
(out/'summary.json').write_text(json.dumps(dict(passed=counts,mutations=evidence,sanitizer='address',scope='Direct file IO/Node integration; no performance or power-loss claim'),indent=2))
print(counts,flush=True)
