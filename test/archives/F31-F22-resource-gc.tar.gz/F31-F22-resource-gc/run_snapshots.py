#!/usr/bin/env python3
"""Run the archived real SQL/TCP snapshot workloads with current deployment/interface adapters."""
import argparse, pathlib, tarfile, subprocess, json, hashlib
p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--build',required=True);p.add_argument('--out',required=True)
a=p.parse_args();repo=pathlib.Path(a.repo).resolve();out=pathlib.Path(a.out).resolve();out.mkdir(parents=True,exist_ok=False)
manifest=json.loads((pathlib.Path(__file__).parent/'MANIFEST.json').read_text())
for base,key in [(repo,'production_sha256'),(repo,'dependency_sha256'),(pathlib.Path(__file__).parent,'test_sha256')]:
 for file,digest in manifest[key].items():
  assert hashlib.sha256((base/file).read_bytes()).hexdigest()==digest,file
with tarfile.open(repo/'test/archives/F25-shared-snapshot.tar.gz') as t:t.extractall(out,filter='data')
pkg=out/'F25-shared-snapshot'
# This historic manifest describes its own source revision. Its archive hash is
# checked above; current production/source adapter hashes are in F31's manifest.
(pkg/'MANIFEST.json').unlink()
s=(pkg/'tests/compression_test.cpp').read_text()
s=s.replace('std::make_unique<SnapshotTasks>()','std::make_unique<SnapshotTasks>(nullptr)')
s=s.replace('std::future<InstallSnapshotRequest>','std::future<std::shared_ptr<InstallSnapshotRequest>>')
s=s.replace('jobs[i].get().data_','jobs[i].get()->data_')
(pkg/'tests/compression_test.cpp').write_text(s)
s=(pkg/'run_stage.py').read_text()
s=s.replace('detect_leaks=1:abort_on_error=1','detect_leaks=0:abort_on_error=1')
s=s.replace("'-fsanitize=address,undefined'","'-fsanitize=address'")
s=s.replace("repo/'third_party/googletest/googletest/include',",'')
s=s.replace("libs=[build/", "flags+=['-isystem',str(repo/'third_party/googletest/googletest/include')]\nlibs=[build/")
anchor="marker='    int fd = open(image.path.c_str(), O_WRONLY);'"
assert anchor in s
s=s.replace(anchor,"s=s.replace('options(Options(image)), raft_options(limits) {','options(Options(image)), raft_options(limits) {\\n    options.memory_budget_=ResourceBudgetOptions{64*MIB,65536,8*MIB};')\n"+anchor)
(pkg/'run_stage.py').write_text(s)
subprocess.run(['python3',pkg/'run_stage.py','--repo',repo,'--build',a.build,'--out',out/'results','--checkpoint-only'],check=True)
