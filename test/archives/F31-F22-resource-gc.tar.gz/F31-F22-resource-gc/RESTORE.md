# F31/F22 S12.1 恢复

仅阶段源码，未注册常驻测试。必须先阅读 docs/storage_redesign/s12_execution_20261007.md 的范围与限制。

1. 在隔离源码树检出 MANIFEST 的 base_commit。结果包 `source/` 保存本轮改变的源文件，覆盖隔离基准树；不能覆盖有其他修改的工作区。核对 production_sha256 和全部 dependency_sha256。当前工作树已相同时不重复覆盖。
2. 将本源码包解压到仓库外。构建与测试输出也放在隔离目录：

```bash
cmake -S "$stage_repo" -B "$stage_build" \
  -DCMAKE_C_COMPILER=clang-14 -DCMAKE_CXX_COMPILER=clang++-14 \
  -DCMAKE_BUILD_TYPE=Debug -DBUSTUB_SANITIZER=address
cmake --build "$stage_build" --target bustub gmock_main -j 4
python3 "$stage_tests/F31-F22-resource-gc/run_stage.py" \
  --repo "$stage_repo" --build "$stage_build" --out "$stage_output" \
  --regressions --mutations
```

变量均由调用者设为明确绝对目录；out 必须尚不存在。需 Linux 文件 Direct IO 支持，夹具查询实际对齐并检查 8 MiB 文件预算；不硬编码生产对齐。

runner 校验归档源摘要、逐条记录命令、检查 XML 执行数/断言和变异目标；正常场景 39、变异 8。发生超时终止该命令进程组，不能计通过。模块不重复存储原 F27/F19/F26/S5 测试正文，按依赖哈希解压复用。F27 只适配部署，另一个测试文件复用原暂停门来验证真实完成压力及引用操作暂满。

阶段包的源码/预算/风险可由后续生产 E2E 接管；跨模块验证应沿用业务输入和独立判据，调整适配层。旧生产源摘要不同不能直接沿用此轮结果。不要把阶段预留名额检查扩散为每层计数/编码测试。

最终 ASan 启用，detect_leaks=0（此沙箱 LeakSanitizer 不支持进程跟踪环境）；无 TSan、性能、裸设备、真实断电结论。
