# F31/F22 S12.1＋S12.2 恢复

模块阶段源码，不注册常驻测试。当前范围与八项审查：`docs/storage_redesign/s12_integration_execution_20261008.md`；S12.1 的旧场景仍保留于同包。

1. 在隔离源码树检出 MANIFEST 的 base_commit。结果包 `source/` 保存本轮生产文件，覆盖隔离基准树；不得覆盖其他未提交工作。核对 production_sha256 和 dependency_sha256。若现有工作树完全匹配则不重复覆盖。
2. 源码包解压到仓库外；构建和输出同样在隔离目录。各 out 必须尚不存在：

```bash
cmake -S "$stage_repo" -B "$stage_build" \
  -DCMAKE_C_COMPILER=clang-14 -DCMAKE_CXX_COMPILER=clang++-14 \
  -DCMAKE_BUILD_TYPE=Debug -DBUSTUB_SANITIZER=address
cmake --build "$stage_build" --target bustub gmock_main -j 4
python3 "$stage_tests/F31-F22-resource-gc/run_stage.py" \
  --repo "$stage_repo" --build "$stage_build" --out "$stage_output" \
  --regressions --mutations
python3 "$stage_tests/F31-F22-resource-gc/run_snapshots.py" \
  --repo "$stage_repo" --build "$stage_build" --out "$snapshot_output"
```

变量设为明确绝对目录。需要 Linux 文件 Direct IO 和可绑定 loopback 端口的环境，设备对齐实际查询。runner 记录命令，清除外部 GTEST 过滤器，检查 XML 场景数、未跳过、退出码和 mutation 的目标断言；超时不能计通过。第二 runner 复用 F25 原输入/SQL/恢复判据，只适配部署与新结果所有权接口；源依赖由外层 manifest 验证，不拿旧模块生产哈希套到新生产代码。

预期：第一 runner 47 正常＋13 个指定 mutation；第二 runner 35 正常，总计 82。新增 8 场景，原 S12.1 39 及 Store/checkpoint/快照 35 复用。源码包只保存新增场景和适配 runner，不重复存依赖模块的测试正文。正常期望成功，变异期望特定失败；编译错误、任意崩溃或环境失败不能记为检出。

当前最终使用 AddressSanitizer，detect_leaks=0；没有 TSan、性能或真实掉电结论。目录名沿用原 S12.1，源码/结果原位换代，无前版备用包。后续完整生产 E2E 接管相同风险后，简化/合并阶段证据；共同 C/P 和 SS/RS/PL/GT 不因这些阶段验证而算完成。
