#!/usr/bin/env python3
"""Compile isolated broken production objects; never edit the repository or its library."""
import pathlib,subprocess,json,argparse,os,signal,time,xml.etree.ElementTree as ET
p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--baseline',required=True);p.add_argument('--out',required=True);p.add_argument('--only',nargs='*');a=p.parse_args()
repo=pathlib.Path(a.repo).resolve();base=pathlib.Path(a.baseline).resolve();out=pathlib.Path(a.out).resolve();out.mkdir(parents=True,exist_ok=False)
commands=json.loads((base/'commands.json').read_text());compile_cmd=next(c['command'] for c in commands if c['log']=='checkpoint-compile.log');link_cmd=next(c['command'] for c in commands if c['log']=='checkpoint-link.log')
env={k:v for k,v in os.environ.items() if not k.startswith('GTEST_')};env.update(S5_WORKDIR=str(out),ASAN_OPTIONS='detect_leaks=1:abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
results=[];calls=[]
def run(cmd,name,expected):
 start=time.monotonic()
 with (out/(name+'.log')).open('w') as log:
  with subprocess.Popen(cmd,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True) as process:
   try:process.wait(timeout=120)
   except subprocess.TimeoutExpired:
    os.killpg(process.pid,signal.SIGKILL);process.wait();raise
 calls.append(dict(command=cmd,exit=process.returncode,seconds=time.monotonic()-start,log=name+'.log'));(out/'commands.json').write_text(json.dumps(calls,indent=2))
 if process.returncode!=expected:raise RuntimeError((name,process.returncode,expected))
full='S11Checkpoint.'
ref=(repo/'src/storage/disk/object_reference.cpp').read_text();start=ref.index('    // Persistent checkpoint/fork references');stop=ref.index('    pinned = Merge',start)
mutations=[
 ('ignore-persistent-sharing','src/storage/disk/object_reference.cpp',ref[start:stop],'    // broken: ignore durable shared ownership\n','SharedJournalContentSurvivesOwnerRetirementRestartAndFinalRelease','kept.released_bytes_'),
 ('ignore-original-source','src/storage/disk/object_mapping.cpp','const auto owner = span.data_->owner_.value_or(key);','const auto owner = key;','SharedJournalContentSurvivesOwnerRetirementRestartAndFinalRelease','read()'),
 ('omit-dirty-content','src/buffer/buffer_pool_manager.cpp','capture.dirty_.push_back(std::move(copy));','(void)copy;','DirtySqlCheckpointKeepsCapturedRowsWhileCommittedSuffixApplies',None),
 ('omit-root-publication','src/distributed/raft_state_machine.cpp','tx = {{}, {{deployment.pages_.registry_, 0, root.Take()}}};\n  SubmitCheckpoint(*deployment.storage_, tx);','tx = {{}, {{deployment.pages_.registry_, 0, root.Take()}}};\n  // broken: return success without publishing the root','SqlSessionsIndexesAndCommittedSuffixRestoreAcrossMultipleGenerations','LocalRecoveryPoint'),
 ('reset-page-highwater','src/distributed/raft_state_machine.cpp','state->buffer_pool_manager_->SetNextPageIdForRecovery(static_cast<page_id_t>(count));','// broken: reconstruct allocation boundary from live table pages only','SqlSessionsIndexesAndCommittedSuffixRestoreAcrossMultipleGenerations',None),
]
early = '      validate_local(local_probe.latest_boundary_term_);'
src = (repo/'src/raft/persistent_state.cpp').read_text()
mutations.append(('validate-after-cleanup','src/raft/persistent_state.cpp',src,
 src.replace(early, '      (void)local_probe; // broken: validate only after retirement').replace(
 '  return {std::move(stable_store), std::move(log_store), std::move(snapshot_store)};',
 '  if (use_local) validate_local(log_store->TermAt(local->index_));\n  return {std::move(stable_store), std::move(log_store), std::move(snapshot_store)};'),
 'RejectedLocalBoundaryPreservesPortableRecoveryHistory','OldestRetained'))
fsm = (repo/'src/distributed/raft_state_machine.cpp').read_text()
start = fsm.index('void BusTubRaftStateMachine::DrainCheckpoint()')
stop = fsm.index('void BusTubRaftStateMachine::OpenLocalCheckpoint()', start)
drain = fsm[start:stop]
mutations.append(('skip-worker-drain','src/distributed/raft_state_machine.cpp',drain,
 drain.replace('  checkpoint_->changed_.wait(lock, [&] { return !checkpoint_->busy_; });',
               '  // broken: return without waiting for the accepted worker'),
 'RequestReturnsBeforeDeviceCompletionAndShutdownDrainsWorker','drain.wait_for'))
mutations.append(('omit-worker-dirty-write','src/distributed/raft_state_machine.cpp',
 'for (const auto &page : pages->dirty_) {',
 'for (const auto &page : std::vector<CapturedPage>{}) {',
 'DirtySqlCheckpointKeepsCapturedRowsWhileCommittedSuffixApplies',None))
for name,file,old,new,test,marker in mutations:
 if a.only and name not in a.only:continue
 s=(repo/file).read_text();assert s.count(old)==1,(name,s.count(old));source=out/(name+'.cpp');source.write_text(s.replace(old,new));obj=out/(name+'.o');exe=out/name
 c=compile_cmd.copy();c.insert(1,'-I'+str(repo/'third_party/libpg_query/include'));i=c.index('-c');c[i+1]=str(source);c[c.index('-o')+1]=str(obj);run(c,name+'-compile',0)
 c=link_cmd.copy();i=c.index(str(base/'checkpoint.o'));c.insert(i+1,str(obj));c[c.index('-o')+1]=str(exe);run(c,name+'-link',0)
 xml=out/(name+'.xml');run([str(exe),'--gtest_filter='+full+test,'--gtest_output=xml:'+str(xml)],name,1)
 cases=ET.parse(xml).getroot().findall('.//testcase');assert len(cases)==1 and cases[0].attrib.get('status')=='run' and cases[0].find('skipped') is None
 failures=[f.text or '' for f in cases[0].findall('failure')];assert failures and (marker is None or any(marker in f for f in failures)),(name,failures)
 if test == 'DirtySqlCheckpointKeepsCapturedRowsWhileCommittedSuffixApplies':
  assert any('saving_captured_body' not in f for f in failures), ('only IO gate failed', name, failures)
 results.append(dict(mutation=name,file=file,test=full+test,old=old,new=new,failures=failures));(out/'mutations.json').write_text(json.dumps(results,indent=2));print(name+': detected',flush=True)
