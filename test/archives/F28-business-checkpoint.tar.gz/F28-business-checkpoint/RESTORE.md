# F28 / S11 测试恢复

本模块只压缩保留测试，不注册常驻小测试。共同 C/P 输入和 oracle 不变。

## 对应源与依赖

基线 e4d8703 + 本轮工作区；MANIFEST.json 校验当前生产源、测试源和六个依赖归档。必须使用包含本轮改动的生产库；不能只在旧 e4d8703 上解压测试。结果包另存生产差异/修改源快照。S5 历史 producer 还需要仓库已有 cce998a、2512675 Git 对象。

```bash
stage_work=$(mktemp -d /tmp/bustub-f28-XXXXXX)
tar -xzf test/archives/F28-business-checkpoint.tar.gz -C "$stage_work"
cmake -S . -B "$stage_work/build" -DCMAKE_BUILD_TYPE=Debug \
  -DCMAKE_C_COMPILER=clang-14 -DCMAKE_CXX_COMPILER=clang++-14 \
  -DBUSTUB_SANITIZER=address,undefined -DCMAKE_EXE_LINKER_FLAGS=-no-pie
cmake --build "$stage_work/build" --target bustub gmock_main gtest_main -j3
python3 "$stage_work/F28-business-checkpoint/run_stage.py" --repo "$PWD" \
  --build "$stage_work/build" --out "$stage_work/results" --regressions
python3 "$stage_work/F28-business-checkpoint/run_mutations.py" --repo "$PWD" \
  --baseline "$stage_work/results" --out "$stage_work/mutations"
```

run_stage 默认先运行原 F27，--regressions 接续其余场景，共64项。--checkpoint-only 只跑 F28＋S8 共16项；--case 用于单个指定 gtest，必须同时带 --checkpoint-only，并确实执行一项；空过滤表达式或缺少该参数在运行前报错。run_mutations 默认执行8个隔离错误；--only 可选择剩余变异，不改生产源或静态库。

测试在 /tmp Direct 普通文件和 loopback TCP 上运行；需文件系统支持 Direct IO、允许 LSan 枚举本地线程及本机端口。不可通过关闭 sanitizer 把环境错误记作通过。固定数据种子，注入由链接器包装系统调用；没有生产测试开关。

S8 fixture 延用页后端部署适配；T5 唯一额外 fixture 参数在 Create 时配置足够大的 Journal record，并把 Data 区限制为3个实际 allocation unit。原8项S8业务输入及oracle不改。阶段说明、每个测试的目标/输入/Oracle/限制及未来去重见 docs/storage_redesign/s11_execution_20261006.md。

2026-10-06 复审：新增 T8 验证错误 local term 被拒绝前，原 portable snapshot/日志边界未被清理；T2 排空测试先确认线程启动。实际重跑16项，两个新变异检出；另外48项和原五个变异沿用首轮证据，未计为本次重跑。

第二次复审：T4 改为80条真实 SQL 记录经过 F28 worker 保存、并发 Apply 和重启恢复；删除旧测试自行保存候选的循环。生产未改，实际重跑16项，指定 `omit-dirty-content` 和新增 `omit-worker-dirty-write` 均在实际恢复时报错，不仅是 IO 闸门未命中。其余正常/变异结果按原轮次保存，未全部重跑。runner 对这两个变异另要求存在闸门断言以外的失败；该结果校验在已完成 XML 上复验，不重新运行生产测试。

第三次复审：修正 `--case` 单独使用时漏跑目标的问题，补充上述明确拒绝规则；实际验证拒绝命令返回2且不创建结果目录。生产/C++用例/变异未变，本次未重跑正常测试。最近实测仍为第二次复审的16项及两个指定变异，详见执行记录 §11。
