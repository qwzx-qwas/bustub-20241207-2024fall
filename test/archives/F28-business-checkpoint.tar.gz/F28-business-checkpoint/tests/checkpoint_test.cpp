// Reuse the existing S8 production fixture and all eight unchanged workloads.
#include "buffer/buffer_pool_manager.h"
#include "s8-adapted.cpp"
#include <algorithm>
#include <condition_variable>
#include <cstring>
#include <future>
namespace {
std::mutex pause_mutex;
std::condition_variable pause_cv;
bool pause_next = false, paused = false, resume_io = true;
std::string pause_marker;
void ArmData(std::string marker = {}) {
  std::lock_guard lock(pause_mutex);
  pause_marker = std::move(marker);
  pause_next = true;
  paused = false;
  resume_io = false;
}
void ResumeData() {
  std::lock_guard lock(pause_mutex);
  resume_io = true;
  pause_next = false;
  pause_cv.notify_all();
}
bool AwaitData() {
  std::unique_lock lock(pause_mutex);
  return pause_cv.wait_for(lock, 15s, [] { return paused; });
}
struct ResumeOnExit {
  ~ResumeOnExit() { ResumeData(); }
};
} // namespace
extern "C" ssize_t __wrap_pwrite(int fd, const void *data, size_t size,
                                 off_t offset) {
  if ((fcntl(fd, F_GETFL) & O_DIRECT) && offset >= static_cast<off_t>(DATA)) {
    std::unique_lock lock(pause_mutex);
    const auto *begin = static_cast<const char *>(data);
    if (pause_next &&
        (pause_marker.empty() || std::search(begin, begin + size, pause_marker.begin(),
                                           pause_marker.end()) != begin + size)) {
      pause_next = false;
      paused = true;
      pause_cv.notify_all();
      pause_cv.wait(lock, [] { return resume_io; });
    }
  }
  return s8_pwrite(fd, data, size, offset);
}
namespace {
using Rows = std::vector<std::vector<std::string>>;
struct Business {
  Harness h;
  std::shared_ptr<PosixDurableStorage> files =
      std::make_shared<PosixDurableStorage>();
  std::filesystem::path root;
  std::unique_ptr<NodeDirectory> directory;
  std::shared_ptr<BusTubRaftStateMachine> machine;
  std::unique_ptr<LogStore> log;
  std::unique_ptr<StableStore> stable;
  uint64_t index = 0;
  Business() : root(h.image.path + "-checkpoint") {
    directory = NodeDirectory::Open(root, files);
    Open();
  }
  auto Deployment() -> ObjectPageDeployment {
    return {h.node, {4, {h.space, 5}}, {8 * MIB, 2 * MIB, 32, false, 3}};
  }
  void Open() {
    machine = BusTubRaftStateMachine::OpenObjectPages(directory.get(), files,
                                                      32, Deployment());
    auto recovered = RecoverRaftPersistentState(h.objects, machine);
    log = std::move(recovered.log_store_);
    stable = std::move(recovered.stable_store_);
    index = stable->State().commit_index_;
  }
  void Close() {
    machine.reset();
    log.reset();
    stable.reset();
    h.Close();
  }
  void Restart() {
    Close();
    h.Open();
    Open();
  }
  void Apply(const std::string &sql) {
    auto batch = machine->PrepareSql(sql, 71, index + 1,
                                     ComputeWriteIntentFingerprintV1(sql));
    ReplicatedLogEntry e{1, ++index, 3, EntryType::COMMAND_BATCH,
                         CommandBatchCodec::Encode(batch)};
    log->Append({e});
    stable->Update(3, 1, index);
    log->AdvanceCommittedIndex(index);
    machine->Apply(e);
  }
  auto Query(const std::string &sql) -> Rows {
    return ClientQueryResultCodec::Decode(
               machine->ExecuteReadSql(sql, machine->LastApplied()))
        .rows_;
  }
  void Checkpoint() {
    Require(machine->RequestCheckpoint(index, 3),
            "checkpoint request accepted");
    machine->DrainCheckpoint();
    Require(machine->PollCheckpoint() == index, "checkpoint publication");
  }
  ~Business() {
    ResumeData();
    machine.reset();
    log.reset();
    stable.reset();
    directory.reset();
    std::filesystem::remove_all(root);
  }
};
TEST(S11Checkpoint,
     SqlSessionsIndexesAndCommittedSuffixRestoreAcrossMultipleGenerations) {
  Business b;
  b.Apply("CREATE TABLE accounts(id INT PRIMARY KEY, amount INT, label "
          "VARCHAR(400));");
  b.Apply("INSERT INTO accounts VALUES "
          "(7,100,'original-seven'),(37,200,'original-thirty-seven');");
  b.Apply("CREATE INDEX amount_idx ON accounts(amount);");
  b.Checkpoint();
  const auto checkpoint = b.index;
  const auto old_reply = b.machine->GetLastResponse(71);
  b.Apply("UPDATE accounts SET amount=101,label='new-seven' WHERE id=7;");
  const auto new_reply = b.machine->GetLastResponse(71);
  b.Restart();
  ASSERT_TRUE(b.machine->LocalRecoveryPoint());
  EXPECT_EQ(b.machine->LastApplied(), checkpoint);
  EXPECT_EQ(b.machine->GetLastResponse(71), old_reply);
  EXPECT_EQ(b.Query("SELECT id,amount,label FROM accounts ORDER BY id;"),
            (Rows{{"7", "100", "original-seven"},
                  {"37", "200", "original-thirty-seven"}}));
  b.machine->Apply(*b.log->EntryAt(checkpoint + 1));
  EXPECT_EQ(b.machine->GetLastResponse(71), new_reply);
  EXPECT_EQ(
      b.machine->ClassifyRequest(
          71, b.index,
          ComputeWriteIntentFingerprintV1(
              "UPDATE accounts SET amount=101,label='new-seven' WHERE id=7;")),
      RequestDisposition::RETRY_LAST);
  // New index pages and new table pages must not overwrite the recovered table.
  b.Apply("CREATE TABLE later(id INT PRIMARY KEY, body VARCHAR(300));");
  std::string values;
  for (int n = 0; n < 40; ++n) {
    if (n)
      values += ",";
    values += "(" + std::to_string(100 + n) + ",'" +
              std::string(180, char('a' + n % 23)) + "')";
  }
  b.Apply("INSERT INTO later VALUES " + values + ";");
  b.Apply("DELETE FROM later WHERE id>=105;");
  b.Checkpoint();
  b.Restart();
  EXPECT_EQ(b.machine->LastApplied(), b.index);
  EXPECT_EQ(b.Query("SELECT id FROM accounts WHERE amount=101;"),
            (Rows{{"7"}}));
  EXPECT_EQ(b.Query("SELECT id FROM later ORDER BY id;"),
            (Rows{{"100"}, {"101"}, {"102"}, {"103"}, {"104"}}));
  b.Apply("INSERT INTO later VALUES (999,'after-second-recovery');");
  EXPECT_EQ(b.Query("SELECT label FROM accounts WHERE id=37;"),
            (Rows{{"original-thirty-seven"}}));
}
TEST(S11Checkpoint,
     RequestReturnsBeforeDeviceCompletionAndShutdownDrainsWorker) {
  Business b;
  b.Apply("CREATE TABLE tasks(id INT PRIMARY KEY, body VARCHAR(128));");
  b.Apply("INSERT INTO tasks VALUES (19,'pending-checkpoint-body');");
  ArmData();
  ResumeOnExit cleanup;
  ASSERT_TRUE(b.machine->RequestCheckpoint(b.index, 3));
  ASSERT_TRUE(AwaitData());
  EXPECT_FALSE(b.machine->RequestCheckpoint(b.index, 3));
  EXPECT_EQ(b.machine->PollCheckpoint(), 0U);
  std::promise<void> entered;
  auto started = entered.get_future();
  auto drain = std::async(std::launch::async, [&] {
    entered.set_value();
    b.machine->DrainCheckpoint();
  });
  started.get();
  // Timeout is a negative assertion under a deterministic IO gate, not a
  // performance target.
  EXPECT_EQ(drain.wait_for(30ms), std::future_status::timeout);
  ResumeData();
  ASSERT_EQ(drain.wait_for(30s), std::future_status::ready);
  drain.get();
  EXPECT_EQ(b.machine->PollCheckpoint(), b.index);
  b.Restart();
  EXPECT_EQ(b.Query("SELECT body FROM tasks WHERE id=19;"),
            (Rows{{"pending-checkpoint-body"}}));
}
TEST(S11Checkpoint,
     FailedCheckpointDoesNotReplacePreviouslyPublishedBusinessState) {
  Business b;
  b.Apply("CREATE TABLE durable(id INT PRIMARY KEY, value INT);");
  b.Apply("INSERT INTO durable VALUES (23,40);");
  b.Checkpoint();
  const auto previous = b.index;
  b.Apply("UPDATE durable SET value=99 WHERE id=23;");
  fail_data = true;
  ASSERT_TRUE(b.machine->RequestCheckpoint(b.index, 3));
  EXPECT_THROW(b.machine->DrainCheckpoint(), std::exception);
  EXPECT_THROW(b.machine->PollCheckpoint(), std::exception);
  // The failed NodeStorage is discarded. The fresh process view uses the old
  // published checkpoint, then the valid committed suffix supplies the update.
  b.machine.reset();
  b.log.reset();
  b.stable.reset();
  b.h.objects.reset();
  try {
    b.h.node->Close();
  } catch (const std::exception &) {
  }
  b.h.node.reset();
  b.h.Open();
  b.Open();
  EXPECT_EQ(b.machine->LastApplied(), previous);
  EXPECT_EQ(b.Query("SELECT value FROM durable WHERE id=23;"), (Rows{{"40"}}));
  b.machine->Apply(*b.log->EntryAt(previous + 1));
  EXPECT_EQ(b.Query("SELECT value FROM durable WHERE id=23;"), (Rows{{"99"}}));
}
TEST(S11Checkpoint,
     DirtySqlCheckpointKeepsCapturedRowsWhileCommittedSuffixApplies) {
  Business b;
  // Runtime IO budget, via the existing deployment options. No page-layout
  // fields, frame IDs, or capture getters are used by this test.
  const auto alignment = b.h.node->PageIO().memory_alignment_;
  const auto stride = (BUSTUB_PAGE_SIZE + alignment - 1) / alignment * alignment;
  b.Close();
  b.h.options.external_buffer_bytes_ = stride;
  b.h.Open();
  b.Open();
  ASSERT_EQ(b.h.node->PageIO().max_batch_pages_, 1U);
  b.Apply("CREATE TABLE dirty_capture(id INT PRIMARY KEY, body VARCHAR(400));");
  Rows expected;
  std::string values;
  for (int n = 0; n < 80; ++n) {
    const auto text = "frozen-row-" + std::to_string(n) + "-" +
                      std::string(300, char('a' + n % 23));
    expected.push_back({std::to_string(100 + n), text});
    if (n) values += ",";
    values += "(" + std::to_string(100 + n) + ",'" + text + "')";
  }
  b.Apply("INSERT INTO dirty_capture VALUES " + values + ";");
  const auto captured_index = b.index;
  const auto captured_reply = b.machine->GetLastResponse(71);
  const std::string update =
      "UPDATE dirty_capture SET body='applied-after-capture' WHERE id=157;";
  auto batch = b.machine->PrepareSql(update, 71, b.index + 1,
                                     ComputeWriteIntentFingerprintV1(update));
  ReplicatedLogEntry suffix{1, ++b.index, 3, EntryType::COMMAND_BATCH,
                            CommandBatchCodec::Encode(batch)};
  // Real Raft ordering: log + HardState are durable before Apply. Leave this
  // committed entry unapplied until the checkpoint has captured the old rows.
  b.log->Append({suffix});
  b.stable->Update(3, 1, b.index);
  b.log->AdvanceCommittedIndex(b.index);
  // The bounded preflush cannot clean the whole resident table. Match input
  // bytes in a later table page, without knowing its page ID or tuple offsets.
  ArmData("frozen-row-57-");
  ResumeOnExit cleanup;
  ASSERT_TRUE(b.machine->RequestCheckpoint(captured_index, 3));
  const bool saving_captured_body = AwaitData();
  EXPECT_TRUE(saving_captured_body);
  b.machine->Apply(suffix);
  EXPECT_EQ(b.Query("SELECT body FROM dirty_capture WHERE id=157;"),
            (Rows{{"applied-after-capture"}}));
  ResumeData();
  b.machine->DrainCheckpoint();
  EXPECT_EQ(b.machine->PollCheckpoint(), captured_index);
  b.Restart();
  EXPECT_EQ(b.machine->LastApplied(), captured_index);
  EXPECT_EQ(b.machine->GetLastResponse(71), captured_reply);
  EXPECT_EQ(b.Query("SELECT id,body FROM dirty_capture ORDER BY id;"), expected);
  b.machine->Apply(*b.log->EntryAt(captured_index + 1));
  expected[57][1] = "applied-after-capture";
  EXPECT_EQ(b.Query("SELECT id,body FROM dirty_capture ORDER BY id;"), expected);
}
TEST(S11Checkpoint,
     SharedJournalContentSurvivesOwnerRetirementRestartAndFinalRelease) {
  Harness h(Limits(), 3, true);
  const auto unit = h.options.objects_->allocator_.allocation_bytes_;
  const ObjectKey a{h.space, 100}, b{h.space, 101};
  auto put = [&](ObjectTransaction tx) {
    auto s = h.node->SubmitObjects(tx);
    Require(bool(s.ticket_), "object accepted");
    s.ticket_->Wait();
    const auto result = s.ticket_->Result();
    if (result.error_)
      std::rethrow_exception(result.error_);
    Require(result.outcome_ == JournalOutcome::Durable, "object durable");
  };
  put({{{ObjectOperation::Create, a, 0, ObjectSizeMode::Variable, {}},
        {ObjectOperation::Create, b, 3 * unit, ObjectSizeMode::Fixed, {}}},
       {}});
  const auto body = s5::Value(3 * unit, 197);
  ArmData();
  ResumeOnExit cleanup;
  put({{{ObjectOperation::Append, a, 0, ObjectSizeMode::Variable, body}}, {}});
  ASSERT_TRUE(AwaitData());
  auto view = h.node->Objects();
  const auto source = view.Resolve(a, 0, body.size());
  ASSERT_FALSE(source.spans_.empty());
  ASSERT_TRUE(source.spans_[0].journal_);
  const auto allocation = source.spans_[0].data_->allocation_;
  auto shared = h.node->ShareObjectRange(view, a, b, 0, body.size());
  ASSERT_EQ(shared.outcome_, JournalOutcome::Durable);
  put({{{ObjectOperation::Remove, a, 0, ObjectSizeMode::Variable, {}}}, {}});
  auto read = [&] {
    auto r = h.node->ReadObject(h.node->Objects(), b, 0, body.size());
    r.Wait();
    Bytes out(r.Size());
    r.CopyTo(out.data(), out.size());
    return out;
  };
  EXPECT_EQ(read(), body);
  h.node->Checkpoint(64);
  // Fail only the final Data write, after the shared mapping and B checkpoint
  // are durable. Reopen must still resolve the shared content through Journal.
  fail_data = true;
  ResumeData();
  const auto failed_by = std::chrono::steady_clock::now() + 15s;
  while (!h.node->State().error_ &&
         std::chrono::steady_clock::now() < failed_by)
    std::this_thread::sleep_for(1ms);
  ASSERT_TRUE(h.node->State().error_);
  h.Close();
  ArmData();
  h.Open();
  ASSERT_TRUE(AwaitData());
  EXPECT_EQ(read(), body);
  ResumeData();
  const auto deadline = std::chrono::steady_clock::now() + 15s;
  while (h.node->Objects().Resolve(b, 0, body.size()).spans_[0].journal_ &&
         std::chrono::steady_clock::now() < deadline)
    std::this_thread::sleep_for(1ms);
  ASSERT_FALSE(h.node->Objects().Resolve(b, 0, body.size()).spans_[0].journal_);
  view = h.node->Objects(); // Release the old Journal snapshot before actual
                            // reclaim assertions.
  h.Close();
  h.Open();
  auto kept = h.node->ReclaimObject(h.node->Objects(), a, allocation);
  EXPECT_EQ(kept.released_bytes_, 0U);
  EXPECT_EQ(read(), body);
  put({{{ObjectOperation::Unmap,
         b,
         unit,
         ObjectSizeMode::Fixed,
         {},
         std::nullopt,
         unit}},
       {}});
  auto middle = h.node->ReclaimObject(h.node->Objects(), a, allocation);
  EXPECT_EQ(middle.released_bytes_, unit);
  auto expect = body;
  std::fill(expect.begin() + unit, expect.begin() + 2 * unit, std::byte{0});
  EXPECT_EQ(read(), expect);
  // The device has only three allocation units. Successful new writes prove
  // actual reuse, rather than trusting the reclaim result's byte counter.
  const ObjectKey replacement{h.space, 102};
  put({{{ObjectOperation::Create,
         replacement,
         0,
         ObjectSizeMode::Variable,
         {}}},
       {}});
  const auto replacement_body = s5::Value(unit, 211);
  ObjectMutation replace{ObjectOperation::Append, replacement, 0,
                         ObjectSizeMode::Variable, replacement_body};
  replace.common_only_ = true;
  put({{replace}, {}});
  EXPECT_EQ(read(), expect);
  put({{{ObjectOperation::Remove, b, 0, ObjectSizeMode::Variable, {}}}, {}});
  const auto end = h.node->ReclaimObject(h.node->Objects(), a, allocation);
  EXPECT_EQ(end.released_bytes_, 2 * unit);
  const ObjectKey final_owner{h.space, 103};
  put({{{ObjectOperation::Create,
         final_owner,
         0,
         ObjectSizeMode::Variable,
         {}}},
       {}});
  ObjectMutation tail{ObjectOperation::Append, final_owner, 0,
                      ObjectSizeMode::Variable, s5::Value(2 * unit, 229)};
  tail.common_only_ = true;
  put({{tail}, {}});
  auto still = h.node->ReadObject(h.node->Objects(), replacement, 0, unit);
  still.Wait();
  Bytes actual(still.Size());
  still.CopyTo(actual.data(), actual.size());
  EXPECT_EQ(actual, replacement_body);
}
TEST(S11Checkpoint,
     NewerPortableSnapshotSupersedesLocalCheckpointWithoutLosingSuffix) {
  Business b;
  b.Apply("CREATE TABLE versions(id INT PRIMARY KEY, value INT);");
  b.Apply("INSERT INTO versions VALUES (41,10);");
  b.Checkpoint();
  b.Apply("UPDATE versions SET value=20 WHERE id=41;");
  auto snapshots = SnapshotStore::OpenObjects(b.h.objects);
  snapshots->Capture(b.index, 3, *b.machine);
  b.log->InstallSnapshotBase(b.index, 3, true);
  snapshots->RetainOnlyLatest();
  const auto snapshot = b.index;
  b.Apply("UPDATE versions SET value=30 WHERE id=41;");
  snapshots.reset();
  b.Restart();
  EXPECT_EQ(b.machine->LastApplied(), snapshot);
  EXPECT_EQ(b.Query("SELECT value FROM versions WHERE id=41;"), (Rows{{"20"}}));
  b.machine->Apply(*b.log->EntryAt(snapshot + 1));
  EXPECT_EQ(b.Query("SELECT value FROM versions WHERE id=41;"), (Rows{{"30"}}));
}
TEST(S11Checkpoint, RejectedLocalBoundaryPreservesPortableRecoveryHistory) {
  Business b;
  b.Apply("CREATE TABLE history(id INT PRIMARY KEY, value INT);");
  b.Apply("INSERT INTO history VALUES (67,10);");
  auto snapshots = SnapshotStore::OpenObjects(b.h.objects);
  snapshots->Capture(b.index, 3, *b.machine);
  const auto previous = b.index;
  b.Apply("UPDATE history SET value=20 WHERE id=67;");
  snapshots->Capture(b.index, 3, *b.machine);
  const auto latest = b.index;
  // A valid interrupted cleanup: the log already uses the latest base while
  // both portable snapshots remain retained.
  b.log->InstallSnapshotBase(latest, 3, true);
  b.Apply("UPDATE history SET value=30 WHERE id=67;");
  // Deliberately inconsistent recovery inputs, through the real checkpoint
  // API: complete SQL pages at index 4, but a term other than the committed log.
  ASSERT_TRUE(b.machine->RequestCheckpoint(b.index, 9));
  b.machine->DrainCheckpoint();
  const auto committed = b.index;
  snapshots.reset();
  EXPECT_THROW(b.Restart(), std::exception);
  auto retained = SnapshotStore::OpenObjects(b.h.objects);
  ASSERT_TRUE(retained->OldestRetained());
  ASSERT_TRUE(retained->Latest());
  EXPECT_EQ(retained->OldestRetained()->last_included_index_, previous);
  EXPECT_EQ(retained->Latest()->last_included_index_, latest);
  auto hard_state = StableStore::OpenObjects(b.h.objects);
  EXPECT_EQ(hard_state->State().commit_index_, committed);
  const auto log = LogStore::ProbeObjects(b.h.objects, committed, latest, committed);
  EXPECT_EQ(log.snapshot_base_index_, latest);
  EXPECT_EQ(log.last_log_index_, committed);
  EXPECT_EQ(log.latest_boundary_term_, std::optional<uint64_t>{3});
}
} // namespace
namespace {
TEST(S11Checkpoint,
     PublishedCheckpointSurvivesProcessExitWithoutGracefulCleanup) {
  Business b;
  b.Apply("CREATE TABLE crash_state(id INT PRIMARY KEY, value VARCHAR(64));");
  b.Apply("INSERT INTO crash_state VALUES (59,'before-crash');");
  b.Checkpoint();
  b.Close(); // fork only after storage workers have stopped.
  const auto child = fork();
  ASSERT_GE(child, 0);
  if (child == 0) {
    try {
      b.h.Open();
      b.Open();
      b.Apply("UPDATE crash_state SET value='published-in-child' WHERE id=59;");
      b.Checkpoint();
      _exit(0); // no FSM destruction, workspace retirement, or
                // NodeStorage::Close.
    } catch (...) {
      _exit(3);
    }
  }
  int status = 0;
  ASSERT_EQ(waitpid(child, &status, 0), child);
  ASSERT_TRUE(WIFEXITED(status));
  ASSERT_EQ(WEXITSTATUS(status), 0);
  b.h.Open();
  b.Open();
  EXPECT_EQ(b.machine->LastApplied(), 3U);
  EXPECT_EQ(b.Query("SELECT value FROM crash_state WHERE id=59;"),
            (Rows{{"published-in-child"}}));
  EXPECT_EQ(b.machine->ClassifyRequest(
                71, 3,
                ComputeWriteIntentFingerprintV1(
                    "UPDATE crash_state SET value='published-in-child' WHERE "
                    "id=59;")),
            RequestDisposition::RETRY_LAST);
}
} // namespace
