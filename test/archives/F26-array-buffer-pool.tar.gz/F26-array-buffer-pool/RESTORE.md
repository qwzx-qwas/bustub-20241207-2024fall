# F26 S13.4 不可变正文短读：当前唯一阶段包

2026-10-10，基线 dad463f 加本轮生产补丁。先恢复结果包中的 source 快照/补丁，并核对 MANIFEST.json 的 production_sha256、dependency_sha256 和包内 test_sha256；不要覆盖其他工作树。旧零页结果包已被替换，原基础/页IO场景仍保留复用。

## 工具与运行

CMake >=3.20；翻译目录需 C++23 显式寿命和无锁 atomic_ref。本轮使用仓库 `.cache/toolchains/gcc-16.2.0/bin/g++`，运行库 `.cache/toolchains/gcc-16.2.0/lib64`，没有额外 sysroot 参数。其他平台应提供等价原生工具链；部分 runner 的运行库定位沿此布局，可用等价目录或明确调整环境，不得混入旧 libc。

解压到 `/tmp/F26-array-buffer-pool`，设置 PKG/BUILD/CXX/LD_LIBRARY_PATH；每个 out 必须为不存在的新目录。CMake Release，BUSTUB_SANITIZER为空，打开 CMAKE_EXPORT_COMPILE_COMMANDS。

```bash
python3 "$PKG/run_stage.py" --repo "$PWD" --out /tmp/f26-foundation --compiler "$CXX"
python3 "$PKG/run_short.py" --repo "$PWD" --build "$BUILD" --out /tmp/f26-short --compiler "$CXX"
python3 "$PKG/run_pages.py" --repo "$PWD" --build "$BUILD" --out /tmp/f26-pages --compiler "$CXX" --sanitizer ''
python3 "$PKG/run_reused.py" --repo "$PWD" --build "$BUILD" --out /tmp/f26-reused --compiler "$CXX"
python3 "$PKG/run_short_tsan.py" --repo "$PWD" --build "$BUILD" --out /tmp/f26-tsan --compiler "$CXX"
python3 "$PKG/run_short_mutations.py" --repo "$PWD" --build "$BUILD" --out /tmp/f26-mutations --compiler "$CXX"
```

build 先构建 buffer_pool_manager_test、page_guard_test、b_plus_tree_insert_test、b_plus_tree_delete_test、b_plus_tree_concurrent_test、b_plus_tree_contention_test、bustub_state_machine_test、sql_command_preparer_test、distributed_node_test。复用包 F32-metadata-cache、S5 和 F35-raft-pipeline 必须保留，精确命令见结果 commands/log；TCP测试需允许本机监听。F35沿原包测试源码，按当前Release库重新编译执行，没有复制测试正文。

## 证据与范围

首次实施77项结果保留原版本归属。再次复审修正失败入口：当前短读套件7项（新增退役失败保护/封闭），页IO套件10项；短读另运行局部TSan（8个编译单元，非整库），定向变异增至5个。各次最终结果及精确源码指纹见结果包review目录；首次性能数据未重跑。`run_stage.py --mutations` 中原零页变异保留可运行，但不计本轮五变异结果。

short_bench.cpp 使用同一实际B+Tree的短读与原保护分支；read/mixed，1/4读线程，3次交替运行，详见最终 benchmark/commands.json 和 CSV。结果不能替代全套SS/RS/PL/GT、共同C/P或裸设备/掉电验收。

当前证据：test-results/storage-f26-short-20261010/F26-results.tar.gz；审查：docs/storage_redesign/s134_execution_20261010.md。结果包本机保存且被gitignore；跨机器复验需另行保存原始包。测试仅压缩归档，不挂默认CTest，不增加生产测试钩子。源码哈希与成员校验可确认结果归属。
