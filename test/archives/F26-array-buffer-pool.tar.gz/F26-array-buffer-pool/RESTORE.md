# F26 共享零页接续：唯一当前阶段包

2026-10-08，基线提交 3dc23d3 加本轮修改。精确文件哈希见 MANIFEST.json；结果包保存本轮源码补丁/快照、测试源码及原始日志/XML。

最新复审仅加强八个变异的失败内容判据，生产代码及 C++ 场景不变；本次重跑基础六项和八个变异，其余页/课程/S8 与 TSan 结果沿用哈希匹配的上轮证据。各轮运行来源见结果包 `review-summary.json`。

范围：基础 6 项、真实页/对象/SQL 10 项，复用课程 11 项和 S8 八项，共 35 个不同正常场景。基础 TSan 六项；八个当前协议 mutation。旧 S9.1e 的测试包原位替换，旧结果包删除，不沿用旧 25 个 mutation 的计数。

## 工具链

CMake 至少 3.20；翻译实现需要 C++23 `std::start_lifetime_as_array` 和无锁 atomic_ref，公共头仍 C++17。可用原生 GCC/libstdc++ 16；原 Clang14/GCC13 标准库不足，CMake 明确拒绝。

本轮使用隔离工具链：

- 发布者 https://github.com/tttapa/toolchains/releases/tag/1.4.0
- 文件 https://github.com/tttapa/toolchains/releases/download/1.4.0/x-tools-x86_64-focal-linux-gnu-gcc16.tar.xz
- SHA256 `204d2e395e59eb4d81f8bb8bc7fa06928b9735cb7f0a83cbbf7f6b4219870e18`
- 编译器报告 GCC 16.2.0，libstdc++ 显式寿命 macro 202207L。

这个交叉工具链自带的 Linux 头偏旧。实际设备构建使用本机 sysroot 和 multiarch include（本机为 `--sysroot=/ -isystem /usr/include/x86_64-linux-gnu`），从真实 STATX_DIOALIGN 查询对齐；其他机器应采用对应本机工具链/头文件路径，不能复制本机测得的对齐值。

若动态运行库不在系统搜索路径，把该工具链的 libstdc++、libgcc_s、libasan、libubsan、libtsan 放在单独 runtime 目录供 LD_LIBRARY_PATH 使用。**不要把包含旧 libc 的整个交叉 sysroot/lib 加入运行搜索路径。**不改机器全局编译器或库。

## 恢复运行

先恢复同一生产源版本，核对 MANIFEST，不覆盖别的开发树。解压在仓库外，out 使用尚不存在的新目录。以下以机器已安装原生支持工具链为例：

```bash
tar -xzf test/archives/F26-array-buffer-pool.tar.gz -C /tmp
python3 /tmp/F26-array-buffer-pool/run_stage.py --repo "$PWD" --out /tmp/f26-foundation --compiler g++-16 --mutations
python3 /tmp/F26-array-buffer-pool/run_stage.py --repo "$PWD" --out /tmp/f26-thread --compiler g++-16 --sanitizer thread
cmake -S . -B /tmp/f26-build -DCMAKE_BUILD_TYPE=Debug -DCMAKE_CXX_COMPILER=g++-16 -DCMAKE_C_COMPILER=gcc-16 -DBUSTUB_SANITIZER=address,undefined
cmake --build /tmp/f26-build --target buffer_pool_manager_test page_guard_test lru_k_replacer_test disk_scheduler_test -j3
python3 /tmp/F26-array-buffer-pool/run_pages.py --repo "$PWD" --build /tmp/f26-build --out /tmp/f26-pages --compiler g++-16 --regressions
```

交叉工具链需给 CMake 的 C/CXX flags 及 run_pages 的 `--extra-cxxflags` 传上述实际 sysroot 参数；结果包 commands 记录了本轮完整路径。基础组件 runner 不依赖 Direct IO，当前仅其翻译实现和测试采用 C++23。运行器校验源码哈希及精确场景数，测试/编译失败、超时或 sanitizer 崩溃均不算通过。

测试仅在压缩包内，不挂默认 CTest。S5 只复用 fixture；S8 只在测试接口侧适配对象页部署参数，原业务输入和 oracle 保持，不复制第二份 S8 正文。正常页 IO、SQL 与真实三节点 TCP 均经过生产代码。系统调用包装只链接进阶段测试，无 production hook/getter。

## 证据与限度

`test-results/storage-f26-zero-20261008/F26-results.tar.gz`：foundation、tsan、pages 下保存最终 XML/日志/命令，source 下保存必要生产与方案快照和补丁。结果包按既有规则本机保存，Git 仅保存摘要/校验；需要备份结果包才能在其他机器获得原始证据。

smaps 必须可读；不可辨识叶 VMA、Direct IO 不支持、无法运行 LSan/TSan 都明确报告失败，不假成功。TSan 验证本轮六项组件，未重建完整节点 TSan。真实页/节点路径用 ASan/UBSan/LSan。本轮不包含共同 C/P 前后性能、SS/RS/PL/GT、裸设备或断电验收。

审查入口 `docs/storage_redesign/s12_translation_execution_20261008.md`。原旧页 mutation 锚点随 gate/constructed_ 退出而删除；新变异验证当前零页、预算、并发保护等契约，历史失败/旧工具链产物不放入当前源码包。
