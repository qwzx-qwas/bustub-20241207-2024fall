# F26 / S9.1c 测试恢复

本包是当前唯一 F26 源码包：4 项基础 RAM 场景、5 项真实页/对象场景；原 b 人工拼装的页身份测试已经删除，由真实页路径接管。8 个基础变异和 6 个页路径变异。内容与八项审查见 `docs/storage_redesign/s9c_execution_20261004.md`。

基线 `8e16074` 加结果包 `source/` 中生产/构建修改；在隔离 checkout 恢复，不覆盖新开发树。MANIFEST 保存精确 production/test/dependency 哈希。结果包在本机，未进入 Git；仅 clone 仓库没有历史结果包。runner 要求新输出目录，不允许混用旧结果。

在仓库外解压：

```bash
tar -xzf test/archives/F26-array-buffer-pool.tar.gz -C /tmp
python3 /tmp/F26-array-buffer-pool/run_stage.py --repo "$PWD" --out /tmp/f26-foundation --mutations
cmake -S . -B /tmp/f26-build -DCMAKE_BUILD_TYPE=Debug -DCMAKE_CXX_COMPILER=clang++-14 -DCMAKE_C_COMPILER=clang-14 -DBUSTUB_SANITIZER=address,undefined
cmake --build /tmp/f26-build --target bustub buffer_pool_manager_test page_guard_test lru_k_replacer_test disk_scheduler_test -j 4
python3 /tmp/F26-array-buffer-pool/run_pages.py --repo "$PWD" --build /tmp/f26-build --out /tmp/f26-pages --regressions --mutations
```

`--regressions` 直接解压既有 S8 和 S5 包，修改测试侧部署/后端以接上新的 production 路径，课程测试直接执行已构建程序；SQL、输入、断言、超时不变。没有第二份 S8 测试正文。课程共 11 项，S8 共 8 项。暂停/EIO 和地址观察只在测试链接边界；不向 production 加 hook/getter。Direct 文件 fixture 使用实际设备对齐；本轮页 fixture 要求实际 offset 对齐能整除 4 KiB，不满足即失败，不假报跳过成功。

WSL2 上 ASan/TSan 的地址布局可能导致进程启动失败。可为该进程使用 `--no-aslr`（run_pages）或外层 `setarch x86_64 -R`（run_stage）；不改系统配置。不计启动失败、超时、编译失败为通过或变异检出。LSan 需要正常允许退出检查的环境；TCP 需要本机 socket 权限。网络场景运行时避免同时编译，否则混入非测试自身的 CPU 压力；不得因此放宽原超时。

ThreadSanitizer 另建目录，并保持链接/编译 sanitizer 一致：

```bash
cmake -S . -B /tmp/f26-thread -DCMAKE_BUILD_TYPE=Debug -DCMAKE_CXX_COMPILER=clang++-14 -DCMAKE_C_COMPILER=clang-14 -DBUSTUB_SANITIZER=thread -DCMAKE_EXE_LINKER_FLAGS=-no-pie
cmake --build /tmp/f26-thread --target bustub gmock_main -j 4
python3 /tmp/F26-array-buffer-pool/run_pages.py --repo "$PWD" --build /tmp/f26-thread --out /tmp/f26-thread-pages --sanitizer thread --no-aslr
setarch x86_64 -R python3 /tmp/F26-array-buffer-pool/run_stage.py --repo "$PWD" --out /tmp/f26-thread-foundation --sanitizer thread
```

后续 d/e 接管路径缓存、运行期 RAM 归还和预取；F36 接管页内空间及安全释放。基础四项仅保护组件自己的并发/资源契约，不冒充业务 E2E。共同 C/P 输入未修改、未在本阶段重跑；本轮也不是裸设备、物理掉电、非 Linux 或性能验收。每次测试变更仍须八项审查，整个 F26 包原位替换，删除旧结果包；不常驻展开的阶段测试。

2026-10-04 再审查：关闭场景记录实际 pread 退出与 Close 返回顺序，普通缓存读确认已停止接纳；新增删除 Close 等待的定向变异。修正稀疏文件日志清理名。runner 对课程要求精确 7/2/1/1，拒绝跳过或少跑。本次新证据是 5 页场景的 ASan/UBSan/LSan、TSan 和 6 个页变异；其他不变场景沿用已核验的历史记录，不能说本次又运行了全部 28 项。
