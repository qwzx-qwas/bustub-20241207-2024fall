# F26 / S9.1b 阶段源码恢复

这是五项真实 RAM 组件验证；没有 PageGuard、FS 页 IO 或数据库 E2E。整体风险与八项设计审查见仓库 `docs/storage_redesign/s9b_execution_20261004.md`。输入、阈值全部在测试侧，生产代码没有测试接口。

在仓库外解压本包，使用匹配 MANIFEST 的源码树：

```bash
tar -xzf test/archives/F26-array-buffer-pool.tar.gz -C /tmp
python3 /tmp/F26-array-buffer-pool/run_stage.py --repo "$PWD" --out /tmp/f26-replay --mutations
```

runner 需要新输出目录，核验生产/测试哈希后直接编译现有两份 production 源码及仓库 gtest；变异只在输出目录。无需改变 test/CMakeLists 或任何生产默认参数。默认 clang++-14、ASan/UBSan/LeakSanitizer。旧帧代码没有切换，因此不把这个运行当作新 BufferPool 已替换的证明。

归档基线为 MANIFEST 中的 Git commit 加本轮 production 文件；如果后续源码不同，应在隔离 checkout 使用本地结果包 `source/` 的对应文件恢复，而不是覆盖当前开发树。结果包不在 Git，只保存本机或独立备份。不要跳过哈希后把新的运行与旧证据混为一谈。

LeakSanitizer 需要在没有 ptrace 限制的正常环境运行；沙箱下退出检查失败不是测试通过。此轮 TSan 在 WSL2 随机地址布局无法启动，以下形式仅给测试进程关闭 ASLR 后通过，不修改系统配置：

```bash
setarch x86_64 -R python3 /tmp/F26-array-buffer-pool/run_stage.py --repo "$PWD" --out /tmp/f26-tsan --sanitizer thread
```

当前五项场景是 Linux RAM 组件，非裸设备、物理掉电、SQL、网络或性能测试。实际 OS 基础页从环境查询，首次物化的资源场景这次在 4 KiB 基础页平台运行；大页请求结果与实际 smaps 占用分开记录，不要求内核必须提供大页。调用者需在平台更换时检查同样输入预算是否表达同一风险。

后续 c：以正式页加载/Guard/FS 路径接管 T2 的页正文 Oracle 和实例隔离；d：接管 T4 的归还/再次使用；e/共同 C/P：负责完整生产内容。T3 的映射数是阶段资源观察，不应复制成多层业务断言。T5 的人工条目修改计数只保护短访问互斥，不冒充数据库事务。每次接续仍执行八项审查，源码包原位替换，只保留有效版本。

本次复审仍为五项场景，增加普通内存兼容与真实失败区别的输入，共 11 个定向变异。T1/T4 使用测试链接包装模拟不支持 THP 的 advice 返回；本机并未更换内核。零长度调用只用于生产的能力探测，业务输入仍含真实非零页号及正文。运行器核对完整测试名、执行状态、无 skip；变异必须由指定场景的断言发现。
