# F26 / S9.1d 测试恢复

本包是当前唯一 F26 源码包：4 项基础 RAM 场景、6 项真实页/对象场景；原 b 人工拼装的页身份测试已经删除，由真实页路径接管。9 个基础变异和 11 个页路径变异。内容与八项审查见 `docs/storage_redesign/s9d_execution_20261004.md`。

基线 `bd554af` 加结果包 `source/` 中生产/构建修改；在隔离 checkout 恢复，不覆盖新开发树。MANIFEST 保存精确 production/test/dependency 哈希。结果包在本机，未进入 Git；仅 clone 仓库没有历史结果包。runner 要求新输出目录，不允许混用旧结果。

在仓库外解压：

```bash
tar -xzf test/archives/F26-array-buffer-pool.tar.gz -C /tmp
python3 /tmp/F26-array-buffer-pool/run_stage.py --repo "$PWD" --out /tmp/f26-foundation --mutations
cmake -S . -B /tmp/f26-build -DCMAKE_BUILD_TYPE=Debug -DCMAKE_CXX_COMPILER=clang++-14 -DCMAKE_C_COMPILER=clang-14 -DBUSTUB_SANITIZER=address,undefined
cmake --build /tmp/f26-build --target bustub buffer_pool_manager_test page_guard_test lru_k_replacer_test disk_scheduler_test -j 4
python3 /tmp/F26-array-buffer-pool/run_pages.py --repo "$PWD" --build /tmp/f26-build --out /tmp/f26-pages --regressions --mutations
```

`--regressions` 直接解压既有 S8 和 S5 包，修改测试侧部署/后端以接上新的 production 路径，课程测试直接执行已构建程序；SQL、输入、断言、超时不变。没有第二份 S8 测试正文。课程共 11 项，S8 共 8 项。暂停/EIO 和地址观察只在测试链接边界；不向 production 加 hook/getter。Direct 文件 fixture 使用实际设备对齐；本轮页 fixture 要求实际 offset 对齐能整除 4 KiB，不满足即失败，不假报跳过成功。

WSL2 上 ASan/TSan 的地址布局可能导致进程启动失败。可为该进程使用 `--no-aslr`（run_pages）或外层 `setarch x86_64 -R`（run_stage）；不改系统配置。不计启动失败、超时、编译失败为通过或变异检出。LSan 需要正常允许退出检查的环境；TCP 需要本机 socket 权限。网络场景运行时避免同时编译，否则混入非测试自身的 CPU 压力；不得因此放宽原超时。

ThreadSanitizer 另建目录，并保持链接/编译 sanitizer 一致：

```bash
cmake -S . -B /tmp/f26-thread -DCMAKE_BUILD_TYPE=Debug -DCMAKE_CXX_COMPILER=clang++-14 -DCMAKE_C_COMPILER=clang-14 -DBUSTUB_SANITIZER=thread -DCMAKE_EXE_LINKER_FLAGS=-no-pie
cmake --build /tmp/f26-thread --target bustub gmock_main -j 4
python3 /tmp/F26-array-buffer-pool/run_pages.py --repo "$PWD" --build /tmp/f26-thread --out /tmp/f26-thread-pages --sanitizer thread --no-aslr
setarch x86_64 -R python3 /tmp/F26-array-buffer-pool/run_stage.py --repo "$PWD" --out /tmp/f26-thread-foundation --sanitizer thread
```

本轮 d 已接入 PathCache 和实际 RAM 归还；后续 e 接管真实预取；F36 接管页内空间及安全释放。基础四项仅保护组件自己的并发/资源契约，不冒充业务 E2E。共同 C/P 输入未修改、未在本阶段重跑；本轮也不是裸设备、物理掉电、非 Linux 或性能验收。每次测试变更仍须八项审查，整个 F26 包原位替换，删除旧结果包；不常驻展开的阶段测试。

本轮新增一项实际 RAM 归还/重新物化场景，旧 Sparse、SharedLoad、Entry 场景补强而不复制。三线程紧预算时目录可能拒绝本次申请，按既有 bad_alloc/未接纳语义有时限重试同一页；不能跳过正文判断。串行压力不容忍 bad_alloc；一次实际 madvise ENOMEM 必须明确上报且随后可用。真实 mincore 观察不是内部计数或进程 RSS，累计归还事件可能重复同一组，不是净内存收益。

初次 root-alias 变异改点错误导致 sanitizer 退出，不计检出；修正为共用页号解码后由正文断言发现。初次 TSan 暴露测试对紧预算并发拒绝的错误预期；先代码/堆栈分析，再修正判据并重跑。失败诊断保存在结果包 history/，没有旧错误源码压缩包。最终结果分列阶段 10 项、课程/S8 19 项、20 个定向变异；重复运行和 TSan 不增加场景数。

本轮再次复审修复了批量准备失败遗漏帧收尾的问题。现有 RAM 场景用测试侧 PreparationFault 包装原 PageStorage，第三项准备抛错；真实 Read/Write 仍走 FilePageStorage/DiskManager。随后同时保留另外三页，逐字节比较正文，验证所有帧仍可用；无生产 hook 或 pin getter。新 leak-prepared-batch 变异必须由“failed batch retained a frame”断言检出，不能用超时算通过。基础 4 项/9 个变异的源码及被测 RAM 组件未改，保留原证据；本轮重新运行页 6 项、课程/S8 19 项和页 11 个变异。并发检查结果以当前结果包为准，不将旧页验证冒充修复后的验证。
