# F26 / S9.1e 测试恢复

当前唯一 F26 源码包。基础 RAM 4 项、真实页/SQL 9 项，基础变异 9 个、页/查询变异 16 个；课程 11 项、S8 8 项沿用既有源码。32 个不同场景，不把 TSan 或重复运行增加到总数。基线 `4e9fc47`，精确生产/测试/依赖哈希见 MANIFEST；执行与八项设计审查见 `docs/storage_redesign/s9e_execution_20261005.md`。

先在隔离 checkout 恢复相同生产版本，不覆盖后续开发树。结果包 `test-results/storage-f26-s9e-20261005/F26-results.tar.gz` 仅本机保存，不随 Git；包内 source/ 保存本轮生产及方案快照。仅 clone 不能获得本机结果包。

在仓库外解压，所有输出使用新目录，不混用旧证据：

```bash
tar -xzf test/archives/F26-array-buffer-pool.tar.gz -C /tmp
python3 /tmp/F26-array-buffer-pool/run_stage.py --repo "$PWD" --out /tmp/f26-foundation --mutations
cmake -S . -B /tmp/f26-build -DCMAKE_BUILD_TYPE=Debug -DCMAKE_CXX_COMPILER=clang++-14 -DCMAKE_C_COMPILER=clang-14 -DBUSTUB_SANITIZER=address,undefined -DCMAKE_EXE_LINKER_FLAGS=-no-pie
cmake --build /tmp/f26-build --target bustub buffer_pool_manager_test page_guard_test lru_k_replacer_test disk_scheduler_test -j2
python3 /tmp/F26-array-buffer-pool/run_pages.py --repo "$PWD" --build /tmp/f26-build --out /tmp/f26-pages --regressions --mutations --no-aslr
```

并发检查需同 sanitizer 的独立构建：

```bash
cmake -S . -B /tmp/f26-thread -DCMAKE_BUILD_TYPE=Debug -DCMAKE_CXX_COMPILER=clang++-14 -DCMAKE_C_COMPILER=clang-14 -DBUSTUB_SANITIZER=thread -DCMAKE_EXE_LINKER_FLAGS=-no-pie
cmake --build /tmp/f26-thread --target bustub gmock_main -j2
python3 /tmp/F26-array-buffer-pool/run_pages.py --repo "$PWD" --build /tmp/f26-thread --out /tmp/f26-thread-pages --sanitizer thread --no-aslr
setarch x86_64 -R python3 /tmp/F26-array-buffer-pool/run_stage.py --repo "$PWD" --out /tmp/f26-thread-foundation --sanitizer thread
```

`--no-aslr` / setarch 只改变子进程，适用于本机 WSL sanitizer 地址布局；不改系统设置。LSan 需要允许退出线程检查的环境；S8 TCP 需要本机 socket。编译失败、启动失败、超时、sanitizer 崩溃不计通过或变异检出。Direct fixture 查询真实对齐，要求该测试环境 offset 对齐能整除数据库页；不满足即失败，不假报跳过。

run_pages --regressions 只在测试侧解压/适配 S8 的对象页部署和预算（含预取额度），原 SQL/业务输入/断言/超时不变；S5 仅复用 fixture。没有复制第二份 S8 测试正文。SQL 新场景通过既有 BusTubInstance 组装点接入真实对象页，是 integration；正式节点恢复继续由 S8 证明。F36 若改变 DeletePage 的磁盘释放含义，须替换 SQL fixture 的冷缓存 setup，保持业务输入与 oracle，不能删除持久页后再声称验证冷读取。

暂停和 EIO 只在测试链接处，真实读写仍走生产路径。关闭变异的清理要排空真实节点 IO 再销毁帧；不能把挂起算检出。预取只占空闲/干净帧；共享 F02 额度为同等大小需求请求留余量。Capacity=3 页的场景暂停两项预取，第三项拒绝，同时正常读取前进；它不是吞吐测试。

结果包当前 runs/review-asan 保存最终 9 项页测试及 16 个断言变异，runs/asan-final 保存原课程/S8 19 项；runs/foundation-asan 保存 4 项与 9 个断言变异；runs/review-tsan 和 runs/foundation-thread 保存 13 项并发检查。history 只保存初次 fixture/编译/运行环境问题诊断，不当通过证据。无旧错误测试包。

阶段代码只压缩归档，不挂默认 CTest。共同 C/P 内容未改、未重跑；不代表裸设备、物理掉电、跨机或性能收益。S9.1a–e 已完成，F36 和 S10–S13 未执行。未来真实 E2E 接管同一触发/判据后可简化阶段证据，不永久复制小测试。

2026-10-05 再次复审：SQL 场景分别核验点查与全扫描的实际预取，完整比较预期记录集合。原整体 query 变异替换为两个分支变异，当前总计 25。生产未改；本轮重跑页 9、TSan 9、页变异 16；其余未改动基础/课程/S8 证据沿用并校验。见执行审查 §9。
