#!/usr/bin/env python3
"""Actual A short-read lifecycle and tree lookup; B/version regressions are reused separately."""
import argparse, pathlib, subprocess, json, os, time, xml.etree.ElementTree as ET
p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--build',required=True);p.add_argument('--out',required=True);p.add_argument('--compiler',required=True);p.add_argument('--sanitizer',default='');p.add_argument('--bench',action='store_true');a=p.parse_args()
r=pathlib.Path(a.repo).resolve();b=pathlib.Path(a.build).resolve();out=pathlib.Path(a.out).resolve();pkg=pathlib.Path(__file__).resolve().parent
out.mkdir(parents=True,exist_ok=False);commands=[]
env={k:v for k,v in os.environ.items() if not k.startswith('GTEST_')};env.update(ASAN_OPTIONS='detect_leaks=1:abort_on_error=1',TSAN_OPTIONS='halt_on_error=1')
def run(cmd,name,timeout=180):
 start=time.monotonic()
 with (out/(name+'.log')).open('w') as f:q=subprocess.run(list(map(str,cmd)),cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
 commands.append(dict(command=list(map(str,cmd)),returncode=q.returncode,seconds=time.monotonic()-start));(out/'commands.json').write_text(json.dumps(commands,indent=2))
 if q.returncode:raise RuntimeError((name,q.returncode))
flags=[a.compiler,'-std=c++17','-O2','-g','-pthread']
if a.sanitizer:flags+=['-fsanitize='+a.sanitizer,'-fno-omit-frame-pointer','-fno-pie','-no-pie']
flags+=['-I'+str(r/d) for d in ['src/include','test/include','third_party','third_party/fmt/include','third_party/libfort/src','third_party/googletest/googletest/include']]
libs=[b/'lib'/('lib'+n+'.a') for n in ['bustub','bustub_murmur3','bustub_lz4','duckdb_pg_query',('fmtd' if (b/'lib/libfmtd.a').exists() else 'fmt'),'fort','gmock_main','gmock','gtest']]
run(flags+[pkg/'tests/short_read_test.cpp']+libs+['-o',out/'short-tests'],'compile')
run([out/'short-tests','--gtest_output=xml:'+str(out/'short.xml')],'tests')
cases=ET.parse(out/'short.xml').getroot().findall('.//testcase')
expected={'FailedRetirementPreservesGuardAndFencesBothReadPaths','CompletedTreeChangeInvalidatesTentativeLookupResult','PublishedBodySurvivesOrdinaryWriterAndPersistence','BudgetRefusalDrainsReaderBeforeReusingBody','DeleteAndCloseDrainActualShortReaders','PointQueriesDuringRootSplitsAndMergesKeepStableKeys','SmallCacheReloadsAndSeparatePoolsDoNotShareVersions'}
assert {c.get('name') for c in cases}==expected and len(cases)==len(expected)
assert all(c.get('status')=='run' and c.get('result')=='completed' and c.find('failure') is None and c.find('skipped') is None for c in cases)
if a.bench:
 run(flags+[pkg/'short_bench.cpp']+libs+['-o',out/'bench'],'bench-compile');run([out/'bench'],'bench',timeout=300)
(out/'summary.json').write_text(json.dumps(dict(tests=len(cases),failures=0,sanitizer=a.sanitizer,benchmark=a.bench),indent=2))
