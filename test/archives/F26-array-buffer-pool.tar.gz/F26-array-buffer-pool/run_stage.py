#!/usr/bin/env python3
"""Opt-in F26/b component validation. Does not edit the production tree."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess
import time
import xml.etree.ElementTree as ET


def check_mutation_result(path, rc, test, required_failures):
    cases = ET.parse(path).getroot().findall('.//testcase') if path.exists() else []
    if (rc != 1 or len(cases) != 1 or cases[0].get('name') != test
            or cases[0].get('classname') != 'F26Foundation' or cases[0].get('status') != 'run'
            or cases[0].find('skipped') is not None):
        raise SystemExit(f'Mutation did not run/fail as expected: {test}, exit={rc}')
    failures = [' '.join((failure.text or '').split()) for failure in cases[0].findall('failure')]
    # Match each expected assertion within one failure, not fragments from
    # unrelated errors elsewhere in the same test or diagnostic log.
    if not all(any(all(token in text for token in tokens) for text in failures)
               for tokens in required_failures):
        raise SystemExit(f'Mutation failed for an unexpected reason: {test}')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--compiler', default='g++')
    parser.add_argument('--sanitizer', choices=['address,undefined', 'thread'], default='address,undefined')
    parser.add_argument('--mutations', action='store_true')
    args = parser.parse_args()
    repo, out = args.repo.resolve(), args.out.resolve()
    package = Path(__file__).resolve().parent
    if out.exists():
        raise SystemExit('Use a new output directory; never silently reuse old evidence.')
    out.mkdir(parents=True)
    manifest_path = package / 'MANIFEST.json'
    if manifest_path.exists():
        manifest = json.loads(manifest_path.read_text())
        for base, key in [(repo, 'production_sha256'), (package, 'test_sha256')]:
            for path, expected in manifest[key].items():
                actual = hashlib.sha256((base / path).read_bytes()).hexdigest()
                if actual != expected:
                    raise SystemExit(f'Source mismatch: {base / path}')
    commands = []
    env = dict(os.environ)
    env['ASAN_OPTIONS'] = 'detect_leaks=1:abort_on_error=1'
    env['UBSAN_OPTIONS'] = 'halt_on_error=1:print_stacktrace=1'
    env['TSAN_OPTIONS'] = 'halt_on_error=1'

    def run(command, name, timeout=120):
        commands.append(shlex.join(map(str, command)))
        (out / 'commands.txt').write_text('\n'.join(commands) + '\n')
        with (out / f'{name}.log').open('w') as log:
            return subprocess.run(list(map(str, command)), stdout=log, stderr=subprocess.STDOUT,
                                  timeout=timeout, env=env).returncode

    flags = [args.compiler, '-std=c++23', '-pthread', '-g', '-O1', '-Wall', '-Wextra', '-Werror',
             f'-fsanitize={args.sanitizer}', '-fno-omit-frame-pointer', '-fno-pie',
             '-I', repo / 'src/include', '-I', repo / 'src/buffer',
             '-I', repo / 'third_party/googletest/googletest/include',
             '-I', repo / 'third_party/googletest/googletest']
    sources = [package / 'tests/foundation_test.cpp', repo / 'src/buffer/frame_arena.cpp',
               repo / 'src/buffer/translation_directory.cpp',
               repo / 'third_party/googletest/googletest/src/gtest-all.cc',
               repo / 'third_party/googletest/googletest/src/gtest_main.cc']
    objects = []
    for index, source in enumerate(sources):
        obj = out / f'object-{index}.o'
        if run(flags + ['-c', source, '-o', obj], f'compile-{index}') != 0:
            raise SystemExit(f'Compilation failed: {source}')
        objects.append(obj)

    def link(inputs, binary, name):
        command = [args.compiler, '-pthread', f'-fsanitize={args.sanitizer}', '-no-pie', *inputs,
                   '-Wl,--wrap=mmap', '-Wl,--wrap=munmap', '-Wl,--wrap=madvise', '-Wl,--wrap=_Znwm', '-o', binary]
        if run(command, name) != 0:
            raise SystemExit('Link failed')

    binary = out / 'foundation-test'
    link(objects, binary, 'link')
    started = time.monotonic()
    code = run([binary, f'--gtest_output=xml:{out / "stage.xml"}'], 'stage', 60)
    if code != 0:
        raise SystemExit(f'Stage failed (exit {code}); inspect stage.log. Not a pass/skip.')
    xml = ET.parse(out / 'stage.xml').getroot()
    expected = {'FrameBodiesGeometryAndAdvice',
                'ConcurrentFirstUsePublishesOneDirectory', 'FailureBudgetAndLazyInitialization',
                'EntryAccessSerializesChanges', 'ReadOnlyProbesStayZeroUntilMutationAndReturnAfterReclaim',
                'ReadersWritersAndReclaimerKeepPublishedMappings'}
    cases = xml.findall('.//testcase')
    if (int(xml.attrib['tests']) != len(expected) or int(xml.attrib['failures']) != 0
            or int(xml.attrib.get('disabled', 0)) != 0 or len(cases) != len(expected)
            or {case.attrib['name'] for case in cases} != expected
            or any(case.attrib.get('status') != 'run' or case.find('skipped') is not None for case in cases)):
        raise SystemExit('Unexpected stage coverage')
    report = {'stage_tests': 6, 'stage_failures': 0, 'stage_seconds': time.monotonic() - started,
              'sanitizer': args.sanitizer, 'scope': 'F26 zero-page and foundation production components; not SQL E2E',
              'mutations': []}
    # Exact replacements and expected assertion failures, not build failures or
    # timeout. Mutated files/objects live exclusively in this output directory.
    mutations = [
        ('eager-zero-probes', 2, 'return Open(page, false);', 'return Open(page, true);',
         'ReadOnlyProbesStayZeroUntilMutationAndReturnAfterReclaim',
         [('PrivateTranslationBytes(observe.state)', '0U', 'read-only probe privately backed translation pages')]),
        ('reclaim-active-reader', 2, 'if (r->group_.load() == &group)', 'if (false)',
         'ReadOnlyProbesStayZeroUntilMutationAndReturnAfterReclaim', [('held.Version()', 'before Which is:')]),
        ('skip-physical-reclaim', 2, 'madvise(memory_.Data() + index * page_bytes_, page_bytes_, MADV_DONTNEED)', '0',
         'ReadOnlyProbesStayZeroUntilMutationAndReturnAfterReclaim',
         [('PrivateTranslationBytes(observe.state)', '0U Which is: 0')]),
        ('unbudgeted-groups', 2, 'budget_->Take(page_bytes_);', '(void)page_bytes_;',
         'FailureBudgetAndLazyInitialization', [('Value of: full', 'Actual: false', 'Expected: true')]),
        ('no-entry-lock', 2, 'if (!write_) return;', 'return;', 'EntryAccessSerializesChanges',
         [('directory.Lookup(page).Frame()', 'workers*changes Which is: 9000')]),
        ('no-version-change', 2, '(((old >> 32) & kVersionMask) + 1) & kVersionMask',
         '(old >> 32) & kVersionMask', 'EntryAccessSerializesChanges',
         [('access.Version()', 'static_cast<uint32_t>(1 + workers * changes)', '9001')]),
        ('optional-cache-credit-failure', 2, 'if (charged) owner->budget_.Return(sizeof(PathCache));',
         'if (!charged) throw;\n      owner->budget_.Return(sizeof(PathCache));',
         'FailureBudgetAndLazyInitialization',
         [('Value of: failure', 'Expected: false', 'optional cache credit allocation prevented existing mapping work'),
          ('protected_directory.Lookup(protected_page).Frame()', '42')]),
        ('aliased-frame', 1, 'static_cast<size_t>(frame) * impl_->layout_.stride_',
         '(static_cast<size_t>(frame) / 2) * impl_->layout_.stride_', 'FrameBodiesGeometryAndAdvice',
         [('std::memcmp(arena.Frame(frame).data_, expected[frame].data(), page_bytes)', 'Expected equality')]),
    ]
    if args.mutations:
        for name, index, old, new, test, required_failures in mutations:
            source = sources[index].read_text()
            if source.count(old) != 1:
                raise SystemExit(f'Mutation drift: {name}')
            changed = out / f'{name}.cpp'
            changed.write_text(source.replace(old, new))
            obj = out / f'{name}.o'
            if run(flags + ['-c', changed, '-o', obj], f'{name}-compile') != 0:
                raise SystemExit(f'Mutation compile failure is not evidence: {name}')
            inputs = list(objects)
            inputs[index] = obj
            executable = out / name
            link(inputs, executable, f'{name}-link')
            result_xml = out / f'{name}.xml'
            rc = run([executable, f'--gtest_filter=F26Foundation.{test}',
                      f'--gtest_output=xml:{result_xml}'], name, 60)
            check_mutation_result(result_xml, rc, test, required_failures)
            report['mutations'].append({'name': name, 'test': test, 'assertion_detected': True,
                                        'required_failures': required_failures})
    (out / 'summary.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
