import pathlib,subprocess,os,json,xml.etree.ElementTree as E,time,argparse,tarfile
p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--build',required=True);p.add_argument('--out',required=True);p.add_argument('--compiler',required=True);a=p.parse_args()
r=pathlib.Path(a.repo).resolve();b=pathlib.Path(a.build).resolve();o=pathlib.Path(a.out).resolve();o.mkdir(parents=True,exist_ok=False);w=o
for archive in ['F32-metadata-cache','S5-journal-recycling']:
 with tarfile.open(r/'test/archives'/(archive+'.tar.gz')) as t:t.extractall(w/'reuse',filter='data')
env=dict(os.environ,LD_LIBRARY_PATH=str(r/'.cache/toolchains/gcc-16.2.0/lib64'),S5_WORKDIR=str(o))
commands=[]
def run(cmd,name,timeout=300):
 start=time.monotonic()
 with (o/(name+'.log')).open('w') as f:q=subprocess.run(list(map(str,cmd)),env=env,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
 commands.append(dict(command=list(map(str,cmd)),returncode=q.returncode,seconds=time.monotonic()-start));(o/'commands.json').write_text(json.dumps(commands,indent=2))
 assert q.returncode==0,(name,q.returncode)
def check(name):
 cases=E.parse(o/(name+'.xml')).getroot().findall('.//testcase');assert cases and all(c.get('status')=='run' and c.get('result')=='completed' and c.find('failure') is None and c.find('skipped') is None for c in cases);return len(cases)
# This harness imports the unchanged F32 fixture and original production tests.
compiler=a.compiler
flags=[compiler,'-std=c++17','-O2','-g','-pthread']+['-I'+str(p) for p in [w/'reuse',r/'src/include',r/'third_party',r/'third_party/fmt/include',r/'third_party/googletest/googletest/include',w/'reuse/S5-journal-recycling/test/storage_redesign']]
libs=[b/'lib'/('lib'+n+'.a') for n in ['bustub','bustub_lz4','bustub_murmur3','duckdb_pg_query','fmt','fort','gmock_main','gmock','gtest']]
run(flags+[w/'reuse/F32-metadata-cache/tests/cache_test.cpp',*libs,'-Wl,--wrap=_Znwm','-Wl,--wrap=pread','-Wl,--wrap=pwrite','-o',o/'cache'],'cache-compile')
run([o/'cache','--gtest_output=xml:'+str(o/'cache.xml')],'cache');counts={'cache':check('cache')};assert counts['cache']==11
for n in ['buffer_pool_manager_test','page_guard_test','b_plus_tree_insert_test','b_plus_tree_delete_test','b_plus_tree_concurrent_test','b_plus_tree_contention_test','bustub_state_machine_test']:
 run([b/'test'/n,'--gtest_output=xml:'+str(o/(n+'.xml'))],n);counts[n]=check(n)
(o/'summary.json').write_text(json.dumps(counts,indent=2));print(counts)
