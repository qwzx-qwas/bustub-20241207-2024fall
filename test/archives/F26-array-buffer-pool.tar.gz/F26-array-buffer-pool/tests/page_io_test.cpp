#include <atomic>
#include <condition_variable>
#include <cstring>
#include <future>
#include <mutex>
#include <set>
#include <thread>
#include "buffer/buffer_pool_manager.h"
#include "fixture.h"
#include "gtest/gtest.h"
#include "storage/disk/node_storage.h"
using namespace bustub;
using namespace s5;
using namespace std::chrono_literals;
namespace {
constexpr uint64_t DATA = 32 * MIB;
struct Boundary {
  enum class Kind { None, Read, Journal };
  std::mutex mutex;
  std::condition_variable cv;
  Kind kind{Kind::None};
  bool entered{false}, released{true};
  std::atomic<bool> fail_write{false}, fail_journal_reply{false}, journal_seen{false};
  std::vector<std::pair<off_t, const void *>> reads, writes;
  uint64_t event{0}, read_exit{0}, close_exit{0};
  void Reset() {
    std::lock_guard<std::mutex> lock(mutex);
    kind = Kind::None; entered = false; released = true;
    reads.clear(); writes.clear(); event = read_exit = close_exit = 0; fail_write = false; fail_journal_reply = false; journal_seen = false;
  }
  void Arm(Kind k) {
    std::lock_guard<std::mutex> lock(mutex);
    kind = k; entered = false; released = false;
  }
  auto Entered() -> bool {
    std::unique_lock<std::mutex> lock(mutex);
    return cv.wait_for(lock, 10s, [&] { return entered; });
  }
  void Release() {
    std::lock_guard<std::mutex> lock(mutex);
    released = true; cv.notify_all();
  }
  void Observe(bool write, off_t offset, const void *buffer) {
    std::unique_lock<std::mutex> lock(mutex);
    if (offset >= static_cast<off_t>(DATA)) { (write ? writes : reads).emplace_back(offset, buffer); }
    const bool hit = (kind == Kind::Read && !write && offset >= static_cast<off_t>(DATA)) ||
        (kind == Kind::Journal && write && offset >= static_cast<off_t>(8 * MIB) && offset < static_cast<off_t>(16 * MIB));
    if (hit && !entered) { entered = true; cv.notify_all(); cv.wait(lock, [&] { return released; }); }
  }
} boundary;
struct Tasks {
  std::vector<std::future<void>> tasks;
  template <class F> auto Start(F f) -> size_t {
    tasks.push_back(std::async(std::launch::async, std::move(f)));
    return tasks.size() - 1;
  }
  auto Ready(size_t i, std::chrono::milliseconds t = 10000ms) -> bool {
    return tasks[i].wait_for(t) == std::future_status::ready;
  }
  void Get(size_t i) { tasks[i].get(); }
  ~Tasks() {
    boundary.Release();
    for (auto &task : tasks) { if (task.valid()) { task.wait(); } }
  }
};
}  // namespace
extern "C" ssize_t __real_pread(int, void *, size_t, off_t);
extern "C" ssize_t __real_pwrite(int, const void *, size_t, off_t);
extern "C" ssize_t __wrap_pread(int fd, void *buffer, size_t n, off_t offset) {
  if (fcntl(fd, F_GETFL) & O_DIRECT) { boundary.Observe(false, offset, buffer); }
  const auto result = __real_pread(fd, buffer, n, offset);
  if ((fcntl(fd, F_GETFL) & O_DIRECT) && offset >= static_cast<off_t>(DATA)) {
    std::lock_guard<std::mutex> lock(boundary.mutex);
    boundary.read_exit = ++boundary.event; // Real device call has returned.
  }
  return result;
}
extern "C" ssize_t __wrap_pwrite(int fd, const void *buffer, size_t n, off_t offset) {
  if (fcntl(fd, F_GETFL) & O_DIRECT) {
    boundary.Observe(true, offset, buffer);
    if (boundary.fail_journal_reply && offset >= static_cast<off_t>(8*MIB) && offset < static_cast<off_t>(16*MIB)) {
      boundary.journal_seen = true;
    }
    if (offset >= static_cast<off_t>(DATA) && boundary.fail_write.exchange(false)) { errno = EIO; return -1; }
  }
  return __real_pwrite(fd, buffer, n, offset);
}
extern "C" int __real_fdatasync(int);
extern "C" int __wrap_fdatasync(int fd) {
  const auto result = __real_fdatasync(fd);
  if ((fcntl(fd,F_GETFL)&O_DIRECT) && result == 0 && boundary.journal_seen && boundary.fail_journal_reply.exchange(false)) {
    errno = EIO; return -1; // Durable bytes, but the caller loses confirmation.
  }
  return result;
}
namespace {
struct Harness {
  Image image;
  NodeStorageOptions options;
  std::shared_ptr<NodeStorage> node;
  ObjectPageOptions pages;
  std::shared_ptr<ObjectPageStorage> backend;
  std::unique_ptr<BufferPoolManager> cache;
  uint64_t space{0};
  BufferPoolOptions budget{8 * MIB, 2 * MIB, 4, false};
  Harness() {
    boundary.Reset();
    const int fd = open(image.path.c_str(), O_WRONLY);
    Require(fd >= 0 && ftruncate(fd, 64 * MIB) == 0, "image capacity"); close(fd);
    uint32_t unit;
    { BlockDevice probe(image.path, {});
      unit = std::lcm<uint64_t>(BUSTUB_PAGE_SIZE, probe.Info().offset_alignment_);
      Require(unit == BUSTUB_PAGE_SIZE, "this direct-frame fixture requires device alignment dividing database pages");
    }
    BootstrapIdentity id{}; id.storage_.fill(11); id.device_.fill(31);
    JournalIdentity journal{}; journal.fill(73);
    options = {image.path, {}, {3, 2048, 16 * MIB}, id, journal,
       {64ULL * unit, unit, 8192, MIB, 512, 2 * MIB, 8, 32, 4 * MIB},
       {1024, 4096, 16384, MIB}, {1, 1ms, 1000ms},
       ObjectStorageOptions{{unit, 64, 16 * MIB, 32 * MIB, 32, 4096, 65536},
                           {32, 512, MIB, 4096, 64}, {128,128,4096,32,8*MIB,64}, 2*MIB, 2*MIB},
       ObjectTransactionOptions{1, 2, 2 * BUSTUB_PAGE_SIZE, MIB, 1ms, 3600000ms},
       2 * BUSTUB_PAGE_SIZE};
    node = std::make_shared<NodeStorage>(options);
    node->Create({id, 64*MIB, {Range(2*MIB,4*MIB),Range(8*MIB,8*MIB),Range(DATA,32*MIB)}});
    auto registry = node->CreateObjectSpace(node->Objects());
    Require(registry.result_.outcome_ == JournalOutcome::Durable, "registry space");
    pages = {4, {*registry.space_, 5}};
    backend = ObjectPageStorage::Create(node, pages);
    space = backend->Space();
    cache = std::make_unique<BufferPoolManager>(8, backend, budget);
    for (size_t i = 0; i < 16; ++i) { cache->NewPage(); }
  }
  void Reopen() {
    cache.reset(); backend.reset(); node->Close(); node.reset();
    node = std::make_shared<NodeStorage>(options); node->Open();
    backend = ObjectPageStorage::Open(node, space, pages);
    cache = std::make_unique<BufferPoolManager>(8, backend, budget);
    cache->SetNextPageIdForRecovery(16);
  }
  void Cold() { cache.reset(); cache = std::make_unique<BufferPoolManager>(8, backend, budget); }
  void Put(page_id_t page, unsigned seed) {
    auto g = cache->WritePage(page); const auto bytes = Value(BUSTUB_PAGE_SIZE, seed);
    std::memcpy(g.GetDataMut(), bytes.data(), bytes.size());
  }
  void Check(page_id_t page, unsigned seed) {
    auto g = cache->ReadPage(page); const auto expected = Value(BUSTUB_PAGE_SIZE, seed);
    EXPECT_EQ(std::memcmp(g.GetData(), expected.data(), expected.size()), 0) << page;
  }
  auto ObjectBytes(page_id_t page) -> Bytes {
    auto read = node->ReadObject(node->Objects(), {space, 1 + static_cast<uint64_t>(page) / pages.pages_per_object_},
          (page % pages.pages_per_object_) * BUSTUB_PAGE_SIZE, BUSTUB_PAGE_SIZE);
    read.Wait(); Bytes bytes(BUSTUB_PAGE_SIZE); read.CopyTo(bytes.data(), bytes.size()); return bytes;
  }
  ~Harness() {
    boundary.Release(); boundary.fail_write = false; boundary.fail_journal_reply = false;
    cache.reset(); backend.reset();
    if (node) { try { node->Close(); } catch (...) {} }
  }
};
TEST(F26Pages, SparseRealFilePagesAndOpenedInstancesStayIndependent) {
  const auto root = std::filesystem::path(std::getenv("S5_WORKDIR")) / "sparse-pages.bustub";
  struct Cleanup { std::filesystem::path p; ~Cleanup() { std::filesystem::remove(p); std::filesystem::remove(p.replace_extension(".log")); } } clean{root};
  DiskManager disk(root);
  const std::vector<page_id_t> ids{19, 65536 + 19, (1 << 23) + 19, (1 << 23) + 65536 + 19};
  BufferPoolOptions budget{8*MIB, MIB, 3, false};
  auto pages = std::make_unique<BufferPoolManager>(3, FilePageStorage(&disk), budget);
  pages->SetNextPageIdForRecovery(ids.back()+1);
  for (size_t i=0; i<ids.size(); ++i) {
    auto g = pages->WritePage(ids[i]); auto bytes = Value(BUSTUB_PAGE_SIZE, 21+i);
    std::memcpy(g.GetDataMut(),bytes.data(),bytes.size());
  }
  pages->FlushAllPages();
  for (size_t i=0; i<ids.size(); ++i) {
    auto g = pages->ReadPage(ids[i]); auto bytes = Value(BUSTUB_PAGE_SIZE, 21+i);
    EXPECT_EQ(std::memcmp(g.GetData(),bytes.data(),bytes.size()),0);
  }
  auto old = pages->ReadPage(ids[2]);
  pages.reset();
  BufferPoolManager reopened(3, FilePageStorage(&disk), budget);
  { auto g = reopened.WritePage(ids[2]); std::memset(g.GetDataMut(), 63, BUSTUB_PAGE_SIZE); }
  reopened.FlushAllPages();
  auto expected = Value(BUSTUB_PAGE_SIZE,23);
  EXPECT_EQ(std::memcmp(old.GetData(),expected.data(),expected.size()),0);
  EXPECT_EQ(static_cast<unsigned char>(reopened.ReadPage(ids[2]).GetData()[37]),63);
}
TEST(F26Pages, DirectFramesBatchDurabilityAndUnchangedMiddlePage) {
  Harness h;
  for (page_id_t p=1; p<13; ++p) { h.Put(p, p+29); }
  h.cache->FlushAllPages();
  h.Put(1, 91); h.Put(3, 113);
  std::set<const void *> frames;
  { auto a=h.cache->ReadPage(1), b=h.cache->ReadPage(3); frames.insert(a.GetData()); frames.insert(b.GetData()); }
  boundary.Reset();
  h.cache->FlushAllPages();
  { std::lock_guard<std::mutex> lock(boundary.mutex);
    for (auto ptr : frames) {
      EXPECT_TRUE(std::any_of(boundary.writes.begin(),boundary.writes.end(),[&](auto v){return v.second==ptr;}));
    }
  }
  // Reopen through B and journal; input model, not the resident copy, is the oracle.
  h.Reopen(); boundary.Reset();
  for (page_id_t p=1; p<13; ++p) { h.Check(p, p==1?91:(p==3?113:p+29)); }
  h.Cold(); boundary.Reset();
  { auto g=h.cache->ReadPage(3); std::lock_guard<std::mutex> lock(boundary.mutex);
    ASSERT_EQ(boundary.reads.size(),1U); EXPECT_EQ(boundary.reads[0].second,g.GetData()); }
  h.Put(14,77); ASSERT_TRUE(h.cache->FlushPage(14)); h.Reopen(); h.Check(14,77);
}
TEST(F26Pages, SharedLoadIndependentProgressAndCloseDrain) {
  Harness h; h.Put(5,55); h.Put(9,99); h.cache->FlushAllPages(); h.Cold();
  boundary.Reset(); boundary.Arm(Boundary::Kind::Read);
  Tasks tasks;
  auto first=tasks.Start([&]{h.Check(5,55);});
  ASSERT_TRUE(boundary.Entered());
  auto same=tasks.Start([&]{h.Check(5,55);});
  auto other=tasks.Start([&]{h.Check(9,99);});
  ASSERT_TRUE(tasks.Ready(other)); tasks.Get(other);
  { std::lock_guard<std::mutex> lock(boundary.mutex);
    ASSERT_GE(boundary.reads.size(),2U);
    const auto first_offset=boundary.reads.front().first;
    EXPECT_EQ(std::count_if(boundary.reads.begin(),boundary.reads.end(),[&](auto r){return r.first==first_offset;}),1);
  }
  boundary.Release();
  for (auto i : {first,same}) { ASSERT_TRUE(tasks.Ready(i)); tasks.Get(i); }
  { std::lock_guard<std::mutex> lock(boundary.mutex);
    const auto offset=boundary.reads.front().first;
    EXPECT_EQ(std::count_if(boundary.reads.begin(),boundary.reads.end(),[&](auto r){return r.first==offset;}),1);
  }
  // Separate admitted-IO round: no racing not-yet-admitted waiter at Close.
  h.Cold(); h.Check(5,55); boundary.Reset(); boundary.Arm(Boundary::Kind::Read);
  auto pending=tasks.Start([&]{h.Check(9,99);});
  ASSERT_TRUE(boundary.Entered());
  auto close=tasks.Start([&]{
    h.cache->Close();
    std::lock_guard<std::mutex> lock(boundary.mutex);
    boundary.close_exit = ++boundary.event;
  });
  // Observe actual shutdown through an ordinary cached-page request. Merely
  // launching the close thread does not prove it has stopped admission.
  bool admission_stopped = false;
  const auto deadline = std::chrono::steady_clock::now() + 10s;
  while (!admission_stopped && std::chrono::steady_clock::now() < deadline) {
    try { h.Check(5,55); } catch (const std::runtime_error &) { admission_stopped = true; }
    if (!admission_stopped) { std::this_thread::yield(); }
  }
  ASSERT_TRUE(admission_stopped);
  EXPECT_FALSE(tasks.Ready(close,30ms)); // Auxiliary; event order below is the oracle.
  boundary.Release();
  for (auto i : {pending,close}) { ASSERT_TRUE(tasks.Ready(i)); tasks.Get(i); }
  {
    std::lock_guard<std::mutex> lock(boundary.mutex);
    EXPECT_GT(boundary.read_exit,0U);
    EXPECT_GT(boundary.close_exit,boundary.read_exit) << "Close returned before the admitted device read exited";
  }
  EXPECT_THROW(h.cache->ReadPage(9),std::runtime_error);
}
TEST(F26Pages, PublicationBoundaryKeepsSourceStableAndOtherPagesUsable) {
  Harness h; h.Put(5,51); h.cache->FlushAllPages(); h.Put(5,52);
  boundary.Arm(Boundary::Kind::Journal);
  Tasks tasks;
  auto flush=tasks.Start([&]{EXPECT_TRUE(h.cache->FlushPage(5));});
  ASSERT_TRUE(boundary.Entered());
  EXPECT_FALSE(tasks.Ready(flush,0ms));
  EXPECT_EQ(h.ObjectBytes(5),Value(BUSTUB_PAGE_SIZE,51));
  auto same_writer=tasks.Start([&]{h.Put(5,53);});
  auto other=tasks.Start([&]{h.Put(9,94); h.Check(9,94);});
  ASSERT_TRUE(tasks.Ready(other)); tasks.Get(other);
  EXPECT_FALSE(tasks.Ready(same_writer,0ms));
  boundary.Release();
  ASSERT_TRUE(tasks.Ready(flush)); tasks.Get(flush);
  ASSERT_TRUE(tasks.Ready(same_writer)); tasks.Get(same_writer);
  EXPECT_EQ(h.ObjectBytes(5),Value(BUSTUB_PAGE_SIZE,52));
  EXPECT_TRUE(h.cache->ReadPage(5).IsDirty());
  ASSERT_TRUE(h.cache->FlushPage(5)); h.Reopen(); h.Check(5,53);
}
TEST(F26Pages, FailedWritePreservesDirtyBodyAndAcknowledgedOldVersion) {
  Harness h; h.Put(7,71); h.cache->FlushAllPages(); h.Put(7,72);
  boundary.fail_write = true;
  EXPECT_THROW(h.cache->FlushPage(7),std::exception);
  h.Check(7,72); EXPECT_TRUE(h.cache->ReadPage(7).IsDirty());
  h.Reopen(); h.Check(7,71);
  h.Put(7,73);
  boundary.journal_seen = false; boundary.fail_journal_reply = true;
  EXPECT_THROW(h.cache->FlushPage(7), std::exception);
  EXPECT_FALSE(boundary.fail_journal_reply.load()) << "journal completion fault must actually fire";
  h.Check(7,73); EXPECT_TRUE(h.cache->ReadPage(7).IsDirty());
  h.Reopen(); h.Check(7,73); // The wrapper completed the real durability call before reporting EIO.
  // A permanently undersized deployment is rejected, not retried forever.
  h.cache.reset(); h.backend.reset(); h.node->Close();
  h.options.external_buffer_bytes_ = BUSTUB_PAGE_SIZE-1;
  h.node=std::make_shared<NodeStorage>(h.options); h.node->Open();
  EXPECT_THROW(ObjectPageStorage::Open(h.node,h.space,h.pages),std::invalid_argument);
}
} // namespace
