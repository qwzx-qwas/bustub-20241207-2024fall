#include <sys/mman.h>
#include <atomic>
#include <condition_variable>
#include <cstring>
#include <future>
#include <mutex>
#include <set>
#include <thread>
#include "buffer/buffer_pool_manager.h"
#include "common/bustub_instance.h"
#include "concurrency/transaction_manager.h"
#include "execution/execution_engine.h"
#include "recovery/checkpoint_manager.h"
#include "fixture.h"
#include "gtest/gtest.h"
#include "storage/disk/node_storage.h"
using namespace bustub;
using namespace s5;
using namespace std::chrono_literals;
namespace {
constexpr uint64_t DATA = 32 * MIB;
struct Boundary {
  enum class Kind { None, Read, Journal };
  std::mutex mutex;
  std::condition_variable cv;
  Kind kind{Kind::None};
  bool entered{false}, released{true};
  size_t block_reads{1}, blocked_reads{0};
  std::atomic<bool> fail_read{false}, fail_write{false}, fail_journal_reply{false}, journal_seen{false};
  std::vector<std::pair<off_t, const void *>> reads, writes;
  uint64_t event{0}, read_exit{0}, close_exit{0};
  void Reset() {
    std::lock_guard<std::mutex> lock(mutex);
    kind = Kind::None; entered = false; released = true;
    block_reads=1; blocked_reads=0; fail_read=false; reads.clear(); writes.clear(); event = read_exit = close_exit = 0; fail_write = false; fail_journal_reply = false; journal_seen = false;
  }
  void Arm(Kind k) {
    std::lock_guard<std::mutex> lock(mutex);
    kind = k; entered = false; released = false; blocked_reads=0;
  }
  auto Entered() -> bool {
    std::unique_lock<std::mutex> lock(mutex);
    return cv.wait_for(lock, 10s, [&] { return entered; });
  }
  void Release() {
    std::lock_guard<std::mutex> lock(mutex);
    released = true; cv.notify_all();
  }
  void Observe(bool write, off_t offset, const void *buffer) {
    std::unique_lock<std::mutex> lock(mutex);
    if (offset >= static_cast<off_t>(DATA)) { (write ? writes : reads).emplace_back(offset, buffer); }
    const bool hit = (kind == Kind::Read && !write && offset >= static_cast<off_t>(DATA)) ||
        (kind == Kind::Journal && write && offset >= static_cast<off_t>(8 * MIB) && offset < static_cast<off_t>(16 * MIB));
    cv.notify_all();
    if (hit && blocked_reads < block_reads) { ++blocked_reads; entered = true; cv.notify_all(); cv.wait(lock, [&] { return released; }); }
  }
} boundary;
struct MemoryObservation {
  std::mutex mutex;
  bool enabled{false}, fail_next{false};
  size_t successful{0}, failed{0}, actually_released{0};
  void Start() {
    std::lock_guard<std::mutex> lock(mutex);
    enabled = true; fail_next = false; successful = failed = actually_released = 0;
  }
  void Stop() { std::lock_guard<std::mutex> lock(mutex); enabled = fail_next = false; }
} memory;
struct MemoryScope {
  MemoryScope() { memory.Start(); }
  ~MemoryScope() { memory.Stop(); }
};
struct Tasks {
  std::vector<std::future<void>> tasks;
  template <class F> auto Start(F f) -> size_t {
    tasks.push_back(std::async(std::launch::async, std::move(f)));
    return tasks.size() - 1;
  }
  auto Ready(size_t i, std::chrono::milliseconds t = 10000ms) -> bool {
    return tasks[i].wait_for(t) == std::future_status::ready;
  }
  void Get(size_t i) { tasks[i].get(); }
  ~Tasks() {
    boundary.Release();
    for (auto &task : tasks) { if (task.valid()) { task.wait(); } }
  }
};
}  // namespace
extern "C" ssize_t __real_pread(int, void *, size_t, off_t);
extern "C" ssize_t __real_pwrite(int, const void *, size_t, off_t);
extern "C" ssize_t __wrap_pread(int fd, void *buffer, size_t n, off_t offset) {
  if (fcntl(fd, F_GETFL) & O_DIRECT) { boundary.Observe(false, offset, buffer); }
  if ((fcntl(fd,F_GETFL)&O_DIRECT) && offset>=static_cast<off_t>(DATA) && boundary.fail_read.exchange(false)) {
    std::lock_guard<std::mutex> lock(boundary.mutex); boundary.cv.notify_all(); errno=EIO; return -1;
  }
  const auto result = __real_pread(fd, buffer, n, offset);
  if ((fcntl(fd, F_GETFL) & O_DIRECT) && offset >= static_cast<off_t>(DATA)) {
    std::lock_guard<std::mutex> lock(boundary.mutex);
    boundary.read_exit = ++boundary.event; // Real device call has returned.
  }
  return result;
}
extern "C" ssize_t __wrap_pwrite(int fd, const void *buffer, size_t n, off_t offset) {
  if (fcntl(fd, F_GETFL) & O_DIRECT) {
    boundary.Observe(true, offset, buffer);
    if (boundary.fail_journal_reply && offset >= static_cast<off_t>(8*MIB) && offset < static_cast<off_t>(16*MIB)) {
      boundary.journal_seen = true;
    }
    if (offset >= static_cast<off_t>(DATA) && boundary.fail_write.exchange(false)) { errno = EIO; return -1; }
  }
  return __real_pwrite(fd, buffer, n, offset);
}
extern "C" int __real_madvise(void *, size_t, int);
extern "C" int __wrap_madvise(void *address, size_t length, int advice) {
  if (advice != MADV_DONTNEED) { return __real_madvise(address, length, advice); }
  std::lock_guard<std::mutex> lock(memory.mutex);
  if (!memory.enabled) { return __real_madvise(address, length, advice); }
  if (memory.fail_next) {
    memory.fail_next = false; ++memory.failed; errno = ENOMEM; return -1;
  }
  const auto os = static_cast<size_t>(sysconf(_SC_PAGESIZE));
  std::vector<unsigned char> before((length + os - 1) / os), after(before.size());
  const auto observed_before = mincore(address, length, before.data());
  const auto result = __real_madvise(address, length, advice);
  if (result == 0) {
    ++memory.successful;
    const auto observed_after = mincore(address, length, after.data());
    if (observed_before == 0 && observed_after == 0) {
      for (size_t i = 0; i < before.size(); ++i) {
        if ((before[i] & 1U) && !(after[i] & 1U)) { ++memory.actually_released; }
      }
    }
  }
  return result;
}
extern "C" int __real_fdatasync(int);
extern "C" int __wrap_fdatasync(int fd) {
  const auto result = __real_fdatasync(fd);
  if ((fcntl(fd,F_GETFL)&O_DIRECT) && result == 0 && boundary.journal_seen && boundary.fail_journal_reply.exchange(false)) {
    errno = EIO; return -1; // Durable bytes, but the caller loses confirmation.
  }
  return result;
}
namespace {
// Test-side fault at the existing page-backend planning boundary. Actual page
// IO still delegates to FilePageStorage/DiskManager; no production hook/API.
class PreparationFault final : public PageStorage {
 public:
  explicit PreparationFault(std::shared_ptr<PageStorage> backend) : backend_(std::move(backend)) {}
  auto MemoryAlignment() const -> size_t override { return backend_->MemoryAlignment(); }
  auto MaxBatchPages() const -> size_t override { return backend_->MaxBatchPages(); }
  auto WriteDomain(page_id_t page) const -> uint64_t override {
    if (fail_on_domain != 0 && --fail_on_domain == 0) { throw std::bad_alloc(); }
    return backend_->WriteDomain(page);
  }
  void EnsurePages(uint64_t count) override { backend_->EnsurePages(count); }
  void Read(const PageBuffer &b) override { backend_->Read(b); }
  auto Prefetch(const PageBuffer &b, std::function<void(std::exception_ptr)> complete) -> bool override {
    const bool accepted=backend_->Prefetch(b,std::move(complete));
    if (accepted) { ++prefetch_accepted; }
    return accepted;
  }
  std::atomic<size_t> prefetch_accepted{0};
  void Write(const std::vector<PageBuffer> &b) override { backend_->Write(b); }
  void Delete(page_id_t page) override { backend_->Delete(page); }
  mutable size_t fail_on_domain{0};  // Armed only outside concurrent readers.
 private:
  std::shared_ptr<PageStorage> backend_;
};
struct Harness {
  Image image;
  NodeStorageOptions options;
  std::shared_ptr<NodeStorage> node;
  ObjectPageOptions pages;
  std::shared_ptr<ObjectPageStorage> backend;
  std::unique_ptr<BufferPoolManager> cache;
  uint64_t space{0};
  BufferPoolOptions budget{8 * MIB, 2 * MIB, 4, false, 0};
  explicit Harness(size_t prefetch=0, size_t external_pages=2) {
    boundary.Reset();
    budget.prefetch_pages_=prefetch;
    const int fd = open(image.path.c_str(), O_WRONLY);
    Require(fd >= 0 && ftruncate(fd, 64 * MIB) == 0, "image capacity"); close(fd);
    uint32_t unit;
    { BlockDevice probe(image.path, {});
      unit = std::lcm<uint64_t>(BUSTUB_PAGE_SIZE, probe.Info().offset_alignment_);
      Require(unit == BUSTUB_PAGE_SIZE, "this direct-frame fixture requires device alignment dividing database pages");
    }
    BootstrapIdentity id{}; id.storage_.fill(11); id.device_.fill(31);
    JournalIdentity journal{}; journal.fill(73);
    options = {image.path, {}, {3, 2048, 16 * MIB}, id, journal,
       {64ULL * unit, unit, 8192, MIB, 512, 2 * MIB, 8, 32, 4 * MIB},
       {1024, 4096, 16384, MIB}, {1, 1ms, 1000ms},
       ObjectStorageOptions{{unit, 64, 16 * MIB, 32 * MIB, 32, 4096, 65536},
                           {32, 512, MIB, 4096, 64}, {128,128,4096,32,8*MIB,64}, 2*MIB, 2*MIB},
       ObjectTransactionOptions{1, 2, 2 * BUSTUB_PAGE_SIZE, MIB, 1ms, 3600000ms},
       external_pages * BUSTUB_PAGE_SIZE};
    node = std::make_shared<NodeStorage>(options);
    node->Create({id, 64*MIB, {Range(2*MIB,4*MIB),Range(8*MIB,8*MIB),Range(DATA,32*MIB)}});
    auto registry = node->CreateObjectSpace(node->Objects());
    Require(registry.result_.outcome_ == JournalOutcome::Durable, "registry space");
    pages = {4, {*registry.space_, 5}};
    backend = ObjectPageStorage::Create(node, pages);
    space = backend->Space();
    cache = std::make_unique<BufferPoolManager>(8, backend, budget);
    for (size_t i = 0; i < 16; ++i) { cache->NewPage(); }
  }
  void Reopen() {
    cache.reset(); backend.reset(); node->Close(); node.reset();
    node = std::make_shared<NodeStorage>(options); node->Open();
    backend = ObjectPageStorage::Open(node, space, pages);
    cache = std::make_unique<BufferPoolManager>(8, backend, budget);
    cache->SetNextPageIdForRecovery(16);
  }
  void Cold() { cache.reset(); cache = std::make_unique<BufferPoolManager>(8, backend, budget); }
  void Put(page_id_t page, unsigned seed) {
    auto g = cache->WritePage(page); const auto bytes = s5::Value(BUSTUB_PAGE_SIZE, seed);
    std::memcpy(g.GetDataMut(), bytes.data(), bytes.size());
  }
  void Check(page_id_t page, unsigned seed) {
    auto g = cache->ReadPage(page); const auto expected = s5::Value(BUSTUB_PAGE_SIZE, seed);
    EXPECT_EQ(std::memcmp(g.GetData(), expected.data(), expected.size()), 0) << page;
  }
  auto ObjectBytes(page_id_t page) -> Bytes {
    auto read = node->ReadObject(node->Objects(), {space, 1 + static_cast<uint64_t>(page) / pages.pages_per_object_},
          (page % pages.pages_per_object_) * BUSTUB_PAGE_SIZE, BUSTUB_PAGE_SIZE);
    read.Wait(); Bytes bytes(BUSTUB_PAGE_SIZE); read.CopyTo(bytes.data(), bytes.size()); return bytes;
  }
  ~Harness() {
    boundary.Release(); boundary.fail_write = false; boundary.fail_journal_reply = false;
    cache.reset(); backend.reset();
    if (node) { try { node->Close(); } catch (...) {} }
  }
};
TEST(F26Pages, SparseRealFilePagesAndOpenedInstancesStayIndependent) {
  const auto root = std::filesystem::path(std::getenv("S5_WORKDIR")) / "sparse-pages.bustub";
  struct Cleanup { std::filesystem::path p; ~Cleanup() { std::filesystem::remove(p); std::filesystem::remove(p.replace_extension(".log")); } } clean{root};
  DiskManager disk(root);
  const std::vector<page_id_t> ids{19, 65536 + 19, (1 << 23) + 19, (1 << 23) + 65536 + 19};
  BufferPoolOptions budget{8*MIB, MIB, 3, false, 0};
  auto pages = std::make_unique<BufferPoolManager>(3, FilePageStorage(&disk), budget);
  pages->SetNextPageIdForRecovery(ids.back()+1);
  for (size_t i=0; i<ids.size(); ++i) {
    auto g = pages->WritePage(ids[i]); auto bytes = s5::Value(BUSTUB_PAGE_SIZE, 21+i);
    std::memcpy(g.GetDataMut(),bytes.data(),bytes.size());
  }
  pages->FlushAllPages();
  for (size_t i=0; i<ids.size(); ++i) {
    auto g = pages->ReadPage(ids[i]); auto bytes = s5::Value(BUSTUB_PAGE_SIZE, 21+i);
    EXPECT_EQ(std::memcmp(g.GetData(),bytes.data(),bytes.size()),0);
  }
  auto old = pages->ReadPage(ids[2]);
  pages.reset();
  BufferPoolManager reopened(3, FilePageStorage(&disk), budget);
  { auto g = reopened.ReadPage(ids[2]); auto bytes = s5::Value(BUSTUB_PAGE_SIZE,23);
    ASSERT_EQ(std::memcmp(g.GetData(),bytes.data(),bytes.size()),0); }
  { auto g = reopened.WritePage(ids[2]); std::memset(g.GetDataMut(), 63, BUSTUB_PAGE_SIZE); }
  reopened.FlushAllPages();
  auto expected = s5::Value(BUSTUB_PAGE_SIZE,23);
  EXPECT_EQ(std::memcmp(old.GetData(),expected.data(),expected.size()),0);
  EXPECT_EQ(static_cast<unsigned char>(reopened.ReadPage(ids[2]).GetData()[37]),63);
}
TEST(F26Pages, DirectFramesBatchDurabilityAndUnchangedMiddlePage) {
  Harness h;
  for (page_id_t p=1; p<13; ++p) { h.Put(p, p+29); }
  h.cache->FlushAllPages();
  h.Put(1, 91); h.Put(3, 113);
  std::set<const void *> frames;
  { auto a=h.cache->ReadPage(1), b=h.cache->ReadPage(3); frames.insert(a.GetData()); frames.insert(b.GetData()); }
  boundary.Reset();
  h.cache->FlushAllPages();
  { std::lock_guard<std::mutex> lock(boundary.mutex);
    for (auto ptr : frames) {
      EXPECT_TRUE(std::any_of(boundary.writes.begin(),boundary.writes.end(),[&](auto v){return v.second==ptr;}));
    }
  }
  // Reopen through B and journal; input model, not the resident copy, is the oracle.
  h.Reopen(); boundary.Reset();
  for (page_id_t p=1; p<13; ++p) { h.Check(p, p==1?91:(p==3?113:p+29)); }
  h.Cold(); boundary.Reset();
  { auto g=h.cache->ReadPage(3); std::lock_guard<std::mutex> lock(boundary.mutex);
    ASSERT_EQ(boundary.reads.size(),1U); EXPECT_EQ(boundary.reads[0].second,g.GetData()); }
  h.Put(14,77); ASSERT_TRUE(h.cache->FlushPage(14)); h.Reopen(); h.Check(14,77);
}
TEST(F26Pages, SharedLoadIndependentProgressAndCloseDrain) {
  Harness h; h.Put(5,55); h.Put(9,99); h.cache->FlushAllPages(); h.Cold();
  boundary.Reset(); boundary.Arm(Boundary::Kind::Read);
  Tasks tasks;
  auto first=tasks.Start([&]{h.Check(5,55);});
  ASSERT_TRUE(boundary.Entered());
  auto same=tasks.Start([&]{h.Check(5,55);});
  auto other=tasks.Start([&]{h.Check(9,99);});
  ASSERT_TRUE(tasks.Ready(other)); tasks.Get(other);
  { std::lock_guard<std::mutex> lock(boundary.mutex);
    ASSERT_GE(boundary.reads.size(),2U);
    const auto first_offset=boundary.reads.front().first;
    EXPECT_EQ(std::count_if(boundary.reads.begin(),boundary.reads.end(),[&](auto r){return r.first==first_offset;}),1);
  }
  // Drive real request-boundary maintenance while page 5 is Loading. Its
  // translation group still owns live mappings and must not be punched out.
  for (size_t i = 0; i < 64; ++i) { h.Check(9,99); }
  boundary.Release();
  for (auto i : {first,same}) { ASSERT_TRUE(tasks.Ready(i)); tasks.Get(i); }
  { std::lock_guard<std::mutex> lock(boundary.mutex);
    const auto offset=boundary.reads.front().first;
    EXPECT_EQ(std::count_if(boundary.reads.begin(),boundary.reads.end(),[&](auto r){return r.first==offset;}),1);
  }
  // Separate admitted-IO round: no racing not-yet-admitted waiter at Close.
  h.Cold(); h.Check(5,55); boundary.Reset(); boundary.Arm(Boundary::Kind::Read);
  auto pending=tasks.Start([&]{h.Check(9,99);});
  ASSERT_TRUE(boundary.Entered());
  auto close=tasks.Start([&]{
    h.cache->Close();
    std::lock_guard<std::mutex> lock(boundary.mutex);
    boundary.close_exit = ++boundary.event;
  });
  // Observe actual shutdown through an ordinary cached-page request. Merely
  // launching the close thread does not prove it has stopped admission.
  bool admission_stopped = false;
  const auto deadline = std::chrono::steady_clock::now() + 10s;
  while (!admission_stopped && std::chrono::steady_clock::now() < deadline) {
    try { h.Check(5,55); } catch (const std::runtime_error &) { admission_stopped = true; }
    if (!admission_stopped) { std::this_thread::yield(); }
  }
  ASSERT_TRUE(admission_stopped);
  EXPECT_FALSE(tasks.Ready(close,30ms)); // Auxiliary; event order below is the oracle.
  boundary.Release();
  for (auto i : {pending,close}) { ASSERT_TRUE(tasks.Ready(i)); tasks.Get(i); }
  {
    std::lock_guard<std::mutex> lock(boundary.mutex);
    EXPECT_GT(boundary.read_exit,0U);
    EXPECT_GT(boundary.close_exit,boundary.read_exit) << "Close returned before the admitted device read exited";
  }
  EXPECT_THROW(h.cache->ReadPage(9),std::runtime_error);
}
TEST(F26Pages, PublicationBoundaryKeepsSourceStableAndOtherPagesUsable) {
  Harness h; h.Put(5,51); h.cache->FlushAllPages(); h.Put(5,52);
  boundary.Arm(Boundary::Kind::Journal);
  Tasks tasks;
  auto flush=tasks.Start([&]{EXPECT_TRUE(h.cache->FlushPage(5));});
  ASSERT_TRUE(boundary.Entered());
  EXPECT_FALSE(tasks.Ready(flush,0ms));
  EXPECT_EQ(h.ObjectBytes(5),s5::Value(BUSTUB_PAGE_SIZE,51));
  auto same_writer=tasks.Start([&]{h.Put(5,53);});
  auto other=tasks.Start([&]{h.Put(9,94); h.Check(9,94);});
  ASSERT_TRUE(tasks.Ready(other)); tasks.Get(other);
  EXPECT_FALSE(tasks.Ready(same_writer,0ms));
  boundary.Release();
  ASSERT_TRUE(tasks.Ready(flush)); tasks.Get(flush);
  ASSERT_TRUE(tasks.Ready(same_writer)); tasks.Get(same_writer);
  EXPECT_EQ(h.ObjectBytes(5),s5::Value(BUSTUB_PAGE_SIZE,52));
  EXPECT_TRUE(h.cache->ReadPage(5).IsDirty());
  ASSERT_TRUE(h.cache->FlushPage(5)); h.Reopen(); h.Check(5,53);
}
TEST(F26Pages, FailedWritePreservesDirtyBodyAndAcknowledgedOldVersion) {
  Harness h; h.Put(7,71); h.cache->FlushAllPages(); h.Put(7,72);
  boundary.fail_write = true;
  EXPECT_THROW(h.cache->FlushPage(7),std::exception);
  h.Check(7,72); EXPECT_TRUE(h.cache->ReadPage(7).IsDirty());
  h.Reopen(); h.Check(7,71);
  h.Put(7,73);
  boundary.journal_seen = false; boundary.fail_journal_reply = true;
  EXPECT_THROW(h.cache->FlushPage(7), std::exception);
  EXPECT_FALSE(boundary.fail_journal_reply.load()) << "journal completion fault must actually fire";
  h.Check(7,73); EXPECT_TRUE(h.cache->ReadPage(7).IsDirty());
  h.Reopen(); h.Check(7,73); // The wrapper completed the real durability call before reporting EIO.
  // A permanently undersized deployment is rejected, not retried forever.
  h.cache.reset(); h.backend.reset(); h.node->Close();
  h.options.external_buffer_bytes_ = BUSTUB_PAGE_SIZE-1;
  h.node=std::make_shared<NodeStorage>(h.options); h.node->Open();
  EXPECT_THROW(ObjectPageStorage::Open(h.node,h.space,h.pages),std::invalid_argument);
}
} // namespace

TEST(F26Pages, TranslationMemoryReclaimsReusesAndReportsOSFailure) {
  const auto root = std::filesystem::path(std::getenv("S5_WORKDIR")) / "translation-memory.bustub";
  struct Cleanup { std::filesystem::path p; ~Cleanup() { std::filesystem::remove(p); std::filesystem::remove(p.replace_extension(".log")); } } cleanup{root};
  MemoryScope observe;
  const auto os = static_cast<size_t>(sysconf(_SC_PAGESIZE));
  const size_t group_entries = os / 8;
  ASSERT_GT(group_entries,37U);
  const auto groups = (1U << 16) / group_entries;
  ASSERT_GE(groups,6U);
  DiskManager disk(root);
  auto backend=std::make_shared<PreparationFault>(FilePageStorage(&disk));
  BufferPoolManager pages(3,backend,{256*1024+3*os,MIB,3,false,0});
  std::vector<page_id_t> ids;
  for (size_t i=0; i<groups; ++i) { ids.push_back(static_cast<page_id_t>(65536+i*group_entries+37)); }
  pages.SetNextPageIdForRecovery(ids.back()+1);
  for (size_t i=0; i<ids.size(); ++i) {
    auto g=pages.WritePage(ids[i]); auto body=s5::Value(BUSTUB_PAGE_SIZE,31+i);
    std::memcpy(g.GetDataMut(),body.data(),body.size());
  }
  pages.FlushAllPages();
  { std::lock_guard<std::mutex> lock(memory.mutex); memory.fail_next=true; }
  size_t failures=0;
  for (size_t round=0; round<4; ++round) {
    for (size_t i=0; i<ids.size(); ++i) {
      for (;;) {
        try {
          auto g=pages.ReadPage(ids[i]); auto expected=s5::Value(BUSTUB_PAGE_SIZE,31+i);
          ASSERT_EQ(std::memcmp(g.GetData(),expected.data(),expected.size()),0) << ids[i];
          break;
        } catch (const std::system_error &e) {
          ASSERT_EQ(e.code().value(),ENOMEM); ASSERT_EQ(++failures,1U);
        }
      }
    }
  }
  // Concurrent real page reads repeatedly rematerialize/reclaim distinct groups.
  // CheckedReadPage exposes temporary frame/task pressure without treating it
  // as an IO success; bounded retry preserves the same independent body oracle.
  std::array<std::exception_ptr,3> errors{};
  std::vector<std::thread> readers;
  for (size_t worker=0;worker<errors.size();++worker) {
    readers.emplace_back([&,worker] {
      try {
        for (size_t n=0;n<2*ids.size();++n) {
          const auto i=(n+worker*17)%ids.size();
          const auto deadline=std::chrono::steady_clock::now()+10s;
          for (;;) {
            try {
              auto g=pages.CheckedReadPage(ids[i]);
              if (g) {
                const auto expected=s5::Value(BUSTUB_PAGE_SIZE,31+i);
                EXPECT_EQ(std::memcmp(g->GetData(),expected.data(),expected.size()),0) << ids[i];
                break;
              }
            } catch (const std::bad_alloc &) {
              // The bounded directory pressure pass does not wait for another
              // reclaimer. Admission can fail while its charge is still held.
              // No body check is waived: this exact page must succeed by the
              // same deadline; sequential pressure above rejects bad_alloc.
            }
            if (std::chrono::steady_clock::now()>=deadline) { throw std::runtime_error("page progress budget expired"); }
            std::this_thread::yield();
          }
        }
      } catch (...) { errors[worker]=std::current_exception(); }
    });
  }
  for (auto &reader:readers) { reader.join(); }
  for (auto error:errors) { if (error) { std::rethrow_exception(error); } }
  // Prime exactly three resident pages. Fail preparing the third member, after
  // earlier members were retained but before backend Write was called.
  for (size_t i=0;i<3;++i) { auto g=pages.ReadPage(ids[i]); }
  backend->fail_on_domain=3;
  EXPECT_THROW(pages.FlushAllPages(),std::bad_alloc);
  ASSERT_EQ(backend->fail_on_domain,0U) << "preparation fault must actually fire";
  {
    // Each successful read is kept pinned. All three cache frames must remain
    // usable; leaked preparation pins make a later checked read reject.
    std::vector<ReadPageGuard> held;
    for (size_t i=3;i<6;++i) {
      auto g=pages.CheckedReadPage(ids[i]);
      ASSERT_TRUE(g.has_value()) << "failed batch retained a frame";
      const auto expected=s5::Value(BUSTUB_PAGE_SIZE,31+i);
      EXPECT_EQ(std::memcmp(g->GetData(),expected.data(),expected.size()),0);
      held.push_back(std::move(*g));
    }
  }
  pages.FlushAllPages(); pages.Close(); // Failed admission/preparation must release their rights.
  {
    std::lock_guard<std::mutex> lock(memory.mutex);
    EXPECT_EQ(failures,1U); EXPECT_EQ(memory.failed,1U);
    EXPECT_GT(memory.successful,0U); EXPECT_GT(memory.actually_released,0U);
    std::cout << "translation reclaim calls=" << memory.successful
              << " observed OS pages returned=" << memory.actually_released << '\n';
  }
}

TEST(F26Pages, PrefetchSharesLoadsReservesDemandAndDrains) {
  Harness h(3,3);
  for (auto p : {1,5,9,13}) { h.Put(p,81+p); }
  h.cache->FlushAllPages(); h.Cold(); boundary.Reset();
  Tasks tasks; // releases paused IO before any owner can close on assertion failure
  boundary.Arm(Boundary::Kind::Read);
  { std::lock_guard<std::mutex> lock(boundary.mutex); boundary.block_reads=2; }
  const auto submit=tasks.Start([&]{h.cache->PrefetchPages({5,9,13});});
  ASSERT_TRUE(tasks.Ready(submit));tasks.Get(submit); // admission returns while real IO remains paused
  {
    std::unique_lock<std::mutex> lock(boundary.mutex);
    ASSERT_TRUE(boundary.cv.wait_for(lock,10s,[&]{return boundary.blocked_reads==2;}));
    EXPECT_EQ(boundary.reads.size(),2U); // third hint rejected to preserve shared IO capacity
  }
  const auto joined=tasks.Start([&]{h.Check(5,86);});
  const auto foreground=tasks.Start([&]{h.Check(1,82);});
  ASSERT_TRUE(tasks.Ready(foreground));tasks.Get(foreground); // independent demand uses reserved headroom
  {
    std::lock_guard<std::mutex> lock(boundary.mutex);
    EXPECT_EQ(boundary.reads.size(),3U); // joined page did not launch a second read
  }
  boundary.Release();
  ASSERT_TRUE(tasks.Ready(joined));tasks.Get(joined);
  h.Check(9,90);h.Check(13,94);
  // A fresh window with no active caller: Close must drain callback-owned tasks,
  // not merely count synchronous calls. No race about whether a demand call began.
  h.Cold();h.Check(1,82);boundary.Reset();boundary.Arm(Boundary::Kind::Read);
  {std::lock_guard<std::mutex> lock(boundary.mutex);boundary.block_reads=2;}
  h.cache->PrefetchPages({5,9});
  {std::unique_lock<std::mutex> lock(boundary.mutex);ASSERT_TRUE(boundary.cv.wait_for(lock,10s,[&]{return boundary.blocked_reads==2;}));}
  const auto closing=tasks.Start([&]{h.cache->Close();std::lock_guard<std::mutex> lock(boundary.mutex);boundary.close_exit=++boundary.event;});
  const auto deadline=std::chrono::steady_clock::now()+10s;
  for (;;) {
    try { h.cache->ReadPage(1); } catch (const std::runtime_error &) { break; }
    ASSERT_LT(std::chrono::steady_clock::now(),deadline);std::this_thread::yield();
  }
  EXPECT_FALSE(tasks.Ready(closing,0ms));
  boundary.Release();
  ASSERT_TRUE(tasks.Ready(closing));tasks.Get(closing);
  h.node->Close(); // also drain real IO during cleanup if a Close mutation returned early
  {std::lock_guard<std::mutex> lock(boundary.mutex);EXPECT_GT(boundary.close_exit,boundary.read_exit);}
  h.Reopen();h.Check(5,86);h.Check(9,90);h.Check(13,94); // refused hint leaves ordinary demand usable
  // Optional read-ahead must not write dirty victims to make room.
  h.cache.reset();auto tiny=h.budget;tiny.prefetch_pages_=1;
  h.cache=std::make_unique<BufferPoolManager>(2,h.backend,tiny);
  h.Put(1,121);h.Put(5,125);boundary.Reset();
  h.cache->PrefetchPages({9});
  {std::lock_guard<std::mutex> lock(boundary.mutex);EXPECT_TRUE(boundary.writes.empty());EXPECT_TRUE(boundary.reads.empty());}
  h.Check(1,121);h.Check(5,125);
}

TEST(F26Pages, PrefetchFailureIsObservedByDemand) {
  Harness h(2,4);h.Put(1,101);h.Put(5,105);h.cache->FlushAllPages();h.Cold();h.Check(1,101);
  boundary.fail_read=true;
  EXPECT_NO_THROW(h.cache->PrefetchPages({5}));
  h.Check(1,101); // unrelated already-resident record remains readable
  EXPECT_THROW(h.cache->ReadPage(5),std::exception); // actual consumer must observe the failed accepted IO
  EXPECT_FALSE(boundary.fail_read.load());
  h.Reopen();h.Check(5,105); // read-ahead never changed durable content
}

TEST(F26Pages, SqlIndexWindowsPreserveVisibilityAndResults) {
  Harness h(3,8);
  BusTubInstance db(8);
  // Use the existing public composition points before creating tables. This is
  // SQL integration, not a simulated DB or a substitute for S8 node assembly.
  db.checkpoint_manager_.reset();db.execution_engine_.reset();db.catalog_.reset();
  auto observed=std::make_shared<PreparationFault>(h.backend);
  h.cache.reset();
  db.buffer_pool_manager_=std::make_unique<BufferPoolManager>(8,observed,h.budget);
  db.buffer_pool_manager_->SetNextPageIdForRecovery(16);
  db.catalog_=std::make_unique<Catalog>(db.buffer_pool_manager_.get(),db.lock_manager_.get(),db.log_manager_.get());
  db.txn_manager_->catalog_=db.catalog_.get();
  db.execution_engine_=std::make_unique<ExecutionEngine>(db.buffer_pool_manager_.get(),db.txn_manager_.get(),db.catalog_.get());
  auto sql=[&](const std::string &text,Transaction *txn=nullptr) {
    StringVectorWriter writer;
    const bool ok=txn ? db.ExecuteSqlTxn(text,writer,txn) : db.ExecuteSql(text,writer);
    Require(ok,"SQL execution failed");return writer.values_;
  };
  sql("CREATE TABLE items(id INT, bucket INT, payload VARCHAR(800));");
  std::string insert="INSERT INTO items VALUES ";
  for (int i=0;i<36;++i) {
    if (i) { insert+=","; }
    insert+="("+std::to_string(i)+","+std::to_string(7+i%3)+",'"+std::string(650,char('a'+i%23))+"')";
  }
  sql(insert+";");sql("CREATE INDEX bucket_idx ON items(bucket);");
  auto explain=sql("EXPLAIN SELECT id FROM items WHERE bucket=7 ORDER BY id;");
  std::string plan;for (auto &row:explain) {for (auto &c:row) {plan+=c;}}
  ASSERT_NE(plan.find("IndexScan"),std::string::npos); // fixture actually selects the production consumer
  auto *old=db.txn_manager_->Begin(IsolationLevel::SNAPSHOT_ISOLATION);
  sql("UPDATE items SET bucket=9 WHERE id=3;");
  sql("DELETE FROM items WHERE id=6;");
  sql("INSERT INTO items VALUES (99,7,'new-record-body');");
  db.buffer_pool_manager_->FlushAllPages();
  const auto limit=db.buffer_pool_manager_->NewPage();
  auto cold=[&] {
    for (page_id_t p=16;p<limit;++p) { Require(db.buffer_pool_manager_->DeletePage(p),"cold-cache setup retained a page"); }
    observed->prefetch_accepted=0;
  };
  cold();
  auto earlier=sql("SELECT id FROM items WHERE bucket=7 OR bucket=7 ORDER BY id;",old);
  std::vector<std::vector<std::string>> expected;
  for (int i=0;i<36;i+=3) {expected.push_back({std::to_string(i)});}
  EXPECT_EQ(earlier,expected);
  EXPECT_GT(observed->prefetch_accepted.load(),0U) << "point lookup did not prefetch";
  EXPECT_TRUE(db.txn_manager_->Commit(old));
  auto current=sql("SELECT id FROM items WHERE bucket=7 ORDER BY id;");
  expected.clear();for(int i=0;i<36;i+=3){if(i!=3 && i!=6){expected.push_back({std::to_string(i)});}}
  expected.push_back({"99"});EXPECT_EQ(current,expected);
  auto full_plan=sql("EXPLAIN SELECT id,bucket FROM items ORDER BY bucket;");
  plan.clear();for(auto &row:full_plan){for(auto &c:row){plan+=c;}}
  ASSERT_NE(plan.find("IndexScan"),std::string::npos); // also exercise the full-index consumer
  cold();
  auto all=sql("SELECT id,bucket FROM items ORDER BY bucket;");
  std::set<std::pair<int,int>> actual_rows,expected_rows;
  for(int i=0;i<36;++i){if(i!=6){expected_rows.emplace(i,i==3?9:7+i%3);}}
  expected_rows.emplace(99,7);
  std::set<int> seen;int last=0;
  for (const auto &row:all) {
    ASSERT_EQ(row.size(),2U);const int id=std::stoi(row[0]),bucket=std::stoi(row[1]);
    EXPECT_TRUE(seen.insert(id).second);EXPECT_GE(bucket,last);last=bucket;
    actual_rows.emplace(id,bucket);
  }
  EXPECT_EQ(actual_rows,expected_rows); // complete independently derived set; tie order is unspecified
  EXPECT_GT(observed->prefetch_accepted.load(),0U) << "full index scan did not prefetch";
  db.buffer_pool_manager_->Close();
}

TEST(F26Pages, ConcurrentHitsAndEvictionKeepPageBodies) {
  const auto root = std::filesystem::path(std::getenv("S5_WORKDIR")) / "concurrent-lookup.bustub";
  struct Cleanup {
    std::filesystem::path p;
    ~Cleanup() { std::filesystem::remove(p); std::filesystem::remove(p.replace_extension(".log")); }
  } cleanup{root};
  DiskManager disk(root);
  const BufferPoolOptions budget{8 * MIB, 2 * MIB, 16, false, 0};
  constexpr size_t count = 64;
  {
    BufferPoolManager populate(8, FilePageStorage(&disk), budget);
    populate.SetNextPageIdForRecovery(19 + count * 113);
    for (size_t i = 0; i < count; ++i) {
      auto guard = populate.WritePage(19 + i * 113);
      const auto expected = s5::Value(BUSTUB_PAGE_SIZE, 31 + i);
      std::memcpy(guard.GetDataMut(), expected.data(), expected.size());
    }
    populate.FlushAllPages();
  }
  BufferPoolManager pages(8, FilePageStorage(&disk), budget);
  pages.SetNextPageIdForRecovery(19 + count * 113);
  std::promise<void> ready;
  auto start = ready.get_future().share();
  std::vector<std::future<void>> readers;
  for (size_t worker = 0; worker < 4; ++worker) readers.push_back(std::async(std::launch::async, [&, worker] {
    start.wait();
    for (size_t round = 0; round < 1000; ++round) {
      // Alternate shared hot hits and independent cold pages, with fixed inputs.
      const auto i = round % 3 ? (round * 17 + worker * 13) % count : 7;
      auto guard = pages.ReadPage(19 + i * 113);
      const auto expected = s5::Value(BUSTUB_PAGE_SIZE, 31 + i);
      EXPECT_EQ(std::memcmp(guard.GetData(), expected.data(), expected.size()), 0) << "page ordinal=" << i;
    }
  }));
  ready.set_value();
  for (auto &reader : readers) reader.get();
}
