#include <sys/mman.h>
#include <unistd.h>

#include <algorithm>
#include <array>
#include <atomic>
#include <cerrno>
#include <chrono>
#include <condition_variable>
#include <cstring>
#include <future>
#include <iostream>
#include <limits>
#include <map>
#include <mutex>
#include <optional>
#include <stdexcept>
#include <thread>
#include <vector>

#include "buffer/frame_arena.h"
#include "buffer/translation_directory.h"
#include "gtest/gtest.h"

namespace {
using namespace bustub; // NOLINT

// Only the test binary wraps OS calls. Production has no hooks or counters.
struct Hooks {
  std::mutex mutex;
  std::condition_variable cv;
  std::map<void *, size_t> mappings;
  int fail_map{0};
  int fail_nohuge{0};
  int fail_huge{0};
  bool nohuge_unavailable{false};
  bool supported_probe_pending{false};
  size_t rendezvous_bytes{0};
  int arrived{0};
  bool rendezvous_failed{false};
};
std::atomic<Hooks *> hooks{nullptr};

class HookScope {
public:
  HookScope() { hooks.store(&state); }
  ~HookScope() { hooks.store(nullptr); }
  Hooks state;
};

auto OsPage() -> size_t { return static_cast<size_t>(sysconf(_SC_PAGESIZE)); }

auto Pattern(int tag, size_t size) -> std::vector<char> {
  std::vector<char> result(size);
  for (size_t i = 0; i < size; ++i) {
    result[i] = static_cast<char>(1 + (i * 17 + tag * 31) % 251);
  }
  return result;
}

// Common barrier for test start; no sleep or production scheduling changes.
class Start {
public:
  explicit Start(int count) : remaining_(count) {}
  void Wait() {
    std::unique_lock lock(mutex_);
    if (--remaining_ == 0) {
      cv_.notify_all();
    } else {
      cv_.wait(lock, [&] { return remaining_ == 0; });
    }
  }

private:
  std::mutex mutex_;
  std::condition_variable cv_;
  int remaining_;
};
} // namespace

extern "C" auto __real_mmap(void *, size_t, int, int, int, off_t) -> void *;
extern "C" auto __real_munmap(void *, size_t) -> int;
extern "C" auto __real_madvise(void *, size_t, int) -> int;

extern "C" auto __wrap_mmap(void *address, size_t bytes, int prot, int flags,
                            int fd, off_t offset) -> void * {
  auto *state = hooks.load();
  if (state != nullptr) {
    std::lock_guard lock(state->mutex);
    if (state->fail_map > 0) {
      --state->fail_map;
      errno = ENOMEM;
      return MAP_FAILED;
    }
  }
  void *result = __real_mmap(address, bytes, prot, flags, fd, offset);
  if (state != nullptr && result != MAP_FAILED) {
    std::unique_lock lock(state->mutex);
    state->mappings.emplace(result, bytes);
    if (bytes == state->rendezvous_bytes && state->arrived < 2) {
      ++state->arrived;
      state->cv.notify_all();
      if (!state->cv.wait_for(lock, std::chrono::seconds(10),
                              [&] { return state->arrived == 2; })) {
        state->rendezvous_failed = true;
        state->cv.notify_all();
      }
    }
  }
  return result;
}

extern "C" auto __wrap_munmap(void *address, size_t bytes) -> int {
  const auto result = __real_munmap(address, bytes);
  if (result == 0) {
    if (auto *state = hooks.load(); state != nullptr) {
      std::lock_guard lock(state->mutex);
      state->mappings.erase(address);
    }
  }
  return result;
}

extern "C" auto __wrap_madvise(void *address, size_t bytes, int advice) -> int {
  if (auto *state = hooks.load(); state != nullptr) {
    std::lock_guard lock(state->mutex);
    if (advice == MADV_NOHUGEPAGE) {
      if (state->nohuge_unavailable) {
        errno = EINVAL;
        return -1;
      }
      if (bytes == 0 && state->supported_probe_pending) {
        state->supported_probe_pending = false;
        return 0;  // Model a supported advice whose actual mapping failed.
      }
    }
    auto &fail =
        advice == MADV_HUGEPAGE ? state->fail_huge : state->fail_nohuge;
    if (fail > 0) {
      --fail;
      state->supported_probe_pending = advice == MADV_NOHUGEPAGE;
      errno = EINVAL;
      return -1;
    }
  }
  return __real_madvise(address, bytes, advice);
}

namespace {

TEST(F26Foundation, FrameBodiesGeometryAndAdvice) {
  HookScope observe;
  // Non-divisible body sizes distinguish base alignment from slot alignment.
  for (const auto &geometry : std::array<std::pair<size_t, size_t>, 3>{
           std::pair<size_t, size_t>{4096, 512},
           {4103, 64},
           {8197, OsPage() * 3}}) {
    const auto [page_bytes, alignment] = geometry;
    {
      FrameArena arena({9, page_bytes, alignment, 4 * 1024 * 1024, false});
      ASSERT_EQ(arena.Layout().huge_page_advice_, HugePageAdvice::Disabled);
      std::vector<std::vector<char>> expected;
      for (frame_id_t frame = 0; frame < 9; ++frame) {
        const auto memory = arena.Frame(frame);
        ASSERT_EQ(reinterpret_cast<uintptr_t>(memory.data_) % alignment, 0U);
        ASSERT_EQ(memory.size_, page_bytes);
        ASSERT_GE(memory.capacity_, page_bytes);
        expected.push_back(Pattern(frame + 3, page_bytes));
        std::memcpy(memory.data_, expected.back().data(), page_bytes);
      }
      for (frame_id_t frame = 0; frame < 9; ++frame) {
        EXPECT_EQ(std::memcmp(arena.Frame(frame).data_, expected[frame].data(),
                              page_bytes),
                  0)
            << frame;
      }
      EXPECT_THROW(arena.Frame(9), std::out_of_range);
      EXPECT_THROW(arena.Frame(-1), std::out_of_range);
    }
    EXPECT_TRUE(observe.state.mappings.empty());
  }
  // Failure occurs before exposing an arena; later valid creation still works.
  EXPECT_THROW((FrameArena({9, 4096, 512, 4096, false})), std::bad_alloc);
  EXPECT_TRUE(observe.state.mappings.empty());
  // Unsupported advice must not disable the ordinary-memory path.
  observe.state.nohuge_unavailable = true;
  {
    FrameArena arena({3, 4103, 64, 1024 * 1024, false});
    EXPECT_EQ(arena.Layout().huge_page_advice_, HugePageAdvice::Disabled);
    const auto body = Pattern(23, 4103);
    std::memcpy(arena.Frame(1).data_, body.data(), body.size());
    EXPECT_EQ(std::memcmp(arena.Frame(1).data_, body.data(), body.size()), 0);
  }
  observe.state.nohuge_unavailable = false;
  EXPECT_TRUE(observe.state.mappings.empty());
  // Same errno on a supported kernel is a real failure, not a fallback.
  observe.state.fail_nohuge = 1;
  EXPECT_THROW((FrameArena({3, 4103, 64, 1024 * 1024, false})), std::system_error);
  EXPECT_TRUE(observe.state.mappings.empty());
  observe.state.fail_huge = 1;
  {
    FrameArena arena({3, 4096, 512, 1024 * 1024, true});
    ASSERT_EQ(observe.state.fail_huge, 0);
    EXPECT_EQ(arena.Layout().huge_page_advice_, HugePageAdvice::Unavailable);
    EXPECT_EQ(arena.Layout().advice_error_, EINVAL);
    const auto body = Pattern(19, 4096);
    std::memcpy(arena.Frame(2).data_, body.data(), body.size());
    EXPECT_EQ(std::memcmp(arena.Frame(2).data_, body.data(), body.size()), 0);
  }
  // Environment observation only: do not equate advice with actual huge pages.
  {
    FrameArena arena({1024, 4096, OsPage(), 8 * 1024 * 1024, true});
    for (frame_id_t frame = 0; frame < 1024; ++frame) {
      std::memset(arena.Frame(frame).data_, frame % 251 + 1, 4096);
    }
    const auto usage = arena.ObserveMemory();
    std::cout << "THP advice="
              << static_cast<int>(arena.Layout().huge_page_advice_)
              << " errno=" << arena.Layout().advice_error_;
    if (usage) {
      std::cout << " resident=" << usage->resident_bytes_
                << " huge=" << usage->anonymous_huge_page_bytes_;
    } else {
      std::cout << " usage=unknown";
    }
    std::cout << '\n';
  }
  EXPECT_TRUE(observe.state.mappings.empty());
}

TEST(F26Foundation, SparsePagesAndInstanceOwnership) {
  HookScope observe;
  constexpr std::array<page_id_t, 10> pages{
      17, 511, 512, 65535, 65536, 65541, 131077, 8388613, 16777221, 2147483647};
  {
    FrameArena arena({20, 4096, 512, 1024 * 1024, false});
    auto first = std::make_unique<TranslationDirectory>(
        TranslationDirectoryOptions{4 * 1024 * 1024});
    TranslationDirectory second({4 * 1024 * 1024});
    for (size_t i = 0; i < pages.size(); ++i) {
      const auto one = Pattern(static_cast<int>(i), 4096);
      const auto two = Pattern(static_cast<int>(i) + 20, 4096);
      std::memcpy(arena.Frame(i).data_, one.data(), one.size());
      std::memcpy(arena.Frame(i + 10).data_, two.data(), two.size());
      first->Access(pages[i]).SetFrame(static_cast<frame_id_t>(i));
      second.Access(pages[i]).SetFrame(static_cast<frame_id_t>(i + 10));
    }
    for (size_t i = 0; i < pages.size(); ++i) {
      auto access = first->Access(pages[i]);
      ASSERT_EQ(access.Frame(), i);
      const auto expected = Pattern(static_cast<int>(i), 4096);
      EXPECT_EQ(std::memcmp(arena.Frame(*access.Frame()).data_, expected.data(),
                            expected.size()),
                0);
      auto other = second.Access(pages[i]);
      ASSERT_EQ(other.Frame(), i + 10);
      const auto other_expected = Pattern(static_cast<int>(i) + 20, 4096);
      EXPECT_EQ(std::memcmp(arena.Frame(*other.Frame()).data_,
                            other_expected.data(), other_expected.size()),
                0);
    }
    {
      auto access = first->Access(65541);
      const auto old_version = access.Version();
      access.SetFrame(std::nullopt);
      EXPECT_FALSE(access.Frame());
      EXPECT_NE(access.Version(), old_version);
      access.SetFrame(0); // Real frame 0 must not be confused with no mapping.
      EXPECT_EQ(access.Frame(), 0);
    }
    {
      auto old_access = first->Access(65541);
      first.reset();
      TranslationDirectory replacement({1024 * 1024});
      EXPECT_FALSE(replacement.Access(65541).Frame());
      old_access.SetFrame(8);
      EXPECT_FALSE(replacement.Access(65541).Frame());
      auto moved = std::move(old_access);
      EXPECT_EQ(moved.Frame(), 8);
    }
    EXPECT_THROW(second.Access(-1), std::invalid_argument);
  }
  EXPECT_TRUE(observe.state.mappings.empty());
}

TEST(F26Foundation, ConcurrentFirstUsePublishesOneDirectory) {
  HookScope observe;
  const auto page = OsPage();
  observe.state.rendezvous_bytes = ((512 * 1024 + page - 1) / page) * page;
  {
    TranslationDirectory directory({1024 * 1024});
    // Same new leaf and group, distinct nonzero suffixes. Both candidates exist
    // before either can be published; construction races do not rely on luck.
    Start start(2);
    std::array<std::exception_ptr, 2> errors{};
    std::vector<std::thread> threads;
    for (int i = 0; i < 2; ++i) {
      threads.emplace_back([&, i] {
        start.Wait();
        try {
          directory.Access(25755675 + i).SetFrame(71 + i);
        } catch (...) {
          errors[i] = std::current_exception();
        }
      });
    }
    for (auto &thread : threads) {
      thread.join();
    }
    ASSERT_FALSE(observe.state.rendezvous_failed);
    ASSERT_EQ(observe.state.arrived, 2);
    for (const auto &error : errors) {
      ASSERT_FALSE(error);
    }
    EXPECT_EQ(directory.Access(25755675).Frame(), 71);
    EXPECT_EQ(directory.Access(25755676).Frame(), 72);
    // Only the published leaf's virtual mapping remains; a losing candidate is
    // not a second hidden directory. This assertion belongs to stage evidence.
    EXPECT_EQ(observe.state.mappings.size(), 1U);
  }
  EXPECT_TRUE(observe.state.mappings.empty());
}

TEST(F26Foundation, FailureBudgetAndLazyInitialization) {
  HookScope observe;
  const auto page = OsPage();
  observe.state.nohuge_unavailable = true;
  {
    TranslationDirectory ordinary({256 * 1024});
    ordinary.Access(8388621).SetFrame(37);
    EXPECT_EQ(ordinary.Access(8388621).Frame(), 37);
  }
  observe.state.nohuge_unavailable = false;
  EXPECT_TRUE(observe.state.mappings.empty());
  {
    TranslationDirectory directory({256 * 1024});
    // Repeated failures distinguish resource rollback from eventual exhaustion.
    for (int i = 0; i < 40; ++i) {
      observe.state.fail_map = 1;
      EXPECT_THROW(directory.Access(65541), std::system_error);
      ASSERT_EQ(observe.state.fail_map, 0);
      EXPECT_TRUE(observe.state.mappings.empty());
      observe.state.fail_nohuge = 1;
      EXPECT_THROW(directory.Access(65541), std::system_error);
      ASSERT_EQ(observe.state.fail_nohuge, 0);
      EXPECT_TRUE(observe.state.mappings.empty());
    }
    // One access fits; eager touching/charging a whole 512 KiB leaf cannot fit.
    directory.Access(65541).SetFrame(9);
    ASSERT_EQ(directory.Access(65541).Frame(), 9);
    ASSERT_EQ(observe.state.mappings.size(), 1U);
    const auto mapping = *observe.state.mappings.begin();
    std::vector<unsigned char> resident((mapping.second + page - 1) / page);
    ASSERT_EQ(mincore(mapping.first, mapping.second, resident.data()), 0);
    const auto materialized = std::count_if(resident.begin(), resident.end(),
                                            [](auto b) { return b & 1; });
    // Pages may be swapped out; the invariant is no eager touching of the
    // other groups, not a promise that this OS keeps one page resident.
    EXPECT_LE(materialized, 1);

    // A bounded budget must reject *new* groups, while old legal mappings work.
    std::vector<page_id_t> accepted;
    bool full = false;
    const auto entries_per_group = page / 8;
    for (size_t i = 1; i < 65536 / entries_per_group; ++i) {
      const auto id = static_cast<page_id_t>(65536 + i * entries_per_group + 5);
      try {
        directory.Access(id).SetFrame(100 + i);
        accepted.push_back(id);
      } catch (const std::bad_alloc &) {
        full = true;
        break;
      }
    }
    ASSERT_TRUE(full);
    ASSERT_FALSE(accepted.empty());
    EXPECT_EQ(directory.Access(65541).Frame(), 9);
    for (size_t i = 0; i < accepted.size(); ++i) {
      EXPECT_EQ(directory.Access(accepted[i]).Frame(), 101 + i);
    }
  }
  EXPECT_TRUE(observe.state.mappings.empty());
  // A subsequent legitimate owner can acquire and use its own resources.
  TranslationDirectory replacement({256 * 1024});
  replacement.Access(8388613).SetFrame(3);
  EXPECT_EQ(replacement.Access(8388613).Frame(), 3);
}

TEST(F26Foundation, EntryAccessSerializesChanges) {
  TranslationDirectory directory({1024 * 1024});
  constexpr page_id_t page = 131109;
  directory.Access(page).SetFrame(0);
  constexpr int workers = 6;
  constexpr int changes = 1500;
  Start start(workers);
  std::array<std::exception_ptr, workers> errors{};
  std::vector<std::thread> threads;
  for (int i = 0; i < workers; ++i) {
    threads.emplace_back([&, i] {
      start.Wait();
      try {
        for (int n = 0; n < changes; ++n) {
          auto access = directory.Access(page);
          const auto before = access.Frame().value();
          std::this_thread::yield();
          access.SetFrame(before + 1);
        }
      } catch (...) {
        errors[i] = std::current_exception();
      }
    });
  }
  for (auto &thread : threads) {
    thread.join();
  }
  for (const auto &error : errors) {
    ASSERT_FALSE(error);
  }
  auto access = directory.Access(page);
  EXPECT_EQ(access.Frame(), workers * changes);
  EXPECT_EQ(access.Version(), static_cast<uint32_t>(1 + workers * changes));
}
} // namespace
