#include <atomic>
#include <chrono>
#include <cstring>
#include <future>
#include <thread>
#include <vector>
#include "buffer/buffer_pool_manager.h"
#include "storage/index/b_plus_tree.h"
#include "storage/disk/disk_manager_memory.h"
#include "gtest/gtest.h"
#include "test_util.h"
using namespace std::chrono_literals;
namespace bustub {
namespace {
auto Pattern(unsigned seed) -> std::array<char, BUSTUB_PAGE_SIZE> {
  std::array<char, BUSTUB_PAGE_SIZE> result;
  for (size_t i=0; i<result.size(); ++i) result[i]=static_cast<char>((seed*71+i*19+i/31)%251);
  return result;
}
void Put(BufferPoolManager &pool, page_id_t page, const std::array<char,BUSTUB_PAGE_SIZE> &bytes) {
  auto write=pool.WritePage(page); std::memcpy(write.GetDataMut(),bytes.data(),bytes.size());
}
auto Key(int64_t n) -> GenericKey<8> { GenericKey<8> key; key.SetFromInteger(n); return key; }
}
TEST(F26Short, PublishedBodySurvivesOrdinaryWriterAndPersistence) {
  DiskManagerUnlimitedMemory disk;
  BufferPoolManager pool(4,&disk);
  auto page=pool.NewPage();auto old=Pattern(37),next=Pattern(91);
  Put(pool,page,old);{ auto guard=pool.ReadIndexPage(page); }
  std::promise<void> ready,release;
  auto released=release.get_future().share();
  auto reader=std::async(std::launch::async,[&] {
    bool matched=false;
    auto scope=pool.ShortRead();
    bool read=scope.Read(page,[&](const char *body) {
      ready.set_value();released.wait();matched=std::memcmp(body,old.data(),old.size())==0;
    });return read && matched;
  });
  ready.get_future().wait();
  auto writer=std::async(std::launch::async,[&]{Put(pool,page,next);});
  const bool overlapped=writer.wait_for(3s)==std::future_status::ready;
  bool new_read=false;
  if(overlapped) { auto scope=pool.ShortRead();new_read=scope.Read(page,[&](const char *body){EXPECT_EQ(std::memcmp(body,next.data(),next.size()),0);}); }
  release.set_value();writer.get();EXPECT_TRUE(reader.get());EXPECT_TRUE(overlapped);EXPECT_TRUE(new_read);
  pool.FlushAllPages();
  for(int i=0;i<12;++i) {auto p=pool.NewPage();Put(pool,p,Pattern(i));}
  {auto guard=pool.ReadPage(page);EXPECT_EQ(std::memcmp(guard.GetData(),next.data(),next.size()),0);}
}
TEST(F26Short, BudgetRefusalDrainsReaderBeforeReusingBody) {
  auto budget=std::make_shared<ResourceBudget>(ResourceBudgetOptions{2U<<20,4096,0});
  DiskManagerUnlimitedMemory disk;
  BufferPoolManager pool(2,FilePageStorage(&disk),{1U<<20,1U<<20,2,false,0,budget});
  auto p=pool.NewPage();auto old=Pattern(83),next=Pattern(17);Put(pool,p,old);
  {auto read=pool.ReadIndexPage(p);}
  std::promise<void> ready,release;auto released=release.get_future().share();
  auto reader=std::async(std::launch::async,[&] {
    auto scope=pool.ShortRead();bool equal=false;
    bool read=scope.Read(p,[&](const char *body){ready.set_value();released.wait();equal=std::memcmp(body,old.data(),old.size())==0;});
    return read && equal;
  });
  ready.get_future().wait();
  auto account=ResourceAccount::Create(budget);std::vector<ResourceCharge> pressure;
  while(account->Reserve(4096,false)) pressure.emplace_back(account,4096,false);
  std::promise<void> writing;
  auto writer=std::async(std::launch::async,[&]{writing.set_value();Put(pool,p,next);});
  writing.get_future().wait();
  auto status=writer.wait_for(100ms);
  release.set_value();writer.get();EXPECT_TRUE(reader.get());EXPECT_EQ(status,std::future_status::timeout);
  pressure.clear();{auto read=pool.ReadPage(p);EXPECT_EQ(std::memcmp(read.GetData(),next.data(),next.size()),0);}
}
TEST(F26Short, DeleteAndCloseDrainActualShortReaders) {
  DiskManagerUnlimitedMemory disk;BufferPoolManager pool(2,&disk);
  auto p=pool.NewPage();auto old=Pattern(71);Put(pool,p,old);{auto read=pool.ReadIndexPage(p);}
  std::promise<void> ready,release;auto released=release.get_future().share();
  auto reader=std::async(std::launch::async,[&]{auto scope=pool.ShortRead();bool equal=false;
    bool read=scope.Read(p,[&](const char *body){ready.set_value();released.wait();equal=std::memcmp(body,old.data(),old.size())==0;});return read&&equal;});
  ready.get_future().wait();
  auto deletion=std::async(std::launch::async,[&]{return pool.DeletePage(p);});
  auto early=deletion.wait_for(100ms);release.set_value();EXPECT_TRUE(reader.get());EXPECT_TRUE(deletion.get());EXPECT_EQ(early,std::future_status::timeout);
  auto q=pool.NewPage();Put(pool,q,Pattern(99));{auto read=pool.ReadIndexPage(q);}
  {auto scope=pool.ShortRead();EXPECT_FALSE(scope.Read(p,[](const char*){}));}
  std::promise<void> registered,exit;auto exiting=exit.get_future().share();
  auto scope_owner=std::async(std::launch::async,[&]{auto scope=pool.ShortRead();registered.set_value();exiting.wait();});
  registered.get_future().wait();auto close=std::async(std::launch::async,[&]{pool.Close();});
  auto closed_early=close.wait_for(100ms);exit.set_value();scope_owner.get();close.get();EXPECT_EQ(closed_early,std::future_status::timeout);
  auto after=pool.ShortRead();EXPECT_FALSE(after.Read(q,[](const char*){}));
}
TEST(F26Short, PointQueriesDuringRootSplitsAndMergesKeepStableKeys) {
  DiskManagerUnlimitedMemory disk;BufferPoolManager pool(256,&disk);
  auto schema=ParseCreateStatement("a bigint");GenericComparator<8> comparator(schema.get());
  BPlusTree<GenericKey<8>,RID,GenericComparator<8>> tree("short",pool.NewPage(),&pool,comparator,4,4);
  for(int k=11;k<100;k+=7) ASSERT_TRUE(tree.Insert(Key(k),RID(k*3,k+17)));
  std::atomic<bool> go{false};std::atomic<unsigned> errors{0};std::vector<std::thread> readers;
  for(int t=0;t<4;++t) readers.emplace_back([&,t]{while(!go.load())std::this_thread::yield();
    for(int round=0;round<1200;++round){int k=11+7*((round*5+t)%13);std::vector<RID> found;
      if(!tree.GetValue(Key(k),&found)||found.size()!=1||!(found[0]==RID(k*3,k+17)))++errors;
      found.clear();if(tree.GetValue(Key(12+7*((round+t)%13)),&found)||!found.empty())++errors;
    }});
  go=true;
  for(int round=0;round<5;++round){for(int k=200;k<370;++k) if(!tree.Insert(Key(k),RID(k,k+1)))++errors;for(int k=200;k<370;++k)tree.Remove(Key(k));}
  for(auto &reader:readers) reader.join();EXPECT_EQ(errors.load(),0U);
  for(int k=200;k<370;++k){std::vector<RID> found;EXPECT_FALSE(tree.GetValue(Key(k),&found));}
  pool.FlushAllPages();
}
TEST(F26Short, SmallCacheReloadsAndSeparatePoolsDoNotShareVersions) {
  auto schema=ParseCreateStatement("a bigint");GenericComparator<8> comparator(schema.get());
  DiskManagerUnlimitedMemory disk1,disk2;BufferPoolManager first(16,&disk1),second(16,&disk2);
  auto h1=first.NewPage(),h2=second.NewPage();
  BPlusTree<GenericKey<8>,RID,GenericComparator<8>> a("a",h1,&first,comparator,8,8),b("b",h2,&second,comparator,8,8);
  for(int k=100;k<400;++k){ASSERT_TRUE(a.Insert(Key(k),RID(k,1)));ASSERT_TRUE(b.Insert(Key(k),RID(k,2)));}
  for(int i=0;i<900;++i){int k=100+(i*73)%300;std::vector<RID>x,y;ASSERT_TRUE(a.GetValue(Key(k),&x));ASSERT_TRUE(b.GetValue(Key(k),&y));ASSERT_EQ(x.at(0),RID(k,1));ASSERT_EQ(y.at(0),RID(k,2));}
  first.FlushAllPages();second.FlushAllPages();
  BufferPoolManager reopened(16,&disk1);reopened.SetNextPageIdForRecovery(1000);
  BPlusTree<GenericKey<8>,RID,GenericComparator<8>> restored("a",h1,&reopened,comparator,8,8,BPlusTreeOpenMode::Open);
  for(int k=100;k<400;++k){std::vector<RID>x;ASSERT_TRUE(restored.GetValue(Key(k),&x));ASSERT_EQ(x.at(0),RID(k,1));}
}
namespace {
thread_local bool pause_point_reader = false;
struct CompareGate {
  std::atomic<bool> once{true};
  std::promise<void> reached, release;
  std::shared_future<void> released{release.get_future().share()};
};
struct GatedComparator {
  GenericComparator<8> compare;
  CompareGate *gate;
  auto operator()(const GenericKey<8> &a,const GenericKey<8> &b) const -> int {
    if(pause_point_reader && gate->once.exchange(false)) {gate->reached.set_value();gate->released.wait();}
    return compare(a,b);
  }
};
}
TEST(F26Short, CompletedTreeChangeInvalidatesTentativeLookupResult) {
  auto schema=ParseCreateStatement("a bigint");CompareGate gate;
  GatedComparator compare{GenericComparator<8>(schema.get()),&gate};
  DiskManagerUnlimitedMemory disk;BufferPoolManager pool(8,&disk);
  BPlusTree<GenericKey<8>,RID,GatedComparator> tree("validated",pool.NewPage(),&pool,compare,16,16);
  for(int k:{11,37,59})ASSERT_TRUE(tree.Insert(Key(k),RID(k,1)));
  auto reader=std::async(std::launch::async,[&]{pause_point_reader=true;std::vector<RID> found;
    bool exists=tree.GetValue(Key(37),&found);pause_point_reader=false;return std::make_pair(exists,found);});
  gate.reached.get_future().wait();
  auto writer=std::async(std::launch::async,[&]{tree.Remove(Key(37));return tree.Insert(Key(37),RID(370,2));});
  bool overlap=writer.wait_for(3s)==std::future_status::ready;
  gate.release.set_value();EXPECT_TRUE(writer.get());auto result=reader.get();
  ASSERT_TRUE(overlap);ASSERT_TRUE(result.first);ASSERT_EQ(result.second.size(),1U);EXPECT_EQ(result.second[0],RID(370,2));
}

namespace {
// Existing PageStorage seam: ordinary IO is real FilePageStorage; only the
// durable retirement operation fails. No production fault hook is needed.
class FailedRetirement : public PageStorage {
 public:
  explicit FailedRetirement(DiskManager *disk) : storage_(FilePageStorage(disk)) {}
  auto MemoryAlignment() const -> size_t override { return storage_->MemoryAlignment(); }
  auto MaxBatchPages() const -> size_t override { return storage_->MaxBatchPages(); }
  auto WriteDomain(page_id_t p) const -> uint64_t override { return storage_->WriteDomain(p); }
  void EnsurePages(uint64_t n) override { storage_->EnsurePages(n); }
  void Read(const PageBuffer &b) override { storage_->Read(b); }
  void Write(const std::vector<PageBuffer> &b) override { storage_->Write(b); }
  void Delete(page_id_t p) override { storage_->Delete(p); }
  auto SupportsRetirement() const -> bool override { return true; }
  void RetirePage(page_id_t, page_id_t, const std::array<char, BUSTUB_PAGE_SIZE> &) override {
    throw std::runtime_error("injected durable retirement failure");
  }
 private:
  std::shared_ptr<PageStorage> storage_;
};
}
TEST(F26Short, FailedRetirementPreservesGuardAndFencesBothReadPaths) {
  DiskManagerUnlimitedMemory disk;
  BufferPoolManager pool(4,std::make_shared<FailedRetirement>(&disk),{1U<<20,1U<<20,4,false,0});
  auto p=pool.NewPage(),link=pool.NewPage(),witness=pool.NewPage();
  auto old=Pattern(143),next=Pattern(61);
  Put(pool,p,old);Put(pool,link,Pattern(7));Put(pool,witness,Pattern(27));
  {auto read=pool.ReadIndexPage(p);}{auto read=pool.ReadIndexPage(witness);}
  std::promise<void> ready,release;auto released=release.get_future().share();
  auto reader=std::async(std::launch::async,[&] {
    auto scope=pool.ShortRead();bool equal=false;
    bool read=scope.Read(p,[&](const char *body){ready.set_value();released.wait();equal=std::memcmp(body,old.data(),old.size())==0;});
    return read && equal;
  });
  ready.get_future().wait();
  auto writer=std::async(std::launch::async,[&]{Put(pool,p,next);});
  bool copied=writer.wait_for(3s)==std::future_status::ready;
  release.set_value();writer.get();EXPECT_TRUE(reader.get());ASSERT_TRUE(copied);
  auto victim=pool.ReadPage(p);auto predecessor=pool.WritePage(link);
  const char *owned=victim.GetData();
  EXPECT_THROW(pool.RetirePage(victim,predecessor,Pattern(93)),std::runtime_error);
  EXPECT_EQ(victim.GetData(),owned);
  EXPECT_EQ(std::memcmp(victim.GetData(),next.data(),next.size()),0);
  EXPECT_THROW(pool.ReadPage(witness),std::runtime_error);
  auto after=pool.ShortRead();bool exposed=false;
  EXPECT_FALSE(after.Read(witness,[&](const char *){exposed=true;}));
  EXPECT_FALSE(exposed);
}

}
