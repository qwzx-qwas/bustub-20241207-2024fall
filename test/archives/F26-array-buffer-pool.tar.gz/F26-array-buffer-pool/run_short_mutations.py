#!/usr/bin/env python3
import argparse,pathlib,subprocess,shlex,json,os,tarfile
p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--build',required=True);p.add_argument('--out',required=True);p.add_argument('--compiler',required=True);a=p.parse_args()
r=pathlib.Path(a.repo).resolve();b=pathlib.Path(a.build).resolve();o=pathlib.Path(a.out).resolve();o.mkdir(parents=True,exist_ok=False);pkg=pathlib.Path(__file__).resolve().parent
cc=json.loads((b/'compile_commands.json').read_text());env={k:v for k,v in os.environ.items() if not k.startswith('GTEST_')};commands=[];summary=[]
def run(cmd,name):
 with (o/(name+'.log')).open('w') as f:q=subprocess.run(list(map(str,cmd)),cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
 commands.append(dict(command=list(map(str,cmd)),returncode=q.returncode));(o/'commands.json').write_text(json.dumps(commands,indent=2));return q.returncode
flags=[a.compiler,'-std=c++17','-pthread','-O2','-g']+['-I'+str(r/d) for d in ['src/include','src/buffer','test/include','third_party','third_party/fmt/include','third_party/libfort/src','third_party/googletest/googletest/include']]
libs=[b/'lib'/('lib'+n+'.a') for n in ['bustub','bustub_murmur3','bustub_lz4','duckdb_pg_query','fmt','fort','gmock_main','gmock','gtest']]
assert run(flags+['-c',pkg/'tests/short_read_test.cpp','-o',o/'test.o'],'compile-test')==0
mutations=[
 ('unfenced-short-read','src/buffer/buffer_pool_manager.cpp','state_->short_closed_.store(true);\n      state_->closed_ = true;','state_->closed_ = true;','FailedRetirementPreservesGuardAndFencesBothReadPaths'),
 ('overwrite-reader','src/buffer/buffer_pool_manager.cpp','if (!BodyHeld(old)) return;','return;','PublishedBodySurvivesOrdinaryWriterAndPersistence'),
 ('forget-publication','src/storage/page/page_guard.cpp','state_->PublishBody(*frame_);','(void)0;','PublishedBodySurvivesOrdinaryWriterAndPersistence'),
 ('early-recycle','src/buffer/buffer_pool_manager.cpp','while (BodyHeld(&f.bodies_[0]) || BodyHeld(&f.bodies_[1])) std::this_thread::yield();','/* missing reader drain */','DeleteAndCloseDrainActualShortReaders'),
 ('accept-stale-tree','src/include/storage/index/b_plus_tree_impl.h','if (complete && sequence_.load() == before)','if (complete)','CompletedTreeChangeInvalidatesTentativeLookupResult')]
for name,path,old,new,test in mutations:
 source=(r/path).read_text();assert source.count(old)==1;source=source.replace(old,new)
 if path.endswith('.h'):
  overlay=o/name/'include';target=overlay/'storage/index/b_plus_tree_impl.h';target.parent.mkdir(parents=True,exist_ok=True);target.write_text(source)
  obj=o/(name+'.o');assert run(flags[:1]+['-I'+str(overlay)]+flags[1:]+['-c',pkg/'tests/short_read_test.cpp','-o',obj],'compile-'+name)==0;objects=[obj]
 else:
  source=source.replace('../../buffer/buffer_pool_internal.h',str(r/'src/buffer/buffer_pool_internal.h'))
  target=o/(name+'.cpp');target.write_text(source);obj=o/(name+'.o')
  cmd=shlex.split(next(x['command'] for x in cc if x['file']==str(r/path)));cmd[cmd.index('-o')+1]=str(obj);cmd[-1]=str(target);cmd+=['-I'+str(r/'src/buffer')]
  assert run(cmd,'compile-'+name)==0;objects=[o/'test.o',obj]
 exe=o/name/'run';exe.parent.mkdir(exist_ok=True)
 assert run(flags+objects+libs+['-o',exe],'link-'+name)==0
 result=run([exe,'--gtest_filter=F26Short.'+test],'run-'+name);log=(o/('run-'+name+'.log')).read_text()
 assert result==1 and ': Failure\n' in log and 'C++ exception' not in log and '[  FAILED  ] F26Short.'+test in log,(name,result)
 summary.append(dict(mutation=name,test=test,assertion_kill=True,returncode=result))
(o/'summary.json').write_text(json.dumps(summary,indent=2))
