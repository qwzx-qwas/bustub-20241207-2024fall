#!/usr/bin/env python3
"""F26/e real page path, RAM reclaim and query read-ahead validation; build flags must match --sanitizer."""
import argparse, os, pathlib, subprocess, tarfile, json, time, hashlib
import xml.etree.ElementTree as ET
p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--build',required=True);p.add_argument('--out',required=True);p.add_argument('--regressions',action='store_true');p.add_argument('--sanitizer',default='address,undefined');p.add_argument('--no-aslr',action='store_true');p.add_argument('--mutations',action='store_true')
a=p.parse_args();repo=pathlib.Path(a.repo).resolve();build=pathlib.Path(a.build).resolve();out=pathlib.Path(a.out).resolve();pkg=pathlib.Path(__file__).resolve().parent
manifest=pkg/'MANIFEST.json'
if manifest.exists():
    saved=json.loads(manifest.read_text())
    for base,key in [(repo,'production_sha256'),(pkg,'test_sha256'),(repo,'dependency_sha256')]:
        for file,digest in saved[key].items():
            if hashlib.sha256((base/file).read_bytes()).hexdigest()!=digest:raise SystemExit('Source mismatch: '+str(base/file))
out.mkdir(parents=True,exist_ok=False)
with tarfile.open(repo/'test/archives/S5-journal-recycling.tar.gz') as t:t.extractall(out,filter='data')
env={k:v for k,v in os.environ.items() if not k.startswith('GTEST_')};env.update(S5_WORKDIR=str(out),ASAN_OPTIONS='detect_leaks=1:abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1',TSAN_OPTIONS='halt_on_error=1')
commands=[]
def run(cmd,name,expected=0,timeout=240):
    start=time.monotonic()
    with (out/(name+'.log')).open('w') as f:r=subprocess.run(list(map(str,cmd)),env=env,cwd=out,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
    commands.append(dict(command=list(map(str,cmd)),exit=r.returncode,seconds=time.monotonic()-start));(out/'commands.json').write_text(json.dumps(commands,indent=2))
    if r.returncode!=expected:raise RuntimeError((name,r.returncode,expected))
def check(name,expected,fail=False):
    root=ET.parse(out/(name+'.xml')).getroot();cases=root.findall('.//testcase')
    assert len(cases)==expected and all(c.attrib.get('status')=='run' and c.find('skipped') is None for c in cases),(name,'coverage')
    assert sum(c.find('failure') is not None for c in cases)==(1 if fail else 0),(name,'assertion count')
flags=['clang++-14','-std=c++17','-pthread','-g','-O0','-Wall','-Wextra','-Werror','-Wno-unused-parameter','-Wno-attributes',f'-fsanitize={a.sanitizer}','-fno-omit-frame-pointer','-fno-pie']
flags+=['-I'+str(x) for x in [repo/'src/include',repo/'src/buffer',repo/'src/storage/disk',repo/'src/raft',repo/'third_party',repo/'third_party/libfort/src',repo/'third_party/fmt/include',repo/'third_party/googletest/googletest/include',out/'S5-journal-recycling/test/storage_redesign']]
libs=[build/'lib'/('lib'+n+'.a') for n in ['bustub','bustub_murmur3','duckdb_pg_query','fmtd','fort','gmock_main','gmock','gtest']]
wrap=['-Wl,--wrap=pread','-Wl,--wrap=pwrite','-Wl,--wrap=fdatasync','-Wl,--wrap=madvise']
run(flags+['-c',pkg/'tests/page_io_test.cpp','-o',out/'pages.o'],'pages-compile')
run(flags+['-no-pie',out/'pages.o']+libs+wrap+['-o',out/'pages'],'pages-link')
prefix=['setarch','x86_64','-R'] if a.no_aslr else []
run(prefix+[out/'pages','--gtest_output=xml:'+str(out/'pages.xml')],'pages');check('pages',9)
if a.regressions:
    for name,count in [('buffer_pool_manager_test',7),('page_guard_test',2),('lru_k_replacer_test',1),('disk_scheduler_test',1)]:
        run(prefix+[build/'test'/name,'--gtest_output=xml:'+str(out/(name+'.xml'))],name)
        check(name,count)
    with tarfile.open(repo/'test/archives/S8-raft-object-stores.tar.gz') as t:t.extractall(out,filter='data')
    s=(out/'S8-raft-object-stores/tests/object_stores_test.cpp').read_text()
    old='ObjectTransactionOptions{32, 128, MIB, 8 * MIB, 2ms, 10ms}};';new='ObjectTransactionOptions{32, 128, MIB, 8 * MIB, 2ms, 10ms}, 2 * MIB};'
    assert s.count(old)==1;s=s.replace(old,new)
    old='RaftObjectDeployment{h.options, h.space, Limits()}';new='RaftObjectDeployment{h.options, h.space, Limits(), PageCacheDeployment{4U, BufferPoolOptions{8*MIB, 2*MIB, 32, false, 3}}}'
    assert s.count(old)==1;s=s.replace(old,new)
    old='BusTubRaftStateMachine::Open(directory.get(), files, 64)';new='BusTubRaftStateMachine::OpenObjectPages(directory.get(), files, 64, {h.node, {4, {h.space, 5}}, {8*MIB,2*MIB,32,false,3}})'
    assert s.count(old)==2;s=s.replace(old,new)
    s=s.replace('ASSERT_EQ(last.status_, ClientResponseStatus::COMMITTED);',
      'ASSERT_EQ(last.status_, ClientResponseStatus::COMMITTED) << "term=" << last.term_ << " commit=" << last.commit_index_ << " applied=" << last.last_applied_ << " payload=" << std::string(reinterpret_cast<const char *>(last.payload_.data()), last.payload_.size());')
    adapted=out/'s8-adapted.cpp';adapted.write_text(s)
    run(flags+['-c',adapted,'-o',out/'s8.o'],'s8-compile')
    run(flags+['-no-pie',out/'s8.o']+libs+['-Wl,--wrap=pwrite','-Wl,--wrap=fdatasync','-o',out/'s8'],'s8-link')
    run(prefix+[out/'s8','--gtest_output=xml:'+str(out/'s8.xml')],'s8');check('s8',8)
if a.mutations:
    mutations=[
      ('prefetch-takes-demand-headroom','storage/disk/io_executor.cpp','const size_t share = read_ahead ? 2 : 1;', 'const size_t share = 1;', 'PrefetchSharesLoadsReservesDemandAndDrains'),
      ('hide-prefetch-read-error','buffer/buffer_pool_manager.cpp','f.phase_ = error ? FramePhase::Failed : FramePhase::Resident;', 'error = nullptr; f.phase_ = FramePhase::Resident;', 'PrefetchFailureIsObservedByDemand'),
      ('point-query-skips-prefetch','execution/index_scan_executor.cpp','      PrefetchWindow();', '      /* broken: point query skips its window */', 'SqlIndexWindowsPreserveVisibilityAndResults'),
      ('full-query-skips-prefetch','execution/index_scan_executor.cpp','    PrefetchWindow();\n    const auto &[entry_key', '    /* broken: full query skips its window */\n    const auto &[entry_key', 'SqlIndexWindowsPreserveVisibilityAndResults'),
      ('close-ignores-prefetch','buffer/buffer_pool_manager.cpp','state_->calls_ == 0 && state_->tasks_ == 0','state_->calls_ == 0','PrefetchSharesLoadsReservesDemandAndDrains'),
      ('leak-prepared-batch','buffer/buffer_pool_manager.cpp','error = std::current_exception();\n    }\n    for (auto *f : held)', 'if (buffers.size() == 2) { throw; }\n      error = std::current_exception();\n    }\n    for (auto *f : held)', 'TranslationMemoryReclaimsReusesAndReportsOSFailure'),
      ('stale-path-owner','buffer/translation_directory.cpp','cache_ && cache_->owner_.lock() != owner','cache_ && false','SparseRealFilePagesAndOpenedInstancesStayIndependent'),
      ('skip-live-check','buffer/translation_directory.cpp','!group.constructed_ || group.live_entries_.load(std::memory_order_relaxed) != 0','!group.constructed_','SharedLoadIndependentProgressAndCloseDrain'),
      ('no-ram-return','buffer/translation_directory.cpp','madvise(memory_.Data() + index * page_bytes_, page_bytes_, MADV_DONTNEED)','0','TranslationMemoryReclaimsReusesAndReportsOSFailure'),
      ('retain-physical-charge','buffer/translation_directory.cpp','budget_->Return(page_bytes_);\n    return true;','/* broken: charge survives reclaim */\n    return true;','TranslationMemoryReclaimsReusesAndReportsOSFailure'),
      ('close-without-drain','buffer/buffer_pool_manager.cpp','state_->changed_.wait(lock, [&] { return state_->calls_ == 0 && state_->tasks_ == 0; });','/* broken: stop admission but do not drain accepted work */','SharedLoadIndependentProgressAndCloseDrain'),
      ('middle-alias','buffer/translation_directory.cpp','const auto id = static_cast<uint32_t>(page);','const auto id = static_cast<uint32_t>(page) & ~0x7f0000U;','SparseRealFilePagesAndOpenedInstancesStayIndependent'),
      ('root-alias','buffer/translation_directory.cpp','const auto id = static_cast<uint32_t>(page);','const auto id = static_cast<uint32_t>(page) & 0x7fffffU;','SparseRealFilePagesAndOpenedInstancesStayIndependent'),
      ('wrong-page-offset','buffer/page_storage.cpp','(page % options_.pages_per_object_) * uint64_t{BUSTUB_PAGE_SIZE}','uint64_t{0}','DirectFramesBatchDurabilityAndUnchangedMiddlePage'),
      ('force-owned-copy','storage/disk/object_io.cpp','bool external = true;','bool external = false;','DirectFramesBatchDurabilityAndUnchangedMiddlePage'),
      ('clear-failed-dirty','buffer/buffer_pool_manager.cpp','if (!error) {\n        f->clean_version_', 'if (true) {\n        f->clean_version_','FailedWritePreservesDirtyBodyAndAcknowledgedOldVersion'),
    ]
    results=[]
    for name,file,old,new,test in mutations:
      s=(repo/'src'/file).read_text();assert s.count(old)==1,(name,'anchor')
      path=out/(name+'.cpp');path.write_text(s.replace(old,new))
      run(flags+['-c',path,'-o',out/(name+'.o')],name+'-compile')
      run(flags+['-no-pie',out/'pages.o',out/(name+'.o')]+libs+wrap+['-o',out/name],name+'-link')
      run(prefix+[out/name,'--gtest_filter=F26Pages.'+test,'--gtest_output=xml:'+str(out/(name+'.xml'))],name,expected=1)
      check(name,1,True);results.append(dict(name=name,test=test,result='assertion failure'))
    (out/'mutations.json').write_text(json.dumps(results,indent=2))
(out/'summary.json').write_text(json.dumps(dict(stage='S9.1e',page_tests=9,sanitizer=a.sanitizer,regressions=a.regressions,mutations=a.mutations),indent=2))
