#!/usr/bin/env python3
"""F26/e real page path, RAM reclaim and query read-ahead validation; build flags must match --sanitizer."""
import argparse, os, pathlib, subprocess, tarfile, json, time, hashlib, shlex
import xml.etree.ElementTree as ET
p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--build',required=True);p.add_argument('--compiler',default='g++');p.add_argument('--extra-cxxflags',default='');p.add_argument('--out',required=True);p.add_argument('--regressions',action='store_true');p.add_argument('--sanitizer',default='address,undefined');p.add_argument('--no-aslr',action='store_true')
a=p.parse_args();repo=pathlib.Path(a.repo).resolve();build=pathlib.Path(a.build).resolve();out=pathlib.Path(a.out).resolve();pkg=pathlib.Path(__file__).resolve().parent
manifest=pkg/'MANIFEST.json'
if manifest.exists():
    saved=json.loads(manifest.read_text())
    for base,key in [(repo,'production_sha256'),(pkg,'test_sha256'),(repo,'dependency_sha256')]:
        for file,digest in saved[key].items():
            if hashlib.sha256((base/file).read_bytes()).hexdigest()!=digest:raise SystemExit('Source mismatch: '+str(base/file))
out.mkdir(parents=True,exist_ok=False)
with tarfile.open(repo/'test/archives/S5-journal-recycling.tar.gz') as t:t.extractall(out,filter='data')
env={k:v for k,v in os.environ.items() if not k.startswith('GTEST_')};env.update(S5_WORKDIR=str(out),ASAN_OPTIONS='detect_leaks=1:abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1',TSAN_OPTIONS='halt_on_error=1')
commands=[]
def run(cmd,name,expected=0,timeout=240):
    start=time.monotonic()
    with (out/(name+'.log')).open('w') as f:r=subprocess.run(list(map(str,cmd)),env=env,cwd=out,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
    commands.append(dict(command=list(map(str,cmd)),exit=r.returncode,seconds=time.monotonic()-start));(out/'commands.json').write_text(json.dumps(commands,indent=2))
    if r.returncode!=expected:raise RuntimeError((name,r.returncode,expected))
def check(name,expected,fail=False):
    root=ET.parse(out/(name+'.xml')).getroot();cases=root.findall('.//testcase')
    assert len(cases)==expected and all(c.attrib.get('status')=='run' and c.find('skipped') is None for c in cases),(name,'coverage')
    assert sum(c.find('failure') is not None for c in cases)==(1 if fail else 0),(name,'assertion count')
flags=[a.compiler,'-std=c++17','-pthread','-g','-O0','-Wall','-Wextra','-Werror','-Wno-unused-parameter','-Wno-attributes',f'-fsanitize={a.sanitizer}','-fno-omit-frame-pointer','-fno-pie']
flags+=shlex.split(a.extra_cxxflags)
flags+=['-I'+str(x) for x in [repo/'src/include',repo/'src/buffer',repo/'src/storage/disk',repo/'src/raft',out/'S5-journal-recycling/test/storage_redesign']]
flags+=['-isystem'+str(x) for x in [repo/'third_party',repo/'third_party/libfort/src',repo/'third_party/fmt/include',repo/'third_party/googletest/googletest/include']]
libs=[build/'lib'/('lib'+n+'.a') for n in ['bustub','bustub_murmur3','bustub_lz4','duckdb_pg_query','fmtd','fort','gmock_main','gmock','gtest']]
wrap=['-Wl,--wrap=pread','-Wl,--wrap=pwrite','-Wl,--wrap=fdatasync','-Wl,--wrap=madvise']
run(flags+['-c',pkg/'tests/page_io_test.cpp','-o',out/'pages.o'],'pages-compile')
run(flags+['-no-pie',out/'pages.o']+libs+wrap+['-o',out/'pages'],'pages-link')
prefix=['setarch','x86_64','-R'] if a.no_aslr else []
run(prefix+[out/'pages','--gtest_output=xml:'+str(out/'pages.xml')],'pages');check('pages',10)
if a.regressions:
    for name,count in [('buffer_pool_manager_test',7),('page_guard_test',2),('lru_k_replacer_test',1),('disk_scheduler_test',1)]:
        run(prefix+[build/'test'/name,'--gtest_output=xml:'+str(out/(name+'.xml'))],name)
        check(name,count)
    with tarfile.open(repo/'test/archives/S8-raft-object-stores.tar.gz') as t:t.extractall(out,filter='data')
    s=(out/'S8-raft-object-stores/tests/object_stores_test.cpp').read_text()
    old='ObjectTransactionOptions{32, 128, MIB, 8 * MIB, 2ms, 10ms}};';new='ObjectTransactionOptions{32, 128, MIB, 8 * MIB, 2ms, 10ms}, 2 * MIB};'
    assert s.count(old)==1;s=s.replace(old,new)
    old='RaftObjectDeployment{h.options, h.space, Limits()}';new='RaftObjectDeployment{h.options, h.space, Limits(), PageCacheDeployment{4U, BufferPoolOptions{8*MIB, 2*MIB, 32, false, 3}}}'
    assert s.count(old)==1;s=s.replace(old,new)
    old='BusTubRaftStateMachine::Open(directory.get(), files, 64)';new='BusTubRaftStateMachine::OpenObjectPages(directory.get(), files, 64, {h.node, {4, {h.space, 5}}, {8*MIB,2*MIB,32,false,3}})'
    assert s.count(old)==2;s=s.replace(old,new)
    s=s.replace('ASSERT_EQ(last.status_, ClientResponseStatus::COMMITTED);',
      'ASSERT_EQ(last.status_, ClientResponseStatus::COMMITTED) << "term=" << last.term_ << " commit=" << last.commit_index_ << " applied=" << last.last_applied_ << " payload=" << std::string(reinterpret_cast<const char *>(last.payload_.data()), last.payload_.size());')
    adapted=out/'s8-adapted.cpp';adapted.write_text(s)
    run(flags+['-c',adapted,'-o',out/'s8.o'],'s8-compile')
    run(flags+['-no-pie',out/'s8.o']+libs+['-Wl,--wrap=pwrite','-Wl,--wrap=fdatasync','-o',out/'s8'],'s8-link')
    run(prefix+[out/'s8','--gtest_output=xml:'+str(out/'s8.xml')],'s8');check('s8',8)
(out/'summary.json').write_text(json.dumps(dict(stage='F26-zero-page',page_tests=10,sanitizer=a.sanitizer,regressions=a.regressions,mutations=False),indent=2))
