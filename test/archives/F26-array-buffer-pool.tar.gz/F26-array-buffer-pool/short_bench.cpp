#include <atomic>
#include <chrono>
#include <iostream>
#include <thread>
#include <vector>
#include "buffer/buffer_pool_manager.h"
#include "storage/disk/disk_manager_memory.h"
#include "storage/index/b_plus_tree.h"
#include "test_util.h"
namespace bustub {
// Selects the existing guarded tree path through its original page-access contract.
// No alternative lookup algorithm or production benchmark switch.
class LockedPager : public BufferPoolManager { public: using BufferPoolManager::BufferPoolManager; };
template<class Pager> void Run(const char *name, int workers, bool mixed) {
 DiskManagerUnlimitedMemory disk;Pager pool(128,&disk);
 auto schema=ParseCreateStatement("a bigint");GenericComparator<8> compare(schema.get());
 BPlusTree<GenericKey<8>,RID,GenericComparator<8>,Pager> tree("bench",pool.NewPage(),&pool,compare,120,120);
 constexpr int count=4096,queries=100000;
 for(int k=0;k<count;++k){GenericKey<8> key;key.SetFromInteger(1001+k);if(!tree.Insert(key,RID(k,17)))std::abort();}
 std::atomic<bool> go{false};std::atomic<int> ready{0};std::atomic<uint64_t> sum{0};std::vector<std::thread> threads;
 for(int t=0;t<workers;++t) threads.emplace_back([&,t]{std::vector<RID> result;result.reserve(1);GenericKey<8> key;
  for(int i=0;i<count;++i){key.SetFromInteger(1001+i);result.clear();tree.GetValue(key,&result);}
  ++ready;while(!go.load())std::this_thread::yield();uint64_t local=0;
  for(int i=0;i<queries;++i){int n=(i*73+t*101)%(mixed ? count/2 : count);key.SetFromInteger(1001+n);result.clear();
   if(!tree.GetValue(key,&result)||result.size()!=1||!(result[0]==RID(n,17)))std::abort();local+=result[0].GetPageId();}
  sum.fetch_add(local);
 });
 if(mixed) threads.emplace_back([&]{++ready;while(!go.load())std::this_thread::yield();
   for(int i=0;i<2000;++i){const int n=count/2+(i*37)%(count/2);GenericKey<8> key;key.SetFromInteger(1001+n);
     tree.Remove(key);if(!tree.Insert(key,RID(n,17)))std::abort();}});
 while(ready.load()!=workers+(mixed?1:0))std::this_thread::yield();auto start=std::chrono::steady_clock::now();go=true;
 for(auto &t:threads)t.join();double seconds=std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count();
 std::cout<<name<<","<<(mixed?"mixed":"read")<<","<<workers<<","<<queries*workers<<","<<seconds<<","<<(queries*workers/seconds)<<","<<sum<<"\n";
}
}
int main(){std::cout<<"path,workload,threads,queries,seconds,queries_per_second,checksum\n";for(int repeat=0;repeat<3;++repeat)for(int workers:{1,4})for(bool mixed:{false,true}){
 if(repeat%2){bustub::Run<bustub::BufferPoolManager>("short",workers,mixed);bustub::Run<bustub::LockedPager>("guarded",workers,mixed);}
 else {bustub::Run<bustub::LockedPager>("guarded",workers,mixed);bustub::Run<bustub::BufferPoolManager>("short",workers,mixed);}}
}
