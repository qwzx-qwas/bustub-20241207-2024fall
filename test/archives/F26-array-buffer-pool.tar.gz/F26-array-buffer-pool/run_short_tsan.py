import pathlib,subprocess,os,json,shlex,time,xml.etree.ElementTree as E,argparse
p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--build',required=True);p.add_argument('--out',required=True);p.add_argument('--compiler',required=True);a=p.parse_args()
r=pathlib.Path(a.repo).resolve();b=pathlib.Path(a.build).resolve();o=pathlib.Path(a.out).resolve();o.mkdir(parents=True,exist_ok=False);pkg=pathlib.Path(__file__).resolve().parent;cmds=[]
env=dict(os.environ,LD_LIBRARY_PATH=str(r/'.cache/toolchains/gcc-16.2.0/lib64'),TSAN_OPTIONS='halt_on_error=1')
def run(cmd,name):
 with (o/(name+'.log')).open('w') as f:q=subprocess.run(list(map(str,cmd)),cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=240)
 cmds.append(dict(command=list(map(str,cmd)),returncode=q.returncode));(o/'commands.json').write_text(json.dumps(cmds,indent=2));assert q.returncode==0,(name,q.returncode)
units=['src/buffer/buffer_pool_manager.cpp','src/buffer/translation_directory.cpp','src/buffer/clock_pro_replacer.cpp','src/buffer/frame_arena.cpp','src/buffer/file_page_storage.cpp','src/storage/page/page_guard.cpp','src/storage/disk/disk_manager_memory.cpp','src/storage/disk/disk_manager.cpp']
cc=json.loads((b/'compile_commands.json').read_text());objects=[]
for i,path in enumerate(units):
 command=shlex.split(next(c['command'] for c in cc if c['file']==str(r/path)));command[command.index('-o')+1]=str(o/(str(i)+'.o'));command+=['-fsanitize=thread','-g','-O1','-fno-omit-frame-pointer','-fno-pie'];run(command,'compile-'+str(i));objects.append(o/(str(i)+'.o'))
flags=[a.compiler,'-std=c++17','-pthread','-g','-O1','-fsanitize=thread','-fno-pie','-no-pie']+['-I'+str(r/d) for d in ['src/include','test/include','third_party','third_party/fmt/include','third_party/libfort/src','third_party/googletest/googletest/include']]
libs=[b/'lib'/('lib'+n+'.a') for n in ['bustub','bustub_murmur3','bustub_lz4','duckdb_pg_query','fmt','fort','gmock_main','gmock','gtest']]
run(flags+[pkg/'tests/short_read_test.cpp',*objects,*libs,'-o',o/'short-tests'],'link');run([o/'short-tests','--gtest_output=xml:'+str(o/'short.xml')],'tests')
cases=E.parse(o/'short.xml').getroot().findall('.//testcase');assert len(cases)==7 and all(c.get('status')=='run' and c.get('result')=='completed' and c.find('failure') is None for c in cases)
(o/'summary.json').write_text(json.dumps({'tests':len(cases),'instrumented_units':units,'scope':'short-read tests and listed cache units; not whole-node TSan'},indent=2))
