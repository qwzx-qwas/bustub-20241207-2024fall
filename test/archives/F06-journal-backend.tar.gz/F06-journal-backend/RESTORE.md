# F06/S2 阶段测试恢复

本包只有两项 Journal 段范围组件测试、runner 及版本说明，不注册常驻测试。
基准为 5be34fbfcd18abe14714c192509a312f3874f5a4 加本轮变更；该基准本身没有 F06。
实际源码以 MANIFEST.json 的 production_sha256 为准。使用匹配工作树，
或在外部目录 git archive 基准，再用本地 F06-results.tar.gz 的 source/ 覆盖，
逐项核对哈希后执行；不能覆盖有用户修改的工作树。

需要 Linux、Clang14/CMake/Python3、仓库已有 googletest，及支持真实 O_DIRECT/statx
查询的文件系统。所有对齐从设备查询；段大小由测试选择为实际偏移对齐的 3/5 倍，
不是生产默认。F03 要求对齐能支持其 64 KiB 引导槽；fixture 还明确限制几何预算。
没有静默改走 Buffered。偏移对齐为 1 时不存在非对齐整数输入，会明确报告该分支。

在仓库根目录执行；先核对 MANIFEST 的生产和源码文件 SHA-256：
~~~sh
f06_repo=$(pwd)
f06_scratch=$(mktemp -d /tmp/bustub-f06-restore-XXXXXX)
(cd "$f06_repo/test/archives" && sha256sum -c SHA256SUMS)
tar -xzf "$f06_repo/test/archives/F06-journal-backend.tar.gz" -C "$f06_scratch"
python3 "$f06_scratch/F06-journal-backend/test/storage_redesign/run_stage.py" \
  --repo "$f06_repo" --work "$f06_scratch/run" --mutations
~~~

runner 校验原 F04 包 SHA 后复用三项测试，不在本包复制其源码。必须实际通过 2 项
F06 和 3 项 F04，七个隔离变异必须成功编译并被指定断言发现；编译失败、超时、
检测器异常和零用例均不能算成功。它清理外部 GTEST_* 并核验完整 XML。

构建 -j2；F06 单个镜像 16 MiB，原 F04 最多两个。两个 worker、八成员、自有缓冲
2 MiB/外部 1 MiB，另有测试全镜像内存。IO watchdog 5 秒、测试进程 120 秒，
不作为性能 SLO。证据为 XML、日志、commands.json、mutations.json、environment.json。

这是原始范围 IO 集成验证，不是记录恢复、B/Raft/SQL E2E、真实裸设备或掉电测试，
没有性能结论，也不验证 S3/S5 未实现的段身份/提交/回收协议。
运行后自行核验并压缩结果，再删除自己的临时目录；不恢复到长期 test/ 目录。
