#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>

#include <algorithm>
#include <atomic>
#include <cerrno>
#include <chrono>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <iostream>
#include <limits>
#include <memory>
#include <stdexcept>
#include <string>
#include <system_error>
#include <vector>

#include "storage/disk/bootstrap_store.h"
#include "storage/disk/journal_backend.h"
#include "gtest/gtest.h"

extern "C" int __real_fdatasync(int);
extern "C" ssize_t __real_pread(int, void *, size_t, off_t);
extern "C" ssize_t __real_pwrite(int, const void *, size_t, off_t);
namespace {
std::atomic<size_t> successful_flushes{0};
std::atomic<size_t> range_calls{0};
} // namespace
extern "C" int __wrap_fdatasync(int fd) {
  const auto result = __real_fdatasync(fd);
  if (result == 0) {
    ++successful_flushes;
  }
  return result;
}
extern "C" ssize_t __wrap_pread(int fd, void *buffer, size_t size,
                                off_t offset) {
  ++range_calls;
  return __real_pread(fd, buffer, size, offset);
}
extern "C" ssize_t __wrap_pwrite(int fd, const void *buffer, size_t size,
                                 off_t offset) {
  ++range_calls;
  return __real_pwrite(fd, buffer, size, offset);
}

namespace bustub {
namespace {
using namespace std::chrono_literals;
constexpr uint64_t MIB = 1024 * 1024;
constexpr size_t CAPACITY = 16 * MIB;
using Bytes = std::vector<unsigned char>;

auto Range(uint64_t offset, uint64_t size) -> StorageByteRange {
  auto result = StorageByteRange::Create(offset, size);
  if (!result) {
    throw std::invalid_argument("bad test layout");
  }
  return *result;
}

struct RawFile {
  int fd_{-1};
  std::string path_;
  explicit RawFile(unsigned seed) {
    const char *directory = std::getenv("F06_WORKDIR");
    if (directory == nullptr) {
      throw std::runtime_error("runner must set F06_WORKDIR");
    }
    std::string name = std::string(directory) + "/device-XXXXXX";
    fd_ = mkstemp(name.data());
    if (fd_ < 0) {
      throw std::system_error(errno, std::generic_category(), "mkstemp");
    }
    path_ = name;
    try {
      Bytes image(CAPACITY);
      for (size_t i = 0; i < image.size(); ++i) {
        image[i] = static_cast<unsigned char>(
            (i * 17 + (i / 131) * 7 + seed * 19) % 251);
      }
      std::fill_n(image.begin(), 65536, 0);
      std::fill_n(image.begin() + MIB, 65536, 0);
      size_t done = 0;
      while (done < image.size()) {
        const auto n = pwrite(fd_, image.data() + done, image.size() - done,
                              static_cast<off_t>(done));
        if (n < 0 && errno == EINTR) {
          continue;
        }
        if (n <= 0) {
          throw std::runtime_error("fixture write failed");
        }
        done += static_cast<size_t>(n);
      }
      if (__real_fdatasync(fd_) != 0) {
        throw std::system_error(errno, std::generic_category(), "fixture sync");
      }
    } catch (...) {
      close(fd_);
      unlink(path_.c_str());
      throw;
    }
  }
  ~RawFile() {
    close(fd_);
    unlink(path_.c_str());
  }
  auto ReadAll() const -> Bytes {
    if (std::filesystem::file_size(path_) != CAPACITY) {
      throw std::runtime_error("device size changed");
    }
    Bytes image(CAPACITY);
    size_t done = 0;
    while (done < image.size()) {
      const auto n = pread(fd_, image.data() + done, image.size() - done,
                           static_cast<off_t>(done));
      if (n < 0 && errno == EINTR) {
        continue;
      }
      if (n <= 0) {
        throw std::runtime_error("independent oracle read failed");
      }
      done += static_cast<size_t>(n);
    }
    return image;
  }
};

auto Payload(size_t size, unsigned seed) -> Bytes {
  Bytes result(size);
  for (size_t i = 0; i < size; ++i) {
    result[i] = static_cast<unsigned char>((i * 23 + seed * 41 + i / 19) % 253);
  }
  return result;
}

void Finish(IOExecutor &io, IOBatch &batch) {
  if (io.TrySubmit(batch) != IOAdmission::Accepted || !batch.WaitFor(5s)) {
    throw std::runtime_error("accepted IO did not complete within watchdog");
  }
}

struct Buffer {
  Bytes storage_;
  char *data_;
  explicit Buffer(size_t size, uint32_t alignment) {
    if (alignment == 0 || alignment > MIB) {
      throw std::runtime_error("fixture alignment exceeds resource budget");
    }
    storage_.resize(size + alignment - 1);
    const auto address = reinterpret_cast<uintptr_t>(storage_.data());
    data_ = reinterpret_cast<char *>(
        storage_.data() + (alignment - address % alignment) % alignment);
  }
};

auto Layout(uint64_t start, uint64_t length) -> BootstrapLayout {
  BootstrapLayout result{
      {},
      CAPACITY,
      {Range(2 * MIB, MIB), Range(start, length), Range(9 * MIB, 6 * MIB)}};
  result.identity_.storage_.fill(17);
  result.identity_.device_.fill(37);
  return result;
}

TEST(JournalTest, SegmentRangesPreserveOtherBytesAndReopen) {
  for (unsigned variant : {0U, 1U}) {
    SCOPED_TRACE(variant);
    RawFile file(variant);
    const uint64_t start = (4 + variant) * MIB;
    uint64_t unit = 0;
    uint64_t segment = 0;
    Bytes expected;
    BootstrapIdentity identity;
    std::vector<Bytes> payloads;
    {
      BlockDevice device(file.path_, BlockDeviceOptions{});
      const auto &info = device.Info();
      ASSERT_EQ(info.access_mode_, DeviceAccessMode::Direct);
      unit = info.offset_alignment_;
      ASSERT_GT(unit, 0U);
      ASSERT_LE(unit, 65536U) << "fixture exceeds its bounded geometry budget";
      ASSERT_EQ(65536 % unit, 0U) << "geometry cannot support F03 bootstrap";
      segment = (3 + 2 * variant) * unit;
      std::cout << "real geometry: memory=" << info.memory_alignment_
                << " offset=" << unit << " segment=" << segment << '\n';
      payloads = {Payload(segment, 11 + variant),
                  Payload(segment, 23 + variant),
                  Payload(segment - unit, 37 + variant)};
      IOExecutor io(device, {2, 8, 2 * MIB}, MIB);
      BootstrapStore bootstrap(io);
      // Explicit, non-power-of-two segment sizes: exact capacity, then partial
      // tail.
      const auto layout = Layout(start, 4 * segment + variant * unit);
      identity = layout.identity_;
      bootstrap.Create(layout);
      bootstrap.Open(identity);
      RegionManager regions(bootstrap);
      JournalBackend backend(regions, segment);
      ASSERT_EQ(backend.SegmentCapacity(), 4U);
      expected = file.ReadAll();
      const std::vector<uint64_t> positions{start + 3 * segment, start,
                                            start + 2 * segment + unit};
      for (size_t i = 0; i < payloads.size(); ++i) {
        std::copy(payloads[i].begin(), payloads[i].end(),
                  expected.begin() + positions[i]);
      }
      {
        successful_flushes = 0;
        // The batch is twice the segment size; every individual range is legal.
        auto prep = backend.TryPrepare({{3, IOOperation::Write, 0, segment},
                                        {0, IOOperation::Write, 0, segment}},
                                       true);
        ASSERT_EQ(prep.admission_, IOAdmission::Accepted);
        std::memcpy(prep.batch_->Buffer(0), payloads[0].data(), segment);
        std::memcpy(prep.batch_->Buffer(1), payloads[1].data(), segment);
        Finish(io, *prep.batch_);
        ASSERT_EQ(prep.batch_->Phase(), IOBatchPhase::Succeeded);
        EXPECT_TRUE(prep.batch_->Result().writes_durable_);
        EXPECT_GT(successful_flushes.load(), 0U);
        ASSERT_EQ(prep.batch_->Result().operations_.size(), 2U);
        for (const auto &result : prep.batch_->Result().operations_) {
          EXPECT_EQ(result.outcome_, IOOutcome::Succeeded);
          EXPECT_EQ(result.completed_bytes_, segment);
          EXPECT_EQ(result.error_, nullptr);
        }
      }
      auto buffer =
          std::make_shared<Buffer>(segment - unit, info.memory_alignment_);
      auto releases = std::make_shared<std::atomic<unsigned>>(0);
      std::memcpy(buffer->data_, payloads[2].data(), segment - unit);
      std::vector<IOBufferLease> leases;
      leases.push_back(IOBufferLease::ForWrite(
          buffer->data_, segment - unit, [buffer, releases] { ++*releases; }));
      {
        successful_flushes = 0;
        auto prep = backend.TryPrepareExternal(
            {{2, IOOperation::Write, unit, segment - unit}}, leases, true);
        ASSERT_EQ(prep.admission_, IOAdmission::Accepted);
        EXPECT_TRUE(leases.empty());
        Finish(io, *prep.batch_);
        ASSERT_EQ(prep.batch_->Phase(), IOBatchPhase::Succeeded);
        EXPECT_TRUE(prep.batch_->Result().writes_durable_);
        EXPECT_GT(successful_flushes.load(), 0U);
        EXPECT_EQ(releases->load(), 1U);
      }
      EXPECT_EQ(file.ReadAll(), expected);
      std::memset(buffer->data_, 0, segment - unit);
      leases.push_back(IOBufferLease::ForRead(
          buffer->data_, segment - unit, [buffer, releases] { ++*releases; }));
      {
        auto prep = backend.TryPrepareExternal(
            {{2, IOOperation::Read, unit, segment - unit}}, leases, false);
        ASSERT_EQ(prep.admission_, IOAdmission::Accepted);
        EXPECT_TRUE(leases.empty());
        Finish(io, *prep.batch_);
        ASSERT_EQ(prep.batch_->Phase(), IOBatchPhase::Succeeded);
        EXPECT_FALSE(prep.batch_->Result().writes_durable_);
        EXPECT_EQ(releases->load(), 2U);
        EXPECT_EQ(
            std::memcmp(buffer->data_, payloads[2].data(), segment - unit), 0);
      }
    } // Drain and close all production IO before reopening.
    {
      BlockDevice device(file.path_, BlockDeviceOptions{});
      IOExecutor io(device, {2, 8, 2 * MIB}, MIB);
      BootstrapStore bootstrap(io);
      bootstrap.Open(identity);
      RegionManager regions(bootstrap);
      JournalBackend backend(regions, segment);
      auto prep =
          backend.TryPrepare({{3, IOOperation::Read, 0, segment},
                              {0, IOOperation::Read, 0, segment},
                              {2, IOOperation::Read, unit, segment - unit}},
                             false);
      ASSERT_EQ(prep.admission_, IOAdmission::Accepted);
      for (size_t i = 0; i < payloads.size(); ++i) {
        std::memset(prep.batch_->Buffer(i), 0, payloads[i].size());
      }
      Finish(io, *prep.batch_);
      ASSERT_EQ(prep.batch_->Phase(), IOBatchPhase::Succeeded);
      for (size_t i = 0; i < payloads.size(); ++i) {
        EXPECT_EQ(std::memcmp(prep.batch_->Buffer(i), payloads[i].data(),
                              payloads[i].size()),
                  0);
      }
      // Independent whole-file oracle includes metadata, data, gaps and the
      // tail.
      EXPECT_EQ(file.ReadAll(), expected);
    }
  }
}

TEST(JournalTest, InvalidGeometryOrMemberRejectsWholePreparation) {
  RawFile file(7);
  BlockDevice device(file.path_, BlockDeviceOptions{});
  const uint64_t unit = device.Info().offset_alignment_;
  ASSERT_GT(unit, 0U);
  ASSERT_LE(unit, 65536U);
  ASSERT_EQ(65536 % unit, 0U);
  const uint64_t segment = 3 * unit;
  const uint64_t length = 4 * segment + unit;
  IOExecutor io(device, {2, 8, 2 * MIB}, MIB);
  BootstrapStore bootstrap(io);
  const auto layout = Layout(4 * MIB, length);
  bootstrap.Create(layout);
  bootstrap.Open(layout.identity_);
  RegionManager regions(bootstrap);
  const auto before = file.ReadAll();
  const auto max = std::numeric_limits<uint64_t>::max();
  const auto calls_before = range_calls.load();
  for (uint64_t invalid : {uint64_t{0}, length + unit, max}) {
    EXPECT_THROW({ JournalBackend invalid_backend(regions, invalid); },
                 std::invalid_argument);
  }
  if (unit > 1) {
    EXPECT_THROW({ JournalBackend invalid_backend(regions, segment + 1); },
                 std::invalid_argument);
  } else {
    std::cout << "offset alignment is 1: unaligned offsets/segment size do not "
                 "exist\n";
  }
  JournalBackend backend(regions, segment);
  EXPECT_EQ(backend.SegmentCapacity(), 4U);
  EXPECT_EQ(range_calls.load(), calls_before);

  std::vector<JournalIORequest> invalids{
      {4, IOOperation::Write, 0,
       unit}, // Fits region tail, not a complete slot.
      {max, IOOperation::Write, 0, unit}, // Must reject before multiplication.
      {1, IOOperation::Write, segment - unit,
       2 * unit}, // Crosses slot but fits region.
      {1, IOOperation::Write, segment, unit},
      {1, IOOperation::Write, max, unit}, // Addition must not wrap.
      {1, IOOperation::Write, unit, max},
      {1, IOOperation::Write, 0, 0}};
  if (unit > 1) {
    invalids.push_back({1, IOOperation::Write, 1, unit});
    invalids.push_back({1, IOOperation::Write, 0, unit + 1});
  }
  auto buffer =
      std::make_shared<Buffer>(segment, device.Info().memory_alignment_);
  const auto bytes = Payload(segment, 71);
  std::memcpy(buffer->data_, bytes.data(), bytes.size());
  for (const auto &invalid : invalids) {
    SCOPED_TRACE(::testing::Message()
                 << "slot=" << invalid.segment_slot_
                 << " offset=" << invalid.offset_ << " size=" << invalid.size_);
    auto releases = std::make_shared<std::atomic<unsigned>>(0);
    std::vector<IOBufferLease> leases;
    for (unsigned i = 0; i < 2; ++i) {
      // Stable immutable RAM can be shared; the device ranges are distinct.
      leases.push_back(IOBufferLease::ForWrite(
          buffer->data_, segment, [buffer, releases] { ++*releases; }));
    }
    const std::vector<JournalIORequest> requests{
        {0, IOOperation::Write, 0, unit}, invalid};
    const auto range_before = range_calls.load();
    const auto flush_before = successful_flushes.load();
    EXPECT_THROW(backend.TryPrepare(requests, true), std::invalid_argument);
    EXPECT_THROW(backend.TryPrepareExternal(requests, leases, true),
                 std::invalid_argument);
    EXPECT_EQ(range_calls.load(), range_before);
    EXPECT_EQ(successful_flushes.load(), flush_before);
    ASSERT_EQ(leases.size(), 2U);
    EXPECT_EQ(releases->load(), 0U);

    // A rejected request must leave the same permissions usable.
    auto good = backend.TryPrepareExternal(
        {{0, IOOperation::Write, 0, unit}, {1, IOOperation::Write, 0, unit}},
        leases, true);
    ASSERT_EQ(good.admission_, IOAdmission::Accepted);
    EXPECT_TRUE(leases.empty());
    good.batch_.reset(); // Prepared only: no device access.
    EXPECT_EQ(releases->load(), 2U);
    EXPECT_EQ(range_calls.load(), range_before);
  }
  EXPECT_EQ(file.ReadAll(), before);
}
} // namespace
} // namespace bustub
