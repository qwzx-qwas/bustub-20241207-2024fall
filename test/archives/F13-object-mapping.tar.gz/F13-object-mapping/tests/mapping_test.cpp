// Reuse the unchanged F12 tests, real S5 fixture, IO gates and actual IO
// helpers.
#include "allocator_test.cpp"
#include "storage/disk/object_mapping.h"
namespace {
auto MappingOptions() -> ObjectMappingOptions { return {2, 512, 128 * 1024, 256, 32}; }
struct MappingRig {
  Rig r;
  DataAllocator a;
  ObjectMappingStore objects;
  MappingRig(const Image &image, bool create, ObjectMappingOptions options = MappingOptions())
      : r(image, create), a(r.b, r.opts), objects(a, options) {
    if (create) {
      Require(a.Create().outcome_ == JournalOutcome::Durable, "create allocator");
      Require(objects.Create().outcome_ == JournalOutcome::Durable, "create object format");
    } else {
      a.Open();
      objects.Open();
    }
  }
  auto Space() -> uint64_t {
    auto result = objects.CreateSpace(objects.Read());
    Require(result.result_.outcome_ == JournalOutcome::Durable && result.space_.has_value(), "publish space");
    return *result.space_;
  }
  auto Written(const Bytes &bytes) -> DataReservation {
    auto reservation = a.Reserve(bytes.size());
    auto lease = reservation.Lease();
    size_t cursor = 0;
    for (const auto &range : reservation.Extents()) {
      Bytes block(range.Size(), std::byte{0});
      const auto take = std::min<size_t>(range.Size(), bytes.size() - cursor);
      std::copy_n(bytes.begin() + cursor, take, block.begin());
      auto batch = r.Write(range.Offset(), block);
      batch.Wait();
      Require(batch.Phase() == IOBatchPhase::Succeeded && batch.Result().writes_durable_, "durable data");
      cursor += take;
    }
    return reservation;
  }
  void Put(ObjectKey key, uint64_t offset, const Bytes &bytes) {
    auto reservation = Written(bytes);
    Durable(objects.Replace(objects.Read(), key, offset, bytes.size(), reservation));
  }
  // Test-side IO adapter for the production mapping result, not an independent
  // implementation of lookup. The expected bytes always come from input/model.
  auto ReadBody(const ObjectMappingSnapshot &view, ObjectKey key, uint64_t offset, uint64_t length) -> Bytes {
    Bytes result;
    const auto begin = offset;
    const auto end = offset + length;
    for (;;) {
      const auto page = view.Resolve(key, offset, end - offset);
      for (const auto &span : page.spans_) {
        Require(span.offset_ == begin + result.size(), "contiguous result coverage");
        if (!span.data_) {
          result.resize(result.size() + span.size_, std::byte{0});
          continue;
        }
        const auto alignment = r.regions.Describe(r.data).offset_alignment_;
        const auto physical = span.data_->offset_;
        const auto start = physical / alignment * alignment;
        const auto stop = (physical + span.size_ + alignment - 1) / alignment * alignment;
        auto prepared = r.regions.TryPrepare({{r.data, IOOperation::Read, start, stop - start}}, false);
        Require(prepared.batch_.has_value(), "read prepare");
        auto batch = std::move(*prepared.batch_);
        Require(r.stack.io.TrySubmit(batch) == IOAdmission::Accepted, "read submit");
        batch.Wait();
        Require(batch.Phase() == IOBatchPhase::Succeeded, "read actual IO");
        const auto *data = reinterpret_cast<const std::byte *>(batch.Buffer(0)) + physical - start;
        result.insert(result.end(), data, data + span.size_);
      }
      if (page.complete_) return result;
      Require(page.next_offset_ > offset, "pagination must make progress");
      offset = page.next_offset_;
    }
  }
};
template <class F>
void MappingFails(F f, ObjectMappingErrorCode code) {
  try {
    f();
    ADD_FAILURE() << "mapping operation must reject";
  } catch (const ObjectMappingError &e) {
    EXPECT_EQ(e.Code(), code);
  }
}
TEST(F13Mapping, IdentityFormatAndTombstone) {
  Image image;
  uint64_t first_space, second_space;
  {
    Rig r(image, true);
    DataAllocator a(r.b, r.opts);
    Durable(a.Create());
    Durable(r.b.Commit(r.b.Read(), {{{40, 9, 1}, Value(51, 3)}}));
    ObjectMappingStore missing(a, MappingOptions());
    MappingFails([&] { missing.Open(); }, ObjectMappingErrorCode::NotInitialized);
    ObjectMappingStore objects(a, MappingOptions());
    Durable(objects.Create());
    auto first = objects.CreateSpace(objects.Read());
    ASSERT_TRUE(first.space_);
    first_space = *first.space_;
    Durable(objects.CreateObject(objects.Read(), {first_space, 7}, 321, ObjectSizeMode::Variable));
    auto second = objects.CreateSpace(objects.Read());
    ASSERT_TRUE(second.space_);
    second_space = *second.space_;
    EXPECT_NE(first_space, second_space) << "rebuild must get a different space identity";
    Durable(objects.CreateObject(objects.Read(), {second_space, 7}, 654, ObjectSizeMode::Fixed));
    const auto old = objects.Read();
    Durable(objects.Remove(objects.Read(), {first_space, 7}));
    MappingFails([&] { objects.Read().Describe({first_space, 7}); }, ObjectMappingErrorCode::NotFound);
    MappingFails(
        [&] {
          objects.CreateObject(objects.Read(), {first_space, 7}, 99, ObjectSizeMode::Variable);
        },
        ObjectMappingErrorCode::AlreadyExists);
    EXPECT_EQ(old.Describe({first_space, 7}).size_, 321U);
    EXPECT_EQ(objects.Read().Describe({second_space, 7}).size_, 654U);
    ObjectMappingStore duplicate(a, MappingOptions());
    MappingFails([&] { duplicate.Create(); }, ObjectMappingErrorCode::AlreadyExists);
    EXPECT_EQ(r.b.Read().Get({40, 9, 1}), Value(51, 3));
    EXPECT_EQ(r.b.Checkpoint(256).outcome_, MetadataCheckpointOutcome::Durable);
  }
  MappingRig r(image, false);
  EXPECT_EQ(r.objects.Read().Describe({second_space, 7}).size_, 654U);
  MappingFails([&] { r.objects.Read().Describe({first_space, 7}); }, ObjectMappingErrorCode::NotFound);
  EXPECT_GT(r.Space(), second_space) << "reopen cannot reuse a published space identity";
}
TEST(F13Mapping, ScatterLookupReplacementAndOldView) {
  Image image;
  MappingRig r(image, true);
  const auto u = r.r.opts.allocation_bytes_;
  const auto origin = 7 * u + 137;  // Logical start is neither zero nor IO aligned.
  ObjectKey key{r.Space(), 8};
  Durable(r.objects.CreateObject(r.objects.Read(), key, 0, ObjectSizeMode::Variable));
  Durable(r.a.SetQuarantine(r.r.b.Read(), {Range(0, r.r.Usable())}, true));
  Durable(r.a.SetQuarantine(r.r.b.Read(), {Range(2 * u, u), Range(5 * u, u), Range(9 * u, u)}, false));
  const auto bytes = Value(3 * u, 8);
  auto reserved = r.Written(bytes);
  ASSERT_EQ(reserved.Extents().size(), 3U);
  Durable(r.objects.Replace(r.objects.Read(), key, origin, bytes.size(), reserved));
  const auto old = r.objects.Read();
  struct ReadCase {
    const char *name;
    uint64_t relative;
    uint64_t length;
  };
  // Each input exercises a distinct position/range, all in nonzero-start mappings.
  for (const auto &q : std::vector<ReadCase>{{"exact start", 0, 17},
                                             {"first extent interior", u / 3, 29},
                                             {"second extent interior", u + 73, 59},
                                             {"third extent tail", 3 * u - 11, 11},
                                             {"cross three extents", u - 19, u + 43}}) {
    SCOPED_TRACE(q.name);
    EXPECT_EQ(r.ReadBody(old, key, origin + q.relative, q.length),
              Bytes(bytes.begin() + q.relative, bytes.begin() + q.relative + q.length))
        << "nonzero mapping range must match input";
  }
  // Keep one origin-zero boundary. The adjacent read starts in the leading hole.
  EXPECT_EQ(r.ReadBody(old, key, 0, 31), Bytes(31, std::byte{0}));
  Bytes crossing(17, std::byte{0});
  crossing.insert(crossing.end(), bytes.begin(), bytes.begin() + 17);
  EXPECT_EQ(r.ReadBody(old, key, origin - 17, 34), crossing) << "leading hole must end at the nonzero mapping start";
  Durable(r.a.SetQuarantine(r.r.b.Read(), {Range(12 * u, u)}, false));
  const auto patch = Value(u, 101);
  auto next = r.Written(patch);
  const auto base = r.objects.Read();
  Durable(r.objects.Replace(base, key, origin + u / 2, patch.size(), next));
  auto expected = bytes;
  std::copy(patch.begin(), patch.end(), expected.begin() + u / 2);
  EXPECT_EQ(r.ReadBody(r.objects.Read(), key, origin, bytes.size()), expected)
      << "partial replacement preserves both sides";
  EXPECT_EQ(r.ReadBody(r.objects.Read(), key, origin + u / 2 + 29, 63), Bytes(patch.begin() + 29, patch.begin() + 92))
      << "replacement interior must subtract its own logical start";
  EXPECT_EQ(r.ReadBody(r.objects.Read(), key, origin + 3 * u / 2 + 41, 31),
            Bytes(bytes.begin() + 3 * u / 2 + 41, bytes.begin() + 3 * u / 2 + 72))
      << "retained right slice must preserve physical offset";
  EXPECT_EQ(r.ReadBody(old, key, origin, bytes.size()), bytes) << "old view still addresses old data";
  const auto retired = r.objects.Read().Retired(key, 0);
  ASSERT_EQ(retired.ranges_.size(), 2U);
  EXPECT_EQ(retired.ranges_[0].span_.offset_, origin + u / 2);
  EXPECT_EQ(retired.ranges_[0].span_.size_, u / 2);
  EXPECT_EQ(retired.ranges_[1].span_.offset_, origin + u);
  EXPECT_EQ(retired.ranges_[1].span_.size_, u / 2);
  EXPECT_NE(retired.ranges_[0].span_.data_->allocation_, retired.ranges_[1].span_.data_->allocation_);
  try {
    r.objects.Resize(base, key, 1);
    FAIL() << "stale mapping snapshot accepted";
  } catch (const MetadataError &e) {
    EXPECT_EQ(e.Code(), MetadataErrorCode::Conflict);
  }
  EXPECT_EQ(r.ReadBody(r.objects.Read(), key, origin, bytes.size()), expected);
}
TEST(F13Mapping, TruncateExtendAndDurableRetirement) {
  Image image;
  ObjectKey key{};
  Bytes expected;
  uint64_t u;
  {
    MappingRig r(image, true);
    u = r.r.opts.allocation_bytes_;
    key = {r.Space(), 12};
    Durable(r.objects.CreateObject(r.objects.Read(), key, 0, ObjectSizeMode::Variable));
    const auto bytes = Value(3 * u, 25);
    r.Put(key, 0, bytes);
    Durable(r.objects.Resize(r.objects.Read(), key, u + 13));
    Durable(r.objects.Resize(r.objects.Read(), key, 4 * u));
    expected = Bytes(bytes.begin(), bytes.begin() + u + 13);
    expected.resize(4 * u, std::byte{0});
    EXPECT_EQ(r.ReadBody(r.objects.Read(), key, 0, 4 * u + 99), expected)
        << "truncated tail must not resurrect on extension";
    EXPECT_TRUE(r.objects.Read().Resolve(key, 4 * u + 10, 9).spans_.empty());
    ObjectKey fixed{key.space_, 13};
    Durable(r.objects.CreateObject(r.objects.Read(), fixed, 2 * u, ObjectSizeMode::Fixed));
    r.Put(fixed, u, Value(u, 3));
    EXPECT_EQ(r.objects.Read().Describe(fixed).size_, 2 * u);
    EXPECT_THROW(r.objects.Resize(r.objects.Read(), fixed, u), std::invalid_argument);
    auto retire = r.objects.Read().Retired(key, 0);
    ASSERT_EQ(retire.ranges_.size(), 1U);
    EXPECT_EQ(retire.ranges_[0].span_.offset_, u + 13);
    EXPECT_EQ(retire.ranges_[0].span_.size_, 2 * u - 13) << "retired slice keeps byte bounds";
    EXPECT_EQ(r.r.b.Checkpoint(256).outcome_, MetadataCheckpointOutcome::Durable);
  }
  MappingRig r(image, false);
  EXPECT_EQ(r.ReadBody(r.objects.Read(), key, u - 11, 3 * u + 11), Bytes(expected.begin() + u - 11, expected.end()));
  auto retire = r.objects.Read().Retired(key, 0);
  ASSERT_EQ(retire.ranges_.size(), 1U) << "retirement must survive recovery";
  EXPECT_EQ(retire.ranges_[0].span_.size_, 2 * u - 13);
  auto rest = r.a.Reserve(r.r.Usable() - 4 * u);
  AllocationFails([&] { r.a.Reserve(u); }, AllocationErrorCode::NoSpace,
                  "F13 must not free retired storage before F14");
}
TEST(F13Mapping, PredecessorAcrossTreePages) {
  Image image;
  MappingRig r(image, true);
  std::vector<MetadataMutation> values;
  std::map<uint64_t, Bytes> expected;
  for (uint64_t i = 0; i < 240; ++i) {
    auto bytes = Value(19, i + 1);
    expected.emplace(i * 10, bytes);
    values.push_back({{66, 7, i * 10}, bytes});
  }
  Durable(r.r.b.Commit(r.r.b.Read(), values));
  // Fill some gaps before deleting, so queries also see gaps that did not
  // cause a merge/rebalance. No tree capacity/separator is read by the test.
  values.clear();
  for (uint64_t i = 0; i < 240; i += 2) {
    auto bytes = Value(19, i + 17);
    expected.emplace(i * 10 + 5, bytes);
    values.push_back({{66, 7, i * 10 + 5}, bytes});
  }
  Durable(r.r.b.Commit(r.r.b.Read(), values));
  values.clear();
  for (uint64_t i = 1; i < 240; i += 3) {
    values.push_back({{66, 7, i * 10}, std::nullopt});
    expected.erase(i * 10);
  }
  Durable(r.r.b.Commit(r.r.b.Read(), values));
  {
    const auto view = r.r.b.Read();
    for (uint64_t query = 0; query < 2410; ++query) {
      auto it = expected.upper_bound(query);
      ASSERT_NE(it, expected.begin());
      --it;
      auto got = view.GetFloor({66, 7, query});
      ASSERT_TRUE(got) << "cross-page floor must retain a left predecessor";
      EXPECT_EQ(got->key_.category_, 66U);
      EXPECT_EQ(got->key_.owner_, 7U);
      EXPECT_EQ(got->key_.item_, it->first) << "cross-page floor must return greatest key <= request";
      EXPECT_EQ(got->value_, it->second);
    }
    EXPECT_FALSE(view.GetFloor({0, 0, 0}));
  }
}
TEST(F13Mapping, BudgetRefusalPreservesStateAndReservation) {
  Image image;
  auto options = MappingOptions();
  options.max_retired_records_ = 1;
  MappingRig r(image, true, options);
  auto u = r.r.opts.allocation_bytes_;
  ObjectKey key{r.Space(), 3};
  Durable(r.objects.CreateObject(r.objects.Read(), key, 0, ObjectSizeMode::Variable));
  r.Put(key, 0, Value(u, 1));
  r.Put(key, u, Value(u, 2));
  const auto before = r.objects.Read();
  MappingFails([&] { r.objects.Resize(before, key, 0); }, ObjectMappingErrorCode::ResourceUnavailable);
  EXPECT_EQ(r.objects.Read().Describe(key).size_, 2 * u);
  EXPECT_TRUE(r.objects.Read().Retired(key, 0).ranges_.empty()) << "budget refusal cannot partially retire mappings";
  // A stale transaction must not consume or publish an otherwise valid
  // reservation.
  auto pending = r.Written(Value(u, 7));
  Durable(r.objects.Resize(r.objects.Read(), key, 3 * u));
  try {
    r.objects.Replace(before, key, 2 * u, u, pending);
    FAIL() << "stale replacement accepted";
  } catch (const MetadataError &e) {
    EXPECT_EQ(e.Code(), MetadataErrorCode::Conflict);
  }
  Durable(r.objects.Replace(r.objects.Read(), key, 2 * u, u, pending));
  EXPECT_EQ(r.ReadBody(r.objects.Read(), key, 2 * u, u), Value(u, 7));
}
TEST(F13Mapping, FailedPublicationRecoversWholeChange) {
  Image image;
  ObjectKey key{};
  Bytes old_data, new_data;
  uint64_t u, origin;
  {
    MappingRig r(image, true);
    u = r.r.opts.allocation_bytes_;
    origin = 2 * u + 113;
    key = {r.Space(), 4};
    Durable(r.objects.CreateObject(r.objects.Read(), key, 0, ObjectSizeMode::Variable));
    old_data = Value(u, 2);
    new_data = Value(u, 53);
    r.Put(key, origin, old_data);
    auto pending = r.Written(new_data);
    auto old = r.objects.Read();
    Arm(Point::JournalFlush, true);
    auto commit = std::async(std::launch::async, [&] { return r.objects.Replace(old, key, origin, u, pending); });
    ReleaseOnExit cleanup;
    ASSERT_TRUE(WaitEntered());
    EXPECT_EQ(r.ReadBody(r.objects.Read(), key, origin, u), old_data) << "mapping cannot publish before durable";
    EXPECT_TRUE(r.objects.Read().Retired(key, 0).ranges_.empty());
    ReleaseGate();
    const auto result = commit.get();
    EXPECT_NE(result.outcome_, JournalOutcome::Durable);
    EXPECT_TRUE(result.error_);
    EXPECT_THROW(r.objects.Read(), MetadataError);
  }
  MappingRig r(image, false);
  const auto view = r.objects.Read();
  const auto bytes = r.ReadBody(view, key, origin, u);
  const auto retire = view.Retired(key, 0);
  if (bytes == new_data) {
    EXPECT_EQ(view.Describe(key).version_, 3U);
    ASSERT_EQ(retire.ranges_.size(), 1U) << "recovered new mapping requires persistent retirement";
    auto rest = r.a.Reserve(r.r.Usable() - 2 * u);
    AllocationFails([&] { r.a.Reserve(u); }, AllocationErrorCode::NoSpace,
                    "recovered mapping requires both retained allocations");
  } else {
    EXPECT_EQ(bytes, old_data) << "recovery must expose a whole old or new value";
    EXPECT_EQ(view.Describe(key).version_, 2U);
    EXPECT_TRUE(retire.ranges_.empty());
    auto rest = r.a.Reserve(r.r.Usable() - u);
    AllocationFails([&] { r.a.Reserve(u); }, AllocationErrorCode::NoSpace,
                    "unpublished allocation must recover as free");
  }
}
}  // namespace
