#!/usr/bin/env python3
"""F13 real mapping/B/allocator IO contracts; archived, not registered in CTest."""
import argparse, hashlib, json, os, pathlib, subprocess, tarfile, time
import xml.etree.ElementTree as ET
p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--work',required=True);p.add_argument('--mutations',action='store_true');a=p.parse_args()
repo=pathlib.Path(a.repo).resolve();work=pathlib.Path(a.work).resolve();src=pathlib.Path(__file__).resolve().parent
assert repo!=work and repo not in work.parents,'work must be outside repository'
work.mkdir(parents=True,exist_ok=True)
manifest=src.parent/'MANIFEST.json'
if manifest.exists():
 m=json.loads(manifest.read_text())
 for field in ('production_sha256','dependency_sha256'):
  for name,h in m[field].items():assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==h,('source drift',name)
env={k:v for k,v in os.environ.items() if not k.startswith('GTEST_')};env.update(S5_WORKDIR=str(work),ASAN_OPTIONS='detect_leaks=1:abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1')
commands=[]
def run(cmd,log,expected=0,timeout=900,cwd=None):
 cmd=list(map(str,cmd));start=time.monotonic()
 with (work/log).open('w') as out:r=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT,env=env,cwd=cwd or repo,timeout=timeout)
 commands.append({'command':cmd,'log':log,'seconds':time.monotonic()-start,'exit':r.returncode})
 (work/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 assert r.returncode==expected,(log,r.returncode,expected)
run(['cmake','-S',repo,'-B',work/'build','-DCMAKE_BUILD_TYPE=Debug','-DCMAKE_C_COMPILER=clang-14','-DCMAKE_CXX_COMPILER=clang++-14','-DBUSTUB_SANITIZER=address,undefined','-DCMAKE_EXE_LINKER_FLAGS=-no-pie'],'configure.log')
run(['cmake','--build',work/'build','--target','bustub','gtest_main','b_plus_tree_insert_test','b_plus_tree_delete_test','-j3'],'build.log')
for name in ['S5-journal-recycling','F34-node-lifecycle','F12-data-allocator']:
 with tarfile.open(repo/('test/archives/'+name+'.tar.gz')) as t:t.extractall(work,filter='data')
dep=work/'S5-journal-recycling/test/storage_redesign'
flags=['clang++-14','-std=c++17','-g','-O0','-Wall','-Wextra','-Werror','-Wno-unused-parameter','-pthread','-fsanitize=address,undefined','-fno-omit-frame-pointer','-I'+str(repo/'src/include'),'-I'+str(repo/'third_party/fmt/include'),'-I'+str(repo/'third_party/googletest/googletest/include'),'-I'+str(dep),'-I'+str(work/'F12-data-allocator/tests')]
libs=[work/'build/lib'/('lib'+name+'.a') for name in ['bustub','fmtd','gtest_main','gtest']]
wraps=['-Wl,--wrap=pwrite','-Wl,--wrap=fdatasync']
run(flags+['-c',src/'mapping_test.cpp','-o',work/'mapping-test.o'],'compile.log')
run(flags+['-no-pie',work/'mapping-test.o']+libs+wraps+['-o',work/'mapping-test'],'link.log')
run([work/'mapping-test','--gtest_output=xml:'+str(work/'f13-f12.xml')],'f13-f12.log',timeout=120)
run(flags+['-no-pie',work/'F34-node-lifecycle/tests/lifecycle_test.cpp']+libs+wraps+['-Wl,--wrap=pread','-Wl,--wrap=close','-o',work/'lifecycle_test'],'f34-compile.log')
run([work/'lifecycle_test','--gtest_output=xml:'+str(work/'lifecycle.xml')],'f34-run.log',timeout=120)
run(['python3',dep/'build_checks.py',repo,work],'s5-regression.log',timeout=300)
for name in ['insert','delete']:
 run([work/('build/test/b_plus_tree_'+name+'_test'),'--gtest_output=xml:'+str(work/(name+'.xml'))],name+'-run.log',timeout=120,cwd=work)
counts={'f13-f12.xml':12,'lifecycle.xml':5,'s5.xml':8,'insert.xml':3,'delete.xml':2}
for name,n in counts.items():
 cases=ET.parse(work/name).getroot().findall('./testsuite/testcase')
 assert len(cases)==n and all(c.get('result')=='completed' and not any(c.find(k) is not None for k in ('failure','error','skipped')) for c in cases),name
# Each mutant must compile and reach a named behavioral assertion; a crash,
# timeout, compiler failure or unrelated test failure is not a detection.
mutations=[
 ('assume_zero_mapping','const auto floor = base_.GetFloor(lower);','const auto floor = base_.GetFloor(Key(Mapping, key, 0));','ScatterLookupReplacementAndOldView','nonzero mapping range must match input'),
 ('omit_logical_origin','span.data_->offset_ + (begin - span.offset_)','span.data_->offset_ + begin','ScatterLookupReplacementAndOldView','nonzero mapping range must match input'),
 ('wrong_slice_address','span.data_->offset_ + (begin - span.offset_)','span.data_->offset_','ScatterLookupReplacementAndOldView','partial replacement preserves both sides'),
 ('resurrect_truncated_tail','Cut(base.base_, key, size, d.info_.size_, d, changes);','// mutation: keep mappings beyond EOF','TruncateExtendAndDurableRetirement','truncated tail must not resurrect'),
 ('drop_retirement','Put(Key(PendingRange, key, id),','return; Put(Key(PendingRange, key, id),','TruncateExtendAndDurableRetirement','retire.ranges_.size()'),
 ('refresh_stale_base','allocator_.Commit(base.base_, *reservation, mutations)','allocator_.Commit(metadata_.Read(), *reservation, mutations)','BudgetRefusalPreservesStateAndReservation','stale replacement accepted'),
 ('ignore_retirement_budget','if (d.pending_ >= options_.max_retired_records_) {','if (false && d.pending_ >= options_.max_retired_records_) {','BudgetRefusalPreservesStateAndReservation','mapping operation must reject'),
 ('reuse_deleted_object','if (base.base_.Get(descriptor)) {','if (base.base_.Get(descriptor) && ReadDescription(base.base_, key, true).alive_) {','IdentityFormatAndTombstone','mapping operation must reject'),
]
evidence=[]
if a.mutations:
 for name,old,new,test,marker in mutations:
  code=(repo/'src/storage/disk/object_mapping.cpp').read_text();assert code.count(old)==1,(name,old)
  cpp=work/(name+'.cpp');cpp.write_text(code.replace(old,new));obj=work/(name+'.o');exe=work/name
  run(flags+['-c',cpp,'-o',obj],name+'-compile.log',timeout=120)
  run(flags+['-no-pie',work/'mapping-test.o',obj]+libs+wraps+['-o',exe],name+'-link.log',timeout=120)
  run([exe,'--gtest_filter=F13Mapping.'+test,'--gtest_output=xml:'+str(work/(name+'.xml'))],name+'-run.log',expected=1,timeout=120)
  failures=[f.text or '' for f in ET.parse(work/(name+'.xml')).getroot().iter('failure')]
  assert any(marker in f for f in failures),(name,failures)
  evidence.append({'mutation':name,'old':old,'new':new,'test':test,'expected_marker':marker,'failures':failures})
  (work/'mutations.json').write_text(json.dumps(evidence,indent=2)+'\n');print(name+': detected by specified oracle',flush=True)
 # Exercise the new production floor traversal separately, without modifying A.
 name='lose_left_predecessor';old='left = internal->ValueAt(index - 1);';new='left = INVALID_PAGE_ID;'
 code=(repo/'src/include/storage/index/b_plus_tree_impl.h').read_text();assert code.count(old)==1
 private=work/name/'storage/index';private.mkdir(parents=True,exist_ok=True);(private/'b_plus_tree_impl.h').write_text(code.replace(old,new))
 obj=work/(name+'.o');exe=work/(name+'-test')
 run(flags[:1]+['-I'+str(work/name)]+flags[1:]+['-c',repo/'src/storage/disk/metadata_engine.cpp','-o',obj],name+'-compile.log',timeout=120)
 run(flags+['-no-pie',work/'mapping-test.o',obj]+libs+wraps+['-o',exe],name+'-link.log',timeout=120)
 run([exe,'--gtest_filter=F13Mapping.PredecessorAcrossTreePages','--gtest_output=xml:'+str(work/(name+'.xml'))],name+'-run.log',expected=1,timeout=120)
 failures=[f.text or '' for f in ET.parse(work/(name+'.xml')).getroot().iter('failure')]
 assert any('got' in f or 'cross-page floor' in f for f in failures),failures
 evidence.append({'mutation':name,'old':old,'new':new,'test':'PredecessorAcrossTreePages','expected_marker':'got/cross-page floor','failures':failures})
 (work/'mutations.json').write_text(json.dumps(evidence,indent=2)+'\n')
(work/'summary.json').write_text(json.dumps({'passed':counts,'mutations_detected':len(evidence),'scope':'F13 with real B/F12/Journal/Direct file; mapping output read by test adapter. No F14 release, NodeStorage objects, SQL/Raft E2E, raw device, physical power loss or performance claim.'},indent=2)+'\n')
print('F13 6 + F12 6 + F34 5 + S5 8 + A 5 passed; mutations '+str(len(evidence)),flush=True)
