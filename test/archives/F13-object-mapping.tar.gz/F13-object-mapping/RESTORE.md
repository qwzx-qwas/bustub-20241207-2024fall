# F13 对象映射阶段验证恢复

仅模块归档，不加入常驻 CMake/CTest。Linux、Clang 14、CMake、Python 3（支持 tarfile data filter）；Direct 文件支持和设备对齐必须能真实查询。使用仓库外至少约 1 GiB 临时空间。

1. 校验 `test/archives/SHA256SUMS` 与结果目录校验表。
2. 历史复验：在隔离目录检出基准 `954769f`，将同哈希 F13 结果包 `source/` 下的生产文件覆盖到相对位置。若直接运行当前源码，必须匹配 MANIFEST 的 production_sha256。
3. 将本包解压到仓库外；保持原 F12-data-allocator、F34-node-lifecycle、S5-journal-recycling 包的依赖哈希，runner 自动解压复用。A 原插入/删除测试保留原样。
4. 执行（两个路径均用实际绝对路径，work 不在仓库内）：

```bash
python3 /tmp/F13-object-mapping/tests/run_stage.py \
  --repo /path/to/isolated/repo --work /tmp/f13-verify --mutations
```

5. 核验 12 项（F13 六项+原 F12 六项）、F34 五项、S5 八项、A 五项 XML，以及九个变异命中指定断言。崩溃、超时和编译错误不是有效变异检出。
6. 仅保留本轮结果压缩包；删除临时 work/展开源码。不要将测试适配器 ReadBody 搬到 production。

恢复顺序和接口含义按 F13 §11。预期字节来自输入模型；元数据查询与实际 Data IO 均经过正式库，EIO/暂停仅通过链接包装。这里没有 F14 物理释放或完整对象服务，不代表节点 SQL/Raft E2E、真实裸设备、掉电和性能验收。未来正式对象链路可沿 F13 的风险条目接管同一场景，不新增每层重复测试。

非零起点复审：范围场景主要数据映射从 7u+137 起，故障场景从 2u+113 起。生产哈希未变，旧 F13 包已被本版替换。
