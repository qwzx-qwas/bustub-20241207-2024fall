# F08 恢复方式

只在仓库外恢复；不把阶段测试重新注册为常驻目标。

1. 在仓库的 `test/archives` 执行 `sha256sum -c SHA256SUMS`，将本包解压到独立临时目录。
2. 生产源码必须与 MANIFEST.json 的 production_sha256 匹配。历史基准 `015f95bf91cb7039d35e9163263f80b61a5d6dd5` 本身没有 F08：可在隔离目录恢复该提交，再覆盖本地 `F08-results.tar.gz` 的 `source/` 文件；不要覆盖当前工作树。
3. runner 与 C++ 源码保持同目录，执行：

```bash
python3 /外部解压目录/F08-metadata-engine/test/storage_redesign/run_stage.py \
  --repo /匹配源码的绝对路径 --work /另一个外部工作目录 --mutations
```

runner 使用 clang 14/CMake/ASan/UBSan，构建真实全库、六项组件和既有十二项 A 回归，再检验十二个定向变异；需要 Linux Direct 文件 IO。测试创建各自的 192 MiB 稀疏临时文件，不使用用户裸设备。工作目录不可位于源码仓库中；重跑需留足构建空间（本次约 848 MiB），不是性能压力测试。

日志、XML 和 commands.json 留在指定 work；runner 明确过滤测试、清理 GTEST_* 干扰并核对数量，不能仅以退出 0 代替实际用例执行。变异修改只在 work 中，正常生产源码不修改。未知结果场景的 EIO/暂停仅在测试链接侧。

该包只有最终测试源码、runner、说明和清单，没有二进制/镜像/构建缓存。结果与八项审查的范围限制仍适用。后续正式业务接入沿 F08 风险标识复用共同 C/P 内容，不能把这些组件测试改个名字就声称完整 E2E。

## 2026-09-26 清理复核的版本区别

当前 production_sha256 对应只删除两个未使用私有 ReadGuard 成员后的代码；本次仅重新执行 Clang/GCC 语法与格式检查，未重新跑六项/十二项/十二变异。测试源码与 runner 未改变，已保存运行证据仍属于 runtime_evidence_production_sha256 指定的版本。

本地结果包 source/ 保存当前清理版；若要精确还原那次已保存的运行，恢复 source/ 后再覆盖 runtime-source/ 的唯一差异文件。runtime-manifest.json 保存原运行版本清单。若重新验证当前版，使用 source/ 和本包原 runner 正常运行即可；不要把编译检查记为新一次运行通过。
