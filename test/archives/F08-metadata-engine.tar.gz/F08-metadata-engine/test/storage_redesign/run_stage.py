"""Opt-in F08 integration and existing A regressions; no permanent test registration."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time
import xml.etree.ElementTree as ET

TESTS = {
    'MixedValuesSplitMergeAndReopen', 'OldViewsConflictAndSpaceReuse',
    'RejectedPrivateChangesDoNotLeak', 'PublicationWaitsForDurabilityAndFaultsOnUnknownResult',
    'ProcessExitReplaysConfirmedNonemptyTransactions', 'ValidJournalCannotHideWrongMetadataRedoBase',
}
REGRESSIONS = {
    'b_plus_tree_insert_test': 3, 'b_plus_tree_delete_test': 2,
    'b_plus_tree_sequential_scale_test': 1, 'canonical_snapshot_test': 2, 'raft_state_machine_test': 4,
}

def check_xml(path, count, names=None):
    cases = ET.parse(path).getroot().findall('./testsuite/testcase')
    if len(cases) != count or (names is not None and {c.get('name') for c in cases} != names):
        raise RuntimeError('wrong test discovery: ' + str(path))
    if any(c.get('status') != 'run' or c.get('result') != 'completed' or
           c.find('failure') is not None or c.find('skipped') is not None for c in cases):
        raise RuntimeError('failed/skipped tests: ' + str(path))

parser = argparse.ArgumentParser()
parser.add_argument('--repo', required=True)
parser.add_argument('--work', required=True)
parser.add_argument('--mutations', action='store_true')
args = parser.parse_args()
repo, work = Path(args.repo).resolve(), Path(args.work).resolve()
if repo == work or repo in work.parents:
    raise RuntimeError('work must be outside the repository')
work.mkdir(parents=True, exist_ok=True)
build = work / 'build'
env = {k: v for k, v in os.environ.items() if not k.startswith('GTEST_')}
env.update(F08_WORKDIR=str(work), ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',
           UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
commands = []

def call(argv, log, expected=0, timeout=300, cwd=None):
    argv = list(map(str, argv))
    entry = {'command': argv, 'log': log}
    commands.append(entry)
    begin = time.monotonic()
    try:
        with (work / log).open('w') as output:
            result = subprocess.run(argv, stdout=output, stderr=subprocess.STDOUT, env=env,
                                    cwd=cwd or work, timeout=timeout)
        entry['exit'] = result.returncode
        if result.returncode != expected:
            raise RuntimeError(f'{log}: exit {result.returncode}, expected {expected}')
    except subprocess.TimeoutExpired:
        entry['timeout_seconds'] = timeout
        raise
    finally:
        entry['elapsed_seconds'] = time.monotonic() - begin
        (work / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')

call(['cmake', '-S', repo, '-B', build, '-DCMAKE_BUILD_TYPE=Debug', '-DCMAKE_C_COMPILER=clang-14',
      '-DCMAKE_CXX_COMPILER=clang++-14', '-DBUSTUB_SANITIZER=address,undefined',
      '-DCMAKE_EXE_LINKER_FLAGS=-no-pie'], 'configure.log')
call(['cmake', '--build', build, '--target', 'bustub', 'gtest_main', *REGRESSIONS, '-j3'], 'build.log', timeout=900)
flags = ['clang++-14', '-std=c++17', '-g', '-O0', '-Wall', '-Wextra', '-Werror', '-Wno-unused-parameter',
         '-fsanitize=address,undefined', '-fno-omit-frame-pointer', '-pthread',
         '-I' + str(repo / 'src/include'), '-I' + str(repo / 'third_party/fmt/include'),
         '-I' + str(repo / 'third_party/googletest/googletest/include')]
source = Path(__file__).with_name('metadata_engine_test.cpp')
obj = work / 'stage-test.o'
call(flags + ['-c', source, '-o', obj], 'test-compile.log')
libs = [build / 'lib' / name for name in ['libbustub.a', 'libfmtd.a', 'libgtest_main.a', 'libgtest.a']]
def link(binary, overrides=()):
    call(flags + ['-no-pie', obj, *overrides, *libs, '-Wl,--wrap=fdatasync', '-o', binary], binary.name + '-link.log')

binary = work / 'stage-test'
link(binary)
xml = work / 'results.xml'
xml.unlink(missing_ok=True)
call([binary, '--gtest_filter=MetadataEngineTest.*', '--gtest_repeat=1', '--gtest_shuffle=0',
      '--gtest_output=xml:' + str(xml)], 'run.log')
check_xml(xml, 6, TESTS)
print('F08: six real component cases passed', flush=True)
for name, count in REGRESSIONS.items():
    output = work / (name + '.xml')
    output.unlink(missing_ok=True)
    call([build / 'test' / name, '--gtest_filter=*', '--gtest_repeat=1', '--gtest_shuffle=0',
          '--gtest_output=xml:' + str(output)], name + '-run.log', timeout=180)
    check_xml(output, count)
print('A: twelve unchanged tree/snapshot/state-machine regression cases passed', flush=True)

if args.mutations:
    original = (repo / 'src/storage/disk/metadata_engine.cpp').read_text()
    mutants = []
    def add(name, old, new, test, oracle):
        if original.count(old) != 1:
            raise RuntimeError('mutation source drift: ' + name)
        mutants.append((name, original.replace(old, new), test, oracle))
    conflict = 'OldViewsConflictAndSpaceReuse'
    private = 'RejectedPrivateChangesDoNotLeak'
    publish = 'PublicationWaitsForDurabilityAndFaultsOnUnknownResult'
    add('ignore_stale_base', 'if (base.version_ != s.published_) {', 'if (false) {',
        conflict, 'stale view must not overwrite a newer commit')
    add('ignore_page_capacity', 'if (working_->pages_.size() >= limit_) {', 'if (false && working_->pages_.size() >= limit_) {',
        private, 'page capacity must reject the complete transaction')
    add('keep_dead_slot_directory', '  Store(page->data_.data(), 4, count);',
        '  /* mutated: leave the deleted slot directory at its old length */',
        conflict, 'metadata page region is full')
    add('ignore_reader_budget', 'if (live >= budget->limit_) {', 'if (false) {',
        private, 'reader retention must stay within the live-page budget')
    add('publish_before_flush', '    submission.ticket_->Wait();',
        '    { std::lock_guard<std::mutex> lock(view_mutex_); published_ = next; }\n    submission.ticket_->Wait();',
        publish, 'entry.value_')
    add('report_unknown_as_success', '      ready_ = false;\n      return result;',
        '      ready_ = false;\n      result.outcome_ = JournalOutcome::Durable;\n      return result;',
        publish, 'JournalOutcome::Indeterminate')
    add('keep_serving_after_unknown', '      ready_ = false;', '      ready_ = true;',
        publish, 'engine.Read()')
    # Keep valid outer Journal checksums: the test isolates B\'s page base contract.
    old = '''      Require(before ? before->generation_ == base_generation && before->lsn_ == base_lsn
                     : base_generation == 0 && base_lsn == 0,
              "metadata redo base is missing");'''
    # clang-format alignment can be inspected once; fail on source drift, never silently skip a mutant.
    if old not in original:
        begin = original.index('      Require(before ?')
        end = original.index('"metadata redo base is missing");', begin) + len('"metadata redo base is missing");')
        old = original[begin:end]
    add('ignore_redo_base', old, '      (void)base_generation; (void)base_lsn;',
        'ValidJournalCannotHideWrongMetadataRedoBase', 'wrong metadata redo base must stop recovery')
    add('omit_patch_application', '          std::copy(bytes.begin(), bytes.end(), body.begin() + offset);',
        '          /* mutated: discard valid patch bytes */',
        'ProcessExitReplaysConfirmedNonemptyTransactions', 'metadata reconstructed page checksum mismatch')
    add('ignore_scan_lower', 'auto it = tree.Begin(EncodeKey(lower))', 'auto it = tree.Begin()',
        'MixedValuesSplitMergeAndReopen', 'bounded scan must honor lower key')
    add('ignore_scan_limit', '!it.IsEnd() && result.size() < limit', '!it.IsEnd()',
        'MixedValuesSplitMergeAndReopen', 'bounded scan must honor lower key and limit')
    add('reverse_key_order', 'std::memcmp(a.data_, b.data_, sizeof(a.data_))',
        'std::memcmp(b.data_, a.data_, sizeof(a.data_))',
        'MixedValuesSplitMergeAndReopen', 'entries.size()')
    results = []
    for name, code, test, oracle in mutants:
        cpp, mutant_obj, exe = (work / (name + suffix) for suffix in ('.cpp', '.o', ''))
        cpp.write_text(code)
        call(flags + ['-c', cpp, '-o', mutant_obj], name + '-compile.log')
        link(exe, [mutant_obj])
        output = work / (name + '.xml')
        output.unlink(missing_ok=True)
        call([exe, '--gtest_filter=MetadataEngineTest.' + test, '--gtest_repeat=1', '--gtest_shuffle=0',
              '--gtest_output=xml:' + str(output)], name + '-run.log', expected=1, timeout=180)
        cases = ET.parse(output).getroot().findall('./testsuite/testcase')
        failures = [failure for c in cases for failure in c.findall('failure')]
        if len(cases) != 1 or cases[0].get('name') != test or not any(oracle in (f.text or '') for f in failures):
            raise RuntimeError('mutation failed for the wrong reason: ' + name)
        results.append({'name': name, 'test': test, 'oracle': oracle, 'exit': 1})
        (work / 'mutations.json').write_text(json.dumps(results, indent=2) + '\n')
        cpp.unlink(); mutant_obj.unlink(); exe.unlink()
        print('caught ' + name, flush=True)
    print('F08: twelve specified mutants rejected by their intended oracles', flush=True)

(work / 'environment.json').write_text(json.dumps({k: env[k] for k in ('ASAN_OPTIONS','UBSAN_OPTIONS','F08_WORKDIR')},indent=2)+'\n')
