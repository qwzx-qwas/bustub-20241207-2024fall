#include <fcntl.h>
#include <sys/wait.h>
#include <unistd.h>

#include <algorithm>
#include <cerrno>
#include <chrono>
#include <condition_variable>
#include <cstdlib>
#include <future>
#include <limits>
#include <map>
#include <mutex>
#include <numeric>
#include <string>
#include <tuple>
#include <vector>

#include "gtest/gtest.h"
#include "storage/disk/block_device.h"
#include "storage/disk/io_executor.h"
#include "storage/disk/metadata_engine.h"

extern "C" int __real_fdatasync(int);
namespace {
std::mutex gate_mutex;
std::condition_variable gate_cv;
bool pause_flush = false;
bool entered_flush = false;
bool error_flush = false;
void Release() {
  std::lock_guard<std::mutex> guard(gate_mutex);
  pause_flush = false;
  error_flush = false;
  gate_cv.notify_all();
}
struct ReleaseOnExit {
  ~ReleaseOnExit() { Release(); }
};
}  // namespace
extern "C" int __wrap_fdatasync(int fd) {
  {
    std::unique_lock<std::mutex> guard(gate_mutex);
    if (pause_flush) {
      entered_flush = true;
      gate_cv.notify_all();
      gate_cv.wait(guard, [] { return !pause_flush; });
    }
    if (error_flush) {
      errno = EIO;
      return -1;
    }
  }
  return __real_fdatasync(fd);
}
namespace bustub {
namespace {
using Bytes = std::vector<std::byte>;
using ModelKey = std::tuple<uint64_t, uint64_t, uint64_t>;
using Model = std::map<ModelKey, Bytes>;
constexpr uint64_t MIB = 1024 * 1024;
constexpr uint64_t CAPACITY = 192 * MIB;
auto Key(uint64_t i) -> MetadataKey { return {1 + i % 4, i % 17, i}; }
auto ModelOf(MetadataKey key) -> ModelKey { return {key.category_, key.owner_, key.item_}; }
auto KeyOf(ModelKey key) -> MetadataKey { return {std::get<0>(key), std::get<1>(key), std::get<2>(key)}; }
auto Value(size_t length, unsigned seed) -> Bytes {
  Bytes b(length);
  for (size_t i = 0; i < length; i++) {
    b[i] = std::byte((i * 19 + seed * 31 + i / 23) % 251);
  }
  return b;
}
auto Range(uint64_t start, uint64_t size) -> StorageByteRange { return *StorageByteRange::Create(start, size); }
struct ImageFile {
  std::string path;
  ImageFile() {
    const char *work = std::getenv("F08_WORKDIR");
    if (!work) {
      throw std::runtime_error("F08_WORKDIR must name an explicit scratch directory");
    }
    path = std::string(work) + "/metadata-device-XXXXXX";
    int fd = mkstemp(path.data());
    if (fd < 0) {
      throw std::runtime_error("mkstemp failed");
    }
    int result = ftruncate(fd, CAPACITY);
    close(fd);
    if (result != 0) {
      unlink(path.c_str());
      throw std::runtime_error("ftruncate failed");
    }
  }
  ~ImageFile() { unlink(path.c_str()); }
};
struct Stack {
  BlockDevice device;
  IOExecutor io;
  BootstrapStore bootstrap;
  JournalIdentity identity{};
  BootstrapIdentity root{};
  JournalOptions journal;
  MetadataOptions options{2048, 8192, 65536, 2 * MIB};
  explicit Stack(const std::string &path, bool create)
      : device(path, BlockDeviceOptions{}), io(device, {3, 4096, 32 * MIB}), bootstrap(io) {
    auto unit = static_cast<uint32_t>(std::lcm<uint64_t>(4096, device.Info().offset_alignment_));
    if (unit > 65536) {
      throw std::runtime_error("test device alignment exceeds explicit fixture budget");
    }
    journal = {64ULL * unit, unit, 8192, 2 * MIB, 1024, 4 * MIB, 8, 32, 8 * MIB};
    identity.fill(59);
    root.storage_.fill(17);
    root.device_.fill(37);
    if (create) {
      bootstrap.Create(
          {root, CAPACITY, {Range(2 * MIB, 8 * MIB), Range(10 * MIB, 128 * MIB), Range(140 * MIB, 32 * MIB)}});
    }
    bootstrap.Open(root);
  }
  ~Stack() {
    bootstrap.Close();
    io.Shutdown();
  }
};
void Apply(MetadataEngine &engine, const std::vector<MetadataMutation> &batch, Model *expected) {
  auto result = engine.Commit(engine.Read(), batch);
  ASSERT_EQ(result.outcome_, JournalOutcome::Durable);
  for (const auto &m : batch) {
    if (m.value_) {
      (*expected)[ModelOf(m.key_)] = *m.value_;
    } else {
      expected->erase(ModelOf(m.key_));
    }
  }
}
void Check(const MetadataSnapshot &view, const Model &expected) {
  const auto entries = view.Scan({0, 0, 0}, expected.size() + 1);
  ASSERT_EQ(entries.size(), expected.size());
  auto oracle = expected.begin();
  for (const auto &entry : entries) {
    ASSERT_EQ(ModelOf(entry.key_), oracle->first);
    ASSERT_EQ(entry.value_, oracle->second);
    auto found = view.Get(KeyOf(oracle->first));
    ASSERT_TRUE(found.has_value());
    ASSERT_EQ(*found, oracle->second);
    ++oracle;
  }
  EXPECT_FALSE(view.Get({9, 0, 0}).has_value());
}
// Expected range is derived from the input model, independent of the tree's
// comparator/iterator and the production result count.
void CheckScan(const MetadataSnapshot &view, const Model &model, MetadataKey lower, size_t limit) {
  std::vector<std::pair<ModelKey, Bytes>> expected;
  for (auto it = model.lower_bound(ModelOf(lower)); it != model.end() && expected.size() < limit; ++it) {
    expected.push_back(*it);
  }
  const auto actual = view.Scan(lower, limit);
  ASSERT_EQ(actual.size(), expected.size()) << "bounded scan must honor lower key and limit";
  for (size_t i = 0; i < expected.size(); ++i) {
    EXPECT_EQ(ModelOf(actual[i].key_), expected[i].first) << "bounded scan must honor lower key";
    EXPECT_EQ(actual[i].value_, expected[i].second);
  }
}
TEST(MetadataEngineTest, MixedValuesSplitMergeAndReopen) {
  ImageFile file;
  Model expected;
  {
    Stack s(file.path, true);
    MetadataEngine engine(s.bootstrap, s.identity, s.journal, s.options);
    engine.Create();
    // Enough actual entries to grow past a single internal node at production
    // capacities.
    for (uint64_t start = 0; start < 12000; start += 250) {
      std::vector<MetadataMutation> batch;
      for (uint64_t i = start; i < start + 250; i++) {
        batch.push_back({Key(i), Value(i % 311 == 0 ? 6001 + i % 97 : 17 + i % 111, i % 13)});
      }
      Apply(engine, batch, &expected);
      ASSERT_FALSE(HasFatalFailure());
    }
    Apply(engine, {{{UINT64_MAX, UINT64_MAX, UINT64_MAX}, Value(23, 91)}, {{0, 0, 0}, Bytes{}}}, &expected);
    Check(engine.Read(), expected);
    ASSERT_FALSE(HasFatalFailure());
    // Existing key, an absent lower key between rows, and the last key. These
    // are different range failures; all use the real mixed multi-page tree.
    CheckScan(engine.Read(), expected, Key(7111), 7);
    CheckScan(engine.Read(), expected, {0, 0, 1}, 5);
    CheckScan(engine.Read(), expected, {UINT64_MAX, UINT64_MAX, UINT64_MAX}, 3);
    ASSERT_FALSE(HasFatalFailure());
    for (uint64_t start = 0; start < 11000; start += 250) {
      std::vector<MetadataMutation> batch;
      for (uint64_t i = start; i < start + 250; i++) {
        batch.push_back({Key(i), std::nullopt});
      }
      Apply(engine, batch, &expected);
      ASSERT_FALSE(HasFatalFailure());
    }
    Check(engine.Read(), expected);
  }
  {
    Stack s(file.path, false);
    MetadataEngine engine(s.bootstrap, s.identity, s.journal, s.options);
    engine.Open();
    Check(engine.Read(), expected);
    // Key(7111) has been removed; lower_bound must still locate the next
    // surviving entry after recovery rather than demand an exact match.
    CheckScan(engine.Read(), expected, Key(7111), 9);
    Apply(engine, {{Key(0), Value(9011, 61)}, {Key(11000), Value(3, 44)}}, &expected);
    Check(engine.Read(), expected);
  }
  Stack s(file.path, false);
  MetadataEngine reopened(s.bootstrap, s.identity, s.journal, s.options);
  reopened.Open();
  Check(reopened.Read(), expected);
}
TEST(MetadataEngineTest, OldViewsConflictAndSpaceReuse) {
  ImageFile file;
  Model expected;
  {
    Stack s(file.path, true);
    s.options.page_limit_ = 32;
    s.options.max_live_pages_ = 96;
    MetadataEngine engine(s.bootstrap, s.identity, s.journal, s.options);
    engine.Create();
    std::vector<MetadataMutation> initial;
    for (uint64_t i = 0; i < 180; i++) {
      initial.push_back({Key(i), Value(60, i % 7)});
    }
    Apply(engine, initial, &expected);
    ASSERT_FALSE(HasFatalFailure());
    auto old = engine.Read();
    const auto old_expected = expected;
    for (unsigned n = 0; n < 80; n++) {
      std::vector<MetadataMutation> batch;
      for (uint64_t i = 0; i < 180; i++) {
        batch.push_back({Key(i), std::nullopt});
      }
      Apply(engine, batch, &expected);
      ASSERT_FALSE(HasFatalFailure());
      Apply(engine, {{Key(1000), Value(16013, n)}, {Key(1001), Value(3999, n)}}, &expected);
      ASSERT_FALSE(HasFatalFailure());
      Apply(engine, {{Key(1000), std::nullopt}, {Key(1001), std::nullopt}}, &expected);
      // Keep the final live values different from the pinned original view.
      for (size_t i = 0; i < initial.size(); i++) {
        initial[i].value_ = Value(60, static_cast<unsigned>(i % 7 + n + 1));
      }
      Apply(engine, initial, &expected);
      ASSERT_FALSE(HasFatalFailure());
    }
    Check(old, old_expected);
    Check(engine.Read(), expected);
    try {
      engine.Commit(old, {{Key(0), Value(10, 91)}});
      FAIL() << "stale view must not overwrite a newer commit";
    } catch (const MetadataError &e) {
      EXPECT_EQ(e.Code(), MetadataErrorCode::Conflict);
    }
  }
  Stack s(file.path, false);
  s.options.page_limit_ = 32;
  s.options.max_live_pages_ = 96;
  MetadataEngine engine(s.bootstrap, s.identity, s.journal, s.options);
  engine.Open();
  Check(engine.Read(), expected);
}
TEST(MetadataEngineTest, RejectedPrivateChangesDoNotLeak) {
  ImageFile file;
  Model expected;
  {
    Stack s(file.path, true);
    s.options.page_limit_ = 8;
    s.options.max_live_pages_ = 32;
    MetadataEngine engine(s.bootstrap, s.identity, s.journal, s.options);
    engine.Create();
    Apply(engine, {{Key(1), Value(27, 3)}, {Key(2), Value(33, 4)}}, &expected);
    ASSERT_FALSE(HasFatalFailure());
    // First operation modifies private pages; the later overflow exhausts real
    // slots.
    for (int attempt = 0; attempt < 3; attempt++) {
      try {
        engine.Commit(engine.Read(), {{Key(1), Value(200, 99)}, {Key(3), Value(65536, 11)}});
        FAIL() << "page capacity must reject the complete transaction";
      } catch (const MetadataError &e) {
        EXPECT_EQ(e.Code(), MetadataErrorCode::ResourceUnavailable);
      }
      Check(engine.Read(), expected);
    }
    Apply(engine, {{Key(2), Value(11, 71)}}, &expected);
    ASSERT_FALSE(HasFatalFailure());
    // Reader-held old versions must consume budget; releasing them restores
    // admission.
    const auto original = expected;
    std::vector<MetadataSnapshot> readers;
    bool exhausted = false;
    for (unsigned i = 0; i < 64; i++) {
      readers.push_back(engine.Read());
      auto value = Value(27, 100 + i);
      try {
        auto result = engine.Commit(engine.Read(), {{Key(1), value}});
        ASSERT_EQ(result.outcome_, JournalOutcome::Durable);
        expected[ModelOf(Key(1))] = value;
      } catch (const MetadataError &e) {
        ASSERT_EQ(e.Code(), MetadataErrorCode::ResourceUnavailable);
        exhausted = true;
        break;
      }
    }
    ASSERT_TRUE(exhausted) << "reader retention must stay within the live-page budget";
    Check(readers.front(), original);
    Check(engine.Read(), expected);
    readers.clear();
    Apply(engine, {{Key(1), Value(29, 77)}}, &expected);
    ASSERT_FALSE(HasFatalFailure());
  }
  Stack s(file.path, false);
  s.options.page_limit_ = 8;
  s.options.max_live_pages_ = 32;
  MetadataEngine engine(s.bootstrap, s.identity, s.journal, s.options);
  engine.Open();
  Check(engine.Read(), expected);
}
TEST(MetadataEngineTest, PublicationWaitsForDurabilityAndFaultsOnUnknownResult) {
  ImageFile file;
  Model expected;
  {
    Stack s(file.path, true);
    MetadataEngine engine(s.bootstrap, s.identity, s.journal, s.options);
    engine.Create();
    Apply(engine, {{Key(1), Value(51, 1)}, {Key(2), Value(72, 2)}}, &expected);
    auto old = engine.Read();
    auto old_expected = expected;
    const std::vector<MetadataMutation> batch{{Key(1), Value(8011, 17)}, {Key(2), Value(7, 18)}};
    {
      std::lock_guard<std::mutex> lock(gate_mutex);
      pause_flush = true;
      entered_flush = false;
    }
    auto future = std::async(std::launch::async, [&] { return engine.Commit(old, batch); });
    ReleaseOnExit release;
    {
      std::unique_lock<std::mutex> lock(gate_mutex);
      ASSERT_TRUE(gate_cv.wait_for(lock, std::chrono::seconds(10), [] { return entered_flush; }));
    }
    EXPECT_EQ(future.wait_for(std::chrono::milliseconds(0)), std::future_status::timeout);
    Check(engine.Read(), old_expected);
    Release();
    ASSERT_EQ(future.get().outcome_, JournalOutcome::Durable);
    for (const auto &m : batch) {
      expected[ModelOf(m.key_)] = *m.value_;
    }
    Check(old, old_expected);
    Check(engine.Read(), expected);
    {
      std::lock_guard<std::mutex> lock(gate_mutex);
      error_flush = true;
    }
    auto result = engine.Commit(engine.Read(), {{Key(3), Value(93, 99)}, {Key(4), Value(44, 100)}});
    Release();
    ASSERT_EQ(result.outcome_, JournalOutcome::Indeterminate);
    ASSERT_NE(result.error_, nullptr);
    EXPECT_THROW(engine.Read(), MetadataError);
    EXPECT_THROW(engine.Commit(old, {{Key(5), Value(17, 7)}}), MetadataError);
    expected[ModelOf(Key(3))] = Value(93, 99);
    expected[ModelOf(Key(4))] = Value(44, 100);
  }
  // The injected failure was only fdatasync; all actual Direct writes
  // completed. Open must revalidate/reflush the complete batch before exposing
  // it.
  Stack s(file.path, false);
  MetadataEngine engine(s.bootstrap, s.identity, s.journal, s.options);
  engine.Open();
  Check(engine.Read(), expected);
}
TEST(MetadataEngineTest, ProcessExitReplaysConfirmedNonemptyTransactions) {
  ImageFile file;
  Model expected;
  for (uint64_t i = 0; i < 64; i++) {
    expected[ModelOf(Key(i))] = Value(31 + i, i);
  }
  for (uint64_t i = 0; i < 12; i++) {
    expected.erase(ModelOf(Key(i)));
  }
  expected[ModelOf(Key(63))] = Value(13013, 81);
  // No IO workers exist in this process when it forks.
  pid_t child = fork();
  ASSERT_GE(child, 0);
  if (child == 0) {
    try {
      Stack s(file.path, true);
      MetadataEngine engine(s.bootstrap, s.identity, s.journal, s.options);
      engine.Create();
      std::vector<MetadataMutation> initial;
      for (uint64_t i = 0; i < 64; i++) {
        initial.push_back({Key(i), Value(31 + i, i)});
      }
      if (engine.Commit(engine.Read(), initial).outcome_ != JournalOutcome::Durable) {
        _exit(41);
      }
      std::vector<MetadataMutation> edits;
      for (uint64_t i = 0; i < 12; i++) {
        edits.push_back({Key(i), std::nullopt});
      }
      edits.push_back({Key(63), Value(13013, 81)});
      if (engine.Commit(engine.Read(), edits).outcome_ != JournalOutcome::Durable) {
        _exit(42);
      }
      _exit(0);  // Deliberately no destructor/Close/checkpoint.
    } catch (...) {
      _exit(43);
    }
  }
  int status = 0;
  ASSERT_EQ(waitpid(child, &status, 0), child);
  ASSERT_TRUE(WIFEXITED(status));
  ASSERT_EQ(WEXITSTATUS(status), 0);
  Stack s(file.path, false);
  MetadataEngine engine(s.bootstrap, s.identity, s.journal, s.options);
  engine.Open();
  Check(engine.Read(), expected);
}
TEST(MetadataEngineTest, ValidJournalCannotHideWrongMetadataRedoBase) {
  ImageFile file;
  Stack s(file.path, true);
  {
    MetadataEngine engine(s.bootstrap, s.identity, s.journal, s.options);
    engine.Create();
    ASSERT_EQ(engine.Commit(engine.Read(), {{Key(1), Value(31, 1)}}).outcome_, JournalOutcome::Durable);
    ASSERT_EQ(engine.Commit(engine.Read(), {{Key(1), Value(32, 2)}}).outcome_, JournalOutcome::Durable);
  }
  {
    JournalService journal(s.bootstrap, s.identity, s.journal);
    JournalRecords last;
    uint64_t latest = 0;
    journal.Open([&](uint64_t lsn, const JournalRecords &records) {
      last = records;
      latest = lsn;
    });
    ASSERT_GE(last.size(), size_t{2});
    ASSERT_EQ(last[0].size(), size_t{48});
    // Append a batch claiming to follow latest, but retain old page base
    // versions. Only test-side byte editing; F07 produces fresh valid outer
    // checksums.
    for (size_t i = 0; i < 8; i++) {
      last[0][32 + i] = std::byte((latest >> ((7 - i) * 8)) & 255U);
    }
    auto accepted = journal.TryAppend(last);
    ASSERT_EQ(accepted.admission_, JournalAdmission::Accepted);
    ASSERT_TRUE(accepted.ticket_->WaitFor(std::chrono::seconds(10)));
    ASSERT_EQ(accepted.ticket_->Result().outcome_, JournalOutcome::Durable);
  }
  MetadataEngine reopened(s.bootstrap, s.identity, s.journal, s.options);
  try {
    reopened.Open();
    FAIL() << "wrong metadata redo base must stop recovery";
  } catch (const MetadataError &e) {
    EXPECT_EQ(e.Code(), MetadataErrorCode::Corrupt);
  }
  EXPECT_THROW(reopened.Read(), MetadataError);
}
}  // namespace
}  // namespace bustub
