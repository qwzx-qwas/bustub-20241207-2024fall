// Temporary F02 integration checks; all observation/injection is test-side.
#include "storage/disk/io_executor.h"

#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>

#include <algorithm>
#include <atomic>
#include <cerrno>
#include <condition_variable>
#include <cstdlib>
#include <filesystem>
#include <functional>
#include <future>
#include <iostream>
#include <limits>
#include <memory>
#include <mutex>
#include <numeric>
#include <stdexcept>
#include <string>
#include <vector>

#include "gtest/gtest.h"

extern "C" ssize_t __real_pread(int, void *, size_t, off_t);
extern "C" ssize_t __real_pwrite(int, const void *, size_t, off_t);
extern "C" int __real_fdatasync(int);
extern "C" void *__real_malloc(size_t);
extern "C" void *__real__Znwm(size_t);

using namespace std::chrono_literals;
namespace observation {
std::mutex mutex;
std::condition_variable changed;
off_t paused_offset = -1;
bool released = true;
bool entered = false;
off_t short_offset = -1;
size_t short_count = 0;
off_t fail_offset = -1;
bool failed = false;
bool sync_error = false;
size_t write_calls = 0;
size_t read_calls = 0;
size_t successful_writes = 0;
size_t sync_calls = 0;
size_t successful_syncs = 0;
size_t required_writes = 0;
bool early_flush = false;
thread_local size_t fail_allocation = 0;
thread_local size_t fail_new_number = 0;
thread_local bool new_failed = false;

void Reset() {
  std::lock_guard<std::mutex> lock(mutex);
  paused_offset = short_offset = fail_offset = -1;
  short_count = 0;
  released = true;
  entered = failed = sync_error = early_flush = false;
  write_calls = read_calls = successful_writes = sync_calls = successful_syncs = required_writes = 0;
  fail_allocation = 0;
  fail_new_number = 0;
  new_failed = false;
}
void Pause(off_t offset) {
  std::lock_guard<std::mutex> lock(mutex);
  paused_offset = offset;
  released = false;
}
void Release() {
  std::lock_guard<std::mutex> lock(mutex);
  released = true;
  changed.notify_all();
}
struct ReleaseOnExit {
  ~ReleaseOnExit() { Release(); }
};
template <class Predicate>
auto Await(Predicate predicate) -> bool {
  std::unique_lock<std::mutex> lock(mutex);
  return changed.wait_for(lock, 5s, predicate);
}
}  // namespace observation

extern "C" void *__wrap__Znwm(size_t size) {
  if (observation::fail_new_number != 0 && --observation::fail_new_number == 0) {
    observation::new_failed = true;
    throw std::bad_alloc();
  }
  return __real__Znwm(size);
}
extern "C" void *__wrap_malloc(size_t size) {
  if (observation::fail_allocation != 0 && observation::fail_allocation == size) {
    observation::fail_allocation = 0;
    errno = ENOMEM;
    return nullptr;
  }
  return __real_malloc(size);
}
extern "C" ssize_t __wrap_pread(int fd, void *buffer, size_t count, off_t offset) {
  {
    std::lock_guard<std::mutex> lock(observation::mutex);
    ++observation::read_calls;
  }
  return __real_pread(fd, buffer, count, offset);
}
extern "C" ssize_t __wrap_pwrite(int fd, const void *buffer, size_t count, off_t offset) {
  {
    std::unique_lock<std::mutex> lock(observation::mutex);
    ++observation::write_calls;
    if (offset == observation::paused_offset) {
      observation::entered = true;
      observation::changed.notify_all();
      observation::changed.wait(lock, [] { return observation::released; });
    }
    if (offset == observation::fail_offset) {
      // Ensure another member is genuinely in flight before producing EIO.
      observation::changed.wait(lock, [] { return observation::entered || observation::released; });
      observation::failed = true;
      observation::changed.notify_all();
      errno = EIO;
      return -1;
    }
    if (offset == observation::short_offset) {
      count = std::min(count, observation::short_count);
    }
  }
  auto result = __real_pwrite(fd, buffer, count, offset);
  if (result > 0) {
    std::lock_guard<std::mutex> lock(observation::mutex);
    ++observation::successful_writes;
    observation::changed.notify_all();
  }
  return result;
}
extern "C" int __wrap_fdatasync(int fd) {
  {
    std::lock_guard<std::mutex> lock(observation::mutex);
    ++observation::sync_calls;
    observation::early_flush =
        observation::early_flush || observation::successful_writes < observation::required_writes;
    if (observation::sync_error) {
      observation::sync_error = false;
      errno = EIO;
      return -1;
    }
  }
  auto result = __real_fdatasync(fd);
  if (result == 0) {
    std::lock_guard<std::mutex> lock(observation::mutex);
    ++observation::successful_syncs;
  }
  return result;
}

namespace bustub {
namespace {
class Fd {
 public:
  explicit Fd(int fd) : fd_(fd) {
    if (fd < 0) {
      throw std::system_error(errno, std::generic_category());
    }
  }
  ~Fd() { close(fd_); }
  auto Get() const -> int { return fd_; }
  Fd(const Fd &) = delete;
  auto operator=(const Fd &) -> Fd & = delete;

 private:
  int fd_;
};
auto Pattern(size_t size, size_t offset, unsigned seed) -> std::vector<char> {
  std::vector<char> data(size);
  for (size_t i = 0; i < size; ++i) {
    auto address = offset + i;
    data[i] = static_cast<char>((address * 131 + (address >> 8) * 17 + seed) ^ (address >> 16));
  }
  return data;
}
auto Range(size_t offset, size_t length) -> StorageByteRange {
  return StorageByteRange::Create(offset, length).value();
}
// Test-owned aligned bytes, not a substitute for the future FrameArena.
// A lease captures this allocation; observers can drop their copy during IO.
struct ExternalBytes {
  ExternalBytes(size_t size, size_t alignment) : storage(size + alignment - 1), capacity(size) {
    auto remainder = reinterpret_cast<uintptr_t>(storage.data()) % alignment;
    data = storage.data() + (remainder == 0 ? 0 : alignment - remainder);
  }
  std::vector<char> storage;
  char *data;
  size_t capacity;
};
using Returns = std::shared_ptr<std::atomic<size_t>>;
auto Permission(const std::shared_ptr<ExternalBytes> &bytes, IOOperation operation, const Returns &returned)
    -> IOBufferLease {
  auto release = [bytes, returned] { returned->fetch_add(1); };
  return operation == IOOperation::Read ? IOBufferLease::ForRead(bytes->data, bytes->capacity, release)
                                        : IOBufferLease::ForWrite(bytes->data, bytes->capacity, release);
}
class IOExecutorTest : public ::testing::Test {
 protected:
  void SetUp() override {
    observation::Reset();
    const char *root = std::getenv("F02_WORKDIR");
    ASSERT_NE(root, nullptr);
    std::string name = std::string(root) + "/device-XXXXXX";
    std::vector<char> writable(name.begin(), name.end());
    writable.push_back('\0');
    auto *created = mkdtemp(writable.data());
    ASSERT_NE(created, nullptr);
    directory_ = created;
    path_ = directory_ / "image";
    Fd fd(open(path_.c_str(), O_RDWR | O_CREAT | O_EXCL | O_CLOEXEC, 0600));
    struct statx info {};
    ASSERT_EQ(statx(fd.Get(), "", AT_EMPTY_PATH, STATX_DIOALIGN, &info), 0);
    ASSERT_NE(info.stx_mask & STATX_DIOALIGN, 0U);
    ASSERT_GT(info.stx_dio_mem_align, 0U);
    ASSERT_GT(info.stx_dio_offset_align, 0U);
    memory_alignment_ = info.stx_dio_mem_align;
    offset_alignment_ = info.stx_dio_offset_align;
    unit_ = std::lcm(memory_alignment_, offset_alignment_);
    ASSERT_LE(unit_, 256U * 1024U);
    capacity_ = 256 * unit_;
    initial_ = Pattern(capacity_, 0, 23);
    size_t done = 0;
    while (done < initial_.size()) {
      auto size = __real_pwrite(fd.Get(), initial_.data() + done, initial_.size() - done, done);
      ASSERT_GT(size, 0);
      done += static_cast<size_t>(size);
    }
    ASSERT_EQ(__real_fdatasync(fd.Get()), 0);
    std::cout << "DIRECT memory=" << memory_alignment_ << " offset=" << offset_alignment_ << " unit=" << unit_
              << " capacity=" << capacity_ << '\n';
  }
  void TearDown() override {
    observation::Reset();
    std::error_code error;
    if (!directory_.empty()) {
      std::filesystem::remove_all(directory_, error);
      EXPECT_FALSE(error) << error.message();
    }
  }
  auto Write(size_t offset, size_t units = 1) const -> IORequest {
    return {IOOperation::Write, Range(offset * unit_, units * unit_)};
  }
  auto Read(size_t offset, size_t units = 1) const -> IORequest {
    return {IOOperation::Read, Range(offset * unit_, units * unit_)};
  }
  auto Options(size_t workers, size_t operations) const -> IOExecutorOptions {
    return {workers, operations, operations * (unit_ * 4 + memory_alignment_ - 1)};
  }
  auto Prepare(IOExecutor &executor, std::vector<IORequest> requests, bool flush) -> IOBatch {
    auto prepared = executor.TryPrepare(std::move(requests), flush);
    if (prepared.admission_ != IOAdmission::Accepted || !prepared.batch_) {
      throw std::runtime_error("valid bounded batch was not admitted");
    }
    return std::move(*prepared.batch_);
  }
  auto Fill(IOBatch &batch, size_t member, size_t offset, size_t units, unsigned seed) -> std::vector<char> {
    auto payload = Pattern(units * unit_, offset * unit_, seed);
    EXPECT_EQ(reinterpret_cast<uintptr_t>(batch.Buffer(member)) % memory_alignment_, 0U);
    std::copy(payload.begin(), payload.end(), batch.Buffer(member));
    return payload;
  }
  auto External(size_t offset, size_t units, unsigned seed) const -> std::shared_ptr<ExternalBytes> {
    auto bytes = std::make_shared<ExternalBytes>(unit_ * units, memory_alignment_);
    auto payload = Pattern(unit_ * units, offset * unit_, seed);
    std::copy(payload.begin(), payload.end(), bytes->data);
    return bytes;
  }
  auto PrepareExternal(IOExecutor &executor, std::vector<IORequest> requests, std::vector<IOBufferLease> &leases,
                       bool flush) -> IOBatch {
    auto prepared = executor.TryPrepareExternal(std::move(requests), leases, flush);
    if (prepared.admission_ != IOAdmission::Accepted || !prepared.batch_) {
      throw std::runtime_error("valid external batch was not admitted");
    }
    EXPECT_TRUE(leases.empty());
    return std::move(*prepared.batch_);
  }
  auto Oracle() const -> std::vector<char> {
    Fd fd(open(path_.c_str(), O_RDONLY | O_CLOEXEC));
    struct stat info {};
    if (fstat(fd.Get(), &info) != 0) {
      throw std::runtime_error("oracle stat failed");
    }
    std::vector<char> result(info.st_size);
    size_t done = 0;
    while (done < result.size()) {
      auto count = __real_pread(fd.Get(), result.data() + done, result.size() - done, done);
      if (count <= 0) {
        throw std::runtime_error("oracle unexpected EOF");
      }
      done += static_cast<size_t>(count);
    }
    return result;
  }
  std::filesystem::path directory_;
  std::filesystem::path path_;
  size_t memory_alignment_{0};
  size_t offset_alignment_{0};
  size_t unit_{0};
  size_t capacity_{0};
  std::vector<char> initial_;
};

TEST_F(IOExecutorTest, ParallelMembersDoNotSkipBarrierHoles) {
  BlockDevice device(path_, BlockDeviceOptions{});
  IOExecutor executor(device, Options(2, 8));
  observation::ReleaseOnExit release;
  observation::Pause(2 * unit_);
  auto batch = Prepare(executor, {Write(2), Write(9), Write(17)}, true);
  auto expected = initial_;
  const size_t offsets[] = {2, 9, 17};
  for (size_t i = 0; i < 3; ++i) {
    auto payload = Fill(batch, i, offsets[i], 1, 81 + i);
    std::copy(payload.begin(), payload.end(), expected.begin() + offsets[i] * unit_);
  }
  {
    std::lock_guard<std::mutex> lock(observation::mutex);
    observation::required_writes = 3;
  }
  ASSERT_EQ(executor.TrySubmit(batch), IOAdmission::Accepted);
  ASSERT_TRUE(observation::Await([] { return observation::entered && observation::successful_writes == 2; }));
  // A separate read can progress with the first write paused. Its completion
  // also ensures the free worker has processed the earlier write completions.
  auto probe = Prepare(executor, {Read(40)}, false);
  ASSERT_EQ(executor.TrySubmit(probe), IOAdmission::Accepted);
  ASSERT_TRUE(probe.WaitFor(5s));
  ASSERT_EQ(probe.Phase(), IOBatchPhase::Succeeded);
  EXPECT_EQ(batch.Phase(), IOBatchPhase::Executing);
  EXPECT_FALSE(batch.WaitFor(0ms));
  EXPECT_THROW(batch.Buffer(0), std::logic_error);
  EXPECT_THROW(batch.Result(), std::logic_error);
  {
    std::lock_guard<std::mutex> lock(observation::mutex);
    EXPECT_EQ(observation::sync_calls, 0U);
  }
  observation::Release();
  ASSERT_TRUE(batch.WaitFor(5s));
  EXPECT_EQ(batch.Phase(), IOBatchPhase::Succeeded);
  EXPECT_TRUE(batch.Result().writes_durable_);
  for (const auto &result : batch.Result().operations_) {
    EXPECT_EQ(result.outcome_, IOOutcome::Succeeded);
    EXPECT_EQ(result.completed_bytes_, unit_);
    EXPECT_FALSE(result.error_);
  }
  auto reads = Prepare(executor, {Read(17), Read(2), Read(9)}, false);
  ASSERT_EQ(executor.TrySubmit(reads), IOAdmission::Accepted);
  reads.Wait();
  ASSERT_EQ(reads.Phase(), IOBatchPhase::Succeeded);
  const size_t positions[] = {17, 2, 9};
  for (size_t i = 0; i < 3; ++i) {
    EXPECT_EQ(reads.Result().operations_[i].outcome_, IOOutcome::Succeeded);
    EXPECT_EQ(reads.Result().operations_[i].completed_bytes_, unit_);
    EXPECT_FALSE(reads.Result().operations_[i].error_);
    EXPECT_TRUE(std::equal(expected.begin() + positions[i] * unit_, expected.begin() + (positions[i] + 1) * unit_,
                           reads.Buffer(i)));
  }
  EXPECT_FALSE(reads.Result().writes_durable_);
  executor.Shutdown();
  EXPECT_EQ(Oracle(), expected);
  std::lock_guard<std::mutex> lock(observation::mutex);
  EXPECT_FALSE(observation::early_flush);
  EXPECT_GT(observation::successful_syncs, 0U);
}

TEST_F(IOExecutorTest, BudgetIncludesPreparedRunningAndRetainedResults) {
  BlockDevice device(path_, BlockDeviceOptions{});
  IOExecutor executor(device, Options(1, 2));
  observation::ReleaseOnExit release;
  observation::Pause(3 * unit_);
  auto prepared = executor.TryPrepare({Write(3), Write(7)}, false);
  ASSERT_EQ(prepared.admission_, IOAdmission::Accepted);
  Fill(*prepared.batch_, 0, 3, 1, 39);
  Fill(*prepared.batch_, 1, 7, 1, 45);
  EXPECT_EQ(executor.TryPrepare({Read(30)}, false).admission_, IOAdmission::Full);
  ASSERT_EQ(executor.TrySubmit(*prepared.batch_), IOAdmission::Accepted);
  ASSERT_TRUE(observation::Await([] { return observation::entered; }));
  EXPECT_EQ(executor.TryPrepare({Read(30)}, false).admission_, IOAdmission::Full);
  observation::Release();
  ASSERT_TRUE(prepared.batch_->WaitFor(5s));
  EXPECT_EQ(executor.TryPrepare({Read(30)}, false).admission_, IOAdmission::Full);
  prepared.batch_.reset();
  auto next = executor.TryPrepare({Read(30), Read(31)}, false);
  ASSERT_EQ(next.admission_, IOAdmission::Accepted);
  next.batch_.reset();

  const size_t charged = unit_ + memory_alignment_ - 1;
  IOExecutor bytes_limited(device, {1, 8, charged * 2});
  EXPECT_EQ(bytes_limited.TryPrepare({Read(20, 3)}, false).admission_, IOAdmission::Full);
  auto fits = bytes_limited.TryPrepare({Read(20), Read(21)}, false);
  ASSERT_EQ(fits.admission_, IOAdmission::Accepted);
  EXPECT_EQ(bytes_limited.TryPrepare({Read(22)}, false).admission_, IOAdmission::Full);
  fits.batch_.reset();
  // Keep the byte-only checks above independent of the member limit. For the
  // failure/retry below, use all member and byte capacity so neither can leak
  // unnoticed. Stop the earlier worker before creating this executor.
  bytes_limited.Shutdown();
  IOExecutor allocation_limited(device, {1, 2, charged * 2});
  observation::fail_allocation = charged;
  EXPECT_THROW(allocation_limited.TryPrepare({Read(20), Read(21)}, false), std::bad_alloc);
  EXPECT_EQ(observation::fail_allocation, 0U);
  EXPECT_EQ(allocation_limited.TryPrepare({Read(20), Read(21)}, false).admission_, IOAdmission::Accepted);
}

TEST_F(IOExecutorTest, RejectionNeverStartsIOOrStealsPreparedBuffers) {
  BlockDevice device(path_, BlockDeviceOptions{});
  IOExecutor executor(device, Options(1, 6));
  IOExecutor other(device, Options(1, 6));
  EXPECT_THROW(executor.TryPrepare({Write(256)}, false), std::invalid_argument);
  if (offset_alignment_ > 1) {
    EXPECT_THROW(executor.TryPrepare({{IOOperation::Write, Range(1, unit_)}}, false), std::invalid_argument);
  }
  EXPECT_THROW(executor.TryPrepare({Write(5, 2), Read(6)}, false), std::invalid_argument);
  auto batch = Prepare(executor, {Write(2)}, false);
  auto expected = initial_;
  auto payload = Fill(batch, 0, 2, 1, 63);
  EXPECT_THROW(other.TrySubmit(batch), std::invalid_argument);
  EXPECT_EQ(batch.Phase(), IOBatchPhase::Prepared);
  EXPECT_TRUE(std::equal(payload.begin(), payload.end(), batch.Buffer(0)));
  {
    std::lock_guard<std::mutex> lock(observation::mutex);
    EXPECT_EQ(observation::write_calls + observation::read_calls, 0U);
  }
  EXPECT_EQ(Oracle(), initial_);
  ASSERT_EQ(executor.TrySubmit(batch), IOAdmission::Accepted);
  EXPECT_THROW(executor.TrySubmit(batch), std::logic_error);
  batch.Wait();
  EXPECT_FALSE(batch.Result().writes_durable_);
  std::copy(payload.begin(), payload.end(), expected.begin() + 2 * unit_);
  auto retained = Prepare(executor, {Write(19)}, false);
  Fill(retained, 0, 19, 1, 97);
  executor.Shutdown();
  EXPECT_EQ(executor.TrySubmit(retained), IOAdmission::Stopped);
  EXPECT_EQ(retained.Phase(), IOBatchPhase::Prepared);
  EXPECT_EQ(executor.TryPrepare({Read(30)}, false).admission_, IOAdmission::Stopped);
  EXPECT_EQ(Oracle(), expected);
}

TEST_F(IOExecutorTest, PartialFailureDrainsRunningIOAndSkipsUnstartedMembers) {
  BlockDevice device(path_, BlockDeviceOptions{});
  IOExecutor executor(device, Options(2, 5), 5 * unit_);
  observation::ReleaseOnExit release;
  observation::Pause(12 * unit_);
  {
    std::lock_guard<std::mutex> lock(observation::mutex);
    observation::short_offset = 2 * unit_;
    observation::short_count = unit_;
    observation::fail_offset = 3 * unit_;
  }
  auto returned = std::make_shared<std::atomic<size_t>>(0);
  auto a = External(2, 3, 57), b = External(12, 1, 85), c = External(25, 1, 98);
  auto first = Pattern(3 * unit_, 2 * unit_, 57), second = Pattern(unit_, 12 * unit_, 85);
  std::vector<IOBufferLease> leases;
  for (const auto &bytes : {a, b, c}) leases.push_back(Permission(bytes, IOOperation::Write, returned));
  auto batch = PrepareExternal(executor, {Write(2, 3), Write(12), Write(25)}, leases, true);
  std::weak_ptr<ExternalBytes> in_flight = b;
  a.reset();
  b.reset();
  c.reset();
  ASSERT_EQ(executor.TrySubmit(batch), IOAdmission::Accepted);
  ASSERT_TRUE(observation::Await([] { return observation::failed; }));
  auto probe = Prepare(executor, {Read(40)}, false);
  ASSERT_EQ(executor.TrySubmit(probe), IOAdmission::Accepted);
  ASSERT_TRUE(probe.WaitFor(5s));
  ASSERT_EQ(probe.Phase(), IOBatchPhase::Succeeded);
  EXPECT_EQ(batch.Phase(), IOBatchPhase::Draining);
  EXPECT_FALSE(batch.WaitFor(0ms));
  EXPECT_EQ(returned->load(), 0U);
  EXPECT_FALSE(in_flight.expired());
  EXPECT_THROW(batch.Buffer(1), std::logic_error);
  observation::Release();
  ASSERT_TRUE(batch.WaitFor(5s));
  EXPECT_EQ(batch.Phase(), IOBatchPhase::Failed);
  EXPECT_EQ(returned->load(), 3U);
  EXPECT_TRUE(in_flight.expired());
  const auto &result = batch.Result();
  EXPECT_FALSE(result.writes_durable_);
  EXPECT_EQ(result.operations_[0].outcome_, IOOutcome::Failed);
  EXPECT_EQ(result.operations_[0].completed_bytes_, unit_);
  ASSERT_TRUE(result.operations_[0].error_);
  try {
    std::rethrow_exception(result.operations_[0].error_);
    FAIL() << "lost IO exception";
  } catch (const BlockDeviceIOError &error) {
    EXPECT_EQ(error.code().value(), EIO);
    EXPECT_EQ(error.Range().Offset(), 2 * unit_);
    EXPECT_EQ(error.CompletedBytes(), unit_);
  }
  EXPECT_EQ(result.operations_[1].outcome_, IOOutcome::Succeeded);
  EXPECT_EQ(result.operations_[2].outcome_, IOOutcome::NotStarted);
  auto expected = initial_;
  std::copy(first.begin(), first.begin() + unit_, expected.begin() + 2 * unit_);
  std::copy(second.begin(), second.end(), expected.begin() + 12 * unit_);
  executor.Shutdown();
  EXPECT_EQ(Oracle(), expected);
  std::lock_guard<std::mutex> lock(observation::mutex);
  EXPECT_EQ(observation::sync_calls, 0U);
  EXPECT_EQ(observation::write_calls,
            3U);  // Prefix, EIO, and the independent write: no retry.
}

TEST_F(IOExecutorTest, FlushFailureIsNotDurableAndDoesNotLoseLaterWork) {
  BlockDevice device(path_, BlockDeviceOptions{});
  IOExecutor executor(device, Options(2, 4), unit_);
  auto returned = std::make_shared<std::atomic<size_t>>(0);
  auto bytes = External(2, 1, 104);
  std::vector<IOBufferLease> leases;
  leases.push_back(Permission(bytes, IOOperation::Write, returned));
  auto batch = PrepareExternal(executor, {Write(2)}, leases, true);
  auto expected = initial_;
  auto first = Pattern(unit_, 2 * unit_, 104);
  {
    std::lock_guard<std::mutex> lock(observation::mutex);
    observation::sync_error = true;
  }
  ASSERT_EQ(executor.TrySubmit(batch), IOAdmission::Accepted);
  ASSERT_TRUE(batch.WaitFor(5s));
  EXPECT_EQ(batch.Phase(), IOBatchPhase::Failed);
  EXPECT_EQ(returned->load(), 1U);
  EXPECT_EQ(batch.Result().operations_[0].outcome_, IOOutcome::Succeeded);
  EXPECT_FALSE(batch.Result().writes_durable_);
  ASSERT_TRUE(batch.Result().flush_error_);
  try {
    std::rethrow_exception(batch.Result().flush_error_);
    FAIL() << "lost flush error";
  } catch (const std::system_error &error) {
    EXPECT_EQ(error.code().value(), EIO);
  }
  auto next = Prepare(executor, {Write(15)}, true);
  auto second = Fill(next, 0, 15, 1, 127);
  ASSERT_EQ(executor.TrySubmit(next), IOAdmission::Accepted);
  ASSERT_TRUE(next.WaitFor(5s));
  EXPECT_EQ(next.Phase(), IOBatchPhase::Succeeded);
  EXPECT_TRUE(next.Result().writes_durable_);
  executor.Shutdown();
  std::copy(first.begin(), first.end(), expected.begin() + 2 * unit_);
  std::copy(second.begin(), second.end(), expected.begin() + 15 * unit_);
  EXPECT_EQ(Oracle(), expected);
  std::lock_guard<std::mutex> lock(observation::mutex);
  EXPECT_EQ(observation::write_calls, 2U);
  EXPECT_GT(observation::successful_syncs, 0U);
}

TEST_F(IOExecutorTest, DroppingHandleDoesNotCancelIOAndShutdownDrains) {
  BlockDevice device(path_, BlockDeviceOptions{});
  IOExecutor executor(device, Options(1, 2), 2 * unit_);
  observation::ReleaseOnExit release;
  observation::Pause(5 * unit_);
  auto expected = initial_;
  auto returned = std::make_shared<std::atomic<size_t>>(0);
  std::weak_ptr<ExternalBytes> in_flight;
  {
    auto a = External(5, 1, 174), b = External(18, 1, 182);
    in_flight = a;
    std::vector<IOBufferLease> leases;
    leases.push_back(Permission(a, IOOperation::Write, returned));
    leases.push_back(Permission(b, IOOperation::Write, returned));
    auto batch = PrepareExternal(executor, {Write(5), Write(18)}, leases, true);
    auto first = Pattern(unit_, 5 * unit_, 174);
    auto second = Pattern(unit_, 18 * unit_, 182);
    std::copy(first.begin(), first.end(), expected.begin() + 5 * unit_);
    std::copy(second.begin(), second.end(), expected.begin() + 18 * unit_);
    ASSERT_EQ(executor.TrySubmit(batch), IOAdmission::Accepted);
    ASSERT_TRUE(observation::Await([] { return observation::entered; }));
    EXPECT_FALSE(batch.WaitFor(0ms));
  }
  EXPECT_EQ(executor.TryPrepare({Read(30)}, false).admission_, IOAdmission::Full);
  EXPECT_FALSE(in_flight.expired());
  EXPECT_EQ(returned->load(), 0U);
  std::promise<void> started;
  auto closing = std::async(std::launch::async, [&] {
    started.set_value();
    executor.Shutdown();
  });
  // This guard precedes destruction of the future if an assertion/exception
  // fails.
  observation::ReleaseOnExit release_before_future;
  started.get_future().wait();
  EXPECT_EQ(closing.wait_for(0ms), std::future_status::timeout);
  observation::Release();
  ASSERT_EQ(closing.wait_for(5s), std::future_status::ready);
  closing.get();
  EXPECT_TRUE(in_flight.expired());
  EXPECT_EQ(returned->load(), 2U);
  executor.Shutdown();
  EXPECT_EQ(executor.TryPrepare({Read(30)}, false).admission_, IOAdmission::Stopped);
  EXPECT_EQ(Oracle(), expected);
  std::lock_guard<std::mutex> lock(observation::mutex);
  EXPECT_EQ(observation::write_calls, 2U);
  EXPECT_GT(observation::successful_syncs, 0U);
}
TEST_F(IOExecutorTest, ExternalRoundTripReturnsPermissionsBeforePublishingCompletion) {
  BlockDevice device(path_, BlockDeviceOptions{});
  // Explicitly disable owned byte allocations; external admission must still
  // work.
  IOExecutor executor(device, {2, 8, 0}, 2 * unit_);
  observation::ReleaseOnExit release;
  auto returned = std::make_shared<std::atomic<size_t>>(0);
  auto outside_lock = std::make_shared<std::atomic<bool>>(false);
  auto a = External(2, 1, 76), b = External(9, 1, 97);
  std::weak_ptr<ExternalBytes> weak = a;
  std::vector<IOBufferLease> leases;
  leases.push_back(IOBufferLease::ForWrite(a->data, a->capacity, [a, returned, outside_lock, &executor, this] {
    // A legitimate non-waiting API must be callable when permission is
    // returned. Full here is due to the independent owned-byte limit, not a
    // failure.
    try {
      outside_lock->store(executor.TryPrepare({Read(40)}, false).admission_ == IOAdmission::Full);
    } catch (...) {
      outside_lock->store(false);
    }
    returned->fetch_add(1);
  }));
  leases.push_back(Permission(b, IOOperation::Write, returned));
  auto batch = PrepareExternal(executor, {Write(2), Write(9)}, leases, true);
  EXPECT_THROW(batch.Buffer(0), std::logic_error);
  a.reset();
  b.reset();
  auto spare = External(30, 1, 11);
  auto spare_returns = std::make_shared<std::atomic<size_t>>(0);
  leases.push_back(Permission(spare, IOOperation::Read, spare_returns));
  EXPECT_EQ(executor.TryPrepareExternal({Read(30)}, leases, false).admission_, IOAdmission::Full);
  EXPECT_EQ(leases.size(), 1U);
  observation::Pause(2 * unit_);
  ASSERT_EQ(executor.TrySubmit(batch), IOAdmission::Accepted);
  ASSERT_TRUE(observation::Await([] { return observation::entered && observation::successful_writes == 1; }));
  EXPECT_EQ(returned->load(), 0U);
  EXPECT_FALSE(weak.expired());
  EXPECT_EQ(executor.TryPrepareExternal({Read(30)}, leases, false).admission_, IOAdmission::Full);
  observation::Release();
  ASSERT_TRUE(batch.WaitFor(5s));
  ASSERT_EQ(batch.Phase(), IOBatchPhase::Succeeded);
  EXPECT_TRUE(batch.Result().writes_durable_);
  EXPECT_EQ(returned->load(), 2U);
  EXPECT_TRUE(outside_lock->load());
  EXPECT_TRUE(weak.expired());
  EXPECT_THROW(batch.Buffer(0), std::logic_error);
  for (const auto &result : batch.Result().operations_) {
    EXPECT_EQ(result.outcome_, IOOutcome::Succeeded);
    EXPECT_EQ(result.completed_bytes_, unit_);
    EXPECT_FALSE(result.error_);
  }
  // Retaining batch/result must not keep external byte capacity or pins.
  auto pending = executor.TryPrepareExternal({Read(30)}, leases, false);
  ASSERT_EQ(pending.admission_, IOAdmission::Accepted);
  EXPECT_EQ(spare_returns->load(), 0U);
  pending.batch_.reset();
  EXPECT_EQ(spare_returns->load(), 1U);
  auto x = External(0, 1, 0), y = External(0, 1, 0);
  auto read_returns = std::make_shared<std::atomic<size_t>>(0);
  leases.push_back(Permission(x, IOOperation::Read, read_returns));
  leases.push_back(Permission(y, IOOperation::Read, read_returns));
  auto read = PrepareExternal(executor, {Read(9), Read(2)}, leases, false);
  ASSERT_EQ(executor.TrySubmit(read), IOAdmission::Accepted);
  ASSERT_TRUE(read.WaitFor(5s));
  ASSERT_EQ(read.Phase(), IOBatchPhase::Succeeded);
  EXPECT_FALSE(read.Result().writes_durable_);
  EXPECT_EQ(read_returns->load(), 2U);
  for (const auto &result : read.Result().operations_) {
    EXPECT_EQ(result.outcome_, IOOutcome::Succeeded);
    EXPECT_EQ(result.completed_bytes_, unit_);
    EXPECT_FALSE(result.error_);
  }
  auto first = Pattern(unit_, 2 * unit_, 76), second = Pattern(unit_, 9 * unit_, 97);
  EXPECT_TRUE(std::equal(second.begin(), second.end(), x->data));
  EXPECT_TRUE(std::equal(first.begin(), first.end(), y->data));
  auto expected = initial_;
  std::copy(first.begin(), first.end(), expected.begin() + 2 * unit_);
  std::copy(second.begin(), second.end(), expected.begin() + 9 * unit_);
  executor.Shutdown();
  EXPECT_EQ(Oracle(), expected);
  std::lock_guard<std::mutex> lock(observation::mutex);
  EXPECT_GT(observation::successful_syncs, 0U);
}

TEST_F(IOExecutorTest, ExternalAdmissionPreservesPermissionsAndRejectsConflictingRAM) {
  BlockDevice device(path_, BlockDeviceOptions{});
  IOExecutor executor(device, Options(1, 8), 2 * unit_);
  IOExecutor owned_only(device, Options(1, 8));
  auto a = External(2, 2, 65);
  auto returned = std::make_shared<std::atomic<size_t>>(0);
  std::vector<IOBufferLease> leases;
  EXPECT_THROW(IOBufferLease::ForRead(nullptr, unit_, [] {}), std::invalid_argument);
  EXPECT_THROW(IOBufferLease::ForWrite(a->data, unit_, {}), std::invalid_argument);
  EXPECT_THROW(executor.TryPrepareExternal({Write(2)}, leases, false), std::invalid_argument);
  leases.push_back(IOBufferLease::ForWrite(a->data, unit_, [a, returned] { ++*returned; }));
  EXPECT_EQ(owned_only.TryPrepareExternal({Write(2)}, leases, false).admission_, IOAdmission::Full);
  EXPECT_THROW(executor.TryPrepareExternal({Read(2)}, leases, false), std::invalid_argument);
  EXPECT_THROW(executor.TryPrepareExternal({Write(2, 2)}, leases, false), std::invalid_argument);
  EXPECT_EQ(leases.size(), 1U);
  EXPECT_EQ(returned->load(), 0U);
  // A moved-from permission is invalid and never interpreted as "allocate".
  auto valid = std::move(leases.front());
  EXPECT_THROW(executor.TryPrepareExternal({Write(2)}, leases, false), std::invalid_argument);
  leases.front() = std::move(valid);
  leases.clear();
  EXPECT_EQ(returned->load(), 1U);
  if (memory_alignment_ > 1) {
    leases.push_back(IOBufferLease::ForWrite(a->data + 1, unit_, [a, returned] { ++*returned; }));
    EXPECT_THROW(executor.TryPrepareExternal({Write(2)}, leases, false), std::invalid_argument);
    EXPECT_EQ(returned->load(), 1U);
    leases.clear();
  }
  leases.push_back(IOBufferLease::ForWrite(a->data, std::numeric_limits<size_t>::max(), [a] {}));
  EXPECT_THROW(executor.TryPrepareExternal({Write(2)}, leases, false), std::invalid_argument);
  leases.clear();
  const auto before = returned->load();
  leases.push_back(IOBufferLease::ForRead(a->data, unit_, [a, returned] { ++*returned; }));
  leases.push_back(IOBufferLease::ForWrite(a->data, unit_, [a, returned] { ++*returned; }));
  EXPECT_THROW(executor.TryPrepareExternal({Read(2), Write(10)}, leases, false), std::invalid_argument);
  EXPECT_EQ(returned->load(), before);
  leases.clear();
  {
    std::lock_guard<std::mutex> lock(observation::mutex);
    EXPECT_EQ(observation::read_calls + observation::write_calls, 0U);
  }
  EXPECT_EQ(Oracle(), initial_);
  // Charge the permission's retained capacity, not just the shorter IO length.
  auto capacity_returns = std::make_shared<std::atomic<size_t>>(0);
  leases.push_back(Permission(a, IOOperation::Read, capacity_returns));
  auto full_capacity = executor.TryPrepareExternal({Read(40)}, leases, false);
  ASSERT_EQ(full_capacity.admission_, IOAdmission::Accepted);
  auto extra = External(41, 1, 12);
  leases.push_back(Permission(extra, IOOperation::Read, capacity_returns));
  EXPECT_EQ(executor.TryPrepareExternal({Read(41)}, leases, false).admission_, IOAdmission::Full);
  EXPECT_EQ(leases.size(), 1U);
  EXPECT_EQ(capacity_returns->load(), 0U);
  full_capacity.batch_.reset();
  EXPECT_EQ(capacity_returns->load(), 1U);
  auto available_again = executor.TryPrepareExternal({Read(41)}, leases, false);
  ASSERT_EQ(available_again.admission_, IOAdmission::Accepted);
  available_again.batch_.reset();
  EXPECT_EQ(capacity_returns->load(), 2U);
  // Overlapping immutable RAM is valid for device writes to independent ranges.
  leases.push_back(IOBufferLease::ForWrite(a->data, unit_, [a, returned] { ++*returned; }));
  leases.push_back(IOBufferLease::ForWrite(a->data, unit_, [a, returned] { ++*returned; }));
  auto batch = PrepareExternal(executor, {Write(2), Write(10)}, leases, true);
  ASSERT_EQ(executor.TrySubmit(batch), IOAdmission::Accepted);
  ASSERT_TRUE(batch.WaitFor(5s));
  EXPECT_EQ(batch.Phase(), IOBatchPhase::Succeeded);
  EXPECT_TRUE(batch.Result().writes_durable_);
  EXPECT_EQ(returned->load(), before + 4);
  auto expected = initial_;
  auto payload = Pattern(unit_, 2 * unit_, 65);
  std::copy(payload.begin(), payload.end(), expected.begin() + 2 * unit_);
  std::copy(payload.begin(), payload.end(), expected.begin() + 10 * unit_);
  EXPECT_EQ(Oracle(), expected);

  // Use the entire slot and borrowed-capacity budgets on every retry. Otherwise
  // a leaked reservation could hide in spare capacity and still pass.
  owned_only.Shutdown();
  IOExecutor failure_budget(device, {1, 1, 0}, 2 * unit_);
  // Sweep allocations in production preparation, stopping at the first run
  // beyond its allocation points. No assertion depends on the allocation count.
  bool reached_success = false;
  size_t failures = 0;
  for (size_t fault = 1; fault <= 16; ++fault) {
    auto bytes = External(40, 2, 9);
    auto releases = std::make_shared<std::atomic<size_t>>(0);
    leases.push_back(Permission(bytes, IOOperation::Read, releases));
    std::vector<IORequest> requests{Read(40)};
    std::optional<IOPreparation> result;
    observation::new_failed = false;
    observation::fail_new_number = fault;
    bool allocation_failed = false;
    try {
      result = failure_budget.TryPrepareExternal(std::move(requests), leases, false);
    } catch (const std::bad_alloc &) {
      allocation_failed = true;
    } catch (...) {
      observation::fail_new_number = 0;
      throw;
    }
    observation::fail_new_number = 0;
    if (allocation_failed) {
      ASSERT_TRUE(observation::new_failed);
      ++failures;
      EXPECT_EQ(leases.size(), 1U);
      EXPECT_EQ(releases->load(), 0U);
      result = failure_budget.TryPrepareExternal({Read(40)}, leases, false);
    } else {
      reached_success = true;
    }
    ASSERT_TRUE(result.has_value());
    ASSERT_EQ(result->admission_, IOAdmission::Accepted);
    EXPECT_TRUE(leases.empty());
    result.reset();
    EXPECT_EQ(releases->load(), 1U);
    if (reached_success) break;
  }
  EXPECT_TRUE(reached_success);
  EXPECT_GT(failures, 0U);
  EXPECT_EQ(Oracle(), expected);
  auto closing_returns = std::make_shared<std::atomic<size_t>>(0);
  leases.push_back(IOBufferLease::ForRead(a->data, unit_, [a, closing_returns] { ++*closing_returns; }));
  auto prepared = executor.TryPrepareExternal({Read(30)}, leases, false);
  ASSERT_EQ(prepared.admission_, IOAdmission::Accepted);
  executor.Shutdown();
  EXPECT_EQ(executor.TrySubmit(*prepared.batch_), IOAdmission::Stopped);
  EXPECT_EQ(closing_returns->load(), 0U);
  leases.push_back(IOBufferLease::ForRead(a->data + unit_, unit_, [a, closing_returns] { ++*closing_returns; }));
  EXPECT_EQ(executor.TryPrepareExternal({Read(31)}, leases, false).admission_, IOAdmission::Stopped);
  EXPECT_EQ(leases.size(), 1U);
  EXPECT_EQ(closing_returns->load(), 0U);
  leases.clear();
  EXPECT_EQ(closing_returns->load(), 1U);
  prepared.batch_.reset();
  EXPECT_EQ(closing_returns->load(), 2U);
}
}  // namespace
}  // namespace bustub
