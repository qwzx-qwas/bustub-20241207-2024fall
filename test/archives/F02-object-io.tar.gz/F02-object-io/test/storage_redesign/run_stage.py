"""Opt-in F02 stage verification; no production hooks or permanent registration."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET

EXPECTED_TESTS = {
    'ParallelMembersDoNotSkipBarrierHoles',
    'BudgetIncludesPreparedRunningAndRetainedResults',
    'RejectionNeverStartsIOOrStealsPreparedBuffers',
    'PartialFailureDrainsRunningIOAndSkipsUnstartedMembers',
    'FlushFailureIsNotDurableAndDoesNotLoseLaterWork',
    'DroppingHandleDoesNotCancelIOAndShutdownDrains',
}


def check_results(path):
    """A zero exit code alone does not establish that the agreed checks ran."""
    root = ET.parse(path).getroot()
    cases = root.findall('./testsuite/testcase')
    names = [(case.get('classname'), case.get('name')) for case in cases]
    expected = {('IOExecutorTest', name) for name in EXPECTED_TESTS}
    if (len(cases) != len(expected) or set(names) != expected or
            root.get('tests') != str(len(expected)) or
            any(root.get(key) != '0' for key in ('failures', 'errors', 'disabled')) or
            any(case.get('status') != 'run' or case.get('result') != 'completed' or
                any(case.find(tag) is not None for tag in ('failure', 'error', 'skipped'))
                for case in cases)):
        raise RuntimeError('incomplete F02 verification: expected every agreed test to run and pass')
    return len(cases)

parser = argparse.ArgumentParser()
parser.add_argument('--repo', type=Path, required=True)
parser.add_argument('--work', type=Path, required=True)
parser.add_argument('--mutations', action='store_true')
args = parser.parse_args()
repo = args.repo.resolve()
work = args.work.resolve()
work.mkdir(parents=True, exist_ok=True)
build = work / 'build'
source = Path(__file__).with_name('io_executor_test.cpp')
commands = []


def call(argv, log, env=None, timeout=180, expected=0):
    record = {'command': argv, 'log': log}
    commands.append(record)
    try:
        with (work / log).open('w') as output:
            result = subprocess.run(argv, cwd=repo, stdout=output, stderr=subprocess.STDOUT,
                                    env=env, timeout=timeout)
        record['returncode'] = result.returncode
    except subprocess.TimeoutExpired:
        record['timeout_seconds'] = timeout
        raise
    finally:
        (work / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
    if expected is not None and result.returncode != expected:
        raise RuntimeError(f'{log}: exit {result.returncode}, expected {expected}')
    return result.returncode


call(['cmake', '-S', str(repo), '-B', str(build), '-DCMAKE_BUILD_TYPE=Debug',
      '-DCMAKE_C_COMPILER=clang-14', '-DCMAKE_CXX_COMPILER=clang++-14',
      '-DBUSTUB_SANITIZER=address,undefined', '-DCMAKE_EXE_LINKER_FLAGS=-no-pie'], 'configure-final.log')
call(['cmake', '--build', str(build), '--target', 'bustub_storage_disk', 'gtest_main', '-j2'], 'build-final.log')
flags = ['clang++-14', '-std=c++17', '-Wall', '-Wextra', '-Werror', '-Wno-unused-parameter',
         '-pthread', '-g', '-O0', '-fsanitize=address,undefined', '-fno-omit-frame-pointer',
         '-I' + str(repo / 'src/include'), '-I' + str(repo / 'third_party/googletest/googletest/include')]
test_object = work / 'stage-test.o'
call(flags + ['-c', str(source), '-o', str(test_object)], 'test-compile-final.log')
object_directory = build / 'src/storage/disk/CMakeFiles/bustub_storage_disk.dir'
link_tail = [str(object_directory / 'block_device.cpp.o'), str(test_object),
             str(build / 'lib/libgtest_main.a'), str(build / 'lib/libgtest.a'),
             '-Wl,--wrap=pread', '-Wl,--wrap=pwrite', '-Wl,--wrap=fdatasync', '-Wl,--wrap=malloc']
binary = work / 'stage-test'
call(flags + ['-no-pie', str(object_directory / 'io_executor.cpp.o')] + link_tail +
     ['-o', str(binary)], 'test-link-final.log')
# This opt-in runner owns its complete scenario set; ambient filters, repeats,
# disabled-test selection or sharding must not silently reduce that set.
ignored_gtest_keys = sorted(key for key in os.environ if key.startswith('GTEST_'))
env = {key: value for key, value in os.environ.items() if not key.startswith('GTEST_')}
env.update(F02_WORKDIR=str(work), ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',
           UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
(work / 'run-environment.json').write_text(json.dumps({key: env[key] for key in
    ('F02_WORKDIR', 'ASAN_OPTIONS', 'UBSAN_OPTIONS')}, indent=2) + '\n')
(work / 'ignored-gtest-environment.json').write_text(json.dumps(ignored_gtest_keys, indent=2) + '\n')
xml_path = work / 'results-final.xml'
xml_path.unlink(missing_ok=True)
call([str(binary), '--gtest_filter=IOExecutorTest.*', '--gtest_repeat=1', '--gtest_shuffle=0',
      '--gtest_output=xml:' + str(xml_path)], 'run-final.log', env, 60)
checked = check_results(xml_path)
if not args.mutations:
    print(f'{checked} stage checks passed (complete XML verified).')
    raise SystemExit(0)

original = (repo / 'src/storage/disk/io_executor.cpp').read_text()
mutations = []


def replace(name, old, new, count, test):
    if original.count(old) != count:
        raise RuntimeError(f'{name}: source changed; review mutation before use')
    mutations.append((name, original.replace(old, new), test))


replace('skip_flush', 'core->device_.Flush();', 'static_cast<void>(core->device_);', 1,
        'ParallelMembersDoNotSkipBarrierHoles')
replace('ignore_live_budget', 'operations > options_.max_operations_ - operations_ || '
        'bytes > options_.max_buffer_bytes_ - bytes_',
        'operations > options_.max_operations_ || bytes > options_.max_buffer_bytes_', 1,
        'BudgetIncludesPreparedRunningAndRetainedResults')
replace('ignore_member_failure', 'batch->failed_ = batch->failed_ || static_cast<bool>(error);',
        'batch->failed_ = false;', 1, 'PartialFailureDrainsRunningIOAndSkipsUnstartedMembers')
replace('flush_error_is_success', 'batch->result_.writes_durable_ = !error;\n      Finish(batch, !error);',
        'batch->result_.writes_durable_ = true;\n      Finish(batch, true);', 1,
        'FlushFailureIsNotDurableAndDoesNotLoseLaterWork')
replace('misreport_successful_reads', 'result.outcome_ = error ? IOOutcome::Failed : IOOutcome::Succeeded;',
        'result.outcome_ = (error || batch->requests_[member].operation_ == IOOperation::Read) '
        '? IOOutcome::Failed : IOOutcome::Succeeded;', 1, 'ParallelMembersDoNotSkipBarrierHoles')
results = []
for name, text, test in mutations:
    mutant = work / (name + '.cpp')
    mutant.write_text(text)
    obj = work / (name + '.o')
    exe = work / name
    call(flags + ['-c', str(mutant), '-o', str(obj)], name + '-compile.log')
    call(flags + ['-no-pie', str(obj)] + link_tail + ['-o', str(exe)], name + '-link.log')
    status = call([str(exe), '--gtest_filter=IOExecutorTest.' + test], name + '-run.log', env, 60, None)
    log = (work / (name + '-run.log')).read_text()
    caught = status == 1 and '[  FAILED  ] IOExecutorTest.' + test in log
    results.append({'mutation': name, 'test': test, 'returncode': status, 'caught_by_assertion': caught,
                    'source_sha256': hashlib.sha256(text.encode()).hexdigest()})
    (work / 'mutations.json').write_text(json.dumps(results, indent=2) + '\n')
    if not caught:
        raise RuntimeError(f'{name}: not caught by intended assertions; inspect log')
print(f'{checked} stage checks passed (complete XML verified); '
      f'{len(results)} isolated mutations caught by intended assertions.')
