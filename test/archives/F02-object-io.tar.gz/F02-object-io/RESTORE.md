# F02 阶段验证恢复

此包包含 6 项阶段组件测试和 runner，不是常驻套件。依赖 Linux 文件 O_DIRECT/STATX_DIOALIGN、Clang 14、CMake、Python3 及仓库现有 GoogleTest；不下载新库，不接受裸设备路径。

先在仓库中核验 test/archives/SHA256SUMS，再解压到仓库外的独立目录。使用符合 MANIFEST.json 生产哈希的 checkout；基准 2f06f6f 本身不含 F02。如需复现，可在该基准的隔离 checkout 上覆盖本地结果包 source/ 快照。不要恢复进常驻测试目录。

```sh
F02_REPO=/path/to/matching/checkout
F02_PACKAGE=/tmp/unpacked/F02-object-io
F02_WORK=$(mktemp -d /tmp/f02-recheck-XXXXXX)
python3 "$F02_PACKAGE/test/storage_redesign/run_stage.py" --repo "$F02_REPO" --work "$F02_WORK" --mutations
```

runner 构建真实 CMake 对象并独立链接阶段测试，默认运行 6 项，--mutations 另跑 5 个工作区外变异。编译失败、超时或检测器启动失败不能冒充断言捕获。源码漂移时变异脚本会停止，须先审查。

所有检测器开启：ASan、UBSan、LeakSanitizer。临时 no-PIE 与支持泄漏检测的执行环境不修改生产构建默认；Direct 能力不足不能自动换 Buffered。正常结果应退出 0、6 项通过；变异应分别退出 1 且指定测试断言失败。同步门/错误注入不代表真实设备故障、掉电或性能改善。

完成后核验并压缩日志、版本、XML 与源码；删除专用构建、二进制、镜像和变异副本。当前风险、真实业务接入与退出规则见 docs/storage_redesign/f02_execution_20260922.md。共同 C/P 保留原位置和内容。

2026-09-22 再审查：runner 在测试子进程内隔离外部 GTEST_* 配置，强制完整场景一次执行，并核验新生成 XML 中的六个用例均实际完成成功；不支持通过环境过滤成子集后报告全量通过。结果包 review-evidence/ 中的零项日志是修复前误报证据，不能当作验收结果。
