# F02 / S6 普通对象 IO 验证恢复

本包替换历史 F02 包：保留原八项执行器测试，增加七项真实 NodeStorage 对象路径测试及最终 runner。依赖五个有效原模块源码包，不嵌套它们，不放入默认 CTest。

使用与 MANIFEST.json 哈希一致的仓库。基准为 `a739a5c` 加当轮工作区；结果包 source/ 有准确生产快照，不能只 checkout 基准就声称匹配。先验证 test/archives/SHA256SUMS，再在仓库外解压本包：

```sh
python3 /tmp/F02-object-io/tests/run_stage.py --repo /path/to/repo --work /tmp/s6-object-io-recheck --mutations
```

runner 从源码构建真实库，用旧 F13 `1df3ba1` 生产代码生成 v1 镜像，运行新增7+原F02 8+F34 5+F14/F13/F12 18+S5 8，共46项，七个指定变异必须编译成功、退出1且指定断言失败。环境要求 Linux O_DIRECT/STATX_DIOALIGN、Clang14、CMake、Python3及仓库 GoogleTest；不下载库、不接收裸设备路径。完整 XML 核验，不接受外部 GTEST_* 造成零用例或跳过。ASan/UBSan/LeakSanitizer开启，临时 no-PIE 不改变生产编译默认。

输入为可复现的非空不同正文及重复读取，独立数组模型；读取主要从非零映射内部开始。暂停/EIO/分配失败均为测试侧链接包装。5秒门等待/进程时限仅防挂起，不是性能测量。最多3 worker、8MiB对象镜像；原F02保持自身预算。结果不能证明 SQL/Raft E2E、裸设备掉电或性能提升。

完成后核验并压缩结果，删除专用构建、镜像、可执行程序；测试源码只保留本模块一个最终压缩包。后续 S7/S8/S9 复用相同场景与模型替换接入，不另建重复断言矩阵。审查见 docs/storage_redesign/s6_object_io_execution_20261002.md。

2026-10-02再次复审：测试helper必须终止失败场景，所有故障门在接纳前建立清理，关闭future之前释放门。原场景内容和46项数量不变；临时异常收尾诊断只在结果包保存，不注册新测试。
