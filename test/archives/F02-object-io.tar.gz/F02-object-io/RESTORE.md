# F02 外部缓冲阶段验证恢复

本包只有 8 项阶段组件检查和 runner，不注册常驻测试。依赖 Linux 文件 O_DIRECT/STATX_DIOALIGN、Clang 14、CMake、Python3 和仓库 GoogleTest；不下载新库、不接收裸设备路径。

先核验 test/archives/SHA256SUMS，再在仓库外独立目录解压。使用符合 MANIFEST.json 生产哈希的源码；基准 a4a6062 本身还没有本轮外部缓冲扩展。需要时在该基准的隔离 checkout 上覆盖结果包 source/ 快照中的 src/ 文件。不要把本包恢复到常驻测试树。

```sh
F02_REPO=/path/to/matching/checkout
F02_PACKAGE=/tmp/unpacked/F02-object-io
F02_WORK=$(mktemp -d /tmp/f02-recheck-XXXXXX)
python3 "$F02_PACKAGE/test/storage_redesign/run_stage.py" --repo "$F02_REPO" --work "$F02_WORK" --mutations
```

runner 构建真实 CMake 对象并单独链接检查；默认运行 8 项，--mutations 另跑 10 个临时源码变异。它隔离外部 GTEST_* 设置、删除旧 XML 并核验完整用例名单/实际执行/成功完成，不接受零用例或子集作为通过。生产源码变化使变异锚点失配时停止，须先审查，不能强行忽略。

ASan/UBSan/LeakSanitizer 全开启。选择支持 LSan 的环境，临时 no-PIE 不修改生产默认构建；Direct 能力不足不能自动切 Buffered。正常程序应退出 0 且 8 项通过；变异分别退出 1 且指定场景断言失败，编译失败/超时/检测器崩溃不计捕获。最多两个 worker、64 MiB 文件上限，5 秒等待和 60 秒进程限时只防挂起。外部内存由测试 owner 提供，不是生产 FrameArena。结果不证明裸设备、物理掉电或性能改善。

完成后核验、压缩新日志/版本/XML/源码，删除专用临时目录的源码、构建、二进制和镜像。不要将历史包另存为备份；经核验的新模块归档替换旧版。风险接管见 docs/storage_redesign/f02_execution_20260922.md §12；真实 BufferPool 默认迁移归 S9.1c，共同 C/P 内容保持。

2026-09-23 当前版：外部许可与自有缓冲两条准备路径的分配失败检查都已改为满名额、满容量重试，不能用剩余名额掩盖泄漏；自有缓冲原先的独立字节限流检查仍保留。8 项正常场景、10 个变异均已复验，生产未变；见审查 §14。源码/结果包替换旧版，旧漏检复现日志仅作缺陷证据，不计通过。
