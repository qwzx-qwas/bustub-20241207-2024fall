#include "fixture.h"
#include "storage/disk/node_storage.h"
#include "gtest/gtest.h"
#include <chrono>
#include <condition_variable>
#include <cstring>
#include <future>
#include <mutex>
#include <optional>
#include <thread>
using namespace std::chrono_literals;
extern "C" ssize_t __real_pread(int, void *, size_t, off_t);
extern "C" ssize_t __real_pwrite(int, const void *, size_t, off_t);
extern "C" int __real_fdatasync(int);
namespace {
using namespace bustub;
using namespace s5;
enum class Gate { None, Read, Write, Flush };
std::mutex gate_mutex;
std::condition_variable gate_cv;
Gate gate = Gate::None;
bool entered = false, released = true, fail = false, tracking = false;
size_t data_writes = 0, flushes = 0;
int tracked_fd = -1;
void Arm(Gate point, bool error = false) {
  std::lock_guard<std::mutex> lock(gate_mutex);
  gate = point;
  entered = false;
  released = false;
  fail = error;
  data_writes = flushes = 0;
  tracked_fd = -1;
  tracking = true;
}
void Release() {
  std::lock_guard<std::mutex> lock(gate_mutex);
  released = true;
  gate_cv.notify_all();
}
void Reset() {
  std::lock_guard<std::mutex> lock(gate_mutex);
  released = true;
  gate = Gate::None;
  tracking = false;
  tracked_fd = -1;
  gate_cv.notify_all();
}
struct Cleanup {
  ~Cleanup() { Reset(); }
};
bool Pause(std::unique_lock<std::mutex> &lock) {
  entered = true;
  gate = Gate::None;
  gate_cv.notify_all();
  gate_cv.wait(lock, [] { return released; });
  return fail;
}
bool Entered() {
  std::unique_lock<std::mutex> lock(gate_mutex);
  return gate_cv.wait_for(lock, 5s, [] { return entered; });
}
bool Direct(int fd) { return (fcntl(fd, F_GETFL) & O_DIRECT) != 0; }
} // namespace
extern "C" ssize_t __wrap_pread(int fd, void *buf, size_t size, off_t off) {
  if (Direct(fd) && off >= static_cast<off_t>(6 * MIB)) {
    std::unique_lock<std::mutex> lock(gate_mutex);
    if (gate == Gate::Read && Pause(lock)) {
      errno = EIO;
      return -1;
    }
  }
  return __real_pread(fd, buf, size, off);
}
extern "C" ssize_t __wrap_pwrite(int fd, const void *buf, size_t size,
                                 off_t off) {
  if (Direct(fd) && off >= static_cast<off_t>(6 * MIB)) {
    std::unique_lock<std::mutex> lock(gate_mutex);
    if (tracking) {
      ++data_writes;
      tracked_fd = fd;
      gate_cv.notify_all();
    }
    if (gate == Gate::Write && Pause(lock)) {
      errno = EIO;
      return -1;
    }
  }
  return __real_pwrite(fd, buf, size, off);
}
extern "C" int __wrap_fdatasync(int fd) {
  std::unique_lock<std::mutex> lock(gate_mutex);
  if (tracking && fd == tracked_fd) {
    ++flushes;
    if (gate == Gate::Flush && Pause(lock)) {
      errno = EIO;
      return -1;
    }
  }
  lock.unlock();
  return __real_fdatasync(fd);
}
namespace {
auto Options(const Image &image) -> NodeStorageOptions {
  BlockDevice dev(image.path, {});
  const auto u = static_cast<uint32_t>(
      std::lcm<uint64_t>(4096, dev.Info().offset_alignment_));
  Require(u <= 16384, "alignment exceeds fixture budget");
  BootstrapIdentity id{};
  id.storage_.fill(11);
  id.device_.fill(31);
  JournalIdentity jid{};
  jid.fill(73);
  return {image.path,
          {},
          {3, 2048, 16 * MIB},
          id,
          jid,
          {4ULL * u, u, 8192, MIB, 512, 2 * MIB, 8, 32, 4 * MIB},
          {256, 2048, 16384, MIB},
          {1, 1ms, 1000ms},
          ObjectStorageOptions{{u, 64, MIB, 2 * MIB, 8, 1024, 4096},
                               {2, 512, 128 * 1024, 256, 32},
                               {64, 64, 1024, 8, 2 * MIB, 16},
                               2 * MIB,
                               2 * MIB}};
}
auto Layout(const NodeStorageOptions &o) -> BootstrapLayout {
  return {o.identity_,
          8 * MIB,
          {Range(2 * MIB, MIB),
           Range(JOURNAL_START, 64ULL * o.journal_.unit_bytes_),
           Range(6 * MIB, 2 * MIB)}};
}
void Durable(const JournalResult &r) {
  Require(r.outcome_ == JournalOutcome::Durable && !r.error_,
          "required metadata operation is not durable");
}
auto New(NodeStorage &node, uint64_t number) -> ObjectKey {
  const auto space = node.CreateObjectSpace(node.Objects());
  Require(space.result_.outcome_ == JournalOutcome::Durable && space.space_,
          "space durable");
  ObjectKey key{*space.space_, number};
  Require(node.CreateObject(node.Objects(), key, 0, ObjectSizeMode::Variable)
                  .outcome_ == JournalOutcome::Durable,
          "object durable");
  return key;
}
void Put(NodeStorage &node, ObjectKey key, uint64_t offset,
         const Bytes &bytes) {
  auto write = node.WriteObjectData(bytes.data(), bytes.size());
  write.Wait();
  Require(write.Result().writes_durable_, "setup object data is not durable");
  Durable(node.PublishObjectData(node.Objects(), key, offset, write));
}
auto Read(NodeStorage &node, ObjectKey key, uint64_t offset, uint64_t length)
    -> Bytes {
  auto read = node.ReadObject(node.Objects(), key, offset, length);
  read.Wait();
  Bytes bytes(read.Size());
  read.CopyTo(bytes.data(), bytes.size());
  return bytes;
}
auto Allocation(NodeStorage &node, ObjectKey key, uint64_t offset) -> uint64_t {
  const auto resolved = node.Objects().Resolve(key, offset, 1);
  Require(resolved.spans_.size() == 1 && resolved.spans_.front().data_,
          "setup requires a mapped byte at the requested offset");
  return resolved.spans_.front().data_->allocation_;
}
void AwaitDraining(NodeStorage &node) {
  const auto until = std::chrono::steady_clock::now() + 5s;
  while (node.State().phase_ != NodeStoragePhase::Draining &&
         std::chrono::steady_clock::now() < until)
    std::this_thread::yield();
  Require(node.State().phase_ == NodeStoragePhase::Draining,
          "Close did not enter Draining before the test deadline");
}
TEST(S6ObjectIO, NonzeroSlicesHolesAndRecovery) {
  Image image;
  auto options = Options(image);
  NodeStorage node(options);
  node.Create(Layout(options));
  ASSERT_TRUE(node.State().object_read_);
  const auto u = options.objects_->allocator_.allocation_bytes_;
  const auto key = New(node, 31);
  Bytes model(15 * u, std::byte{0});
  Durable(node.ResizeObject(node.Objects(), key, model.size()));
  for (auto spec : std::vector<std::tuple<uint64_t, size_t, unsigned>>{
           {3 * u + 137, 2 * u + 79, 17},
           {8 * u + 51, u + 193, 137},
           {4 * u + 31, 173, 229}}) {
    auto [off, n, seed] = spec;
    auto bytes = Value(n, seed);
    Put(node, key, off, bytes);
    std::copy(bytes.begin(), bytes.end(), model.begin() + off);
  }
  for (auto spec :
       std::vector<std::pair<uint64_t, uint64_t>>{{3 * u + 211, 7 * u},
                                                  {4 * u + 91, 127},
                                                  {8 * u + 103, u},
                                                  {6 * u, 513},
                                                  {14 * u + 17, 2 * u},
                                                  {0, 37}}) {
    auto [off, n] = spec;
    EXPECT_EQ(Read(node, key, off, n),
              Bytes(model.begin() + off,
                    model.begin() + std::min<uint64_t>(model.size(), off + n)))
        << "logical slices match input model";
  }
  auto old = node.Objects();
  node.Close();
  node.Open();
  EXPECT_THROW(node.ReadObject(old, key, 3 * u + 211, 59), MetadataError);
  EXPECT_EQ(Read(node, key, 3 * u + 211, 9 * u),
            Bytes(model.begin() + 3 * u + 211, model.begin() + 12 * u + 211));
  EXPECT_THROW(node.ReadObject(node.Objects(), key, 0,
                               options.objects_->max_read_bytes_ + 1),
               MetadataError);
  node.Close();
}
TEST(S6ObjectIO, AbandonedReadPinsUntilCloseDrains) {
  Image image;
  auto options = Options(image);
  NodeStorage node(options);
  node.Create(Layout(options));
  const auto u = options.objects_->allocator_.allocation_bytes_;
  const auto key = New(node, 41);
  const auto origin = 5 * u + 73;
  Put(node, key, origin, Value(4 * u, 23));
  auto allocation = Allocation(node, key, origin);
  Cleanup cleanup;
  Arm(Gate::Read);
  std::optional<ObjectRead> read(
      node.ReadObject(node.Objects(), key, origin + u + 123, 37));
  ASSERT_TRUE(Entered());
  EXPECT_FALSE(read->WaitFor(1ms));
  read.reset();
  Durable(node.RemoveObject(node.Objects(), key));
  auto part = node.ReclaimObject(node.Objects(), key, allocation);
  EXPECT_EQ(part.released_bytes_, 3 * u) << "only unpinned units may be reused";
  EXPECT_EQ(part.pinned_bytes_, u)
      << "abandoned read retains its physical unit";
  auto closing = std::async(std::launch::async, [&] { node.Close(); });
  // Release the IO gate before the future destructor joins Close on failure.
  Cleanup close_cleanup;
  AwaitDraining(node);
  EXPECT_EQ(closing.wait_for(20ms), std::future_status::timeout)
      << "Close must drain abandoned IO";
  EXPECT_FALSE(node.State().object_read_);
  Release();
  closing.get();
  Reset();
  node.Open();
  auto last = node.ReclaimObject(node.Objects(), key, allocation);
  EXPECT_EQ(last.released_bytes_, u);
  node.Close();
}
TEST(S6ObjectIO, CompletedReadDoesNotPinRetainedResult) {
  Image image;
  auto options = Options(image);
  NodeStorage node(options);
  node.Create(Layout(options));
  const auto u = options.objects_->allocator_.allocation_bytes_;
  const auto key = New(node, 43);
  const auto bytes = Value(u, 71);
  Put(node, key, 7 * u + 43, bytes);
  auto allocation = Allocation(node, key, 7 * u + 43);
  auto read = node.ReadObject(node.Objects(), key, 7 * u + 43, bytes.size());
  read.Wait();
  Durable(node.RemoveObject(node.Objects(), key));
  auto reclaimed = node.ReclaimObject(node.Objects(), key, allocation);
  EXPECT_EQ(reclaimed.released_bytes_, u)
      << "completed result must not pin physical storage";
  Bytes actual(read.Size());
  read.CopyTo(actual.data(), actual.size());
  EXPECT_EQ(actual, bytes);
  node.Close();
  read.CopyTo(actual.data(), actual.size());
  EXPECT_EQ(actual, bytes);
}
TEST(S6ObjectIO, FragmentedBatchSharesFlushBeforePublication) {
  Image image;
  auto options = Options(image);
  NodeStorage node(options);
  node.Create(Layout(options));
  const auto u = options.objects_->allocator_.allocation_bytes_;
  const auto a = New(node, 51), b = New(node, 52), c = New(node, 53),
             d = New(node, 54), target = New(node, 55);
  Put(node, a, 0, Value(u, 1));
  Put(node, b, 0, Value(u, 2));
  Put(node, c, 0, Value(u, 3));
  Put(node, d, 0, Value(2 * MIB - 3 * u, 4));
  for (auto key : {a, c}) {
    const auto id = Allocation(node, key, 0);
    Durable(node.RemoveObject(node.Objects(), key));
    EXPECT_EQ(node.ReclaimObject(node.Objects(), key, id).released_bytes_, u);
  }
  const auto bytes = Value(2 * u - 137, 181);
  Cleanup cleanup;
  Arm(Gate::Write);
  auto write = node.WriteObjectData(bytes.data(), bytes.size());
  ASSERT_TRUE(Entered());
  {
    std::unique_lock<std::mutex> lock(gate_mutex);
    ASSERT_TRUE(gate_cv.wait_for(lock, 5s, [] { return data_writes == 2; }));
    EXPECT_EQ(flushes, 0U) << "Flush must wait for all batch members";
  }
  EXPECT_FALSE(write.WaitFor(1ms));
  EXPECT_THROW(
      node.PublishObjectData(node.Objects(), target, 9 * u + 31, write),
      std::logic_error);
  Release();
  write.Wait();
  {
    std::lock_guard<std::mutex> lock(gate_mutex);
    EXPECT_EQ(data_writes, 2U);
    EXPECT_EQ(flushes, 1U) << "one data Flush for the fragmented batch";
  }
  Reset();
  ASSERT_TRUE(write.Result().writes_durable_);
  EXPECT_EQ(node.Objects().Describe(target).size_, 0U);
  Durable(node.PublishObjectData(node.Objects(), target, 9 * u + 31, write));
  EXPECT_EQ(Read(node, target, 9 * u + 31, bytes.size()), bytes)
      << "fragmented batch body matches caller bytes";
  auto ranges = node.Objects().Resolve(target, 9 * u + 31, bytes.size());
  ASSERT_EQ(ranges.spans_.size(), 2U);
  // Independent physical bytes also check the submitted final padding was
  // initialized.
  const auto &tail = ranges.spans_.back();
  const auto padding =
      image.Read(6 * MIB + tail.data_->offset_ + tail.size_, 137);
  EXPECT_TRUE(std::all_of(padding.begin(), padding.end(),
                          [](auto v) { return v == 0; }));
  node.Close();
}
TEST(S6ObjectIO, AbandonedWriteRetainsReservationAndCloseWaits) {
  Image image;
  auto options = Options(image);
  NodeStorage node(options);
  node.Create(Layout(options));
  const auto bytes = Value(2 * MIB, 59);
  Cleanup cleanup;
  Arm(Gate::Write);
  std::optional<ObjectWrite> write(
      node.WriteObjectData(bytes.data(), bytes.size()));
  ASSERT_TRUE(Entered());
  EXPECT_FALSE(write->WaitFor(1ms));
  write.reset();
  try {
    auto other = node.WriteObjectData(
        bytes.data(), options.objects_->allocator_.allocation_bytes_);
    ADD_FAILURE() << "abandoned write reservation must remain unavailable";
  } catch (const AllocationError &e) {
    EXPECT_EQ(e.Code(), AllocationErrorCode::NoSpace);
  }
  auto closing = std::async(std::launch::async, [&] { node.Close(); });
  // Release the IO gate before the future destructor joins Close on failure.
  Cleanup close_cleanup;
  AwaitDraining(node);
  EXPECT_EQ(closing.wait_for(20ms), std::future_status::timeout)
      << "Close must drain abandoned write";
  Release();
  closing.get();
  Reset();
  node.Open();
  auto retry = node.WriteObjectData(bytes.data(), bytes.size());
  retry.Wait();
  EXPECT_TRUE(retry.Result().writes_durable_);
  node.Close();
}
TEST(S6ObjectIO, ReadWriteAndFlushFailuresPreserveData) {
  for (auto point : {Gate::Read, Gate::Write, Gate::Flush}) {
    Image image;
    auto options = Options(image);
    NodeStorage node(options);
    node.Create(Layout(options));
    const auto key = New(node, 61);
    const auto old = Value(1031, 11), changed = Value(2079, 79);
    Put(node, key, 533, old);
    if (point == Gate::Read) {
      Cleanup cleanup;
      Arm(point, true);
      auto read = node.ReadObject(node.Objects(), key, 533, old.size());
      ASSERT_TRUE(Entered());
      Release();
      read.Wait();
      Bytes destination(read.Size(), std::byte{0x5a});
      EXPECT_THROW(read.CopyTo(destination.data(), destination.size()),
                   BlockDeviceIOError);
      EXPECT_EQ(destination, Bytes(read.Size(), std::byte{0x5a}))
          << "failed read must not publish partial bytes";
      EXPECT_EQ(node.State().phase_, NodeStoragePhase::Failed);
      Reset();
      node.Close();
      node.Open();
      EXPECT_EQ(Read(node, key, 533, old.size()), old);
      node.Close();
      continue;
    }
    Cleanup cleanup;
    Arm(point, true);
    auto write = node.WriteObjectData(changed.data(), changed.size());
    ASSERT_TRUE(Entered());
    Release();
    write.Wait();
    EXPECT_FALSE(write.Result().writes_durable_);
    auto result = write.Result();
    EXPECT_TRUE(result.flush_error_ || result.operations_.front().error_);
    EXPECT_THROW(node.PublishObjectData(node.Objects(), key, 533, write),
                 MetadataError);
    EXPECT_EQ(node.State().phase_, NodeStoragePhase::Failed);
    EXPECT_TRUE(node.State().error_);
    Reset();
    node.Close();
    node.Open();
    EXPECT_EQ(Read(node, key, 533, old.size()), old)
        << "failed new IO must preserve old mapping";
    node.Close();
  }
}
TEST(S6ObjectIO, ExplicitInitializationAndReopenIdentity) {
  for (bool partial : {false, true}) {
    Image image;
    auto options = Options(image);
    if (partial) {
      Stack stack(image.path, true);
      MetadataEngine b(stack.boot, stack.jid, stack.journal, stack.metadata);
      b.Create();
      DataAllocator a(b, options.objects_->allocator_);
      Durable(a.Create());
      a.Close();
      b.Close();
    } else {
      auto meta = options;
      meta.objects_.reset();
      NodeStorage node(meta);
      node.Create(Layout(meta));
      node.Close();
    }
    NodeStorage node(options);
    node.Open();
    EXPECT_TRUE(node.State().metadata_read_);
    EXPECT_FALSE(node.State().object_read_);
    EXPECT_TRUE(node.State().object_error_);
    EXPECT_THROW(node.Objects(), MetadataError);
    node.Close();
    node.Open();
    EXPECT_FALSE(node.State().object_read_);
    node.InitializeObjects();
    EXPECT_TRUE(node.State().object_read_);
    const auto key = New(node, 71);
    const auto bytes = Value(2051, 109);
    auto unposted = node.WriteObjectData(bytes.data(), bytes.size());
    unposted.Wait();
    auto old = node.Objects();
    node.Close();
    node.Open();
    EXPECT_TRUE(node.State().object_read_);
    EXPECT_THROW(node.PublishObjectData(node.Objects(), key, 79, unposted),
                 MetadataError);
    EXPECT_THROW(node.ReadObject(old, key, 0, 19), MetadataError);
    EXPECT_EQ(node.Objects().Describe(key).size_, 0U);
    Put(node, key, 791, bytes);
    EXPECT_EQ(Read(node, key, 811, 431),
              Bytes(bytes.begin() + 20, bytes.begin() + 451));
    node.Close();
  }
  // Produced by the original v1 F13 implementation, not hand-encoded metadata.
  Image legacy;
  const auto *legacy_path = std::getenv("F14_LEGACY_IMAGE");
  Require(legacy_path != nullptr, "legacy production fixture required");
  std::filesystem::copy_file(legacy_path, legacy.path,
                             std::filesystem::copy_options::overwrite_existing);
  NodeStorage old_node(Options(legacy));
  old_node.Open();
  EXPECT_TRUE(old_node.State().metadata_read_);
  EXPECT_FALSE(old_node.State().object_read_);
  EXPECT_TRUE(old_node.State().object_error_);
  EXPECT_THROW(old_node.InitializeObjects(), ObjectReferenceError);
  old_node.Close();
  old_node.Open();
  EXPECT_TRUE(old_node.State().metadata_read_);
  EXPECT_FALSE(old_node.State().object_read_);
  old_node.Close();
}
} // namespace
