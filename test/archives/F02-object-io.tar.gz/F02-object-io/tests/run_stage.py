#!/usr/bin/env python3
"""S6 object IO and unchanged component regressions; no production test hooks."""
import argparse, hashlib, json, os, pathlib, subprocess, tarfile, time
import xml.etree.ElementTree as ET
p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--work',required=True);p.add_argument('--mutations',action='store_true');a=p.parse_args()
repo=pathlib.Path(a.repo).resolve();work=pathlib.Path(a.work).resolve();src=pathlib.Path(__file__).resolve().parent
assert repo!=work and repo not in work.parents
work.mkdir(parents=True,exist_ok=True)
manifest=src.parent/'MANIFEST.json'
if manifest.exists():
 m=json.loads(manifest.read_text())
 for field in ('production_sha256','dependency_sha256','test_sha256'):
  for name,h in m[field].items():
   root=src.parent if field=='test_sha256' else repo
   assert hashlib.sha256((root/name).read_bytes()).hexdigest()==h,('source drift',name)
env={k:v for k,v in os.environ.items() if not k.startswith('GTEST_')};env.update(S5_WORKDIR=str(work),F02_WORKDIR=str(work),ASAN_OPTIONS='detect_leaks=1:abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1')
commands=[]
def run(cmd,log,expected=0,timeout=900,cwd=None):
 cmd=list(map(str,cmd));start=time.monotonic()
 with (work/log).open('w') as out:r=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT,env=env,cwd=cwd or repo,timeout=timeout)
 commands.append({'command':cmd,'log':log,'seconds':time.monotonic()-start,'exit':r.returncode});(work/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 assert r.returncode==expected,(log,r.returncode,expected)
run(['cmake','-S',repo,'-B',work/'build','-DCMAKE_BUILD_TYPE=Debug','-DCMAKE_C_COMPILER=clang-14','-DCMAKE_CXX_COMPILER=clang++-14','-DBUSTUB_SANITIZER=address,undefined','-DCMAKE_EXE_LINKER_FLAGS=-no-pie'],'configure.log')
run(['cmake','--build',work/'build','--target','bustub','gtest_main','-j3'],'build.log')
for name in ['S5-journal-recycling','F34-node-lifecycle','F12-data-allocator','F13-object-mapping','F14-object-references']:
 with tarfile.open(repo/('test/archives/'+name+'.tar.gz')) as t:t.extractall(work,filter='data')
dep=work/'S5-journal-recycling/test/storage_redesign'
flags=['clang++-14','-std=c++17','-g','-O0','-Wall','-Wextra','-Werror','-Wno-unused-parameter','-pthread','-fsanitize=address,undefined','-fno-omit-frame-pointer','-I'+str(repo/'src/include'),'-I'+str(repo/'third_party/fmt/include'),'-I'+str(repo/'third_party/googletest/googletest/include'),'-I'+str(dep),'-I'+str(work/'F12-data-allocator/tests'),'-I'+str(work/'F13-object-mapping/tests'),'-I'+str(repo/'src/storage/disk')]
libs=[work/'build/lib'/('lib'+name+'.a') for name in ['bustub','fmtd','gtest_main','gtest']]
wraps=['-Wl,--wrap=pread','-Wl,--wrap=pwrite','-Wl,--wrap=fdatasync']
legacy=work/'legacy-f13';(legacy/'storage/disk').mkdir(parents=True,exist_ok=True)
for name,target in [('src/include/storage/disk/object_mapping.h',legacy/'storage/disk/object_mapping.h'),('src/storage/disk/object_mapping.cpp',legacy/'object_mapping.cpp')]:
 target.write_bytes(subprocess.check_output(['git','show','1df3ba1:'+name],cwd=repo))
legacyflags=flags[:1]+['-I'+str(legacy)]+flags[1:]
run(legacyflags+['-c',legacy/'object_mapping.cpp','-o',work/'legacy-map.o'],'legacy-compile.log')
run(legacyflags+['-no-pie',work/'F14-object-references/tests/legacy_fixture.cpp',work/'legacy-map.o']+libs+wraps[1:]+['-o',work/'legacy-producer'],'legacy-link.log')
run([work/'legacy-producer',work/'f13-legacy.img'],'legacy-producer.log',timeout=120)
env['F14_LEGACY_IMAGE']=str(work/'f13-legacy.img')
run(flags+['-c',src/'object_io_test.cpp','-o',work/'object-test.o'],'object-compile.log')
run(flags+['-no-pie',work/'object-test.o']+libs+wraps+['-o',work/'object-test'],'object-link.log')
run([work/'object-test','--gtest_output=xml:'+str(work/'object.xml')],'object-run.log',timeout=180)
# Keep original test bodies, adapt only their external build/run interface.
run(flags+['-no-pie',work/'F34-node-lifecycle/tests/lifecycle_test.cpp']+libs+wraps+['-Wl,--wrap=close','-o',work/'lifecycle-test'],'lifecycle-compile.log')
run([work/'lifecycle-test','--gtest_output=xml:'+str(work/'lifecycle.xml')],'lifecycle-run.log',timeout=120)
run(flags+['-no-pie',src/'io_executor_test.cpp']+libs+wraps+['-Wl,--wrap=malloc','-Wl,--wrap=_Znwm','-o',work/'executor-test'],'executor-compile.log')
run([work/'executor-test','--gtest_output=xml:'+str(work/'executor.xml')],'executor-run.log',timeout=120,cwd=work)
run(flags+['-no-pie',work/'F14-object-references/tests/reference_test.cpp']+libs+wraps+['-o',work/'reference-test'],'reference-compile.log')
run([work/'reference-test','--gtest_output=xml:'+str(work/'references.xml')],'reference-run.log',timeout=180)
run(['python3',dep/'build_checks.py',repo,work],'s5-regression.log',timeout=300)
counts={'object.xml':7,'executor.xml':8,'lifecycle.xml':5,'references.xml':18,'s5.xml':8}
for name,n in counts.items():
 cases=ET.parse(work/name).getroot().findall('./testsuite/testcase')
 assert len(cases)==n and all(c.get('result')=='completed' and not any(c.find(k) is not None for k in ('failure','error','skipped')) for c in cases),name
mutations=[
 ('lose_read_protection','object_io.cpp','data->batch_->RetainUntilComplete([activity](const IOBatchResult &result) { activity->Complete(result); });','data->batch_->RetainUntilComplete([](const IOBatchResult &) {});','AbandonedReadPinsUntilCloseDrains','abandoned read retains its physical unit'),
 ('lose_write_protection','object_io.cpp','data->batch_.RetainUntilComplete([activity](const IOBatchResult &result) { activity->Complete(result); });','data->batch_.RetainUntilComplete([](const IOBatchResult &) {});','AbandonedWriteRetainsReservationAndCloseWaits','abandoned write reservation must remain unavailable'),
 ('wrong_slice_offset','object_io.cpp','piece.skip_ = skip;','piece.skip_ = 0;','NonzeroSlicesHolesAndRecovery','logical slices match input model'),
 ('wrong_hole_bytes','object_io.cpp','std::memset(out, 0, piece.size_);','std::memset(out, 1, piece.size_);','NonzeroSlicesHolesAndRecovery','logical slices match input model'),
 ('omit_data_flush','object_io.cpp','auto prepared = regions_.TryPrepare(requests, true);','auto prepared = regions_.TryPrepare(requests, requests.size() == 1);','FragmentedBatchSharesFlushBeforePublication','one data Flush for the fragmented batch'),
 ('ignore_read_budget','object_io.cpp','if (length > max_read_bytes_) {','if (false && length > max_read_bytes_) {','NonzeroSlicesHolesAndRecovery','throws an exception'),
 ('expose_draining_readiness','node_storage.cpp','result.object_read_ = result.object_read_ && result.metadata_read_;','// mutation: retain readiness while draining','AbandonedReadPinsUntilCloseDrains','node.State().object_read_'),
]
evidence=[]
if a.mutations:
 for name,file,old,new,test,marker in mutations:
  code=(repo/'src/storage/disk'/file).read_text();assert code.count(old)==1,(name,old)
  cpp=work/(name+'.cpp');cpp.write_text(code.replace(old,new));obj=work/(name+'.o');exe=work/name
  run(flags+['-c',cpp,'-o',obj],name+'-compile.log',timeout=120)
  run(flags+['-no-pie',work/'object-test.o',obj]+libs+wraps+['-o',exe],name+'-link.log',timeout=120)
  run([exe,'--gtest_filter=S6ObjectIO.'+test,'--gtest_output=xml:'+str(work/(name+'.xml'))],name+'-run.log',expected=1,timeout=120)
  failures=[f.text or '' for f in ET.parse(work/(name+'.xml')).getroot().iter('failure')]
  assert any(marker in f for f in failures),(name,failures)
  evidence.append({'mutation':name,'file':file,'old':old,'new':new,'test':test,'expected_marker':marker,'failures':failures})
  (work/'mutations.json').write_text(json.dumps(evidence,indent=2)+'\n');print(name+': detected',flush=True)
(work/'summary.json').write_text(json.dumps({'passed':counts,'mutations_detected':len(evidence),'scope':'NodeStorage ordinary-object production path on Direct regular files; not SQL/Raft E2E, raw device, power loss or performance.'},indent=2)+'\n')
print('S6 7 + F02 8 + F34 5 + F14/F13/F12 18 + S5 8 passed; mutants '+str(len(evidence)),flush=True)
