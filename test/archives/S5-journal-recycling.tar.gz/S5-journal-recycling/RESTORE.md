# S5 Journal 回收阶段测试恢复

本包仅是按模块压缩的测试源码，不注册常驻测试。基准 `cce998a` 加本次结果包 source/ 生产快照；先校验 MANIFEST 的生产与依赖哈希。新格式 v2、旧格式 v1 均通过正式接口运行。

在仓库外解压，例如 `/tmp/s5-review`，执行：

```bash
python3 /tmp/s5-review/S5-journal-recycling/test/storage_redesign/run_stage.py --repo /绝对路径/项目 --work /tmp/s5-run --mutations
```

需要 Linux Direct 普通文件支持、Clang 14、GCC 可选、CMake、Python3 和仓库已有第三方依赖；runner 使用 3 个构建 worker，ASan/UBSan，禁用 PIE。工作目录必须在仓库外，不会修改 production。

旧镜像通过 `git show cce998a` 提取旧 Bootstrap/Journal/B 三个编译单元及头文件重新编译生成，其他未修改组件复用构建库。不是用当前编码器伪造旧格式。运行需保留该 Git 历史；原始旧镜像也在结果包 fixtures/。

本包包含 8 项 S5 集成用例；F03/F08/F09 原档案直接复用，F10 测试侧只识别 v3 根并选择五项适用场景。不复制旧源码矩阵。F10 的旧根回退组合只适用于保留全部历史的旧阶段，本轮由 S5 退役入口拒绝与损坏测试接续。具体风险、八项审查和未测边界见项目 `docs/storage_redesign/s5_execution_20260930.md`。

完整运行应有：8 + 8 + 6 + 4 + 5 = 31 项通过，8 个指定变异在指定 oracle 失败；不能把编译失败或 watchdog 当检出。结果文件中的绝对路径只是当次执行位置，不要求未来沿用路径。运行后删除临时镜像、构建和展开源码，仅保留压缩结果。

不是 SQL/Raft E2E、性能基线、裸设备或掉电证明。旧模块有效依赖包保持原样，不删除。
