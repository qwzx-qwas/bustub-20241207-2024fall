import sys
import pathlib,subprocess,os,json,xml.etree.ElementTree as ET
repo=pathlib.Path(sys.argv[1]).resolve();work=pathlib.Path(sys.argv[2]).resolve(); src=pathlib.Path(__file__).resolve().parent;env={**os.environ,'S5_WORKDIR':str(work),'S5_LEGACY_IMAGE':str(work/'legacy.img'),'ASAN_OPTIONS':'detect_leaks=1:abort_on_error=1','UBSAN_OPTIONS':'halt_on_error=1'}
flags=['clang++-14','-std=c++17','-g','-O0','-Wall','-Wextra','-Werror','-Wno-unused-parameter','-pthread','-fsanitize=address,undefined','-fno-omit-frame-pointer','-I'+str(repo/'src/include'),'-I'+str(repo/'third_party/fmt/include'),'-I'+str(repo/'third_party/googletest/googletest/include'),'-I'+str(src)]
lib=work/'build/lib';libs=[lib/('lib'+x+'.a') for x in ['bustub','fmtd','gtest_main','gtest']]
def run(cmd,log,expected=0):
 with (work/log).open('w') as out:r=subprocess.run(list(map(str,cmd)),stdout=out,stderr=subprocess.STDOUT,env=env,timeout=120)
 if r.returncode!=expected:raise RuntimeError((log,r.returncode,expected))
run(flags+['-c',src/'recycling_test.cpp','-o',work/'s5-test.o'],'test-compile.log')
definitions=[
 ('skip_control_flush','journal_service',[('auto io = PrepareUnit(0, IOOperation::Write, true);', 'auto io = PrepareUnit(0, IOOperation::Write, false);')],'InterruptedRetirementCompletesBeforeOpening','cp.outcome_'),
 ('short_reservation','journal_service',[('const auto needed = next_sequence_ + count - 1;', 'const auto needed = next_sequence_;')],'WrapReopenAndLiveSnapshot','reservation exhausted'),
 ('no_maintenance_reserve','journal_service',[('units.size() + (maintenance ? 0 : 1) > AvailableUnits()', 'units.size() > AvailableUnits()')],'FullLogStillCheckpointsAndResumes','checkpoint Journal admission failed'),
 ('skip_retirement_resume','metadata_engine',[('s.journal_.RetireBefore(checkpoint->position_);','// mutation: do not finish interrupted retirement')],'InterruptedRetirementCompletesBeforeOpening','root'),
 ('discard_tail_identity','journal_service',[('sequence < retain_from_ / options_.segment_bytes_ &&','sequence == UINT64_MAX &&')],'WrapReopenAndLiveSnapshot','wrong segment identity'),
 ('allow_old_recovery_root','journal_service',[('begin >= retain_from_ && begin % options_.unit_bytes_ == 0','begin % options_.unit_bytes_ == 0'),('checkpoint <= previous_ && checkpoint >= retain_from_', 'checkpoint <= previous_')],'OldValidBootstrapCannotResurrectRetiredHistory','throws nothing'),
 ('close_without_drain','metadata_engine',[('void MetadataEngine::Close() {','void MetadataEngine::Close() { return; // mutation: prematurely complete Close')],'MaintenanceDrainsAndPreventsEarlyReuse','Close must drain retirement control IO'),
 ('checkpoint_gate_removed','metadata_engine',[('if (s.checkpointing_) {\n      throw MetadataError(MetadataErrorCode::ResourceUnavailable, "metadata checkpoint is excluding modifications");','if (false && s.checkpointing_) {\n      throw MetadataError(MetadataErrorCode::ResourceUnavailable, "metadata checkpoint is excluding modifications");')],'MaintenanceDrainsAndPreventsEarlyReuse','checkpoint gate must reject'),
]
evidence=[]
for name,unit,changes,test,marker in definitions:
 code=(repo/f'src/storage/disk/{unit}.cpp').read_text()
 for old,new in changes:
  assert code.count(old)==1,(name,old);code=code.replace(old,new)
 path=work/(name+'.cpp');path.write_text(code);obj=work/(name+'.o');exe=work/name
 run(flags+['-c',path,'-o',obj],name+'-compile.log')
 run(flags+['-no-pie',work/'s5-test.o',obj]+libs+['-Wl,--wrap=pwrite','-Wl,--wrap=fdatasync','-o',exe],name+'-link.log')
 run([exe,'--gtest_filter=S5Recycle.'+test,'--gtest_output=xml:'+str(work/(name+'.xml'))],name+'-run.log',1)
 failures=[f.text or '' for f in ET.parse(work/(name+'.xml')).getroot().iter('failure')]
 assert any(marker in f for f in failures),(name,failures)
 evidence.append({'mutation':name,'test':test,'expected_marker':marker,'changes':changes,'failures':failures})
 (work/'mutations.json').write_text(json.dumps(evidence,indent=2)+'\n')
 print(name+': detected by intended oracle',flush=True)
