import sys
import pathlib,tarfile,subprocess,os,hashlib,json
repo=pathlib.Path(sys.argv[1]).resolve();work=pathlib.Path(sys.argv[2]).resolve(); env={**os.environ, **{n+'_WORKDIR':str(work) for n in ['F03','F08','F09']},'ASAN_OPTIONS':'detect_leaks=1:abort_on_error=1','UBSAN_OPTIONS':'halt_on_error=1'}
flags=['clang++-14','-std=c++17','-g','-O0','-Wall','-Wextra','-Werror','-Wno-unused-parameter','-pthread','-fsanitize=address,undefined','-fno-omit-frame-pointer','-I'+str(repo/'src/include'),'-I'+str(repo/'third_party/fmt/include'),'-I'+str(repo/'third_party/googletest/googletest/include'),'-I'+str(work)]
lib=work/'build/lib';libs=[lib/('lib'+x+'.a') for x in ['bustub','fmtd','gtest_main','gtest']]
def run(cmd,log):
 with (work/log).open('w') as out:subprocess.run(list(map(str,cmd)),stdout=out,stderr=subprocess.STDOUT,env=env,check=True,timeout=300)
for module,cpp,wraps in [('F03-bootstrap','bootstrap_store_test.cpp',['fdatasync','pwrite','pread','pthread_cond_clockwait']),('F08-metadata-engine','metadata_engine_test.cpp',['fdatasync']),('F09-metadata-page-writer','metadata_page_writer_test.cpp',['fdatasync','pwrite'])]:
 with tarfile.open(repo/'test/archives'/f'{module}.tar.gz') as t:source=t.extractfile(f'{module}/test/storage_redesign/{cpp}').read()
 path=work/cpp;path.write_bytes(source);exe=work/module
 run(flags+[path]+libs+['-no-pie']+['-Wl,--wrap='+x for x in wraps]+['-o',exe],module+'-build.log')
 run([exe,'--gtest_output=xml:'+str(work/(module+'.xml'))],module+'-run.log'); print(module+' passed',flush=True)
with tarfile.open(repo/'test/archives/F10-metadata-checkpoint.tar.gz') as t:
 runner=t.extractfile('F10-metadata-checkpoint/test/storage_redesign/run_stage.py').read().decode()
 source=t.extractfile('F10-metadata-checkpoint/test/storage_redesign/metadata_checkpoint_test.cpp').read().decode()
exec(runner[runner.index('archive = repo /'):runner.index("run(['cmake'")])
source=source.replace('format == 1 || format == 2','format == 1 || format == 2 || format == 3').replace('if (format == 2) {','if (format == 2 || format == 3) {')
path=work/'f10-adapted.cpp';path.write_text(source)
run(flags+[path]+libs+['-no-pie','-Wl,--wrap=fdatasync','-Wl,--wrap=pwrite','-o',work/'f10-adapted'],'F10-build.log')
run([work/'f10-adapted','--gtest_filter=-MetadataCheckpointTest.DamagedRootAndDamagedTargetDiffer','--gtest_output=xml:'+str(work/'F10.xml')],'F10-run.log');print('F10 5 applicable cases passed; old-root fallback is legacy-only and replaced by S5 negative case',flush=True)
