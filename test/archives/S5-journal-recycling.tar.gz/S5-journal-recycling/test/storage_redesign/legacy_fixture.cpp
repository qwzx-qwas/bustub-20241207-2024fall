#include "fixture.h"
// Built against cce998a's Journal, Bootstrap, B and headers. No test-generated
// codec.
int main(int argc, char **argv) {
  s5::Require(argc == 2, "supply output image");
  s5::Image image;
  {
    s5::Stack stack(image.path, true);
    bustub::MetadataEngine engine(stack.boot, stack.jid, stack.journal,
                                  stack.metadata);
    engine.Create();
    s5::Model model;
    s5::Put(engine, 7, 9013, 11, model);
    s5::Require(engine.Checkpoint(8).outcome_ ==
                    bustub::MetadataCheckpointOutcome::Durable,
                "legacy checkpoint");
    s5::Put(engine, 9, 701, 21, model);
  }
  std::filesystem::copy_file(image.path, argv[1],
                             std::filesystem::copy_options::overwrite_existing);
}
