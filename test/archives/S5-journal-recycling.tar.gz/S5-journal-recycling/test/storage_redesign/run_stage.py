#!/usr/bin/env python3
"""S5 isolated component verification; no CMake registration or production hooks."""
import argparse,hashlib,json,os,pathlib,subprocess,time,xml.etree.ElementTree as ET
p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--work',required=True);p.add_argument('--mutations',action='store_true');a=p.parse_args()
repo=pathlib.Path(a.repo).resolve();work=pathlib.Path(a.work).resolve();tests=pathlib.Path(__file__).resolve().parent
work.mkdir(parents=True,exist_ok=True)
if repo==work or repo in work.parents:raise RuntimeError('use an external work directory')
manifest=tests.parents[1]/'MANIFEST.json'
if manifest.exists():
 data=json.loads(manifest.read_text())
 for group in ['production_sha256','dependency_sha256']:
  for name,expected in data[group].items():
   if hashlib.sha256((repo/name).read_bytes()).hexdigest()!=expected:raise RuntimeError('source drift: '+name)
env={k:v for k,v in os.environ.items() if not k.startswith('GTEST_')};env.update(ASAN_OPTIONS='detect_leaks=1:abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1')
commands=[]
def run(cmd,log):
 start=time.monotonic()
 with (work/log).open('w') as out:r=subprocess.run(list(map(str,cmd)),stdout=out,stderr=subprocess.STDOUT,env=env,timeout=900)
 commands.append({'command':list(map(str,cmd)),'log':log,'exit':r.returncode,'seconds':time.monotonic()-start})
 (work/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 if r.returncode:raise RuntimeError('failed: '+log)
run(['cmake','-S',repo,'-B',work/'build','-DCMAKE_BUILD_TYPE=Debug','-DCMAKE_C_COMPILER=clang-14','-DCMAKE_CXX_COMPILER=clang++-14','-DBUSTUB_SANITIZER=address,undefined','-DCMAKE_EXE_LINKER_FLAGS=-no-pie'],'configure.log')
run(['cmake','--build',work/'build','--target','bustub','gtest_main','-j3'],'build.log')
run(['python3',tests/'build_checks.py',repo,work],'checks.log')
run(['python3',tests/'regressions.py',repo,work],'regressions.log')
expected={'s5.xml':8,'F03-bootstrap.xml':8,'F08-metadata-engine.xml':6,'F09-metadata-page-writer.xml':4,'F10.xml':5}
for name,n in expected.items():
 cases=ET.parse(work/name).getroot().findall('./testsuite/testcase')
 assert len(cases)==n and all(c.get('status')=='run' and c.get('result')=='completed' and not any(c.find(k) is not None for k in ['failure','error','skipped']) for c in cases),(name,n)
if a.mutations:
 run(['python3',tests/'mutations.py',repo,work],'mutations.log')
 assert len(json.loads((work/'mutations.json').read_text()))==8
(work/'summary.json').write_text(json.dumps({'passed':expected,'mutations_detected':8 if a.mutations else None,'scope':'Direct regular-file components; no power-loss, raw-device, SQL/Raft E2E or performance claim'},indent=2)+'\n')
print('S5 8 + reused 23 passed'+('; 8 intended mutations detected' if a.mutations else ''))
