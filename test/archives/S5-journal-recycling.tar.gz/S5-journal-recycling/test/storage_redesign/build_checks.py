import sys
import pathlib,subprocess,os
root=pathlib.Path(sys.argv[1]).resolve(); work=pathlib.Path(sys.argv[2]).resolve(); src=pathlib.Path(__file__).resolve().parent; old=work/'legacy'; old.mkdir(exist_ok=True)
files=['src/storage/disk/journal_service.cpp','src/storage/disk/bootstrap_store.cpp','src/storage/disk/metadata_engine.cpp','src/include/storage/disk/journal_service.h','src/include/storage/disk/bootstrap_store.h','src/include/storage/disk/metadata_engine.h']
for f in files:
 p=old/f;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(subprocess.check_output(['git','show','cce998a:'+f]))
flags=['clang++-14','-std=c++17','-g','-O0','-Wall','-Wextra','-Werror','-Wno-unused-parameter','-pthread','-fsanitize=address,undefined','-fno-omit-frame-pointer']
incs=['-I'+str(root/'src/include'),'-I'+str(root/'third_party/fmt/include'),'-I'+str(src),'-I'+str(root/'third_party/googletest/googletest/include')]
lib=work/'build/lib'; libs=[str(lib/'libbustub.a'),str(lib/'libfmtd.a')]
for f in files[:3]:
 p=old/f;o=old/(p.stem+'.o'); subprocess.run(flags+['-I'+str(old/'src/include')]+incs+['-c',str(p),'-o',str(o)],check=True)
subprocess.run(flags+['-I'+str(old/'src/include')]+incs+[str(src/'legacy_fixture.cpp')]+[str(old/(pathlib.Path(f).stem+'.o')) for f in files[:3]]+libs+['-no-pie','-o',str(work/'legacy_fixture')],check=True)
subprocess.run([str(work/'legacy_fixture'),str(work/'legacy.img')],check=True,env={**os.environ,'S5_WORKDIR':str(work)},timeout=60)
subprocess.run(flags+incs+[str(src/'recycling_test.cpp')]+libs+[str(lib/'libgtest_main.a'),str(lib/'libgtest.a'),'-no-pie','-Wl,--wrap=pwrite','-Wl,--wrap=fdatasync','-o',str(work/'recycling_test')],check=True)
subprocess.run([str(work/'recycling_test'),'--gtest_output=xml:'+str(work/'s5.xml')],check=True,env={**os.environ,'S5_WORKDIR':str(work),'S5_LEGACY_IMAGE':str(work/'legacy.img')},timeout=300)
