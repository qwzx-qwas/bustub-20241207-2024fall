#pragma once
#include "storage/disk/block_device.h"
#include "storage/disk/io_executor.h"
#include "storage/disk/metadata_engine.h"
#include <algorithm>
#include <array>
#include <cstdlib>
#include <fcntl.h>
#include <filesystem>
#include <map>
#include <numeric>
#include <stdexcept>
#include <tuple>
#include <unistd.h>
#include <vector>
namespace s5 {
using namespace bustub;
constexpr uint64_t MIB = 1024 * 1024;
constexpr uint64_t JOURNAL_START = 4 * MIB;
using Bytes = std::vector<std::byte>;
using Model = std::map<std::tuple<uint64_t, uint64_t, uint64_t>, Bytes>;
inline void Require(bool ok, const char *why) {
  if (!ok)
    throw std::runtime_error(why);
}
inline auto Value(size_t n, unsigned seed) -> Bytes {
  Bytes v(n);
  for (size_t i = 0; i < n; ++i)
    v[i] = std::byte((i * 17 + i / 19 + seed * 23) % 251);
  return v;
}
inline auto Key(uint64_t n) -> MetadataKey { return {n % 3, n % 11, n}; }
inline auto Range(uint64_t off, uint64_t size) -> StorageByteRange {
  return *StorageByteRange::Create(off, size);
}
struct Image {
  std::string path;
  Image() {
    auto *dir = std::getenv("S5_WORKDIR");
    Require(dir, "S5_WORKDIR must be explicit");
    path = std::string(dir) + "/device-XXXXXX";
    int fd = mkstemp(path.data());
    Require(fd >= 0, "mkstemp");
    int status = ftruncate(fd, 8 * MIB);
    close(fd);
    Require(status == 0, "ftruncate");
  }
  ~Image() { unlink(path.c_str()); }
  auto Read(uint64_t off, size_t n) const -> std::vector<uint8_t> {
    std::vector<uint8_t> v(n);
    int fd = open(path.c_str(), O_RDONLY);
    Require(fd >= 0, "read open");
    auto got = pread(fd, v.data(), n, off);
    close(fd);
    Require(got == static_cast<ssize_t>(n), "read size");
    return v;
  }
  void Write(uint64_t off, const std::vector<uint8_t> &v) const {
    int fd = open(path.c_str(), O_WRONLY);
    Require(fd >= 0, "write open");
    auto got = pwrite(fd, v.data(), v.size(), off);
    int flushed = fdatasync(fd);
    close(fd);
    Require(got == static_cast<ssize_t>(v.size()) && flushed == 0,
            "write size or flush");
  }
};
struct Stack {
  BlockDevice device;
  IOExecutor io;
  BootstrapStore boot;
  JournalIdentity jid{};
  BootstrapIdentity id{};
  JournalOptions journal;
  MetadataOptions metadata{256, 2048, 16384, 1024 * 1024};
  explicit Stack(const std::string &path, bool create)
      : device(path, BlockDeviceOptions{}), io(device, {3, 2048, 16 * MIB}),
        boot(io) {
    auto unit = static_cast<uint32_t>(
        std::lcm<uint64_t>(4096, device.Info().offset_alignment_));
    Require(unit <= 16384,
            "device alignment exceeds this fixture's explicit budget");
    journal = {4ULL * unit, unit, 8192, MIB, 512, 2 * MIB, 8, 32, 4 * MIB};
    jid.fill(73);
    id.storage_.fill(11);
    id.device_.fill(31);
    if (create)
      boot.Create({id,
                   8 * MIB,
                   {Range(2 * MIB, MIB), Range(JOURNAL_START, 64ULL * unit),
                    Range(6 * MIB, 2 * MIB)}});
    boot.Open(id);
  }
  ~Stack() {
    boot.Close();
    io.Shutdown();
  }
};
inline auto Put(MetadataEngine &engine, uint64_t key, size_t len, unsigned seed,
                Model &model) -> uint64_t {
  auto k = Key(key);
  auto val = Value(len, seed);
  auto result = engine.Commit(engine.Read(), {{k, val}});
  Require(result.outcome_ == JournalOutcome::Durable && !result.error_,
          "commit not durable");
  model[{k.category_, k.owner_, k.item_}] = val;
  return result.begin_;
}
inline auto BE(const std::vector<uint8_t> &v, size_t off, size_t n)
    -> uint64_t {
  Require(off + n <= v.size(), "oracle range");
  uint64_t r = 0;
  for (size_t i = 0; i < n; ++i)
    r = (r << 8) | v[off + i];
  return r;
}
inline auto Physical(uint64_t lsn, const JournalOptions &o) -> uint64_t {
  return JOURNAL_START +
         (1 + (lsn / o.segment_bytes_ - 1) % 15) * o.segment_bytes_ +
         lsn % o.segment_bytes_;
}
} // namespace s5
