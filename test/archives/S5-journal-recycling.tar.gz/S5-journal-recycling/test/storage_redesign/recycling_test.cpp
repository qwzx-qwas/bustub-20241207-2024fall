#include "fixture.h"
#include "gtest/gtest.h"
#include <atomic>
#include <cerrno>
#include <chrono>
#include <condition_variable>
#include <cstring>
#include <future>
#include <mutex>
#include <set>
extern "C" ssize_t __real_pwrite(int, const void *, size_t, off_t);
extern "C" int __real_fdatasync(int);
namespace {
std::mutex gate_mutex;
std::condition_variable gate_cv;
enum class FaultPoint { Write, Flush };
bool armed = false, entered = false, released = true, fail_io = false;
FaultPoint fault_point = FaultPoint::Write;
int pending_flush_fd = -1;
void Arm(FaultPoint point, bool pause, bool fail) {
  std::lock_guard<std::mutex> lock(gate_mutex);
  fault_point = point;
  pending_flush_fd = -1;
  armed = true;
  entered = false;
  released = !pause;
  fail_io = fail;
}
// Caller holds gate_mutex. No production hook or replacement storage path.
auto StopAtGate(std::unique_lock<std::mutex> &lock) -> bool {
  entered = true;
  gate_cv.notify_all();
  gate_cv.wait(lock, [] { return released; });
  if (fail_io) {
    errno = EIO;
    return true;
  }
  return false;
}
void Release() {
  std::lock_guard<std::mutex> lock(gate_mutex);
  armed = false;
  pending_flush_fd = -1;
  released = true;
  gate_cv.notify_all();
}
struct ReleaseOnExit {
  ~ReleaseOnExit() { Release(); }
};
} // namespace
extern "C" ssize_t __wrap_pwrite(int fd, const void *data, size_t size,
                                 off_t off) {
  if (off == static_cast<off_t>(s5::JOURNAL_START) && size >= 8 &&
      std::memcmp(data, "BUSTJFMT", 8) == 0) {
    std::unique_lock<std::mutex> lock(gate_mutex);
    if (armed) {
      armed = false;
      if (fault_point == FaultPoint::Flush) {
        pending_flush_fd = fd;
      } else if (StopAtGate(lock)) {
        return -1;
      }
    }
  }
  return __real_pwrite(fd, data, size, off);
}
extern "C" int __wrap_fdatasync(int fd) {
  {
    std::unique_lock<std::mutex> lock(gate_mutex);
    if (fd == pending_flush_fd) {
      pending_flush_fd = -1;
      if (StopAtGate(lock)) {
        return -1;
      }
    }
  }
  return __real_fdatasync(fd);
}
namespace s5 {
namespace {
void Check(const MetadataSnapshot &view, const Model &model) {
  auto rows = view.Scan({0, 0, 0}, model.size() + 1);
  ASSERT_EQ(rows.size(), model.size());
  size_t n = 0;
  for (const auto &[key, val] : model) {
    const auto &r = rows[n++];
    EXPECT_EQ(std::make_tuple(r.key_.category_, r.key_.owner_, r.key_.item_),
              key);
    EXPECT_EQ(r.value_, val);
    EXPECT_EQ(view.Get(r.key_), std::optional<Bytes>(val));
  }
}
auto LatestRoot(const Image &image) -> std::vector<uint8_t> {
  auto a = image.Read(0, 65536), b = image.Read(MIB, 65536);
  return BE(a, 112, 8) >= BE(b, 112, 8) ? a : b;
}
void CP(MetadataEngine &engine) {
  auto r = engine.Checkpoint(8);
  if (r.error_)
    std::rethrow_exception(r.error_);
  ASSERT_EQ(r.outcome_, MetadataCheckpointOutcome::Durable);
}
void FillRemaining(MetadataEngine &engine, Model &model) {
  auto key = Key(9);
  for (unsigned i = 0; i < 100; ++i) {
    auto value = model.at({key.category_, key.owner_, key.item_});
    value[15] ^= std::byte{1};
    try {
      auto r = engine.Commit(engine.Read(), {{key, value}});
      ASSERT_EQ(r.outcome_, JournalOutcome::Durable);
      model[{key.category_, key.owner_, key.item_}] = value;
    } catch (const MetadataError &e) {
      ASSERT_EQ(e.Code(), MetadataErrorCode::ResourceUnavailable);
      return;
    }
  }
  FAIL() << "bounded nonempty updates must reach the small Journal limit";
}
TEST(S5Recycle, WrapReopenAndLiveSnapshot) {
  Image image;
  Model model, old_model;
  uint64_t last = 0;
  std::optional<MetadataSnapshot> old;
  uint64_t segment_bytes = 0;
  size_t wraps = 0;
  bool stale_tail_seen = false, crossing_seen = false;
  for (unsigned round = 0; round < 28; ++round) {
    Stack stack(image.path, round == 0);
    segment_bytes = stack.journal.segment_bytes_;
    MetadataEngine engine(stack.boot, stack.jid, stack.journal, stack.metadata);
    if (round == 0)
      engine.Create();
    else
      engine.Open();
    Check(engine.Read(), model);
    for (unsigned n = 0; n < 2; ++n) {
      auto lsn = Put(engine, n + 7, n ? 47 : 9013, round * 3 + n, model);
      EXPECT_GT(lsn, last);
      if (last && Physical(lsn, stack.journal) < Physical(last, stack.journal))
        ++wraps;
      last = lsn;
    }
    if (round == 0) {
      old = engine.Read();
      old_model = model;
    }
    CP(engine);
    // Establish that the input really produced cross-slot batches and reused
    // short tails. These observations are independent of the production
    // decoder.
    std::map<uint64_t, std::set<uint64_t>> batch_slots;
    for (uint64_t slot = 1; slot < 16; ++slot) {
      auto bytes =
          image.Read(JOURNAL_START + slot * segment_bytes, segment_bytes);
      const auto owner = BE(bytes, 32, 8);
      for (uint64_t off = stack.journal.unit_bytes_; off < segment_bytes;
           off += stack.journal.unit_bytes_) {
        if (std::memcmp(bytes.data() + off, "BUSTJUNT", 8) != 0)
          continue;
        auto sequence = BE(bytes, off + 32, 8);
        if (sequence && sequence < owner && round < 27)
          stale_tail_seen = true;
        batch_slots[BE(bytes, off + 48, 8)].insert(slot);
      }
    }
    for (const auto &entry : batch_slots)
      crossing_seen |= entry.second.size() > 1;
    Check(engine.Read(), model);
    Check(*old, old_model);
  }
  EXPECT_GT(wraps, 2U);
  EXPECT_TRUE(stale_tail_seen);
  EXPECT_TRUE(crossing_seen);
  EXPECT_GT(last, 16 * segment_bytes);
  Stack stack(image.path, false);
  MetadataEngine engine(stack.boot, stack.jid, stack.journal, stack.metadata);
  engine.Open();
  Check(engine.Read(), model);
  Check(*old, old_model);
}
TEST(S5Recycle, FullLogStillCheckpointsAndResumes) {
  Image image;
  Model model;
  {
    Stack stack(image.path, true);
    MetadataEngine engine(stack.boot, stack.jid, stack.journal, stack.metadata);
    engine.Create();
    Put(engine, 9, 47, 17, model);
    bool full = false;
    unsigned accepted = 0;
    for (; accepted < 100; ++accepted) {
      try {
        Put(engine, 7, 9013, accepted, model);
      } catch (const MetadataError &e) {
        ASSERT_EQ(e.Code(), MetadataErrorCode::ResourceUnavailable);
        full = true;
        break;
      }
    }
    ASSERT_TRUE(full);
    ASSERT_GT(accepted, 0U);
    FillRemaining(engine, model);
    Check(engine.Read(), model);
    CP(engine);
    Put(engine, 7, 9013, 139, model);
    Check(engine.Read(), model);
  }
  Stack stack(image.path, false);
  MetadataEngine engine(stack.boot, stack.jid, stack.journal, stack.metadata);
  engine.Open();
  Check(engine.Read(), model);
}
TEST(S5Recycle, InterruptedRetirementCompletesBeforeOpening) {
  for (const auto point : {FaultPoint::Write, FaultPoint::Flush}) {
    SCOPED_TRACE(point == FaultPoint::Write ? "control write failure"
                                            : "control Flush failure");
    Image image;
    Model model;
    uint64_t root = 0;
    {
      Stack stack(image.path, true);
      MetadataEngine engine(stack.boot, stack.jid, stack.journal,
                            stack.metadata);
      engine.Create();
      Put(engine, 9, 47, 17, model);
      Put(engine, 7, 9013, 1, model);
      CP(engine);
      for (unsigned i = 0; i < 100; ++i) {
        try {
          Put(engine, 7, 9013, i + 2, model);
        } catch (const MetadataError &e) {
          ASSERT_EQ(e.Code(), MetadataErrorCode::ResourceUnavailable);
          break;
        }
      }
      FillRemaining(engine, model);
      Arm(point, false, true);
      ReleaseOnExit release;
      auto cp = engine.Checkpoint(8);
      ASSERT_EQ(cp.outcome_, MetadataCheckpointOutcome::Indeterminate);
      ASSERT_TRUE(cp.error_);
      root = BE(LatestRoot(image), 120, 8);
      EXPECT_TRUE(entered);
      const auto visible_floor =
          BE(image.Read(JOURNAL_START, stack.journal.unit_bytes_), 104, 8);
      if (point == FaultPoint::Write) {
        EXPECT_LT(visible_floor, root);
      } else {
        // Readback proves the write happened; it does NOT prove durability.
        EXPECT_EQ(visible_floor, root);
      }
      EXPECT_THROW(engine.Read(), MetadataError);
    }
    Stack stack(image.path, false);
    MetadataEngine engine(stack.boot, stack.jid, stack.journal, stack.metadata);
    engine.Open();
    Check(engine.Read(), model);
    EXPECT_EQ(BE(image.Read(JOURNAL_START, stack.journal.unit_bytes_), 104, 8),
              root);
    Put(engine, 7, 9013, 141, model);
    Check(engine.Read(), model);
  }
}
TEST(S5Recycle, MaintenanceDrainsAndPreventsEarlyReuse) {
  Image image;
  Model model;
  Stack stack(image.path, true);
  MetadataEngine engine(stack.boot, stack.jid, stack.journal, stack.metadata);
  engine.Create();
  Put(engine, 7, 9013, 3, model);
  auto view = engine.Read();
  Arm(FaultPoint::Flush, true, false);
  std::future<MetadataCheckpointResult> work;
  std::future<JournalResult> commit;
  std::future<void> closing;
  ReleaseOnExit
      release; // Unblock IO before any future destructor on assertion failure.
  work = std::async(std::launch::async, [&] { return engine.Checkpoint(8); });
  {
    std::unique_lock<std::mutex> lock(gate_mutex);
    ASSERT_TRUE(gate_cv.wait_for(lock, std::chrono::seconds(10),
                                 [] { return entered; }));
  }
  EXPECT_EQ(work.wait_for(std::chrono::milliseconds(0)),
            std::future_status::timeout);
  Check(view, model);
  commit = std::async(std::launch::async, [&] {
    return engine.Commit(view, {{Key(8), Value(43, 4)}});
  });
  const bool rejected_promptly =
      commit.wait_for(std::chrono::seconds(10)) == std::future_status::ready;
  EXPECT_TRUE(rejected_promptly) << "checkpoint gate must reject a "
                                    "modification without waiting for its IO";
  if (rejected_promptly) {
    try {
      commit.get();
      FAIL() << "write admitted before retirement finished";
    } catch (const MetadataError &e) {
      EXPECT_EQ(e.Code(), MetadataErrorCode::ResourceUnavailable);
    }
  }
  std::promise<void> close_started;
  closing = std::async(std::launch::async, [&] {
    close_started.set_value();
    engine.Close();
  });
  close_started.get_future().wait();
  EXPECT_EQ(closing.wait_for(std::chrono::milliseconds(100)),
            std::future_status::timeout)
      << "Close must drain retirement control IO";
  Release();
  ASSERT_EQ(work.get().outcome_, MetadataCheckpointOutcome::Durable);
  if (commit.valid()) {
    try {
      commit.get();
    } catch (const MetadataError &) {
    }
  }
  closing.get();
  Check(view, model);
}
TEST(S5Recycle, OldValidBootstrapCannotResurrectRetiredHistory) {
  Image image;
  Model model;
  std::vector<uint8_t> a, b;
  {
    Stack stack(image.path, true);
    stack.journal.segment_bytes_ = 16ULL * stack.journal.unit_bytes_;
    MetadataEngine engine(stack.boot, stack.jid, stack.journal, stack.metadata);
    engine.Create();
    Put(engine, 7, 47, 3, model);
    Put(engine, 9, 49, 17, model);
    CP(engine);
    a = image.Read(0, 65536);
    b = image.Read(MIB, 65536);
    Put(engine, 7, 47, 4, model);
    CP(engine);
    const auto &old_root = BE(a, 112, 8) > BE(b, 112, 8) ? a : b;
    ASSERT_EQ(BE(old_root, 120, 8) / stack.journal.segment_bytes_,
              BE(LatestRoot(image), 120, 8) / stack.journal.segment_bytes_)
        << "exercise an expired entry even when its physical segment remains "
           "retained";
    Put(engine, 8, 61, 5, model);
  }
  image.Write(0, a);
  image.Write(MIB, b);
  Stack stack(image.path, false);
  stack.journal.segment_bytes_ = 16ULL * stack.journal.unit_bytes_;
  MetadataEngine engine(stack.boot, stack.jid, stack.journal, stack.metadata);
  EXPECT_THROW(engine.Open(), JournalError);
  EXPECT_THROW(engine.Read(), MetadataError);
}
TEST(S5Recycle, RequiredCorruptFragmentCannotBeSkipped) {
  Image image;
  Model model;
  uint64_t position;
  uint32_t unit;
  {
    Stack stack(image.path, true);
    MetadataEngine engine(stack.boot, stack.jid, stack.journal, stack.metadata);
    engine.Create();
    Put(engine, 7, 9013, 3, model);
    CP(engine);
    auto lsn = Put(engine, 7, 9013, 4, model);
    position = Physical(lsn, stack.journal);
    unit = stack.journal.unit_bytes_;
  }
  auto bytes = image.Read(position, unit);
  bytes[100] ^= 0x80;
  image.Write(position, bytes);
  Stack stack(image.path, false);
  MetadataEngine engine(stack.boot, stack.jid, stack.journal, stack.metadata);
  EXPECT_THROW(engine.Open(), JournalError);
  EXPECT_THROW(engine.Read(), MetadataError);
}
TEST(S5Recycle, EmptyReopenReservesIdentityWithoutInventingHistory) {
  Image image;
  std::vector<uint64_t> lsn;
  const JournalRecords input{Value(8013, 97), Value(4013, 17)};
  for (unsigned i = 0; i < 5; ++i) {
    Stack stack(image.path, i == 0);
    JournalService journal(stack.boot, stack.jid, stack.journal);
    if (i == 0)
      journal.Create();
    else {
      size_t seen = 0;
      journal.Open([&](uint64_t pos, const JournalRecords &records) {
        ASSERT_LT(seen, lsn.size());
        EXPECT_EQ(pos, lsn[seen++]);
        EXPECT_EQ(records, input);
      });
      EXPECT_EQ(seen, lsn.size());
    }
    if (i >= 2 && i < 4) {
      auto r = journal.TryAppend(input);
      ASSERT_EQ(r.admission_, JournalAdmission::Accepted);
      r.ticket_->Wait();
      auto result = r.ticket_->Result();
      ASSERT_EQ(result.outcome_, JournalOutcome::Durable);
      if (!lsn.empty())
        EXPECT_GT(result.begin_, lsn.back());
      lsn.push_back(result.begin_);
    }
  }
}
TEST(S5Recycle, LegacyImageRetainsAppendOnlyReadWriteRecovery) {
  const auto *fixture = std::getenv("S5_LEGACY_IMAGE");
  ASSERT_NE(fixture, nullptr);
  Image image;
  std::filesystem::copy_file(fixture, image.path,
                             std::filesystem::copy_options::overwrite_existing);
  Model model;
  auto k = Key(7);
  model[{k.category_, k.owner_, k.item_}] = Value(9013, 11);
  k = Key(9);
  model[{k.category_, k.owner_, k.item_}] = Value(701, 21);
  auto original = image.Read(JOURNAL_START, 4096);
  ASSERT_EQ(BE(original, 8, 4), 1U);
  {
    Stack stack(image.path, false);
    MetadataEngine engine(stack.boot, stack.jid, stack.journal, stack.metadata);
    engine.Open();
    Check(engine.Read(), model);
    Put(engine, 7, 9013, 41, model);
    CP(engine);
    ASSERT_EQ(BE(LatestRoot(image), 8, 4), 2U);
    Put(engine, 9, 701, 42, model);
  }
  EXPECT_EQ(image.Read(JOURNAL_START, 4096), original);
  Stack stack(image.path, false);
  MetadataEngine engine(stack.boot, stack.jid, stack.journal, stack.metadata);
  engine.Open();
  Check(engine.Read(), model);
}
} // namespace
} // namespace s5
