from pathlib import Path
import json,shlex,subprocess,os
repo=Path.cwd();root=Path('/tmp/s12-node-work');build=root/'build'
commands=json.loads((build/'compile_commands.json').read_text())
env={**os.environ,'LD_LIBRARY_PATH':'/tmp/bustub-gcc16/native-runtime'}
def compile_source(original,source,output):
 e=next(x for x in commands if x['file']==str(repo/original));cmd=shlex.split(e['command'])
 cmd[cmd.index('-o')+1]=str(output);cmd[-1]=str(source)
 cmd+=['-I'+str(repo/'tools/bustub-node'),'-I'+str(repo/'src/storage/disk')]
 with output.with_suffix('.compile.log').open('w') as log:subprocess.run(cmd,cwd=e['directory'],stdout=log,stderr=log,check=True)
compile_source('tools/bustub-node/bustub-node.cpp',root/'metadata_range.cpp',root/'range.o')
linkcwd=build/'tools/bustub-node';base=shlex.split((linkcwd/'CMakeFiles/bustub-node.dir/link.txt').read_text())
base=[str((linkcwd/x).resolve()) if x.startswith(('CMakeFiles/','../../')) else x for x in base]
base[base.index(str(linkcwd/'CMakeFiles/bustub-node.dir/bustub-node.cpp.o'))]=str(root/'range.o')
for mutation in (False,True):
 work=root/('range-mutant' if mutation else 'range-normal');work.mkdir()
 cmd=base.copy();cmd[cmd.index('-o')+1]=str(work/'test')
 if mutation:
  source=(repo/'src/storage/disk/metadata_engine.cpp').read_text();needle='if (stop && KeyCompare{}(entry.first, *stop) >= 0) break;';assert source.count(needle)==1
  (work/'metadata_engine.cpp').write_text(source.replace(needle,''))
  compile_source('src/storage/disk/metadata_engine.cpp',work/'metadata_engine.cpp',work/'metadata.o')
  cmd.insert(1,str(work/'metadata.o'))
 with (work/'link.log').open('w') as out:subprocess.run(cmd,cwd=linkcwd,stdout=out,stderr=out,check=True)
 text=(repo/'docs/storage_redesign/node-storage.example.conf').read_text()
 fields={k.strip():v.strip() for raw in text.splitlines() if (line:=raw.split('#',1)[0].strip()) for k,v in [line.split('=',1)]}
 device=work/'device';fields['device.path']=str(device)
 with device.open('xb') as f:f.truncate(int(fields['create.capacity']))
 config=work/'config.conf';config.write_text(''.join(f'{k}={v}\n' for k,v in fields.items()))
 with (work/'result.log').open('w') as out:r=subprocess.run([str(work/'test'),str(config)],env=env,stdout=out,stderr=out,timeout=90)
 log=(work/'result.log').read_text()
 assert (r.returncode==1 and 'bounded scan mismatch: count' in log) if mutation else (r.returncode==0),log
 print(('mutation caught' if mutation else 'normal passed'),flush=True)
