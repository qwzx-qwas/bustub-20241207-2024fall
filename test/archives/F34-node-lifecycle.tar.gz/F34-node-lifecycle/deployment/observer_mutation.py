from pathlib import Path
import shutil,subprocess
repo=Path.cwd();root=Path('/tmp/s12-node-work'); target=root/'observer-mutant'
for sub in ['test/storage_acceptance','test/support']:
 for p in (repo/sub).glob('*.py'):
  q=target/sub/p.name; q.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(p,q)
p=target/'test/storage_acceptance/faults.py';s=p.read_text();old='kind = 5 if is_snapshot_request(request) else request["type"]';assert s.count(old)==1;p.write_text(s.replace(old,'kind = request["type"]'))
r=subprocess.run(['python3',str(root/'observer_test.py'),str(target)],text=True,capture_output=True)
(root/'observer-mutant.log').write_text(r.stdout+r.stderr)
assert r.returncode!=0 and 'AssertionError: observer missed completed installation' in r.stderr
print('old wire-type matching fails designated installation assertion')
