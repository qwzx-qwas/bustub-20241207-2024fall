#include "storage_config.h"
#include <algorithm>
#include <iostream>
#include <tuple>
#include <stdexcept>
using namespace bustub;
auto order(const MetadataKey &k) { return std::tie(k.category_, k.owner_, k.item_); }
int main(int argc, char **argv) {
  try {
    if (argc != 2) throw std::runtime_error("expected test-owned config");
    auto config = bustub::cli::ReadStorageConfig(argv[1]);
    config.deployment_.storage_.objects_.reset();
    config.deployment_.storage_.transactions_.reset();
    NodeStorage store(config.deployment_.storage_);
    store.Create(config.layout_);
    std::vector<MetadataEntry> input;
    for (uint64_t i = 0; i < 256; ++i)
      input.push_back({{9, 77, 1000 + i * 13}, {std::byte(i), std::byte(255 - i)}});
    input.push_back({{9, 76, 99999}, {std::byte{3}}});
    input.push_back({{9, 78, 1}, {std::byte{4}}});
    input.push_back({{10, 0, 1}, {std::byte{5}}});
    std::sort(input.begin(), input.end(), [](const auto &a, const auto &b) { return order(a.key_) < order(b.key_); });
    std::vector<MetadataMutation> changes;
    for (const auto &row : input) changes.push_back({row.key_, row.value_});
    auto committed = store.Commit(store.Read(), changes);
    if (committed.outcome_ != JournalOutcome::Durable) throw std::runtime_error("fixture commit failed");
    struct Query { MetadataKey low, high; size_t limit; };
    const Query queries[] = {
      {{9,77,1101},{9,77,1480},100}, {{9,77,1000},{9,77,1001},16},
      {{9,77,2500},{9,77,3500},7}, {{9,77,4328},{9,77,6000},32},
      {{9,77,0},{9,78,0},512}, {{9,77,1501},{9,77,1501},8},
      {{9,77,1102},{9,77,1103},8}, {{9,77,4200},{9,78,2},32}
    };
    auto check = [&] {
      auto view = store.Read();
      for (const auto &q : queries) {
        std::vector<MetadataEntry> expected;
        for (const auto &row : input)
          if (order(row.key_) >= order(q.low) && order(row.key_) < order(q.high) && expected.size() < q.limit)
            expected.push_back(row);
        const auto actual = view.Scan(q.low, q.high, q.limit);
        if (actual.size() != expected.size()) throw std::runtime_error("bounded scan mismatch: count");
        for (size_t i = 0; i < actual.size(); ++i)
          if (order(actual[i].key_) != order(expected[i].key_) || actual[i].value_ != expected[i].value_)
            throw std::runtime_error("bounded scan mismatch: content");
      }
      const auto all = view.Scan({9,0,0}, 512);
      if (all.size() != input.size()) throw std::runtime_error("unbounded scan changed");
    };
    check();
    if (store.Checkpoint(16).outcome_ != MetadataCheckpointOutcome::Durable) throw std::runtime_error("checkpoint failed");
    store.Close(); store.Open(); check(); store.Close();
    std::cout << "bounded metadata range contract passed (8 inputs before/after reopen)\n";
  } catch (const std::exception &e) { std::cerr << e.what() << '\n'; return 1; }
}
