"""Stage-only wire observer check; no database or compression implementation."""
import struct
import sys
from pathlib import Path
repo = Path(sys.argv[1]).resolve()
sys.path[:0] = [str(repo / 'test/support'), str(repo / 'test/storage_acceptance')]
from raft_message_proxy import snapshot_request
from faults import Network, NotCovered

def blob(value):
    return struct.pack('>I', len(value)) + value

def wire(data, tail=b''):
    return (struct.pack('>QQQ', 7, 1, 11) + blob(b'C100') +
            struct.pack('>QQQQIB', 100, 6, 40, 64, 123, 1) + blob(data) + tail)

# Logical range is always [40,64); compressed DATA has only 3 wire bytes.
# REUSE carries no DATA. These explicit expected boundaries come from fixture
# intent, not the observer's decoded length.
cases = [(5, wire(b'x' * 24)),
         (9, wire(b'y' * 24, struct.pack('>QB', 19, 0))),
         (9, wire(b'', struct.pack('>QBQQ', 19, 1, 200, 24))),
         (12, wire(b'abc', struct.pack('>QBIQ', 0, 1, 24, 21)))]
class OnePoll:
    def __init__(self): self.count = 0
    def check(self, _):
        self.count += 1
        if self.count > 1: raise AssertionError('observer missed completed installation')
for kind, message in cases:
    detail = snapshot_request(message, kind)
    assert detail['logical_size'] == 24 and detail['done'] == 1
    request = {'event': 'forwarded', 'type': kind, 'from': 1, 'to': 2, **detail}
    response = {'event': 'forwarded', 'type': 6, 'from': 2, 'to': 1,
                'term': 7, 'request_id': 11, 'success': 1, 'complete': 1,
                'stale': 0, 'match_index': 100}
    net = Network.__new__(Network)
    net.events = lambda _: [request, response, {**response, 'stale': 1}]
    net.control = OnePoll()
    result = net.catchup(2, 'long', 0, 80, 1)
    assert result['response']['stale'] == 0
    net.control = OnePoll()
    try: net.catchup(2, 'short', 0, 80, 1)
    except NotCovered: pass
    else: raise AssertionError('short catchup accepted snapshot')
    net.events = lambda _: [request, {**response, 'stale': 1}]
    net.control = OnePoll()
    try: net.catchup(2, 'long', 0, 80, 1)
    except AssertionError as error:
        assert str(error) == 'observer missed completed installation'
    else: raise AssertionError('stale response accepted as installation')
print('PASS: raw/delta DATA/REUSE/compressed observation, matching completion and short-path exclusion')
