#include "storage_config.h"
#include <cstdlib>
#include <iostream>
#include <numeric>
#include <unistd.h>
#include "storage/disk/journal_service.h"
using namespace bustub;
namespace {
void require(bool ok, const char *why) {
  if (!ok) { std::cerr << why << std::endl; std::_Exit(1); }
}
auto bytes(size_t size, unsigned seed) {
  std::vector<std::byte> out(size);
  for (size_t i = 0; i < size; ++i) out[i] = std::byte((i * 31 + seed) % 251);
  return out;
}
}
extern "C" ssize_t __real_pwrite(int, const void *, size_t, off_t);
extern "C" ssize_t __wrap_pwrite(int fd, const void *p, size_t n, off_t off) {
  return __real_pwrite(fd, p, n, off);
}
int main(int argc, char **argv) {
  try {
    require(argc == 3, "expected isolated config and scenario");
    const auto config = bustub::cli::ReadStorageConfig(argv[1]);
    const auto &settings = config.deployment_.storage_;
    BlockDevice device(settings.device_path_, settings.device_);
    IOExecutor io(device, {2, 2, 1024 * 1024});
    BootstrapStore bootstrap(io);
    auto options = settings.journal_;
    options.unit_bytes_ = std::lcm<uint64_t>(4096, device.Info().offset_alignment_);
    options.segment_bytes_ = 4ULL * options.unit_bytes_;
    options.max_record_bytes_ = 4ULL * options.unit_bytes_;
    auto layout = config.layout_;
    layout.regions_[1] = *StorageByteRange::Create(layout.regions_[1].Offset(), 8 * options.segment_bytes_);
    bootstrap.Create(layout);
    bootstrap.Open(settings.identity_);
    JournalService journal(bootstrap, settings.journal_identity_, options);
    journal.Create();
    // With three usable units per segment, this spans exactly two write
    // requests. Two F02 slots fit those writes, but NOT their separate Flush.
    bool oversized = false;
    try { journal.TryAppend({bytes(4ULL * options.unit_bytes_, 11)}); }
    catch (const JournalError &e) { oversized = e.Code() == JournalErrorCode::RequestTooLarge; }
    require(oversized, "Journal must count data plus Flush before admission");
    const auto expected = bytes(257, 37);
    auto held = io.TryPrepareFlush();
    require(held.admission_ == IOAdmission::Accepted, "fixture Flush not admitted");
    require(io.TrySubmit(*held.batch_) == IOAdmission::Accepted, "fixture Flush not submitted");
    held.batch_->Wait();
    require(!held.batch_->Result().flush_error_, "fixture Flush failed");
    auto full = journal.TryAppend({expected});
    require(full.admission_ == JournalAdmission::Full && !full.ticket_, "temporary Journal IO shortage must remain Full");
    held.batch_.reset();
    auto accepted = journal.TryAppend({expected});
    require(accepted.admission_ == JournalAdmission::Accepted, "refusal leaked Journal or IO reservation");
    accepted.ticket_->Wait();
    require(accepted.ticket_->Result().outcome_ == JournalOutcome::Durable, "small Journal append not durable");
    accepted.ticket_.reset();
    journal.Close();
    JournalRecords replayed;
    JournalService reopened(bootstrap, settings.journal_identity_, options);
    reopened.Open([&](uint64_t, const JournalRecords &records) {
      replayed.insert(replayed.end(), records.begin(), records.end());
    });
    require(replayed == JournalRecords{expected}, "replay included a refused append or lost durable bytes");
    reopened.Close();
    bootstrap.Close();
    io.Shutdown();
    std::cout << "Journal admission: total capacity, transient pressure and replay passed\n";
  } catch (const std::exception &e) { std::cerr << e.what() << std::endl; std::_Exit(1); }
}
