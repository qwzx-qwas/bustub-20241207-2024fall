#include "storage_config.h"
#include <chrono>
#include <condition_variable>
#include <cstdlib>
#include <future>
#include <iostream>
#include <mutex>
#include <thread>
#include <unistd.h>
using namespace bustub;
using namespace std::chrono_literals;
namespace {
std::mutex mutex;
std::condition_variable changed;
bool store_entered=false, store_release=false, write_armed=false, write_entered=false, write_release=false;
uint64_t data_start=0;
void require(bool ok, const char *message) {
  if (!ok) { std::cerr << message << std::endl; std::_Exit(1); }
}
void durable(const JournalResult &result) {
  if (result.error_) std::rethrow_exception(result.error_);
  require(result.outcome_==JournalOutcome::Durable,"publication was not durable");
}
auto bytes(size_t n, unsigned seed) {
  std::vector<std::byte> v(n);
  for (size_t i=0;i<n;++i) v[i]=std::byte((i*37+seed)%251);
  return v;
}
}
extern "C" ssize_t __real_pwrite(int,const void *,size_t,off_t);
extern "C" ssize_t __wrap_pwrite(int fd,const void *p,size_t n,off_t offset) {
  {
    std::unique_lock lock(mutex);
    if(write_armed && static_cast<uint64_t>(offset)>=data_start) {
      write_armed=false;write_entered=true;changed.notify_all();
      changed.wait(lock,[]{return write_release;});
    }
  }
  return __real_pwrite(fd,p,n,offset);
}
int main(int argc,char **argv) {
  try {
    require(argc==3,"expected isolated device config and close/store scenario");
    const bool store_mode=std::string(argv[2])=="store";
    auto config=bustub::cli::ReadStorageConfig(argv[1]);
    auto &options=config.deployment_.storage_;
    options.metadata_.max_live_pages_=64;
    options.transactions_->gc_interval_=250ms;
    options.transactions_->metadata_writeback_pages_=1;
    options.transactions_->metadata_checkpoint_rounds_=0;
    options.transactions_->integrity_scan_=false;
    options.transactions_->deferred_max_bytes_=0;
    data_start=config.layout_.regions_[2].Offset();
    NodeStorage node(options);
    node.Create(config.layout_);node.InitializeObjects();
    const auto space=node.CreateObjectSpace(node.Objects());durable(space.result_);
    const ObjectKey object{*space.space_,42};
    durable(node.CreateObject(node.Objects(),object,16384,ObjectSizeMode::Fixed));
    const auto expected=bytes(16384,73);
    ObjectTransaction tx;
    tx.objects_.push_back({ObjectOperation::Write,object,0,ObjectSizeMode::Fixed,expected});
    tx.controls_.push_back({object,900,bytes(12000,94)});
    std::promise<JournalResult> store_result;
    auto store_done=store_result.get_future();
    bool store_once=true;
    // Pause an existing maintenance owner after its first B writeback. This
    // prevents background progress from hiding the deliberately full dirty B.
    node.SetStoreMaintenance([&] {
      { std::unique_lock lock(mutex);
        if (!store_once) return;
        store_once=false;store_entered=true;changed.notify_all();
        changed.wait(lock,[]{return store_release;});
      }
      if (store_mode) {
        // Same synchronous submission contract used by RaftObjectStorage's
        // maintenance owner. No substitute transaction engine or fake IO.
        auto work=node.SubmitObjects(tx);
        require(work.admission_==IOAdmission::Accepted,"Store work was not accepted");
        work.ticket_->Wait();store_result.set_value(work.ticket_->Result());
      }
    });
    {
      std::unique_lock lock(mutex);
      require(changed.wait_for(lock,10s,[]{return store_entered;}),"maintenance was not entered");
    }
    size_t seeded=0;bool pressured=false;
    for(size_t i=0;i<1000;++i) {
      try { durable(node.Commit(node.Read(),{{{777,91,i},bytes(12000,i)}}));++seeded; }
      catch(const MetadataCommitBusy &) { pressured=true;break; }
    }
    require(pressured && seeded>1,"fixture did not fill B with dirty bodies");
    std::cout<<"dirty cache pressure after "<<seeded<<" commits\n"<<std::flush;
    {std::lock_guard lock(mutex);write_armed=true;}
    std::optional<ObjectTransactionSubmission> submitted;
    if (store_mode) {std::lock_guard lock(mutex);store_release=true;changed.notify_all();}
    else {
      submitted=node.SubmitObjects(tx);
      require(submitted->admission_==IOAdmission::Accepted,"object request not accepted");
    }
    {
      std::unique_lock lock(mutex);
      require(changed.wait_for(lock,10s,[]{return write_entered;}),"accepted request did not reach real Data IO");
    }
    std::future<void> closing;
    if (!store_mode) {
      closing=std::async(std::launch::async,[&]{node.Close();});
      {std::lock_guard lock(mutex);store_release=true;changed.notify_all();}
      const auto deadline=std::chrono::steady_clock::now()+10s;
      while(node.State().phase_!=NodeStoragePhase::Draining) {
        require(std::chrono::steady_clock::now()<deadline,"Close did not stop admission");
        std::this_thread::yield();
      }
      require(!submitted->ticket_->WaitFor(1ms),"blocked Data IO completed prematurely");
    }
    {std::lock_guard lock(mutex);write_release=true;changed.notify_all();}
    if (store_mode) {
      require(store_done.wait_for(40s)==std::future_status::ready,"Store publication starved on its own maintenance role");
      durable(store_done.get());node.Close();
    } else {
      require(submitted->ticket_->WaitFor(40s),"accepted publication starved after Close stopped admission");
      durable(submitted->ticket_->Result());
      require(closing.wait_for(10s)==std::future_status::ready,"Close did not drain accepted work");
      closing.get();submitted.reset();
    }
    node.Open();
    auto read=node.ReadObject(node.Objects(),object,0,expected.size());
    read.Wait();
    std::vector<std::byte> actual(expected.size());read.CopyTo(actual.data(),actual.size());
    require(actual==expected,"reopen content differs from accepted input");
    require(node.Objects().Control(object,900)==std::optional(bytes(12000,94)),"reopen control differs from accepted input");
    node.Close();
    std::cout<<(store_mode?"Store":"Close")<<" pressure: accepted IO, durable publication, drain and reopen passed\n";
  } catch(const std::exception &e) {std::cerr<<e.what()<<std::endl;std::_Exit(1);}
}
