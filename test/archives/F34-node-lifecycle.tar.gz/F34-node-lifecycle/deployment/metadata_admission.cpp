#include "storage_config.h"
#include <atomic>
#include <cerrno>
#include <chrono>
#include <condition_variable>
#include <cstdlib>
#include <iostream>
#include <mutex>
#include <thread>
#include <unistd.h>
using namespace bustub;
using namespace std::chrono_literals;
namespace {
std::mutex mutex;
std::condition_variable changed;
unsigned entered=0, released=0;
std::atomic<bool> fail_metadata{false};
uint64_t metadata_start=0,metadata_end=0;
void require(bool ok,const char *why) {
  if(!ok){std::cerr<<why<<std::endl;std::_Exit(1);}
}
auto bytes(size_t n,unsigned seed) {
  std::vector<std::byte> result(n);
  for(size_t i=0;i<n;++i)result[i]=std::byte((i*37+seed)%251);
  return result;
}
void durable(const JournalResult &r) {
  if(r.error_)std::rethrow_exception(r.error_);
  require(r.outcome_==JournalOutcome::Durable,"fixture commit not durable");
}
void stage(unsigned n) {
  std::unique_lock lock(mutex);
  require(changed.wait_for(lock,10s,[&]{return entered>=n;}),"periodic maintenance treated temporary IO pressure as fatal");
}
void release(unsigned n) {std::lock_guard lock(mutex);released=n;changed.notify_all();}
}
extern "C" ssize_t __real_pwrite(int,const void *,size_t,off_t);
extern "C" ssize_t __wrap_pwrite(int fd,const void *data,size_t size,off_t offset) {
  if(static_cast<uint64_t>(offset)>=metadata_start && static_cast<uint64_t>(offset)<metadata_end && fail_metadata.exchange(false)) {
    errno=EIO;return -1;
  }
  return __real_pwrite(fd,data,size,offset);
}
int main(int argc,char **argv) {
  try {
    require(argc==3,"expected isolated device config and scenario");
    auto config=bustub::cli::ReadStorageConfig(argv[1]);
    auto &o=config.deployment_.storage_;
    o.io_.max_operations_=64;o.io_.max_buffer_bytes_=1024*1024;
    o.io_.progress_operations_=2;o.io_.progress_buffer_bytes_=64*1024;
    o.transactions_->gc_interval_=50ms;
    o.transactions_->metadata_writeback_pages_=1;
    o.transactions_->metadata_checkpoint_rounds_=1;
    o.transactions_->integrity_scan_=false;
    o.transactions_->deferred_max_bytes_=0;
    metadata_start=config.layout_.regions_[0].Offset();
    metadata_end=metadata_start+config.layout_.regions_[0].Size();
    NodeStorage node(o);node.Create(config.layout_);
    node.SetStoreMaintenance([]{
      std::unique_lock lock(mutex);auto n=++entered;changed.notify_all();
      if(n<=2)changed.wait(lock,[&]{return released>=n;});
    });
    stage(1);
    // More than 64 dirty pages, but a B working set within its 512-body budget.
    // Independent known values; no access to private pager or queue state.
    for(unsigned i=0;i<30;++i)durable(node.Commit(node.Read(),{{{777,91,i},bytes(12000,i)}}));
    auto payload=bytes(o.objects_->allocator_.allocation_bytes_,73);
    std::vector<ObjectWrite> held;
    auto hold_io = [&] {
    for(size_t i=0;i<o.io_.max_operations_;++i) {
      ProgressWork lane(i>=o.io_.max_operations_-o.io_.progress_operations_);
      auto write=node.WriteObjectData(payload.data(),payload.size());write.Wait();
      require(write.Result().writes_durable_,"fixture Data IO failed");
      held.push_back(std::move(write)); // Completed results still own F02 buffers/slots.
    }
    };
    hold_io();
    bool busy=false;
    try {node.Writeback(1);}
    catch(const MetadataCommitBusy &){busy=true;}
    catch(const MetadataError &){require(false,"temporary metadata IO Full must be Busy");}
    require(busy,"fixture did not exhaust shared IO slots");
    release(1);stage(2); // The periodic role itself must also survive the refusal.
    require(node.State().phase_==NodeStoragePhase::Serving,"pressure made node unavailable");
    held.clear();
    auto written=node.Writeback(1);
    require(written.outcome_==MetadataWritebackOutcome::Durable,"B did not progress after IO owners released");
    bool too_large=false;
    try {node.Writeback(65);}
    catch(const MetadataCommitBusy &){require(false,"oversized metadata batch must not retry");}
    catch(const MetadataError &e){too_large=e.Code()==MetadataErrorCode::ResourceUnavailable;}
    require(too_large,"oversized metadata batch was not rejected");
    require(node.Read().Get({777,91,17})==std::optional(bytes(12000,17)),"refused IO changed published metadata");
    require(node.Writeback(1).outcome_==MetadataWritebackOutcome::Durable,"oversize rejection damaged pending work");
    // Drain page writes first: the next refusal must be Journal admission,
    // not the page-IO check exercised above. Callback 2 still holds maintenance.
    while(node.Writeback(64).outcome_!=MetadataWritebackOutcome::Clean) {}
    hold_io();
    bool checkpoint_busy=false;
    try {node.Checkpoint(64);}
    catch(const MetadataCommitBusy &) {checkpoint_busy=true;}
    catch(const MetadataError &) {require(false,"checkpoint Journal Full must be Busy");}
    require(checkpoint_busy,"checkpoint did not reach Journal admission pressure");
    require(node.State().phase_==NodeStoragePhase::Serving,"checkpoint pressure made node unavailable");
    held.clear();
    require(node.Checkpoint(64).outcome_==MetadataCheckpointOutcome::Durable,"checkpoint did not recover after releasing IO");
    require(node.Read().Get({777,91,17})==std::optional(bytes(12000,17)),"checkpoint refusal changed published metadata");
    // A failed admission must also release the checkpoint's commit gate.
    durable(node.Commit(node.Read(),{{{777,91,30},bytes(12000,30)}}));
    // A real submitted write failure must remain observable, unlike pre-IO Full.
    fail_metadata.store(true);release(2);
    const auto end=std::chrono::steady_clock::now()+10s;
    NodeStorageView state;
    do {
      state=node.State();
      if(state.phase_==NodeStoragePhase::Failed)break;
      require(std::chrono::steady_clock::now()<end,"real metadata EIO was hidden");
      std::this_thread::yield();
    } while(true);
    bool eio=false;
    try {if(state.error_)std::rethrow_exception(state.error_);}
    catch(const BlockDeviceIOError &e){eio=e.code().value()==EIO && e.Range().Offset()>=metadata_start && e.Range().Offset()<metadata_end;}
    require(eio,"node did not preserve the submitted metadata EIO");
    node.Close();
    std::cout<<"Metadata admission: transient pressure, recovery, oversize and real IO error passed\n";
  } catch(const std::exception &e){std::cerr<<e.what()<<std::endl;std::_Exit(1);}
}
