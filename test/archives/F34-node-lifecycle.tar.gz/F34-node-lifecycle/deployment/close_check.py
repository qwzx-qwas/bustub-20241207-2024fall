"""Real Node/B/Direct progress and metadata admission, with designated mutations."""
import argparse, hashlib, json, os, pathlib, shlex, subprocess, time
p=argparse.ArgumentParser();p.add_argument('--repo',type=pathlib.Path,required=True);p.add_argument('--build',type=pathlib.Path,required=True);p.add_argument('--out',type=pathlib.Path,required=True);p.add_argument('--mutation',action='store_true');p.add_argument('--scenario',choices=['close','store','admission','journal'],default='close');p.add_argument('--fault',choices=['full-as-resource','oversize-as-busy','io-error-as-busy','checkpoint-as-resource','omit-flush-budget']);a=p.parse_args()
repo=a.repo.resolve();build=a.build.resolve();out=a.out.resolve();out.mkdir(exist_ok=False,parents=True)
pkg=pathlib.Path(__file__).resolve().parent
commands=json.loads((build/'compile_commands.json').read_text());records=[]
def run(cmd,log,cwd=repo,timeout=180):
 start=time.monotonic()
 with (out/log).open('w') as f:r=subprocess.run(list(map(str,cmd)),cwd=cwd,stdout=f,stderr=f,timeout=timeout)
 records.append(dict(command=list(map(str,cmd)),cwd=str(cwd),returncode=r.returncode,seconds=time.monotonic()-start,log=log));(out/'commands.json').write_text(json.dumps(records,indent=2))
 return r.returncode
def compile(original,source,output):
 e=next(x for x in commands if x['file']==str(repo/original));cmd=shlex.split(e['command']);cmd[cmd.index('-o')+1]=str(output);cmd[-1]=str(source)
 cmd+=['-I'+str(repo/'tools/bustub-node'),'-I'+str(repo/'src/storage/disk')]
 assert run(cmd,output.name+'.compile.log',e['directory'])==0,(out/(output.name+'.compile.log')).read_text()
compile('tools/bustub-node/bustub-node.cpp',pkg/({'admission':'metadata_admission.cpp','journal':'journal_admission.cpp'}.get(a.scenario,'close_pressure.cpp')),out/'test.o')
linkcwd=build/'tools/bustub-node';link=shlex.split((linkcwd/'CMakeFiles/bustub-node.dir/link.txt').read_text())
link=[str((linkcwd/x).resolve()) if x.startswith(('CMakeFiles/','../../')) else x for x in link]
link[link.index(str(linkcwd/'CMakeFiles/bustub-node.dir/bustub-node.cpp.o'))]=str(out/'test.o')
link[link.index('-o')+1]=str(out/'close-test');link+=['-Wl,--wrap=pwrite']
if a.mutation or a.fault:
 if a.fault:
  assert a.scenario in ('admission','journal') and not a.mutation
  file={'io-error-as-busy':'src/storage/disk/object_mapping.cpp','omit-flush-budget':'src/storage/disk/journal_service.cpp'}.get(a.fault,'src/storage/disk/metadata_engine.cpp')
  source=(repo/file).read_text()
  edits={
   'checkpoint-as-resource':('  CheckMetadataJournalAdmission(submission.admission_);\n  submission.ticket_->Wait();','  if (submission.admission_ != JournalAdmission::Accepted) throw MetadataError(MetadataErrorCode::ResourceUnavailable, \"checkpoint Journal admission failed\");\n  submission.ticket_->Wait();'),
   'omit-flush-budget':('IOReadBudget io_budget{1, 0};','IOReadBudget io_budget{0, 0};'),
   'full-as-resource':('throw MetadataCommitBusy("metadata page IO credits held");','throw MetadataError(MetadataErrorCode::ResourceUnavailable, "metadata page IO credits held");'),
   'oversize-as-busy':('if (!executor.AccumulateReadBudget(&budget, 1, bytes_per_page))','if (false && !executor.AccumulateReadBudget(&budget, 1, bytes_per_page))'),
   'io-error-as-busy':('if (written.outcome_ == MetadataWritebackOutcome::Failed) std::rethrow_exception(written.error_);','if (written.outcome_ == MetadataWritebackOutcome::Failed) throw MetadataCommitBusy("mutant ignores failed write");')}
  old,new=edits[a.fault]
 else:
  file='src/storage/disk/object_transaction.cpp';source=(repo/file).read_text()
  old='ObjectMappingAccess::MaintainMetadata(mapping_, options_.metadata_writeback_pages_, false);'
  new='/* mutation: only periodic B maintenance can progress */'
 assert source.count(old)==1
 source=source.replace(old,new)
 modified=out/pathlib.Path(file).name;modified.write_text(source)
 compile(file,modified,out/'mutation.o');link.insert(1,str(out/'mutation.o'))
assert run(link,'link.log',linkcwd)==0,(out/'link.log').read_text()
text=(repo/'docs/storage_redesign/node-storage.example.conf').read_text()
fields={k.strip():v.strip() for raw in text.splitlines() if (line:=raw.split('#',1)[0].strip()) for k,v in [line.split('=',1)]}
device=out/'device';fields['device.path']=str(device)
with device.open('xb') as f:f.truncate(int(fields['create.capacity']))
config=out/'config.conf';config.write_text(''.join(f'{k}={v}\n' for k,v in fields.items()))
rc=run([out/'close-test',config,a.scenario],'result.log',timeout=100)
log=(out/'result.log').read_text()
marker='accepted publication starved after Close stopped admission' if a.scenario=='close' else 'Store publication starved on its own maintenance role'
markers={'checkpoint-as-resource':'checkpoint Journal Full must be Busy','omit-flush-budget':'Journal must count data plus Flush before admission','full-as-resource':'temporary metadata IO Full must be Busy','oversize-as-busy':'oversized metadata batch must not retry','io-error-as-busy':'real metadata EIO was hidden'}
if a.fault:marker=markers[a.fault]
expected=(rc==1 and marker in log) if (a.mutation or a.fault) else (rc==0 and ({'admission':'real IO error passed','journal':'transient pressure and replay passed'}.get(a.scenario,'drain and reopen passed')) in log)
assert expected,log
(out/'summary.json').write_text(json.dumps(dict(scenario=a.scenario,mutation=a.fault or a.mutation,expected_observed=expected,scope='Direct file NodeStorage progress/admission integration; not distributed E2E',production_sha256={f:hashlib.sha256((repo/f).read_bytes()).hexdigest() for f in ['src/storage/disk/object_transaction.cpp','src/storage/disk/metadata_engine.cpp','src/storage/disk/object_mapping.cpp','src/storage/disk/journal_service.cpp']}),indent=2))
print(log,flush=True)
