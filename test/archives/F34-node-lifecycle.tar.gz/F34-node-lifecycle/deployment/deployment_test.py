"""Production CLI/lifecycle contract; independent persistent-byte and process oracles."""
import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import subprocess
import socket
import time

p=argparse.ArgumentParser();p.add_argument('--build',type=Path,required=True);p.add_argument('--template',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
a.output.mkdir()
fields={k.strip():v.strip() for raw in a.template.read_text().splitlines() if (line:=raw.split('#',1)[0].strip()) for k,v in [line.split('=',1)]}
device=a.output/'device';capacity=int(fields['create.capacity'])
with device.open('xb') as f:f.truncate(capacity)
fields['device.path']=str(device.resolve());config=a.output/'node.conf'
def save(values):config.write_text(''.join(f'{k}={v}\n' for k,v in values.items()))
save(fields)
cmd=[str(a.build/'bin/bustub-node'),'--node-id','1','--group-id','deployment-review','--data-dir',str(a.output/'state'),'--raft-listen','127.0.0.1:43101','--client-listen','127.0.0.1:43201','--peer','2=127.0.0.1:43102,127.0.0.1:43202','--peer','3=127.0.0.1:43103,127.0.0.1:43203','--storage-config',str(config)]
results=[]
def run(name,extra,ok,needle=None):
 r=subprocess.run(cmd+extra,capture_output=True,text=True,timeout=30)
 (a.output/(name+'.log')).write_text(r.stdout+r.stderr)
 assert (r.returncode==0)==ok,(name,r.returncode,r.stdout,r.stderr)
 if needle:assert needle in r.stdout+r.stderr,(name,r.stdout,r.stderr)
 results.append({'test':name,'exit':r.returncode})
def digest():
 h=hashlib.sha256()
 with device.open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
# Unknown configuration fails before initializing, and normal Open never formats.
blank=digest();save({**fields,'unknown.option':'1'})
run('unknown-field',['--storage-action','initialize'],False,'unknown storage config')
assert digest()==blank
save(fields);run('open-blank',[],False);assert digest()==blank
run('initialize',['--storage-action','initialize'],True,'no node service started')
formatted=digest();assert formatted!=blank
run('refuse-reinitialize',['--storage-action','initialize'],False);assert digest()==formatted
# Lock is on the inode, and must reject even an alternate path to the same file.
link=a.output/'alias';link.symlink_to(device.resolve());save({**fields,'device.path':str(link.absolute())})
with device.open('r+b') as f:
 fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
 run('exclusive-device',[],False,'storage device already owned')
assert digest()==formatted
save({**fields,'identity.storage':'ffffffffffffffffffffffffffffffff'})
run('wrong-identity',[],False);assert digest()==formatted
save(fields)
# Actual Open/start/Stop/reopen, with status payload through the existing TCP client.
for generation in (1,2):
 with (a.output/f'serving-{generation}.log').open('w') as log:
  proc=subprocess.Popen(cmd,stdout=log,stderr=log)
  try:
   end=time.monotonic()+15
   while time.monotonic()<end:
    assert proc.poll() is None,'node exited during startup'
    r=subprocess.run([str(a.build/'bin/bustub-client'),'status','--endpoint','127.0.0.1:43201','--request-id','1','--storage','1'],capture_output=True,text=True,timeout=3)
    (a.output/f'status-{generation}.log').write_text(r.stdout+r.stderr)
    if r.returncode==0 and 'storage_version' in r.stdout:break
    time.sleep(.02)
   else:raise AssertionError('status not available')
   (a.output/f'status-{generation}.log').write_text(r.stdout+r.stderr)
   legacy=subprocess.run([str(a.build/'bin/bustub-client'),'status','--endpoint','127.0.0.1:43201','--request-id','2'],capture_output=True,text=True,timeout=3)
   assert legacy.returncode==0 and 'message=' not in legacy.stdout,legacy.stdout+legacy.stderr
   # Fixed type-5 wire fixture, independently assembled from the protocol table.
   # This catches matching sender/receiver mistakes that a round trip would miss.
   with socket.create_connection(('127.0.0.1',43201),timeout=3) as wire:
    wire.sendall(bytes.fromhex('42434c4e54303031000000010000000c000000050000000000000001f3fa2225'))
    chunks=[]
    while True:
     part=wire.recv(4096)
     if not part:break
     chunks.append(part)
    assert b'"storage_version":1' in b''.join(chunks)
   payload=json.loads(r.stdout.split('message=',1)[1])
   assert payload['data_capacity_bytes']==int(fields['create.data.bytes'])
   assert payload['data_free_bytes']+payload['data_committed_bytes']==payload['data_capacity_bytes']
   assert payload['metadata_descriptors']>0
   results.append({'test':f'open-status-close-{generation}','status':payload})
  finally:
   proc.terminate()
   try:proc.wait(timeout=15)
   except subprocess.TimeoutExpired:proc.kill();proc.wait();raise
  assert proc.returncode==0
(a.output/'results.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps({'passed':len(results)}))
