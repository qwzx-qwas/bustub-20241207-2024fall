# S12 CLI 阶段证据（2026-10-09）

这是同一 F34 包新增的正式部署检查。根目录 tests/、原 production_sha256 仍是 2026-09-30 历史测试，未在本轮重跑；它们不冒充当前验收。当前主线业务测试只使用 test/storage_acceptance。

在隔离 checkout 使用结果包最新 `final-review/source/` 覆盖基准 87f4357（`source/`、`review/source/`、`review2/source/`、`review3/source/` 分别属于此前运行，不可混用），核对本目录 MANIFEST。编译需要支持 C++23 start_lifetime_as_array 的工具链（本次 GCC 16）；构建 build-storage-e2e、client_protocol_test。支持实际 Direct 文件 IO、flock 和 loopback，约需 2 GiB 构建空间及三个稀疏 1 GiB 设备。测试端口 43101/43201，原共同场景端口基数 33100，串行运行。

```bash
python3 /tmp/F34-node-lifecycle/deployment/deployment_test.py --build /tmp/s12-node-work/build --template docs/storage_redesign/node-storage.example.conf --output /tmp/s12-node-work/deployment-verified
```

output 必须尚不存在，指定正确 LD_LIBRARY_PATH。8 项检查、3 项已有协议测试以及两个 CLI 变异详见 docs/storage_redesign/s12_node_execution_20261009.md。变异脚本按本次工作布局运行：将两个 .py 放进新的 /tmp/s12-node-work，build/ 是当前实际构建；在仓库根运行 mutations.py。它读取真实 compile_commands/link.txt，在子目录重编 CLI 对象，不修改仓库生产代码。编译失败或任意非零返回不能算检出，必须匹配指定 AssertionError。不要在性能测量中同时编译。

共同 C/P 使用仓库内原 runner 加 --storage-template；完整命令与参数、每次运行时源码、失败日志在结果包。C1 与限时性能资格未全通过，不能把本包名或脚本退出码当作 S12 总验收结果。原 F34 历史与当前 CLI 检查是不同边界；没有把历史通过数加入本轮统计。

新增范围契约：将 metadata_range.cpp、range_check.py 同样置于 /tmp/s12-node-work，在仓库根运行 range_check.py。一个正常场景含 8 个独立范围输入，分别在重开前后验证；一个移除上界判断的变异必须报 bounded scan mismatch: count。实际调用正常 NodeStorage/B/Direct 路径，不连接网络，也没有假造树或内部页。

快照观察器契约：`python3 /tmp/F34-node-lifecycle/deployment/observer_test.py /path/to/repo`。只验证本项目测试适配器的四种 wire 输入和完成事件；实际数据库由原 C5 验证。变异恢复旧 Network.catchup 的 `kind = request["type"]`，应在 observer missed completed installation 指定断言失败；源码和可重跑脚本均在本目录。没有解压测试或假数据库。


同日关闭/Store 压力复查：复用已构建的 GCC 16 Release 库，无新增 CMake 目标。以下 runner 自动根据 compile_commands/link.txt 编译阶段程序，只在新的 out 目录创建定容设备；从仓库根运行并配置相同运行时库路径：

```bash
python3 /tmp/F34-node-lifecycle/deployment/close_check.py --repo . --build /tmp/review-build --out /tmp/close-normal --scenario close
python3 /tmp/F34-node-lifecycle/deployment/close_check.py --repo . --build /tmp/review-build --out /tmp/store-normal --scenario store
```

分别换新 out 并加 `--mutation` 验证缺陷检出。包装的 pwrite 在暂停后仍调用真实 IO；正常结果要求 Durable、关闭完成和重开逐字节核对。变异只能在指定的“提交无法推进”断言检出才通过 runner。Close 和 Store 是两个不同依赖场景，使用同一装置；§10 说明与旧 F31/F34 的关系、超时边界、生产污染及缺口。每个 out 有稀疏设备，归档仅保留日志/配置/命令/源码，审查后删除设备及二进制。本次未重跑 CLI 八项与 C1/P2，旧结果保持其原源码归属。


再次复查新增 IO 准入场景（同一 runner）：

```bash
python3 /tmp/F34-node-lifecycle/deployment/close_check.py --repo . --build /tmp/review-build --out /tmp/admission-normal --scenario admission
```

变异分别使用新的 out 并增加 `--fault full-as-resource`、`--fault oversize-as-busy`、`--fault io-error-as-busy`；只有指定断言失败才算检出。该场景保持真实 Node/B/IO，通过已完成但仍持有的结果占满名额，检查释放后的推进、永久超限与真实 EIO。没有复制新的 runner，未新增生产接口。阶段源码仅在此包保留，详见执行审查 §11。

同日 checkpoint/Journal 复查：MetadataAdmission 扩展 checkpoint 暂满与恢复，JournalAdmission 使用真实 Direct/F07/F02 检查段写与独立 Flush 总容量；沿用同一 runner。

```sh
python3 close_check.py --repo /path/to/repo --build /path/to/build --out /tmp/f34-checkpoint --scenario admission
python3 close_check.py --repo /path/to/repo --build /path/to/build --out /tmp/f34-checkpoint-mutant --scenario admission --fault checkpoint-as-resource
python3 close_check.py --repo /path/to/repo --build /path/to/build --out /tmp/f34-journal --scenario journal
python3 close_check.py --repo /path/to/repo --build /path/to/build --out /tmp/f34-journal-mutant --scenario journal --fault omit-flush-budget
```

仅指定失败断言计为变异检出；完整 C1/P2 及性能仍须查本轮实际结果，不从局部成功推断。

同日提交门槛复查：runtime C++ 与 review3 未变，仅将旧 DiskScheduler 从生产库移至原课程测试目标。最新生产/构建指纹见本清单；原阶段测试源码不变。构建并运行原 disk_scheduler_test，复跑原 C1 与低缓存 P2，实际结果和未提交原因见 final-review/summary.json 及执行审查 §14。较早四项阶段场景、变异及 C4 属于 review3，不能作为本轮新执行数。
