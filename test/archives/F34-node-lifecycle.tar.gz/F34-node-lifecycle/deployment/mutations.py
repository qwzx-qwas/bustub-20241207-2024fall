from pathlib import Path
import json,shlex,subprocess,os
repo=Path.cwd();root=Path('/tmp/s12-node-work');build=root/'build';env={**os.environ,'LD_LIBRARY_PATH':'/tmp/bustub-gcc16/native-runtime'}
commands=json.loads((build/'compile_commands.json').read_text())
linkcwd=build/'tools/bustub-node';link=shlex.split((linkcwd/'CMakeFiles/bustub-node.dir/link.txt').read_text())
for name,src,old,new,marker in [('open_formats','bustub-node.cpp','if (action == "initialize") {','if (action == "initialize" || action == "open") {','open-blank'),('no_exclusive_owner','storage_config.cpp','if (::flock(fd_, LOCK_EX | LOCK_NB) != 0) {','if (false) {','exclusive-device')]:
 work=root/name; (work/'bin').mkdir(parents=True)
 code=(repo/'tools/bustub-node'/src).read_text();assert code.count(old)==1
 source=work/src;source.write_text(code.replace(old,new))
 entry=next(e for e in commands if e['file']==str(repo/'tools/bustub-node'/src))
 cmd=shlex.split(entry['command']);cmd[cmd.index('-o')+1]=str(work/'mutant.o');cmd[-1]=str(source);cmd+=['-I'+str(repo/'tools/bustub-node')]
 with (work/'compile.log').open('w') as out:subprocess.run(cmd,cwd=entry['directory'],stdout=out,stderr=out,check=True)
 cmd=[str((linkcwd/x).resolve()) if x.startswith(('CMakeFiles/','../../')) else x for x in link]
 cmd[cmd.index('-o')+1]=str(work/'bin/bustub-node')
 objectfile=str((linkcwd/f'CMakeFiles/bustub-node.dir/{src}.o').resolve());cmd[cmd.index(objectfile)]=str(work/'mutant.o')
 with (work/'link.log').open('w') as out:subprocess.run(cmd,cwd=linkcwd,stdout=out,stderr=out,check=True)
 (work/'bin/bustub-client').symlink_to(build/'bin/bustub-client')
 # Isolate the exclusivity check from node startup: a mutated lock reaches
 # Bootstrap's distinct refusal, so it cannot accidentally pass on any error.
 script=(root/'deployment_test.py').read_text()
 if name=='no_exclusive_owner':script=script.replace("run('exclusive-device',[],False,", "run('exclusive-device',['--storage-action','initialize'],False,")
 test=work/'test.py';test.write_text(script)
 with (work/'test.log').open('w') as out:
  r=subprocess.run(['python3',str(test),'--build',str(work),'--template',str(repo/'docs/storage_redesign/node-storage.example.conf'),'--output',str(work/'results')],env=env,stdout=out,stderr=out)
 log=(work/'test.log').read_text();assert r.returncode!=0 and f"AssertionError: ('{marker}'," in log,(name,log)
 print(name+': caught by expected assertion',flush=True)
