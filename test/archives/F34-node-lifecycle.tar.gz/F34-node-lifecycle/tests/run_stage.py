#!/usr/bin/env python3
"""Isolated F33/F34 verification using the production library and S5 data model."""
import argparse,hashlib,json,os,pathlib,subprocess,tarfile,time,xml.etree.ElementTree as ET
p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--work',required=True);p.add_argument('--mutations',action='store_true');a=p.parse_args()
repo=pathlib.Path(a.repo).resolve();work=pathlib.Path(a.work).resolve();src=pathlib.Path(__file__).resolve().parent
assert repo!=work and repo not in work.parents,'work must be outside the repository'
work.mkdir(parents=True,exist_ok=True)
manifest=src.parent/'MANIFEST.json'
if manifest.exists():
 m=json.loads(manifest.read_text())
 for field in ('production_sha256','dependency_sha256'):
  for name,h in m[field].items():assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==h,('source drift',name)
env={k:v for k,v in os.environ.items() if not k.startswith('GTEST_')};env.update(S5_WORKDIR=str(work),ASAN_OPTIONS='detect_leaks=1:abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1')
commands=[]
def run(cmd,log,expected=0,timeout=900):
 cmd=list(map(str,cmd));start=time.monotonic()
 with (work/log).open('w') as out:r=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT,env=env,cwd=repo,timeout=timeout)
 commands.append({'command':cmd,'log':log,'seconds':time.monotonic()-start,'exit':r.returncode})
 (work/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 assert r.returncode==expected,(log,r.returncode,expected)
run(['cmake','-S',repo,'-B',work/'build','-DCMAKE_BUILD_TYPE=Debug','-DCMAKE_C_COMPILER=clang-14','-DCMAKE_CXX_COMPILER=clang++-14','-DBUSTUB_SANITIZER=address,undefined','-DCMAKE_EXE_LINKER_FLAGS=-no-pie'],'configure.log')
run(['cmake','--build',work/'build','--target','bustub','gtest_main','-j3'],'build.log')
with tarfile.open(repo/'test/archives/S5-journal-recycling.tar.gz') as t:t.extractall(work,filter='data')
dep=work/'S5-journal-recycling/test/storage_redesign'
flags=['clang++-14','-std=c++17','-g','-O0','-Wall','-Wextra','-Werror','-Wno-unused-parameter','-pthread','-fsanitize=address,undefined','-fno-omit-frame-pointer','-I'+str(repo/'src/include'),'-I'+str(repo/'third_party/fmt/include'),'-I'+str(repo/'third_party/googletest/googletest/include'),'-I'+str(dep)]
libs=[work/'build/lib'/('lib'+name+'.a') for name in ['bustub','fmtd','gtest_main','gtest']]
wraps=['-Wl,--wrap=pread','-Wl,--wrap=pwrite','-Wl,--wrap=fdatasync','-Wl,--wrap=close']
run(flags+['-c',src/'lifecycle_test.cpp','-o',work/'lifecycle-test.o'],'compile.log')
run(flags+['-no-pie',work/'lifecycle-test.o']+libs+wraps+['-o',work/'lifecycle_test'],'link.log')
run([work/'lifecycle_test','--gtest_output=xml:'+str(work/'lifecycle.xml')],'run.log',timeout=120)
# Reuse eight S5 real-component cases, including the old-production compatibility
# image. No F03/F08/F09/F10 matrix copies. Their production sources did not change.
run(['python3',dep/'build_checks.py',repo,work],'s5-regression.log',timeout=180)
for name,n in [('lifecycle.xml',5),('s5.xml',8)]:
 cases=ET.parse(work/name).getroot().findall('./testsuite/testcase')
 assert len(cases)==n and all(c.get('result')=='completed' and not any(c.find(k) is not None for k in ('failure','error','skipped')) for c in cases),name
mutations=[
 ('drop_final_repair_status',[('      if (context) {\n        state_.Repair(context->RepairStatus());\n      }\n      context_.reset();', '      context_.reset();')],'RepairIsIndependentAndFailureConditionsRemainVisible','Close must retain the final repair error'),
 ('hide_startup_cleanup_error',[('error = close_error_;','// mutation: lose cleanup error from cancelled startup')],'CloseCancelsLateRecoveryAndDrainsItsIO','partial startup cleanup must report close error'),
 ('premature_capability',[('result.phase_ == NodeStoragePhase::Serving;', 'result.phase_ == NodeStoragePhase::Serving || result.phase_ == NodeStoragePhase::Recovering;')],'RealRecoveryPublishesOnlyCompleteMetadata','state.metadata_read_'),
 ('late_startup_success',[('if (state_.View().generation_ != generation) {','if (false && state_.View().generation_ != generation) {')],'CloseCancelsLateRecoveryAndDrainsItsIO','cancelled startup cannot publish success'),
 ('skip_startup_drain',[('return active_ == 0;', 'return active_ == 0 || context_ == nullptr;')],'CloseCancelsLateRecoveryAndDrainsItsIO','Close must drain startup IO'),
 ('admit_during_drain',[('if (state.phase_ != NodeStoragePhase::Serving) {','if (state.phase_ != NodeStoragePhase::Serving && state.phase_ != NodeStoragePhase::Draining) {')],'CheckpointCloseDrainsAndRejectsNewCalls','Draining must close admission'),
 ('hide_io_failure',[('state_.Fail(generation, NodeStorageCondition::IOFault, error);','// mutation: do not report actual IO failure')],'RepairIsIndependentAndFailureConditionsRemainVisible','NodeStoragePhase::Failed'),
 ('drop_draining_error',[('const bool draining = view_.phase_ == NodeStoragePhase::Draining && generation + 1 == view_.generation_;','const bool draining = false;')],'CheckpointCloseDrainsAndRejectsNewCalls','draining must retain the IO fault'),
 ('cancel_is_failure',[('if (!cancelled) {','if (!cancelled || state_.View().phase_ == NodeStoragePhase::Draining) {')],'CloseCancelsLateRecoveryAndDrainsItsIO','intentional shutdown is not recovery failure'),
 ('erase_other_conditions',[('view_.conditions_ = present ? view_.conditions_ | bit : view_.conditions_ & ~bit;','view_.conditions_ = present ? bit : 0;')],'RepairIsIndependentAndFailureConditionsRemainVisible','NodeStorageCondition::ResourcePressure'),
]
evidence=[]
if a.mutations:
 for name,changes,test,marker in mutations:
  code=(repo/'src/storage/disk/node_storage.cpp').read_text()
  for old,new in changes:
   assert code.count(old)==1,(name,old);code=code.replace(old,new)
  cpp=work/(name+'.cpp');cpp.write_text(code);obj=work/(name+'.o');exe=work/name
  run(flags+['-c',cpp,'-o',obj],name+'-compile.log',timeout=120)
  run(flags+['-no-pie',work/'lifecycle-test.o',obj]+libs+wraps+['-o',exe],name+'-link.log',timeout=120)
  run([exe,'--gtest_filter=F34Lifecycle.'+test,'--gtest_output=xml:'+str(work/(name+'.xml'))],name+'-run.log',expected=1,timeout=120)
  failures=[f.text or '' for f in ET.parse(work/(name+'.xml')).getroot().iter('failure')]
  assert any(marker in f for f in failures),(name,failures)
  evidence.append({'mutation':name,'changes':changes,'test':test,'expected_marker':marker,'failures':failures})
  (work/'mutations.json').write_text(json.dumps(evidence,indent=2)+'\n')
  print(name+': detected by specified oracle',flush=True)
(work/'summary.json').write_text(json.dumps({'passed':{'lifecycle.xml':5,'s5.xml':8},'mutations_detected':len(evidence),'scope':'Direct regular-file NodeStorage/B integration. No DistributedNode SQL/Raft migration, raw-device or real power-loss claim.'},indent=2)+'\n')
print('F33/F34 5 + S5 8 passed; mutations '+str(len(evidence)),flush=True)
