#include "fixture.h"
#include "storage/disk/node_storage.h"
#include "gtest/gtest.h"
#include <cerrno>
#include <chrono>
#include <condition_variable>
#include <cstring>
#include <future>
#include <mutex>
#include <thread>
using namespace std::chrono_literals;
extern "C" ssize_t __real_pread(int, void *, size_t, off_t);
extern "C" ssize_t __real_pwrite(int, const void *, size_t, off_t);
extern "C" int __real_fdatasync(int);
extern "C" int __real_close(int);
namespace {
enum class Point { None, Read, Write, JournalFlush };
std::mutex gate_mutex;
std::condition_variable gate_cv;
Point point = Point::None;
uint64_t target = 0;
bool entered = false, released = true, fail_flush = false, failure_seen = false;
int pause_fd = -1, failure_fd = -1;
bool fail_paused_io = false, fail_close = false;
void Arm(Point p, uint64_t offset, bool fail_after_pause = false) {
  std::lock_guard<std::mutex> lock(gate_mutex);
  point = p;
  fail_paused_io = fail_after_pause;
  target = offset;
  entered = false;
  released = false;
  pause_fd = -1;
}
void Release() {
  std::lock_guard<std::mutex> lock(gate_mutex);
  released = true;
  point = Point::None;
  pause_fd = failure_fd = -1;
  fail_flush = false;
  gate_cv.notify_all();
}
struct ReleaseOnExit {
  ~ReleaseOnExit() { Release(); }
};
void Pause(std::unique_lock<std::mutex> &lock) {
  entered = true;
  point = Point::None;
  gate_cv.notify_all();
  gate_cv.wait(lock, [] { return released; });
}
bool WaitEntered() {
  std::unique_lock<std::mutex> lock(gate_mutex);
  return gate_cv.wait_for(lock, 10s, [] { return entered; });
}
bool Direct(int fd) { return (fcntl(fd, F_GETFL) & O_DIRECT) != 0; }
} // namespace
extern "C" int __wrap_close(int fd) {
  bool inject = false;
  {
    std::lock_guard<std::mutex> lock(gate_mutex);
    if (Direct(fd) && fail_close) {
      inject = true;
      fail_close = false;
    }
  }
  const auto result = __real_close(fd);
  if (inject) {
    errno = EIO;
    return -1;
  }
  return result;
}
extern "C" ssize_t __wrap_pread(int fd, void *buf, size_t size, off_t off) {
  if (Direct(fd)) {
    std::unique_lock<std::mutex> lock(gate_mutex);
    if (point == Point::Read && static_cast<uint64_t>(off) == target)
      Pause(lock);
  }
  return __real_pread(fd, buf, size, off);
}
extern "C" ssize_t __wrap_pwrite(int fd, const void *buf, size_t size,
                                 off_t off) {
  if (Direct(fd)) {
    std::unique_lock<std::mutex> lock(gate_mutex);
    if (point == Point::Write && static_cast<uint64_t>(off) == target) {
      Pause(lock);
      if (fail_paused_io) {
        errno = EIO;
        return -1;
      }
    }
    const bool journal_data = off > static_cast<off_t>(s5::JOURNAL_START) &&
                              off < static_cast<off_t>(6 * s5::MIB);
    if (journal_data && point == Point::JournalFlush)
      pause_fd = fd;
    if (journal_data && fail_flush) {
      failure_fd = fd;
      fail_flush = false;
    }
  }
  return __real_pwrite(fd, buf, size, off);
}
extern "C" int __wrap_fdatasync(int fd) {
  {
    std::unique_lock<std::mutex> lock(gate_mutex);
    if (fd == failure_fd) {
      failure_fd = -1;
      failure_seen = true;
      errno = EIO;
      return -1;
    }
    if (fd == pause_fd) {
      pause_fd = -1;
      Pause(lock);
      if (fail_paused_io) {
        errno = EIO;
        return -1;
      }
    }
  }
  return __real_fdatasync(fd);
}
namespace {
using namespace bustub;
using namespace s5;
auto Options(const Image &image) -> NodeStorageOptions {
  BlockDevice dev(image.path, {});
  const auto unit = static_cast<uint32_t>(
      std::lcm<uint64_t>(4096, dev.Info().offset_alignment_));
  Require(unit <= 16384, "device alignment exceeds bounded fixture");
  BootstrapIdentity id{};
  id.storage_.fill(11);
  id.device_.fill(31);
  JournalIdentity jid{};
  jid.fill(73);
  return {image.path,
          {},
          {3, 2048, 16 * MIB},
          id,
          jid,
          {4ULL * unit, unit, 8192, MIB, 512, 2 * MIB, 8, 32, 4 * MIB},
          {256, 2048, 16384, MIB},
          {1, 1ms, 1000ms}};
}
auto Layout(const NodeStorageOptions &o) -> BootstrapLayout {
  return {o.identity_,
          8 * MIB,
          {Range(2 * MIB, MIB),
           Range(JOURNAL_START, 64ULL * o.journal_.unit_bytes_),
           Range(6 * MIB, 2 * MIB)}};
}
bool Has(const NodeStorageView &v, NodeStorageCondition c) {
  return (v.conditions_ & static_cast<uint32_t>(c)) != 0;
}
template <class Action>
void ExpectNotReady(Action action, const char *reason) {
  try {
    action();
    ADD_FAILURE() << reason;
  } catch (const MetadataError &error) {
    EXPECT_EQ(error.Code(), MetadataErrorCode::NotReady) << reason;
  }
}
void Check(const MetadataSnapshot &view, const Model &model) {
  const auto rows = view.Scan({0, 0, 0}, model.size() + 1);
  ASSERT_EQ(rows.size(), model.size());
  size_t n = 0;
  for (const auto &[key, value] : model) {
    const auto &row = rows[n++];
    EXPECT_EQ(
        std::make_tuple(row.key_.category_, row.key_.owner_, row.key_.item_),
        key);
    EXPECT_EQ(row.value_, value);
    EXPECT_EQ(view.Get(row.key_), std::optional<Bytes>(value));
  }
}
void Put(NodeStorage &node, uint64_t id, size_t size, unsigned seed,
         Model &model) {
  const auto key = Key(id);
  const auto value = Value(size, seed);
  auto r = node.Commit(node.Read(), {{key, value}});
  ASSERT_EQ(r.outcome_, JournalOutcome::Durable);
  ASSERT_FALSE(r.error_);
  model[{key.category_, key.owner_, key.item_}] = value;
}
void Seed(NodeStorage &node, const NodeStorageOptions &o, Model &model) {
  node.Create(Layout(o));
  Put(node, 7, 9013, 31, model);
  Put(node, 9, 47, 3, model);
  ASSERT_EQ(node.Checkpoint(8).outcome_, MetadataCheckpointOutcome::Durable);
  node.Close();
}
auto DamageOldBootstrap(const Image &image) -> uint64_t {
  auto a = image.Read(0, 65536), b = image.Read(MIB, 65536);
  const auto offset = BE(a, 112, 8) < BE(b, 112, 8) ? 0 : MIB;
  auto &bytes = offset == 0 ? a : b;
  bytes[0] ^= 0x40;
  image.Write(offset, bytes);
  return offset;
}
bool WaitPhase(const NodeStorage &node, NodeStoragePhase phase) {
  const auto end = std::chrono::steady_clock::now() + 10s;
  while (std::chrono::steady_clock::now() < end) {
    if (node.State().phase_ == phase)
      return true;
    std::this_thread::yield();
  }
  return false;
}
TEST(F34Lifecycle, RealRecoveryPublishesOnlyCompleteMetadata) {
  Image image;
  auto o = Options(image);
  NodeStorage node(o);
  Model model;
  Seed(node, o, model);
  const auto previous_generation = node.State().generation_;
  Arm(Point::Read, JOURNAL_START);
  std::future<void> opening;
  ReleaseOnExit release;
  opening = std::async(std::launch::async, [&] { node.Open(); });
  ASSERT_TRUE(WaitEntered());
  const auto state = node.State();
  EXPECT_EQ(state.phase_, NodeStoragePhase::Recovering);
  EXPECT_FALSE(state.metadata_read_);
  EXPECT_FALSE(state.metadata_write_);
  ExpectNotReady([&] { node.Read(); }, "non-serving storage must reject reads as NotReady");
  Release();
  opening.get();
  EXPECT_EQ(node.State().phase_, NodeStoragePhase::Serving);
  EXPECT_GT(node.State().generation_, previous_generation);
  Check(node.Read(), model);
  Put(node, 7, 9013, 51, model);
  auto old = node.Read();
  node.Close();
  EXPECT_EQ(node.State().phase_, NodeStoragePhase::Stopped);
  Check(old, model);
  node.Open();
  Check(node.Read(), model);
  node.Close();
}
TEST(F34Lifecycle, InvalidRecoveryDoesNotFormatOrRepairItsBootstrap) {
  Image image;
  auto o = Options(image);
  NodeStorage node(o);
  Model model;
  Seed(node, o, model);
  auto a = image.Read(0, 65536), b = image.Read(MIB, 65536);
  const auto root = BE(BE(a, 112, 8) > BE(b, 112, 8) ? a : b, 120, 8);
  DamageOldBootstrap(image);
  auto unit = image.Read(Physical(root, o.journal_), o.journal_.unit_bytes_);
  unit[100] ^= 0x80;
  image.Write(Physical(root, o.journal_), unit);
  const auto boots = image.Read(0, 2 * MIB);
  EXPECT_THROW(node.Open(), JournalError);
  auto state = node.State();
  EXPECT_EQ(state.phase_, NodeStoragePhase::Failed);
  EXPECT_TRUE(Has(state, NodeStorageCondition::RecoveryFailed));
  EXPECT_FALSE(state.metadata_read_);
  EXPECT_FALSE(state.metadata_write_);
  ExpectNotReady([&] { node.Read(); }, "non-serving storage must reject reads as NotReady");
  EXPECT_EQ(image.Read(0, 2 * MIB), boots);
  node.Close();
  EXPECT_EQ(node.State().phase_, NodeStoragePhase::Stopped);
}
TEST(F34Lifecycle, CloseCancelsLateRecoveryAndDrainsItsIO) {
  for (bool close_failure : {false, true}) {
    SCOPED_TRACE(close_failure ? "device close error during cancellation"
                               : "normal cancellation");
    Image image;
    auto o = Options(image);
    NodeStorage node(o);
    Model model;
    Seed(node, o, model);
    DamageOldBootstrap(image);
    const auto boots = image.Read(0, 2 * MIB);
    Arm(Point::Read, JOURNAL_START);
    std::future<void> opening, closing;
    ReleaseOnExit release;
    opening = std::async(std::launch::async, [&] { node.Open(); });
    ASSERT_TRUE(WaitEntered());
    closing = std::async(std::launch::async, [&] { node.Close(); });
    const auto deadline = std::chrono::steady_clock::now() + 10s;
    while (node.State().phase_ != NodeStoragePhase::Draining &&
           closing.wait_for(0ms) != std::future_status::ready &&
           std::chrono::steady_clock::now() < deadline) {
      std::this_thread::yield();
    }
    ASSERT_NE(closing.wait_for(0ms), std::future_status::ready)
        << "Close must drain startup IO";
    const auto observed = node.State().phase_;
    ASSERT_NE(observed, NodeStoragePhase::Stopped)
        << "Close must drain startup IO";
    ASSERT_EQ(observed, NodeStoragePhase::Draining)
        << "drain event watchdog";
    EXPECT_FALSE(node.State().metadata_read_);
    EXPECT_EQ(closing.wait_for(100ms), std::future_status::timeout)
        << "Close must drain startup IO";
    {
      std::lock_guard<std::mutex> lock(gate_mutex);
      fail_close = close_failure;
    }
    Release();
    ExpectNotReady([&] { opening.get(); }, "cancelled startup cannot publish success");
    if (close_failure) {
      EXPECT_THROW(closing.get(), std::system_error)
          << "partial startup cleanup must report close error";
      EXPECT_TRUE(Has(node.State(), NodeStorageCondition::IOFault));
      EXPECT_TRUE(node.State().error_);
    } else {
      closing.get();
      EXPECT_FALSE(node.State().error_);
    }
    EXPECT_EQ(node.State().phase_, NodeStoragePhase::Stopped);
    EXPECT_FALSE(Has(node.State(), NodeStorageCondition::RecoveryFailed))
        << "intentional shutdown is not recovery failure";
    EXPECT_EQ(image.Read(0, 2 * MIB), boots)
        << "cancelled recovery must not start repair";
    node.Open();
    Check(node.Read(), model);
    node.Close();
  }
}
TEST(F34Lifecycle, CheckpointCloseDrainsAndRejectsNewCalls) {
  for (bool fail : {false, true}) {
    SCOPED_TRACE(fail ? "Flush fails while draining"
                      : "Flush succeeds while draining");
    Image image;
    auto o = Options(image);
    NodeStorage node(o);
    Model model;
    node.Create(Layout(o));
    Put(node, 7, 9013, 14, model);
    auto view = node.Read();
    Arm(Point::JournalFlush, 0, fail);
    std::future<MetadataCheckpointResult> checkpoint;
    std::future<void> closing;
    ReleaseOnExit release;
    checkpoint =
        std::async(std::launch::async, [&] { return node.Checkpoint(8); });
    ASSERT_TRUE(WaitEntered());
    closing = std::async(std::launch::async, [&] { node.Close(); });
    ASSERT_TRUE(WaitPhase(node, NodeStoragePhase::Draining));
    ExpectNotReady([&] { node.Read(); }, "Draining must close admission");
    EXPECT_FALSE(node.State().metadata_maintenance_);
    EXPECT_EQ(checkpoint.wait_for(0ms), std::future_status::timeout);
    EXPECT_EQ(closing.wait_for(100ms), std::future_status::timeout);
    Check(view, model);
    Release();
    const auto result = checkpoint.get();
    closing.get();
    EXPECT_EQ(node.State().phase_, NodeStoragePhase::Stopped);
    if (fail) {
      EXPECT_NE(result.outcome_, MetadataCheckpointOutcome::Durable);
      ASSERT_TRUE(result.error_);
      EXPECT_TRUE(Has(node.State(), NodeStorageCondition::IOFault))
          << "draining must retain the IO fault";
      EXPECT_EQ(node.State().error_, result.error_);
    } else {
      EXPECT_EQ(result.outcome_, MetadataCheckpointOutcome::Durable);
      EXPECT_FALSE(Has(node.State(), NodeStorageCondition::IOFault));
    }
    node.Open();
    Check(node.Read(), model);
    Check(view, model);
    node.Close();
  }
}
TEST(F34Lifecycle, RepairIsIndependentAndFailureConditionsRemainVisible) {
  Image image;
  auto o = Options(image);
  NodeStorage node(o);
  Model model;
  Seed(node, o, model);
  const auto damaged = DamageOldBootstrap(image);
  Arm(Point::Write, damaged, true);
  // Open must not wait for this repair write. A runner watchdog catches a
  // blocking implementation; watchdogs are not counted as mutation detections.
  std::future<void> closing;
  ReleaseOnExit release;
  node.Open();
  ASSERT_TRUE(WaitEntered());
  auto state = node.State();
  EXPECT_EQ(state.phase_, NodeStoragePhase::Serving);
  EXPECT_TRUE(state.metadata_read_);
  EXPECT_TRUE(state.metadata_write_);
  EXPECT_TRUE(Has(state, NodeStorageCondition::BootstrapRedundancyLost));
  Check(node.Read(), model);
  bool full = false;
  for (unsigned i = 0; i < 100; ++i) {
    try {
      Put(node, 7, 9013, i, model);
    } catch (const MetadataError &e) {
      ASSERT_EQ(e.Code(), MetadataErrorCode::ResourceUnavailable);
      full = true;
      break;
    }
  }
  ASSERT_TRUE(full);
  state = node.State();
  EXPECT_TRUE(Has(state, NodeStorageCondition::ResourcePressure));
  EXPECT_TRUE(state.metadata_maintenance_);
  auto old = node.Read();
  {
    std::lock_guard<std::mutex> lock(gate_mutex);
    fail_flush = true;
    failure_seen = false;
  }
  auto result = node.Checkpoint(8);
  ASSERT_NE(result.outcome_, MetadataCheckpointOutcome::Durable);
  ASSERT_TRUE(result.error_);
  {
    std::lock_guard<std::mutex> lock(gate_mutex);
    EXPECT_TRUE(failure_seen);
  }
  state = node.State();
  EXPECT_EQ(state.phase_, NodeStoragePhase::Failed);
  EXPECT_TRUE(Has(state, NodeStorageCondition::IOFault));
  EXPECT_TRUE(Has(state, NodeStorageCondition::ResourcePressure));
  EXPECT_TRUE(Has(state, NodeStorageCondition::BootstrapRedundancyLost));
  EXPECT_EQ(state.primary_condition_, NodeStorageCondition::IOFault);
  EXPECT_EQ(state.error_, result.error_);
  EXPECT_FALSE(state.metadata_read_);
  EXPECT_FALSE(state.metadata_write_);
  ExpectNotReady([&] { node.Read(); }, "non-serving storage must reject reads as NotReady");
  Check(old, model);
  closing = std::async(std::launch::async, [&] { node.Close(); });
  ASSERT_TRUE(WaitPhase(node, NodeStoragePhase::Draining));
  EXPECT_EQ(closing.wait_for(100ms), std::future_status::timeout)
      << "Close must drain the accepted repair write";
  // No State polling after release: Close itself must retain the final facts.
  Release();
  closing.get();
  state = node.State();
  EXPECT_EQ(state.phase_, NodeStoragePhase::Stopped);
  EXPECT_EQ(state.error_, result.error_);
  EXPECT_TRUE(Has(state, NodeStorageCondition::IOFault));
  EXPECT_TRUE(Has(state, NodeStorageCondition::BootstrapRedundancyLost));
  ASSERT_TRUE(state.repair_error_) << "Close must retain the final repair error";
  try {
    std::rethrow_exception(state.repair_error_);
  } catch (const std::system_error &error) {
    EXPECT_EQ(error.code().value(), EIO);
  }
  node.Open();
  Check(node.Read(), model);
  node.Close();
}
} // namespace
