# F34 本地生命周期测试恢复

本包是阶段验证归档，未注册为永久测试 target。它验证正式 NodeStorage/B/Journal/Direct 文件调用链；不表示 SQL/Raft 新后端、裸设备、真实掉电或性能已经验证。

## 前提与恢复

- Linux、支持可查询 Direct IO 对齐的普通文件存储；Clang 14、CMake、Python 3（tarfile 支持 data 过滤器）、GCC、项目构建依赖。
- 使用完整仓库历史：本次生产基准 c004052；旧格式生成器还会从 git 读取 cce998a 的生产源码。不要以手写旧格式替代该兼容输入。
- 历史重现可在隔离 checkout 检出 c004052，覆盖 F34-results.tar.gz 的 source/ 三份生产文件。之后按 MANIFEST.json 校验；未来代码有意改动时先重新评估适配，不能跳过漂移检查后把新结果算作原结果。
- 保留仓库内未修改的 test/archives/S5-journal-recycling.tar.gz，哈希见本包 MANIFEST。运行脚本复用其 fixture、独立输入模型、原八项回归与旧生产生成器；没有复制一份 oracle。
- 在仓库外解压本包。脚本的 --repo 指实际仓库；--work 指新的仓库外临时目录。构建约 1 GiB，设备输入每例 8 MiB，采用 -j3；极端主机负载可触发 watchdog，须分析原因而非当性能结果。

```bash
python3 /tmp/F34-node-lifecycle/tests/run_stage.py --repo /path/to/repo --work /tmp/f34-recheck --mutations
```

脚本先校验生产/依赖哈希，构建真实生产库，运行五项 F34 和八项 S5 集成，再在临时目录编译十个单点改坏版本。变异只有编译成功、测试以断言失败退出且命中指定 oracle 才算检出；编译失败、sanitizer 崩溃、watchdog 超时不计。ASan/UBSan 和固定输入启用，测试系统调用包装只存在于临时测试二进制。

S5 的原完整 runner 校验旧阶段 CMake 哈希，并运行其他模块的完整矩阵；本轮使用 F34 当前生产哈希及 S5 原 build_checks.py，仅复验八项直接相关场景，未修改原 S5 包。

## 审查与退出

核对 lifecycle.xml（5）、s5.xml（8）、mutations.json（10）、各次命令及日志，不仅看 summary。完整目标、输入、production 路径、独立 oracle、污染、重复、变异和稳定性审查在 docs/storage_redesign/f34_execution_20260930.md。

验证后先归档证据再删除临时源码、build、变异和设备文件。不能将这些测试直接登记成主线 C/P；S8/S9 真实节点接入时沿用场景与输入模型、替换正式驱动，消除重复验证。

2026-09-30 再次审查版本：Close 保存最终修复结果；测试明确要求 NotReady，提前 Stopped 与函数提前返回属于同一实际故障，watchdog 单独分类。旧同模块包已替换，最新生产/测试哈希以本包 MANIFEST 为准。
