#!/usr/bin/env python3
"""Reuse course and S8 cases; only adapt S8's fixture to the already-shipped object page deployment."""
import argparse,pathlib,subprocess,os,tarfile,json,time,xml.etree.ElementTree as ET
p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--build',required=True);p.add_argument('--out',required=True)
a=p.parse_args();repo=pathlib.Path(a.repo).resolve();build=pathlib.Path(a.build).resolve();out=pathlib.Path(a.out).resolve();out.mkdir(parents=True,exist_ok=False)
env={k:v for k,v in os.environ.items() if not k.startswith('GTEST_')};env.update(S5_WORKDIR=str(out),ASAN_OPTIONS='detect_leaks=1:abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
commands=[]
def run(cmd,name,timeout=240):
 t=time.monotonic()
 with (out/(name+'.log')).open('w') as f:r=subprocess.run(list(map(str,cmd)),cwd=out,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
 commands.append(dict(command=list(map(str,cmd)),exit=r.returncode,seconds=time.monotonic()-t));(out/'commands.json').write_text(json.dumps(commands,indent=2))
 if r.returncode:raise RuntimeError((name,r.returncode))
def check(name,count):
 cases=ET.parse(out/(name+'.xml')).getroot().findall('.//testcase')
 assert len(cases)==count and all(c.attrib.get('status')=='run' and c.find('skipped') is None and c.find('failure') is None for c in cases)
for name,count in [('txn_executor_test',11),('buffer_pool_manager_test',7),('page_guard_test',2),('hnsw_index_test',7),('ivfflat_index_test',13)]:
 run([build/'test'/name,'--gtest_output=xml:'+str(out/(name+'.xml'))],name);check(name,count)
for n in ['S5-journal-recycling','S8-raft-object-stores']:
 with tarfile.open(repo/f'test/archives/{n}.tar.gz') as t:t.extractall(out,filter='data')
s=(out/'S8-raft-object-stores/tests/object_stores_test.cpp').read_text()
for old,new,count in [
 ('ObjectTransactionOptions{32, 128, MIB, 8 * MIB, 2ms, 10ms}};','ObjectTransactionOptions{32, 128, MIB, 8 * MIB, 2ms, 10ms}, 2 * MIB};',1),
 ('RaftObjectDeployment{h.options, h.space, Limits()}','RaftObjectDeployment{h.options, h.space, Limits(), PageCacheDeployment{4U, BufferPoolOptions{8*MIB, 2*MIB, 32, false, 3}}}',1),
 ('BusTubRaftStateMachine::Open(directory.get(), files, 64)','BusTubRaftStateMachine::OpenObjectPages(directory.get(), files, 64, {h.node, {4, {h.space, 5}}, {8*MIB,2*MIB,32,false,3}})',2)]:
 assert s.count(old)==count,(old,s.count(old));s=s.replace(old,new)
adapted=out/'s8-adapted.cpp';adapted.write_text(s)
flags=['clang++-14','-std=c++17','-pthread','-g','-O0','-Wall','-Wextra','-Werror','-Wno-unused-parameter','-Wno-attributes','-fsanitize=address,undefined','-fno-omit-frame-pointer','-fno-pie']
flags+=['-I'+str(x) for x in [repo/'src/include',repo/'src/buffer',repo/'src/storage/disk',repo/'src/raft',repo/'third_party',repo/'third_party/libfort/src',repo/'third_party/fmt/include',repo/'third_party/googletest/googletest/include',out/'S5-journal-recycling/test/storage_redesign']]
libs=[build/'lib'/('lib'+n+'.a') for n in ['bustub','bustub_murmur3','duckdb_pg_query','fmtd','fort','gmock_main','gmock','gtest']]
run(flags+['-c',adapted,'-o',out/'s8.o'],'s8-compile')
run(flags+['-no-pie',out/'s8.o']+libs+['-Wl,--wrap=pwrite','-Wl,--wrap=fdatasync','-o',out/'s8'],'s8-link')
run([out/'s8','--gtest_output=xml:'+str(out/'s8.xml')],'s8');check('s8',8)
(out/'summary.json').write_text(json.dumps(dict(course=20,vector_regressions=20,s8=8),indent=2))
