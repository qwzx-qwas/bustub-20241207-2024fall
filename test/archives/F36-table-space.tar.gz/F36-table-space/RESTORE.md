# F36 / S9.2 阶段验证（仅归档）

基准 `e10acbf` + 当前结果包 `source/` 文件。本包只含最终测试版本，不放入 CMake/CTest 常驻发现。

1. 将本包解压到仓库外独立目录。核对 MANIFEST 的生产/测试/依赖 SHA-256。
2. 使用 Clang 14、C++17、Debug、ASan+UBSan：

```sh
cmake -S /path/to/repo -B /tmp/f36-build -DCMAKE_BUILD_TYPE=Debug -DCMAKE_C_COMPILER=clang-14 -DCMAKE_CXX_COMPILER=clang++-14 -DBUSTUB_SANITIZER=address,undefined -DCMAKE_EXE_LINKER_FLAGS=-no-pie
cmake --build /tmp/f36-build --target bustub txn_executor_test buffer_pool_manager_test page_guard_test hnsw_index_test ivfflat_index_test -j2
python3 /path/to/F36-table-space/run_stage.py --repo /path/to/repo --build /tmp/f36-build --out /tmp/f36-stage --mutations
python3 /path/to/F36-table-space/run_regressions.py --repo /path/to/repo --build /tmp/f36-build --out /tmp/f36-regressions
```

输出目录必须尚不存在。允许本地 TCP，且 LeakSanitizer 不能运行于 ptrace 环境；不要关闭检查后冒充同等验证。本轮编译/运行总临时空间约 3 GiB，建议预留 4 GiB，本轮 `-j2`；Direct 文件夹具要求设备对齐能够承载数据库页，不满足应报告环境限制。

`run_stage.py` 原样 include F26 页/SQL 九项，并新增 F36 六项；依赖 S5 fixture。`run_regressions.py` 复用课程 20 项、既有向量索引 20 项及 S8 八项，只将后者的既有部署配置适配为 S9.1c 真实对象页；S8 输入与断言不改；旧 IVFFlat 重建计数用例已删除，其正确性责任由新的真实 SQL 旧读者/物理退休场景接管，不再约束内部重建次数。新测试的 Raft 场景显式使用 S8 事务额度，不修改生产默认值。

风险归属：F36/tuple-reuse、scan-lifetime、historical-index、mvcc-horizon、raft-turnover。S9.3/S11/S12/S13 后续沿用这些业务内容与独立预期，适配路径后先审覆盖再去重。真实文件/状态机恢复不是物理掉电或完整性能基线；新 Raft 场景不是三节点 E2E，原 S8 有实际三节点 TCP 回归。

完整测试设计、接口污染、稳定性、变异与剩余限制：`docs/storage_redesign/s92_execution_20261005.md`。

本机 Clang 14 的 ASan PIE 测试曾在 main 之前的初始化 mmap 崩溃（诊断栈见结果）；隔离构建显式使用非 PIE 链接，Sanitizer 全部保留，不改仓库生产默认配置。运行脚本不自动重试失败用例。

三次审查另加过滤后多轮候选的真实 SQL 场景，防止重建重新编号使合法结果被去重跳过。14 个指定变异中包含将编号重置回 1；不以 getter 观测内部重建次数。

四次审查增强原多轮 SQL 测试：空表建 IVF 后插入，GC 后查询中途从单桶变多桶，执行器需更新搜索上限。没有新增用例；测试不直接断言桶数。并发安全来自 GetMaxAnnSearchBudget 与重建使用同一已有锁的代码审查，本轮不以 ASan 充当 TSan 证据。

查询内保留已经观察到的最大搜索上限：增长要跟进，缩小也不能让上一轮未完成的搜索直接终止。Raft 向量回归补充索引类型的失败定位信息。
