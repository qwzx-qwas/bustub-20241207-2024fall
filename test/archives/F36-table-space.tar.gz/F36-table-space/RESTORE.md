# F36 / S9.3 阶段验证（仅归档）

基准 `991ced7` 加本轮结果包 source 快照。本包替换 S9.2 包，含最终 9 项 F36 场景，不注册常驻 CTest。

1. 在仓库外展开本包，核对 MANIFEST 的生产、测试和依赖 SHA-256。
2. Clang 14 / C++17 / Debug / ASan + UBSan + LeakSanitizer，显式非 PIE（沿用此前本机检测器初始化兼容方案）：

```sh
cmake -S /path/to/repo -B /tmp/f36-build -DCMAKE_BUILD_TYPE=Debug -DCMAKE_C_COMPILER=clang-14 -DCMAKE_CXX_COMPILER=clang++-14 -DBUSTUB_SANITIZER=address,undefined -DCMAKE_EXE_LINKER_FLAGS=-no-pie
cmake --build /tmp/f36-build --target bustub txn_executor_test buffer_pool_manager_test page_guard_test hnsw_index_test ivfflat_index_test -j2
python3 /path/to/F36-table-space/run_stage.py --repo /path/to/repo --build /tmp/f36-build --out /tmp/f36-stage --mutations
python3 /path/to/F36-table-space/run_regressions.py --repo /path/to/repo --build /tmp/f36-build --out /tmp/f36-regressions
```

输出目录必须尚不存在。允许本机 TCP；LeakSanitizer 不在 ptrace 沙箱内运行。不关闭 sanitizer 或重试失败来制造通过。临时空间预留约 4 GiB，使用 -j2。Direct 文件夹具要求设备对齐能够承载当前数据库页，否则报告环境限制，不静默绕过。

run_stage 复用 F26 页/SQL 九项，F36 保留 S9.2 六项并补三项退役场景。原 SQL 270 行周转适配新合同：空表保留首页、旧页号拒绝、后续页号单调及完整业务行正确；物理复用由真实新对象写入的范围交叠证明，不能以 page_id 推断。run_regressions 复用课程 20、向量索引 20、S8 八项；仅适配 S8 部署到已实现的对象页路径，业务输入与 oracle 不变。共同 C/P 内容不变且不在此 runner 中重新执行。

19 个定向变异：18 个要求指定用例的断言失败。ignore-page-pins 要求先出现持有读者时映射被错误释放的断言，再由 production double-unpin 不变量终止（SIGABRT）；必须同时匹配两项证据。编译错误、超时、检测器启动失败均不能计为检出。禁用 core 文件只为清理中间产物，不改变 production 的不变量检查。

风险登记：F36/tuple-reuse、scan-lifetime、historical-index、mvcc-horizon、raft-turnover、empty-page-unlink、page-identity-retirement、durable-handoff、physical-reuse。原小场景由后续共同 E2E 接管时逐风险去重；不能因后续路径理论上更长就直接删除保护。

具体输入、路径、oracle、失败含义、生产接口审查、变异和稳定性见 docs/storage_redesign/s93_execution_20261005.md。
本轮为 Direct 文件集成及复用 TCP 回归，故障位于系统调用边界；不是裸设备/物理掉电、TSan 或完整性能比较。忙页依赖后续显式 GC/相关 Apply 的有界维护，周期调度 S12、共享快照 S11 尚未实施。
