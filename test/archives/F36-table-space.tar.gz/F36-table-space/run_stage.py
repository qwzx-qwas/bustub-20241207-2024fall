#!/usr/bin/env python3
"""Temporary F36 integration runner. Restores archived dependencies outside the repository."""
import argparse, pathlib, subprocess, tarfile, os, json, time, hashlib
import xml.etree.ElementTree as ET
import resource
resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--build',required=True);p.add_argument('--out',required=True);p.add_argument('--mutations',action='store_true')
a=p.parse_args();repo=pathlib.Path(a.repo).resolve();build=pathlib.Path(a.build).resolve();out=pathlib.Path(a.out).resolve();pkg=pathlib.Path(__file__).resolve().parent
out.mkdir(parents=True,exist_ok=False)
if (pkg/'MANIFEST.json').exists():
 m=json.loads((pkg/'MANIFEST.json').read_text())
 for base,key in [(repo,'production_sha256'),(repo,'dependency_sha256'),(pkg,'test_sha256')]:
  for f,d in m[key].items():
   if hashlib.sha256((base/f).read_bytes()).hexdigest()!=d:raise SystemExit('source mismatch: '+str(base/f))
for n in ['S5-journal-recycling','F26-array-buffer-pool']:
 with tarfile.open(repo/f'test/archives/{n}.tar.gz') as t:t.extractall(out,filter='data')
flags=['clang++-14','-std=c++17','-pthread','-g','-O0','-Wall','-Wextra','-Werror','-Wno-unused-parameter','-Wno-attributes','-fsanitize=address,undefined','-fno-omit-frame-pointer','-fno-pie']
flags+=['-I'+str(x) for x in [repo/'src/include',repo/'src/buffer',repo/'src/storage/disk',repo/'src/raft',repo/'third_party',repo/'third_party/libfort/src',repo/'third_party/fmt/include',repo/'third_party/googletest/googletest/include',out/'S5-journal-recycling/test/storage_redesign',out/'F26-array-buffer-pool/tests']]
libs=[build/'lib'/('lib'+n+'.a') for n in ['bustub','bustub_murmur3','duckdb_pg_query','fmtd','fort','gmock_main','gmock','gtest']]
wrap=['-Wl,--wrap=pread','-Wl,--wrap=pwrite','-Wl,--wrap=fdatasync','-Wl,--wrap=madvise']
env={k:v for k,v in os.environ.items() if not k.startswith('GTEST_')};env.update(S5_WORKDIR=str(out),ASAN_OPTIONS='detect_leaks=1:abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
commands=[]
def run(cmd,name,expected=0,timeout=300):
 start=time.monotonic()
 with (out/(name+'.log')).open('w') as f:r=subprocess.run(list(map(str,cmd)),cwd=out,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
 commands.append(dict(command=list(map(str,cmd)),exit=r.returncode,seconds=time.monotonic()-start));(out/'commands.json').write_text(json.dumps(commands,indent=2))
 if r.returncode!=expected:raise RuntimeError((name,r.returncode,expected))
def check(name,count,fail=False):
 cases=ET.parse(out/(name+'.xml')).getroot().findall('.//testcase')
 assert len(cases)==count and all(c.attrib.get('status')=='run' and c.find('skipped') is None for c in cases)
 assert sum(c.find('failure') is not None for c in cases)==int(fail)
run(flags+['-c',pkg/'tests/table_space_test.cpp','-o',out/'stage.o'],'compile')
run(flags+['-no-pie',out/'stage.o']+libs+wrap+['-o',out/'stage'],'link')
run([out/'stage','--gtest_output=xml:'+str(out/'stage.xml')],'stage');check('stage',18)
if a.mutations:
 mutations=[
  ('ignore-page-pins','buffer/buffer_pool_manager.cpp','f.pins_ != 1 || f.io_','false || f.io_','ScansPinsAndPrefetchProtectRetiringPages'),
  ('skip-range-unmap','storage/disk/object_mapping.cpp','Cut(base.base_, key, op.offset_, End(op.offset_, op.length_), d, changes);','/* broken: retired page remains mapped */','EmptyPagesPreserveNeighborsAndReusePhysicalSpace'),
  ('resurrect-retired-page','buffer/page_storage.cpp','if (storage_->Objects().Control({space_, 0}, uint64_t{static_cast<uint32_t>(page)} + 1)) {','if (false) {','EmptyPagesPreserveNeighborsAndReusePhysicalSpace'),
  ('skip-pending-open','buffer/page_storage.cpp','while (!impl->pending_pages_.empty()) {','while (false) {','RetirementFailuresRecoverOldChainOrFinishDurableHandoff'),
  ('ignore-table-scan','storage/table/table_heap.cpp','if (active_iterators_ != 0) {\n    return;','if (false) {\n    return;','ScansPinsAndPrefetchProtectRetiringPages'),
  ('lose-survivor-offset','storage/page/table_page.cpp','replacement->TupleInfoAt(i) = std::make_tuple(end, size, meta);','replacement->TupleInfoAt(i) = std::make_tuple(offset, size, meta);','CompactionPreservesRidsScanBoundaryAndReopenReuse'),
  ('forget-open-free-space','storage/table/table_heap.cpp','heap->free_pages_.emplace(page->GetFreeSpace(), page_id);','/* broken: lost reclaimed page hints on Open */','CompactionPreservesRidsScanBoundaryAndReopenReuse'),
  ('reuse-during-scan','storage/table/table_heap.cpp','const bool reuse = active_iterators_ == 0;','const bool reuse = true;','CompactionPreservesRidsScanBoundaryAndReopenReuse'),
  ('reclaim-active-transaction','concurrency/transaction_manager.cpp','if (txn->state_ == TransactionState::RUNNING || txn->state_ == TransactionState::TAINTED) {\n      return;','if (txn->state_ == TransactionState::RUNNING || txn->state_ == TransactionState::TAINTED) {\n      /* broken: ignore active RID owners */','MvccRetainsOldReadersThenRetiresEveryHistoricalIndexKey'),
  ('skip-historical-index-retirement','concurrency/transaction_manager.cpp','index->index_->DeleteObsoleteEntries(keys);','/* broken: old index keys survive reuse */','MvccRetainsOldReadersThenRetiresEveryHistoricalIndexKey'),
  ('drop-serializable-evidence','concurrency/transaction_manager.cpp','txn->commit_ts_ <= oldest_serializable','true','GcKeepsSerializablePhantomConflictEvidence'),
  ('freeze-search-budget','execution/vector_index_scan_executor.cpp','index_info_->index_->GetMaxAnnSearchBudget().value_or(max_search_budget)','max_search_budget','IvfRebuildPreservesFilteredMultiRoundQuery'),
  ('skip-raft-vector-retirement','distributed/bustub_state_machine.cpp','index->index_->DeleteObsoleteEntries({{key, rid}});','index->index_->DeleteEntry(key, rid, nullptr);','RaftTurnoverKeepsHeapBoundedAndSnapshotSuffixRestores'),
  ('skip-raft-reclamation','distributed/bustub_state_machine.cpp','row->table_->table_->ReclaimTuples({row->rid_});','/* broken: deleted body is never reclaimed */','RaftTurnoverKeepsHeapBoundedAndSnapshotSuffixRestores'),
 ]
 results=[]
 for name,file,old,new,test in mutations:
  s=(repo/'src'/file).read_text();assert s.count(old)==(2 if name=='skip-raft-reclamation' else 1),(name,'anchor')
  path=out/(name+'.cpp');path.write_text(s.replace(old,new))
  run(flags+['-c',path,'-o',out/(name+'.o')],name+'-compile')
  run(flags+['-no-pie',out/'stage.o',out/(name+'.o')]+libs+wrap+['-o',out/name],name+'-link')
  run([out/name,'--gtest_filter=F36.'+test,'--gtest_output=xml:'+str(out/(name+'.xml'))],name,expected=(-6 if name=='ignore-page-pins' else 1))
  if name=='ignore-page-pins':
   log=(out/(name+'.log')).read_text()
   assert 'PageMapping(h,victim).spans_.front().data_' in log.replace(' ', '') and 'Expected: true' in log and 'terminate called' in log
   results.append(dict(mutation=name,test=test,result='mapping assertion followed by production double-unpin termination'))
  else:
   check(name,1,True);results.append(dict(mutation=name,test=test,result='assertion failure'))
 # Header templates need explicit instantiation before the normal objects so
 # the executable uses the changed production method, not another weak copy.
 for suffix,kind,klass,old,new in [
  ('hnsw-physical-retirement','hnsw','HNSWIndex','node.is_retired_ = true;','node.is_retired_ = false;'),
  ('ivfflat-physical-retirement','ivfflat','IVFFlatIndex','entry.is_retired_ = true;','entry.is_retired_ = false;'),
  ('ivfflat-history-protection','ivfflat','IVFFlatIndex','retired_entry_count_ != stale_entry_count_','false'),
  ('ivfflat-candidate-identity','ivfflat','IVFFlatIndex','artifacts.next_entry_id_ = next_entry_id_;','artifacts.next_entry_id_ = 1;'),
 ]:
  name='skip-'+suffix
  root=out/name;header=root/'storage/index'/ (kind+'_index.h');header.parent.mkdir(parents=True)
  source=(repo/'src/include/storage/index'/(kind+'_index.h')).read_text();assert source.count(old)==1
  header.write_text(source.replace(old,new))
  cpp=root/'instantiate.cpp'
  cpp.write_text('#include "storage/index/'+kind+'_index.h"\n#include "storage/index/int_comparator.h"\ntemplate class bustub::'+klass+'<bustub::Tuple, bustub::RID, bustub::IntComparator>;\n')
  obj=root/'mutant.o';binary=root/'mutant'
  run(flags[:1]+['-I'+str(root)]+flags[1:]+['-c',cpp,'-o',obj],name+'-compile')
  run(flags+['-no-pie',obj,out/'stage.o']+libs+wrap+['-o',binary],name+'-link')
  test=('IvfRebuildPreservesFilteredMultiRoundQuery' if suffix=='ivfflat-candidate-identity'
        else 'VectorRetirementPreservesOldReadersAndStopsVacantRidCandidates')
  run([binary,'--gtest_filter=F36.'+test,'--gtest_output=xml:'+str(out/(name+'.xml'))],name,expected=1)
  check(name,1,True);results.append(dict(mutation=name,test=test,result='test assertion failure'))
 name='missing-vector-null'
 root=out/name;header=root/'type/value_factory.h';header.parent.mkdir(parents=True)
 source=(repo/'src/include/type/value_factory.h').read_text()
 old='      case TypeId::VECTOR:\n        ret_value = Value(TypeId::VECTOR, nullptr, 0, false);\n        break;\n'
 assert source.count(old)==1;header.write_text(source.replace(old,''))
 obj=root/'mutant.o';binary=root/'mutant'
 run(flags[:1]+['-I'+str(root)]+flags[1:]+['-c',repo/'src/execution/execution_common.cpp','-o',obj],name+'-compile')
 run(flags+['-no-pie',obj,out/'stage.o']+libs+wrap+['-o',binary],name+'-link')
 test='VectorRetirementPreservesOldReadersAndStopsVacantRidCandidates'
 run([binary,'--gtest_filter=F36.'+test,'--gtest_output=xml:'+str(out/(name+'.xml'))],name,expected=1)
 check(name,1,True);results.append(dict(mutation=name,test=test,result='test failure'))
 (out/'mutations.json').write_text(json.dumps(results,indent=2))
(out/'summary.json').write_text(json.dumps(dict(stage='S9.3',f36=9,f26_reused=9,mutations=a.mutations),indent=2))
