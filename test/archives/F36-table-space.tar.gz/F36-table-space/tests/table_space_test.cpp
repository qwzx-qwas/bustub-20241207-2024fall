// Reuse the archived F26 production fixture and its unchanged regression cases.
#include "distributed/client_protocol.h"
#include "distributed/raft_state_machine.h"
#include "distributed/request_fingerprint.h"
#include "page_io_test.cpp"
#include "raft/log_store.h"
#include "raft/object_storage.h"
#include "raft/persistent_state.h"
#include "raft/snapshot_store.h"
#include "raft/stable_store.h"
#include "type/value_factory.h"
namespace {
using Rows = std::vector<std::vector<std::string>>;
struct SqlDB {
  BusTubInstance db{32};
  explicit SqlDB(Harness &h) {
    db.checkpoint_manager_.reset();
    db.execution_engine_.reset();
    db.catalog_.reset();
    h.cache.reset();
    db.buffer_pool_manager_ =
        std::make_unique<BufferPoolManager>(32, h.backend, h.budget);
    db.buffer_pool_manager_->SetNextPageIdForRecovery(16);
    db.catalog_ = std::make_unique<Catalog>(db.buffer_pool_manager_.get(),
                                            db.lock_manager_.get(),
                                            db.log_manager_.get());
    db.txn_manager_->catalog_ = db.catalog_.get();
    db.execution_engine_ = std::make_unique<ExecutionEngine>(
        db.buffer_pool_manager_.get(), db.txn_manager_.get(),
        db.catalog_.get());
  }
  auto Sql(const std::string &text, Transaction *txn = nullptr) -> Rows {
    StringVectorWriter writer;
    Require(txn ? db.ExecuteSqlTxn(text, writer, txn)
                : db.ExecuteSql(text, writer),
            "SQL execution");
    return writer.values_;
  }
  ~SqlDB() { db.buffer_pool_manager_->Close(); }
};
auto MakeRow(int key, const std::string &body, const Schema &schema) -> Tuple {
  return Tuple(
      {ValueFactory::GetIntegerValue(key), ValueFactory::GetVarcharValue(body)},
      &schema);
}
TEST(F36, CompactionPreservesRidsScanBoundaryAndReopenReuse) {
  Harness h;
  auto heap = std::make_unique<TableHeap>(h.cache.get());
  Schema schema(
      {Column("id", TypeId::INTEGER), Column("body", TypeId::VARCHAR, 800)});
  struct Row {
    RID rid;
    int id;
    std::string body;
  };
  std::vector<Row> rows;
  std::set<page_id_t> pages;
  for (int i = 0; i < 48; ++i) {
    std::string body(257 + (i % 5) * 43, char('a' + i % 23));
    auto rid = heap->InsertTuple({10, false}, MakeRow(i, body, schema));
    ASSERT_TRUE(rid);
    rows.push_back({*rid, i, body});
    pages.insert(rid->GetPageId());
  }
  ASSERT_GE(pages.size(), 3U);
  const auto first = heap->GetFirstPageId();
  std::vector<RID> dead;
  std::map<int, std::string> expected;
  for (const auto &row : rows) {
    if (row.rid.GetPageId() == first || row.id % 3 == 1) {
      heap->UpdateTupleMeta({11, true}, row.rid);
      dead.push_back(row.rid);
    } else {
      expected[row.id] = row.body;
    }
  }
  heap->ReclaimTuples(dead);
  // Surviving addresses, content and version do not change when bodies move.
  for (const auto &row : rows) {
    if (expected.count(row.id)) {
      auto [meta, tuple] = heap->GetTuple(row.rid);
      EXPECT_EQ(meta.ts_, 10);
      ASSERT_EQ(tuple.GetValue(&schema, 0).GetAs<int32_t>(), row.id);
      EXPECT_EQ(tuple.GetValue(&schema, 1).ToString(), row.body);
    }
  }
  {
    auto scan = heap->MakeIterator();
    auto inserted = heap->InsertTuple(
        {12, false}, MakeRow(900, "during-active-scan", schema));
    ASSERT_TRUE(inserted);
    std::map<int, std::string> seen;
    for (; !scan.IsEnd(); ++scan) {
      auto t = scan.GetTuple().second;
      const auto id = t.GetValue(&schema, 0).GetAs<int32_t>();
      EXPECT_TRUE(seen.emplace(id, t.GetValue(&schema, 1).ToString()).second);
    }
    EXPECT_EQ(seen, expected); // must skip the empty first page and never
                               // include the concurrent insertion
  }
  expected[900] = "during-active-scan";
  const auto tail = heap->GetLastPageId();
  h.cache->FlushAllPages();
  heap.reset();
  h.Reopen();
  h.cache->SetNextPageIdForRecovery(tail + 1);
  heap = TableHeap::Open(h.cache.get(), first);
  for (size_t i = 0; i < dead.size(); ++i) {
    const int id = 1000 + i;
    std::string body(157 + (i % 4) * 17, char('A' + i % 20));
    auto rid = heap->InsertTuple({13, false}, MakeRow(id, body, schema));
    ASSERT_TRUE(rid);
    EXPECT_TRUE(pages.count(rid->GetPageId()))
        << "insert failed to reuse an existing page";
    expected[id] = body;
  }
  h.cache->FlushAllPages();
  heap.reset();
  h.Reopen();
  h.cache->SetNextPageIdForRecovery(tail + 1);
  heap = TableHeap::Open(h.cache.get(), first);
  std::map<int, std::string> seen;
  for (auto scan = heap->MakeIterator(); !scan.IsEnd(); ++scan) {
    auto t = scan.GetTuple().second;
    EXPECT_TRUE(seen.emplace(t.GetValue(&schema, 0).GetAs<int32_t>(),
                             t.GetValue(&schema, 1).ToString())
                    .second);
  }
  EXPECT_EQ(seen, expected);
}
TEST(F36, MvccRetainsOldReadersThenRetiresEveryHistoricalIndexKey) {
  Harness h;
  SqlDB s(h);
  s.Sql("CREATE TABLE items(id INT PRIMARY KEY, bucket INT, tag INT);");
  s.Sql("INSERT INTO items VALUES (1,7,17),(2,7,17),(3,8,18);");
  s.Sql("CREATE INDEX buckets ON items(bucket);");
  // A second supported adapter must obey the same retirement contract.
  auto table = s.db.catalog_->GetTable("items");
  Schema tag_schema({Column("tag", TypeId::INTEGER)});
  auto hash =
      s.db.catalog_->CreateIndex<GenericKey<8>, RID, GenericComparator<8>>(
          nullptr, "tags", "items", table->schema_, tag_schema, {2}, 8,
          HashFunction<GenericKey<8>>{}, false, IndexType::HashTableIndex);
  ASSERT_TRUE(hash);
  auto ordered =
      s.db.catalog_->CreateIndex<GenericKey<8>, RID, GenericComparator<8>>(
          nullptr, "ordered_tags", "items", table->schema_, tag_schema, {2}, 8,
          HashFunction<GenericKey<8>>{}, false, IndexType::STLOrderedIndex);
  ASSERT_TRUE(ordered);

  RID retired;
  {
    for (auto it = table->table_->MakeIterator(); !it.IsEnd(); ++it) {
      if (it.GetTuple().second.GetValue(&table->schema_, 0).GetAs<int32_t>() ==
          1) {
        retired = it.GetRID();
      }
    }
  }
  auto *old = s.db.txn_manager_->Begin();
  s.Sql("UPDATE items SET bucket=9,tag=19 WHERE id=1;");
  s.Sql("DELETE FROM items WHERE id=1;");
  s.db.txn_manager_->GarbageCollection();
  EXPECT_EQ(s.Sql("SELECT id,bucket,tag FROM items ORDER BY id;", old),
            (Rows{{"1", "7", "17"}, {"2", "7", "17"}, {"3", "8", "18"}}));
  EXPECT_EQ(s.Sql("SELECT id FROM items WHERE bucket=7 ORDER BY id;", old),
            (Rows{{"1"}, {"2"}}));
  EXPECT_TRUE(s.db.txn_manager_->Commit(old));
  s.db.txn_manager_->GarbageCollection();
  // Check the formal index API too: residual predicates could otherwise hide
  // dangling candidates.
  for (const auto &index : s.db.catalog_->GetTableIndexes("items")) {
    const std::vector<int> keys =
        index->key_attrs_[0] == 0   ? std::vector<int>{1}
        : index->key_attrs_[0] == 1 ? std::vector<int>{7, 9}
                                    : std::vector<int>{17, 19};
    for (int k : keys) {
      std::vector<RID> found;
      index->index_->ScanKey(
          Tuple({ValueFactory::GetIntegerValue(k)}, &index->key_schema_),
          &found, nullptr);
      EXPECT_EQ(std::count(found.begin(), found.end(), retired), 0);
    }
  }
  s.Sql("INSERT INTO items VALUES (44,7,17);");
  EXPECT_EQ(s.Sql("SELECT id FROM items WHERE bucket=7 ORDER BY id;"),
            (Rows{{"2"}, {"44"}}));
  EXPECT_EQ(s.Sql("SELECT id,bucket,tag FROM items ORDER BY id;"),
            (Rows{{"2", "7", "17"}, {"3", "8", "18"}, {"44", "7", "17"}}));
  EXPECT_EQ(table->table_->GetTuple(retired)
                .second.GetValue(&table->schema_, 0)
                .GetAs<int32_t>(),
            44);
  // Exercise more than one reclamation batch without pinning an internal slot
  // order or exact batch count.
  s.Sql("CREATE TABLE turnover(id INT PRIMARY KEY, amount INT);");
  std::string values;
  for (int i = 0; i < 270; ++i) {
    if (i)
      values += ",";
    values += "(" + std::to_string(i) + ",13)";
  }
  s.Sql("INSERT INTO turnover VALUES " + values + ";");
  auto turnover = s.db.catalog_->GetTable("turnover");
  const auto tail = turnover->table_->GetLastPageId();
  s.Sql("DELETE FROM turnover;");
  for (int i = 0; i < 8; ++i)
    s.db.txn_manager_->GarbageCollection();
  s.Sql("INSERT INTO turnover VALUES " + values + ";");
  EXPECT_EQ(turnover->table_->GetLastPageId(), tail);
  EXPECT_EQ(s.Sql("SELECT count(*),sum(amount) FROM turnover;"),
            (Rows{{"270", "3510"}}));
}
TEST(F36, VectorRetirementPreservesOldReadersAndStopsVacantRidCandidates) {
  for (const auto &kind : {std::string("hnsw"), std::string("ivfflat")}) {
    SCOPED_TRACE(kind);
    Harness h;
    SqlDB s(h);
    s.Sql("CREATE TABLE vectors(id INT PRIMARY KEY, v VECTOR(3));");
    s.Sql("INSERT INTO vectors VALUES (1,ARRAY [0.0,0.0,0.0]),"
          "(2,ARRAY [10.0,0.0,0.0]),(3,ARRAY [20.0,0.0,0.0]);");
    s.Sql("CREATE INDEX vi ON vectors USING " + kind + " (v) WITH " +
          (kind == "hnsw" ? "(m=4, ef_search=8);" : "(nlist=2, nprobe=2);"));
    const std::string query = "SELECT id FROM vectors ORDER BY l2_distance(v, "
                              "ARRAY [0.0,0.0,0.0]) LIMIT 10;";
    std::string plan;
    for (const auto &row : s.Sql("EXPLAIN (o) " + query))
      for (const auto &cell : row)
        plan += cell;
    ASSERT_NE(plan.find("VectorIndexScan"), std::string::npos) << plan;
    auto *old = s.db.txn_manager_->Begin();
    s.Sql("UPDATE vectors SET v=ARRAY [1.0,0.0,0.0] WHERE id=1;");
    s.Sql("DELETE FROM vectors WHERE id=1;");
    s.db.txn_manager_->GarbageCollection();
    EXPECT_EQ(s.Sql(query, old), (Rows{{"1"}, {"2"}, {"3"}}));
    // A first query may trigger index maintenance; the same snapshot must survive it.
    EXPECT_EQ(s.Sql(query, old), (Rows{{"1"}, {"2"}, {"3"}}));
    ASSERT_TRUE(s.db.txn_manager_->Commit(old));
    auto *aborted = s.db.txn_manager_->Begin();
    s.Sql("INSERT INTO vectors VALUES (9,ARRAY [0.25,0.0,0.0]);", aborted);
    s.db.txn_manager_->Abort(aborted);
    auto table = s.db.catalog_->GetTable("vectors");
    std::unordered_set<RID> retired;
    {
      for (auto scan = table->table_->MakeIterator(); !scan.IsEnd(); ++scan)
        if (scan.GetTuple().first.is_deleted_)
          retired.insert(scan.GetRID());
    }
    ASSERT_EQ(retired.size(), 2U);
    s.db.txn_manager_->GarbageCollection();
    auto index = s.db.catalog_->GetIndex("vi", "vectors");
    std::vector<VectorIndexCandidate> candidates;
    index->index_->SearchVector(
        Tuple({ValueFactory::GetVectorValue({0.0, 0.0, 0.0})},
              &index->key_schema_),
        {10, 10, 8}, &candidates, nullptr);
    for (const auto &candidate : candidates) {
      EXPECT_EQ(retired.count(candidate.rid_), 0U);
    }
    // Read before any reuse: a stale candidate must not dereference a vacant
    // slot.
    EXPECT_EQ(s.Sql(query), (Rows{{"2"}, {"3"}}));
    s.Sql("INSERT INTO vectors VALUES (4,ARRAY [-1.0,0.0,0.0]);");
    EXPECT_EQ(s.Sql(query), (Rows{{"4"}, {"2"}, {"3"}}));
    s.Sql("DELETE FROM vectors;");
    s.db.txn_manager_->GarbageCollection();
    EXPECT_TRUE(s.Sql(query).empty());
    // All old HNSW nodes can be retired; a later insertion must still be
    // reachable.
    s.Sql("INSERT INTO vectors VALUES (5,ARRAY [3.0,0.0,0.0]);");
    EXPECT_EQ(s.Sql(query), (Rows{{"5"}}));
  }
}
// Unlike the history/retirement test, this query must expand its candidate
// budget after the first search triggers a rebuild. Expected rows come from
// the inserted distances and SQL filter, not candidate IDs or list ordering.
TEST(F36, IvfRebuildPreservesFilteredMultiRoundQuery) {
  Harness h;
  SqlDB s(h);
  s.Sql("CREATE TABLE ranked(id INT PRIMARY KEY, v VECTOR(3));");
  // Build empty, then insert: the initial directory has one populated list.
  // GC permits a rebuild into four lists during the first query round.
  s.Sql("CREATE INDEX ranked_vi ON ranked USING ivfflat (v) "
        "WITH (nlist=4, nprobe=1);");
  s.Sql("INSERT INTO ranked VALUES (1,ARRAY [1.0,0.0,0.0]),"
        "(2,ARRAY [2.0,0.0,0.0]),(3,ARRAY [3.0,0.0,0.0]),"
        "(4,ARRAY [4.0,0.0,0.0]),(5,ARRAY [5.0,0.0,0.0]),"
        "(6,ARRAY [6.0,0.0,0.0]),(7,ARRAY [7.0,0.0,0.0]),"
        "(8,ARRAY [8.0,0.0,0.0]);");
  const std::string query =
      "SELECT id FROM ranked WHERE id>1 ORDER BY "
      "l2_distance(v,ARRAY [0.0,0.0,0.0]) LIMIT 3;";
  std::string plan;
  for (const auto &row : s.Sql("EXPLAIN (o) " + query))
    for (const auto &cell : row)
      plan += cell;
  ASSERT_NE(plan.find("VectorIndexScan"), std::string::npos) << plan;
  s.Sql("DELETE FROM ranked WHERE id>=5;");
  s.db.txn_manager_->GarbageCollection();
  // No preparatory SearchVector here: SQL itself must encounter maintenance.
  EXPECT_EQ(s.Sql(query), (Rows{{"2"}, {"3"}, {"4"}}));
}
TEST(F36, GcKeepsSerializablePhantomConflictEvidence) {
  Harness h;
  SqlDB s(h);
  s.Sql("CREATE TABLE accounts(id INT PRIMARY KEY, balance INT);");
  s.Sql("INSERT INTO accounts VALUES (1,10),(2,20);");
  auto *t = s.db.txn_manager_->Begin(IsolationLevel::SERIALIZABLE);
  EXPECT_EQ(s.Sql("SELECT id FROM accounts WHERE id>=2;", t), (Rows{{"2"}}));
  s.Sql(
      "INSERT INTO accounts VALUES (3,30);"); // insert has no undo; its write
                                              // set is still a conflict witness
  s.Sql("UPDATE accounts SET balance=11 WHERE id=1;", t);
  s.db.txn_manager_->GarbageCollection();
  EXPECT_FALSE(s.db.txn_manager_->Commit(t));
  EXPECT_EQ(s.Sql("SELECT id,balance FROM accounts ORDER BY id;"),
            (Rows{{"1", "10"}, {"2", "20"}, {"3", "30"}}));
}
TEST(F36, RaftTurnoverKeepsHeapBoundedAndSnapshotSuffixRestores) {
  Harness h;
  // F26's fixture intentionally admits only two Common operations. Raft control
  // roots need the S8 deployment budget.
  h.cache.reset();
  h.backend.reset();
  h.node->Close();
  h.node.reset();
  h.options.transactions_ =
      ObjectTransactionOptions{32, 128, MIB, 8 * MIB, 2ms, 10ms};
  h.options.external_buffer_bytes_ = 2 * MIB;
  h.node = std::make_shared<NodeStorage>(h.options);
  h.node->Open();
  auto files = std::make_shared<PosixDurableStorage>();
  const auto root = std::filesystem::path(h.image.path + "-raft");
  struct Cleanup {
    std::filesystem::path path;
    ~Cleanup() { std::filesystem::remove_all(path); }
  } cleanup{root};
  auto directory = NodeDirectory::Open(root, files);
  auto registry = h.node->CreateObjectSpace(h.node->Objects());
  ASSERT_TRUE(registry.space_);
  auto objects = RaftObjectStorage::Create(
      h.node, *registry.space_,
      {1024, 1024, 2 * MIB, 4096, 64, 128 * 1024, 8 * MIB, 8192});
  auto log = LogStore::OpenObjects(objects, 0, 0, 0);
  auto stable = StableStore::OpenObjects(objects);
  auto snapshots = SnapshotStore::OpenObjects(objects);
  auto deployment =
      ObjectPageDeployment{h.node, {4, {*registry.space_, 9}}, h.budget};
  auto machine = BusTubRaftStateMachine::OpenObjectPages(directory.get(), files,
                                                         16, deployment);
  uint64_t n = 0;
  auto apply = [&](const std::string &sql) {
    auto batch = machine->PrepareSql(sql, 71, n + 1,
                                     ComputeWriteIntentFingerprintV1(sql));
    ReplicatedLogEntry entry{1, ++n, 3, EntryType::COMMAND_BATCH,
                             CommandBatchCodec::Encode(batch)};
    log->Append({entry});
    stable->Update(3, 1, n);
    log->AdvanceCommittedIndex(n);
    machine->Apply(entry);
  };
  apply("CREATE TABLE accounts(id INT PRIMARY KEY, body VARCHAR(800));");
  apply("INSERT INTO accounts VALUES (7,'initial-nonempty');");
  const auto initial = machine->CatalogSnapshotForRead();
  const auto first = initial.tables_[0].first_page_id_;
  std::string body;
  for (int i = 0; i < 18; ++i) {
    body = std::string(100 + (i % 5) * 97, char('a' + i % 23));
    apply("UPDATE accounts SET body='" + body + "' WHERE id=7;");
    if (i % 9 == 0) {
      apply("DELETE FROM accounts WHERE id=7;");
      apply("INSERT INTO accounts VALUES (7,'reborn');");
      body = "reborn";
    }
    auto view = machine->CatalogSnapshotForRead();
    EXPECT_EQ(view.tables_[0].first_page_id_, first);
    auto live = machine->GetRow(
        view.tables_[0].table_oid_,
        PrimaryKeyCodecV1::Encode(ValueFactory::GetIntegerValue(7)));
    ASSERT_TRUE(live);
    EXPECT_EQ(live->second.GetRid().GetPageId(), first)
        << "single-row turnover escaped the original page";
  }
  for (const auto &kind : {std::string("hnsw"), std::string("ivfflat")}) {
    SCOPED_TRACE(kind);
    const auto name = "rv_" + kind;
    apply("CREATE TABLE " + name + "(id INT PRIMARY KEY, v VECTOR(3));");
    apply("INSERT INTO " + name +
          " VALUES (1,ARRAY [0.0,0.0,0.0]),"
          "(2,ARRAY [10.0,0.0,0.0]);");
    apply("CREATE INDEX rvi_" + kind + " ON " + name + " USING " + kind +
          " (v);");
    apply("UPDATE " + name + " SET v=ARRAY [1.0,0.0,0.0] WHERE id=1;");
    apply("DELETE FROM " + name + " WHERE id=1;");
    const auto result = ClientQueryResultCodec::Decode(machine->ExecuteReadSql(
        "SELECT id FROM " + name +
            " ORDER BY l2_distance(v,ARRAY [0.0,0.0,0.0]) LIMIT 10;",
        n));
    EXPECT_EQ(result.rows_, (Rows{{"2"}}));
  }
  const auto snapshot_index = n;
  snapshots->Capture(n, 3, *machine);
  log->InstallSnapshotBase(n, 3, true);
  snapshots->RetainOnlyLatest();
  apply("UPDATE accounts SET body='after-snapshot-final' WHERE id=7;");
  const auto reply = machine->GetLastResponse(71);
  machine.reset();
  snapshots.reset();
  log.reset();
  stable.reset();
  objects.reset();
  // Reopen stores and rebuild the business working state from the published
  // snapshot + committed suffix.
  objects = RaftObjectStorage::Open(
      h.node, *registry.space_,
      {1024, 1024, 2 * MIB, 4096, 64, 128 * 1024, 8 * MIB, 8192});
  machine = BusTubRaftStateMachine::OpenObjectPages(directory.get(), files, 16,
                                                    deployment);
  auto recovered = RecoverRaftPersistentState(objects, machine);
  ASSERT_EQ(machine->LastApplied(), snapshot_index);
  machine->Apply(*recovered.log_store_->EntryAt(n));
  auto query = ClientQueryResultCodec::Decode(
      machine->ExecuteReadSql("SELECT id,body FROM accounts;", n));
  EXPECT_EQ(query.rows_, (Rows{{"7", "after-snapshot-final"}}));
  EXPECT_EQ(machine->GetLastResponse(71), reply);
  for (const auto &kind : {std::string("hnsw"), std::string("ivfflat")}) {
    SCOPED_TRACE(kind);
    auto result = ClientQueryResultCodec::Decode(machine->ExecuteReadSql(
        "SELECT id FROM rv_" + kind +
            " ORDER BY l2_distance(v,ARRAY [0.0,0.0,0.0]) LIMIT 10;",
        n));
    EXPECT_EQ(result.rows_, (Rows{{"2"}}));
  }
}
} // namespace
