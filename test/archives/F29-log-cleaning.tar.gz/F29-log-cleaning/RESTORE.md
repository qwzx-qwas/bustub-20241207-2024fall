# F29 阶段测试恢复

2026-10-08：10 项 F29 integration/regression，复用 82 项既有生产路径回归；7 个指定变异。测试与结果只压缩保存，不注册常驻 CMake 目标。长期共同 C/P E2E 保持原内容。

## 恢复源码与运行

1. 在隔离 checkout 检出 MANIFEST 的 base_commit，再覆盖结果包 `source/` 中的 S12.2/S12.3 当前文件。不要覆盖日常有未提交修改的工作树。
2. 将本包解压到仓库外的临时目录。依赖包从仓库 `test/archives/` 读取，runner 核对 `dependency_sha256`。其他模块有效包不可当作 F29 旧包删除。
3. 核对 MANIFEST 的 production_sha256；测试适配器只调整历史夹具的显式参数，原输入与判据不改变。
4. 需要 Linux Direct 文件支持、Clang 14、CMake、Python 支持 tarfile 的 data filter，以及本机 loopback 权限。没有裸设备操作。

```bash
cmake -S /path/to/isolated/repo -B /tmp/f29-build \
  -DCMAKE_BUILD_TYPE=Debug -DCMAKE_C_COMPILER=clang-14 \
  -DCMAKE_CXX_COMPILER=clang++-14 -DBUSTUB_SANITIZER=address
cmake --build /tmp/f29-build --target bustub gmock_main -j2
python3 /tmp/F29-log-cleaning/run_stage.py \
  --repo /path/to/isolated/repo --build /tmp/f29-build \
  --out /tmp/f29-results --regressions --mutations
```

`--out` 必须尚不存在。单项诊断使用 `--case F29Cleaning.<name>`，不得用它代替完整运行计数。变异必须在指定 assertion 失败；编译失败、崩溃或非预期 exception 不能计为检出。runner 直接检查精确失败标记，XML 同时保留人工复核依据。

## 边界与兼容

T2 使用真实 NodeStorage 维护注册；其余场景通过正式 Collect 控制交错。输入日志独立生成，预期不由待测 Encode/Decode 构造。T8 通过真实 ResourceAccount 和对应压力内存安排额度竞争，不读取账本内部状态。

T1/T2/T3/T6 为核心保护；T4/T5/T7/T8 分别处理跨段、持久共享、设备容量、完成保留。T9 通过真实保留读结果耗尽 IO 名额，T10 验证最终清单容量较小时仍能选择可提交的尾部；它们接续本次复审发现的不同缺口。风险归 F29/F23，F22/F14/F31 及共同 E2E 后续接管时复用行为，不复制各层同义矩阵。部分夹具通过 Control 寻址或等待清单发布，属于阶段耦合，不能当作 E2E 证据。

默认串行运行：链接层 gate/counter 是每个测试二进制的共享测试设施，不支持并行执行用例。ASan 开启，LSan 关闭。未运行 TSan、真实掉电、裸设备、SS/RS/PL/GT 或共同性能比较。进程 `_exit` 不等价设备断电；2 ms 维护轮询与 10 s 上限可能受极重机器负载影响。
