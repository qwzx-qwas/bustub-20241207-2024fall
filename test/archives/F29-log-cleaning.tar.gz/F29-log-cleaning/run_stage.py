#!/usr/bin/env python3
"""F29 production path checks; reuse S8 fixtures and existing S12/F25 workloads."""
import argparse,pathlib,subprocess,tarfile,os,json,time,signal,resource,hashlib
import xml.etree.ElementTree as ET
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--build',required=True);p.add_argument('--out',required=True);p.add_argument('--regressions',action='store_true');p.add_argument('--mutations',action='store_true');p.add_argument('--case')
a=p.parse_args();repo=pathlib.Path(a.repo).resolve();build=pathlib.Path(a.build).resolve();out=pathlib.Path(a.out).resolve();pkg=pathlib.Path(__file__).resolve().parent
if (pkg/'MANIFEST.json').exists():
 m=json.loads((pkg/'MANIFEST.json').read_text())
 for base,key in [(repo,'production_sha256'),(repo,'dependency_sha256'),(pkg,'test_sha256')]:
  for f,h in m[key].items():assert hashlib.sha256((base/f).read_bytes()).hexdigest()==h,str(base/f)
out.mkdir(parents=True,exist_ok=False)
for name in ['S5-journal-recycling','S8-raft-object-stores','F31-F22-resource-gc']:
 with tarfile.open(repo/f'test/archives/{name}.tar.gz') as t:t.extractall(out,filter='data')
s=(out/'S8-raft-object-stores/tests/object_stores_test.cpp').read_text()
s=s.replace('__wrap_pwrite(', 's8_pwrite(').replace('__wrap_fdatasync(', 's8_fdatasync(')
s=s.replace('ObjectTransactionOptions{32, 128, MIB, 8 * MIB, 2ms, 10ms}};', 'ObjectTransactionOptions{32, 128, MIB, 8 * MIB, 2ms, 10ms}, 2*MIB};')
s=s.replace('RaftObjectDeployment{h.options, h.space, Limits()}', 'RaftObjectDeployment{h.options, h.space, Limits(), PageCacheDeployment{4U, BufferPoolOptions{8*MIB,2*MIB,32,false,3}}}')
s=s.replace('options(Options(image)), raft_options(limits) {', 'options(Options(image)), raft_options(limits) {\n    options.memory_budget_=ResourceBudgetOptions{64*MIB,65536,8*MIB};')
s=s.replace('size_t data_units = 0)', 'size_t data_units = 0, bool large_unit = false)')
s=s.replace('    int fd = open(image.path.c_str(), O_WRONLY);', '    if (large_unit) options.objects_->allocator_.allocation_bytes_ *= 2;\n    int fd = open(image.path.c_str(), O_WRONLY);')
(out/'s8-adapted.cpp').write_text(s)
env={k:v for k,v in os.environ.items() if not k.startswith('GTEST_')};env.update(S5_WORKDIR=str(out),ASAN_OPTIONS='detect_leaks=0:abort_on_error=1')
flags=['clang++-14','-std=c++17','-pthread','-g','-O0','-Wall','-Wextra','-Werror','-Wno-unused-parameter','-Wno-attributes','-fsanitize=address','-fno-omit-frame-pointer','-fno-pie']
flags+=['-I'+str(x) for x in [out,repo/'src/include',repo/'src/buffer',repo/'src/storage/disk',repo/'src/raft',repo/'third_party',repo/'third_party/lz4',repo/'third_party/libfort/src',repo/'third_party/fmt/include',out/'S5-journal-recycling/test/storage_redesign']]
flags+=['-isystem',str(repo/'third_party/googletest/googletest/include')]
libs=[build/'lib'/('lib'+n+'.a') for n in ['bustub','bustub_lz4','bustub_murmur3','duckdb_pg_query','fmtd','fort','gmock_main','gmock','gtest']]
wrap=['-Wl,--wrap=pwrite','-Wl,--wrap=fdatasync'];commands=[]
def run(cmd,name,expected=0,timeout=300):
 start=time.monotonic()
 with (out/(name+'.log')).open('w') as f:
  with subprocess.Popen(list(map(str,cmd)),cwd=repo,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True) as r:
   try:r.wait(timeout=timeout)
   except subprocess.TimeoutExpired:os.killpg(r.pid,signal.SIGKILL);r.wait();raise
 commands.append(dict(command=list(map(str,cmd)),exit=r.returncode,seconds=time.monotonic()-start,log=name+'.log'));(out/'commands.json').write_text(json.dumps(commands,indent=2))
 if r.returncode!=expected:raise RuntimeError((name,r.returncode,expected))
def check(name,count,failed=False):
 cases=ET.parse(out/(name+'.xml')).getroot().findall('.//testcase')
 assert len(cases)==count and all(c.get('status')=='run' and c.find('skipped') is None and c.find('error') is None for c in cases)
 failures=[x.text or '' for c in cases for x in c.findall('failure')]
 assert bool(failures)==failed,(name,failures)
 return failures
run(flags+['-c',pkg/'tests/cleaning_test.cpp','-o',out/'cleaning.o'],'compile')
run(flags+['-no-pie',out/'cleaning.o']+libs+wrap+['-o',out/'cleaning'],'link')
run([out/'cleaning','--gtest_filter='+ (a.case or 'F29Cleaning.*'),'--gtest_output=xml:'+str(out/'cleaning.xml')],'cleaning')
check('cleaning',1 if a.case else 10)
if a.regressions:
 old=out/'F31-F22-resource-gc';(old/'MANIFEST.json').unlink()
 # Historic archive is checked above; its old production hashes cannot describe
 # F29. Workloads/oracles remain unchanged; only skip that old revision check.
 runner=(old/'run_snapshots.py').read_text()
 start=runner.index("manifest=json.loads(");end=runner.index('with tarfile.open',start)
 runner=runner[:start]+runner[end:];(old/'run_snapshots.py').write_text(runner)
 run(['python3',old/'run_stage.py','--repo',repo,'--build',build,'--out',out/'resources','--regressions'],'resource-regression',timeout=900)
 run(['python3',old/'run_snapshots.py','--repo',repo,'--build',build,'--out',out/'snapshots'],'snapshot-regression',timeout=900)
if a.mutations:
 changes=[
 ('io-pressure','} catch (const ObjectIOBusy &) {','} catch (const ObjectIOBusy &) { throw;','HeldReadResultsYieldCleaningThenResumeWhenIOSlotsReturn'),
 ('publication-capacity','continue;  // Check only validates configured publication capacities.','throw;  // Intentional mutation: optional capacity becomes fatal.','SmallerFeasibleTailRespectsAtomicPublicationCapacity'),
 ('borrow-completion','account->Reserve(bytes, false)','account->Reserve(bytes, true)','OptionalRelocationLeavesCompletionCreditsAvailable'),
 ('omit-unmap','if (dead) {','if (false && dead) {','PrefixUnmapPreservesPinnedBytesWithoutZeroingOrCopyingLiveTail'),
 ('ignore-new-space','const auto allocated = (written + unit - 1) / unit * unit;','const auto allocated = 0 * ((written + unit - 1) / unit * unit);','PrefixUnmapPreservesPinnedBytesWithoutZeroingOrCopyingLiveTail'),
 ('omit-cleaning','cleaning_ = PlanCleaning();','cleaning_.reset();','PositiveNetGainWaitsForOldReaderThenMakesRealSpaceReusable'),
 ('stale-publication','if (job.generation_ != generation_)','if (false && job.generation_ != generation_)','ConcurrentAppendInvalidatesPreparedRelocationWithoutBlockingBodyIO')]
 for name,old,new,case in changes:
  source=(repo/('src/raft/object_storage.cpp' if name=='io-pressure' else 'src/raft/object_log_store.cpp')).read_text();assert source.count(old)==1,(name,source.count(old))
  f=out/(name+'.cpp');
  source=source.replace(old,new)
  if name=='borrow-completion':source=source.replace('ResourceCharge charge(account, bytes, false);','ResourceCharge charge(account, bytes, true);')
  f.write_text(source);obj=out/(name+'.o')
  run(flags+['-c',f,'-o',obj],name+'-compile')
  run(flags+['-no-pie',out/'cleaning.o',obj]+libs+wrap+['-o',out/name],name+'-link')
  run([out/name,'--gtest_filter=F29Cleaning.'+case,'--gtest_output=xml:'+str(out/(name+'.xml'))],name,expected=1)
  failures=check(name,1,True)
  assert 'C++ exception' not in '\n'.join(failures),(name,failures)
  marker={'io-pressure':'temporary IO capacity escaped cleaning as a failure','publication-capacity':'optional tail exceeded publication budget instead of choosing a feasible tail','borrow-completion':'optional relocation consumed completion credits', 'omit-unmap':'hole.spans_[0].data_', 'ignore-new-space':'zero-gain cleaning copied/zeroed Data', 'omit-cleaning':'compaction did not publish', 'stale-publication':'stale cleaning replaced current history'}[name]
  assert marker in '\n'.join(failures),(name,failures)
(out/'summary.json').write_text(json.dumps(dict(normal=1 if a.case else 10,mutations=7 if a.mutations else 0,regressions=a.regressions),indent=2))
