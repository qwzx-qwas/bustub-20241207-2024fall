#include "s8-adapted.cpp"
#include <condition_variable>
#include <future>
namespace {
std::atomic<uint64_t> data_writes{0};
std::atomic<bool> crash_write{false};
std::mutex gate_mutex;
std::condition_variable gate_changed;
bool gate_arm = false, gate_entered = false, gate_open = false;
struct GateExit {
  ~GateExit() {
    std::lock_guard lock(gate_mutex);
    gate_open = true;
    gate_arm = false;
    gate_changed.notify_all();
  }
};
} // namespace
extern "C" ssize_t __wrap_pwrite(int fd, const void *data, size_t size,
                                 off_t offset) {
  if ((fcntl(fd, F_GETFL) & O_DIRECT) && offset >= static_cast<off_t>(DATA)) {
    ++data_writes;
    {
      std::unique_lock lock(gate_mutex);
      if (gate_arm) {
        gate_arm = false;
        gate_entered = true;
        gate_changed.notify_all();
        gate_changed.wait(lock, [] { return gate_open; });
      }
    }
    if (crash_write.exchange(false)) {
      const auto n = __real_pwrite(fd, data, size, offset);
      _exit(n == static_cast<ssize_t>(size) ? 72 : 74);
    }
  }
  return s8_pwrite(fd, data, size, offset);
}
extern "C" int __wrap_fdatasync(int fd) { return s8_fdatasync(fd); }
namespace {
auto CleaningLimits() -> RaftObjectOptions {
  auto o = Limits();
  o.segment_bytes_ = 65536;
  o.io_chunk_bytes_ = 65536;
  return o;
}
void DurableResult(const JournalResult &r) {
  if (r.error_)
    std::rethrow_exception(r.error_);
  Require(r.outcome_ == JournalOutcome::Durable, "durable transaction");
}
void WriteObject(Harness &h, uint64_t id, size_t bytes) {
  ObjectTransaction t{{{ObjectOperation::Create,
                        {h.space, id},
                        0,
                        ObjectSizeMode::Variable,
                        {}}},
                      {}};
  auto c = h.node->SubmitObjects(t);
  Require(c.admission_ == IOAdmission::Accepted, "create admitted");
  c.ticket_->Wait();
  DurableResult(c.ticket_->Result());
  t = {{{ObjectOperation::Append,
         {h.space, id},
         0,
         ObjectSizeMode::Variable,
         s5::Value(bytes, 193)}},
       {}};
  auto w = h.node->SubmitObjects(t);
  Require(w.admission_ == IOAdmission::Accepted, "write admitted");
  w.ticket_->Wait();
  DurableResult(w.ticket_->Result());
}
auto AppendObject(Harness &h, uint64_t id, size_t bytes) -> JournalResult {
  ObjectTransaction t{{{ObjectOperation::Append,
                        {h.space, id},
                        0,
                        ObjectSizeMode::Variable,
                        s5::Value(bytes, 211)}},
                      {}};
  auto w = h.node->SubmitObjects(t);
  Require(w.admission_ == IOAdmission::Accepted, "append admitted");
  w.ticket_->Wait();
  return w.ticket_->Result();
}
void NoSpace(const JournalResult &r) {
  ASSERT_EQ(r.outcome_, JournalOutcome::NotCommitted);
  ASSERT_TRUE(r.error_);
  try {
    std::rethrow_exception(r.error_);
  } catch (const AllocationError &e) {
    EXPECT_EQ(e.Code(), AllocationErrorCode::NoSpace);
    return;
  }
  FAIL() << "expected allocator NoSpace, not another failure";
}
auto Segments(Harness &h) -> std::vector<uint64_t> {
  std::vector<uint64_t> out;
  for (const auto &x : h.node->Objects().Controls({h.space, 1}, 1, 32))
    out.push_back(x.item_);
  return out;
}
auto Fragmented(Harness &h, LogStore &log) -> std::vector<ReplicatedLogEntry> {
  const auto u = h.options.objects_->allocator_.allocation_bytes_;
  std::vector<ReplicatedLogEntry> model{
      Entry(1, u / 12, 23), Entry(2, u / 13, 44), Entry(3, u / 14, 91)};
  log.Append(model);
  model[1] = Entry(2, u / 13, 147, 4);
  model[2] = Entry(3, u / 14, 182, 4);
  log.ReplaceSuffix(2, {model[1], model[2]});
  return model;
}
void Rounds(Harness &h, size_t count = 80) {
  for (size_t i = 0; i < count; ++i) {
    h.objects->Collect(1);
    std::this_thread::sleep_for(2ms);
  }
}
TEST(F29Cleaning,
     PrefixUnmapPreservesPinnedBytesWithoutZeroingOrCopyingLiveTail) {
  Harness h(CleaningLimits());
  const auto u = h.options.objects_->allocator_.allocation_bytes_;
  auto log = LogStore::OpenObjects(h.objects, 0, 0, 0);
  std::vector<ReplicatedLogEntry> model{Entry(1, 2 * u, 37),
                                        Entry(2, u / 3, 82)};
  log->Append(model);
  const auto ids = Segments(h);
  ASSERT_EQ(ids.size(), 1U);
  auto old = h.node->Objects();
  const ObjectKey key{h.space, ids[0]};
  auto pin =
      std::make_unique<ObjectReadLease>(h.node->ProtectObject(old, key, 0, u));
  auto spans = old.Resolve(key, 0, u);
  ASSERT_TRUE(spans.spans_[0].data_);
  const auto physical = DATA + spans.spans_[0].data_->offset_;
  Bytes before(u), after(u);
  int fd = open(h.image.path.c_str(), O_RDONLY);
  ASSERT_GE(fd, 0);
  ASSERT_EQ(pread(fd, before.data(), u, physical), static_cast<ssize_t>(u));
  log->InstallSnapshotBase(1, 3, true);
  const auto writes = data_writes.load();
  Rounds(h);
  ASSERT_EQ(data_writes.load(), writes)
      << "zero-gain cleaning copied/zeroed Data";
  const auto hole = h.node->Objects().Resolve(key, 0, u);
  ASSERT_EQ(hole.spans_.size(), 1U);
  EXPECT_FALSE(hole.spans_[0].data_);
  ASSERT_EQ(pread(fd, after.data(), u, physical), static_cast<ssize_t>(u));
  close(fd);
  EXPECT_EQ(after, before);
  EXPECT_EQ(log->Entries(2, 2), (std::vector<ReplicatedLogEntry>{model[1]}));
  pin.reset();
  log.reset();
  h.Close();
  h.Open();
  log = LogStore::OpenObjects(h.objects, 1, 1, 3);
  EXPECT_EQ(log->EntryAt(2), std::optional<ReplicatedLogEntry>(model[1]));
}
TEST(F29Cleaning, PositiveNetGainWaitsForOldReaderThenMakesRealSpaceReusable) {
  Harness h(CleaningLimits(), 4, true);
  const auto u = h.options.objects_->allocator_.allocation_bytes_;
  auto log = LogStore::OpenObjects(h.objects, 0, 0, 0);
  const auto model = Fragmented(h, *log);
  auto ids = Segments(h);
  ASSERT_EQ(ids.size(), 2U);
  auto pin = std::make_unique<ObjectReadLease>(
      h.node->ProtectObject(h.node->Objects(), {h.space, ids[0]}, 0, u / 12));
  WriteObject(h, 1000, u);
  NoSpace(AppendObject(h, 1000, 2 * u));
  std::weak_ptr<RaftObjectStorage> owner = h.objects;
  h.node->SetStoreMaintenance([owner] {
    if (auto store = owner.lock())
      store->Collect(1);
  });
  const auto published_deadline = std::chrono::steady_clock::now() + 10s;
  while (Segments(h).size() != 1 &&
         std::chrono::steady_clock::now() < published_deadline)
    std::this_thread::sleep_for(2ms);
  ASSERT_EQ(Segments(h).size(), 1U)
      << "compaction did not publish through the existing GC role";
  EXPECT_EQ(log->Entries(1, 3), model);
  NoSpace(AppendObject(
      h, 1000,
      2 * u)); // One pinned old allocation still prevents the two-unit request.
  pin.reset();
  const auto deadline = std::chrono::steady_clock::now() + 10s;
  bool written = false;
  while (std::chrono::steady_clock::now() < deadline) {
    auto result = AppendObject(h, 1000, 2 * u);
    if (result.outcome_ == JournalOutcome::Durable) {
      written = true;
      break;
    }
    NoSpace(result);
    std::this_thread::sleep_for(2ms);
  }
  ASSERT_TRUE(written) << "compaction did not return net space";
  auto r = h.node->ReadObject(h.node->Objects(), {h.space, 1000}, u, 2 * u);
  r.Wait();
  Bytes body(2 * u);
  r.CopyTo(body.data(), body.size());
  EXPECT_EQ(body, s5::Value(2 * u, 211));
  log.reset();
  h.Close();
  h.Open();
  log = LogStore::OpenObjects(h.objects, 0, 0, 0);
  EXPECT_EQ(log->Entries(1, 3), model);
}
TEST(F29Cleaning,
     ConcurrentAppendInvalidatesPreparedRelocationWithoutBlockingBodyIO) {
  Harness h(CleaningLimits());
  auto log = LogStore::OpenObjects(h.objects, 0, 0, 0);
  auto model = Fragmented(h, *log);
  {
    std::lock_guard lock(gate_mutex);
    gate_arm = true;
    gate_entered = false;
    gate_open = false;
  }
  auto maintenance = std::async(std::launch::async, [&] { Rounds(h, 24); });
  GateExit release;
  {
    std::unique_lock lock(gate_mutex);
    ASSERT_TRUE(gate_changed.wait_for(lock, 10s, [] { return gate_entered; }));
  }
  model.push_back(Entry(4, 277, 241, 5));
  auto append =
      std::async(std::launch::async, [&] { log->Append({model.back()}); });
  const auto status = append.wait_for(10s);
  {
    std::lock_guard lock(gate_mutex);
    gate_open = true;
    gate_changed.notify_all();
  }
  ASSERT_EQ(status, std::future_status::ready)
      << "foreground blocked on cleaning body IO";
  append.get();
  ASSERT_EQ(maintenance.wait_for(10s), std::future_status::ready);
  maintenance.get();
  Rounds(h);
  ASSERT_EQ(log->LastLogIndex(), model.size())
      << "stale cleaning replaced current history";
  EXPECT_EQ(log->Entries(1, 4), model);
  log.reset();
  h.Close();
  h.Open();
  log = LogStore::OpenObjects(h.objects, 0, 0, 0);
  EXPECT_EQ(log->Entries(1, 4), model);
}
TEST(F29Cleaning, CrossSegmentContinuationSurvivesPrefixCleaningAndRecovery) {
  Harness h;
  auto log = LogStore::OpenObjects(h.objects, 0, 0, 0);
  std::vector<ReplicatedLogEntry> model{Entry(1, 173, 13), Entry(2, 3771, 77),
                                        Entry(3, 118, 223)};
  log->Append(model);
  log->InstallSnapshotBase(1, 3, true);
  Rounds(h);
  model.erase(model.begin());
  EXPECT_EQ(log->Entries(2, 3), model);
  log.reset();
  h.Close();
  h.Open();
  log = LogStore::OpenObjects(h.objects, 1, 1, 3);
  EXPECT_EQ(log->Entries(2, 3), model);
}
TEST(F29Cleaning, SharedAllocationIsNotCountedAsRelocationGain) {
  Harness h(CleaningLimits());
  auto log = LogStore::OpenObjects(h.objects, 0, 0, 0);
  const auto model = Fragmented(h, *log);
  const auto ids = Segments(h);
  ASSERT_EQ(ids.size(), 2U);
  ObjectTransaction create{{{ObjectOperation::Create,
                             {h.space, 1000},
                             64,
                             ObjectSizeMode::Variable,
                             {}}},
                           {}};
  auto c = h.node->SubmitObjects(create);
  ASSERT_EQ(c.admission_, IOAdmission::Accepted);
  c.ticket_->Wait();
  DurableResult(c.ticket_->Result());
  const auto view = h.node->Objects();
  const auto length =
      std::min<uint64_t>(64, view.Describe({h.space, ids[0]}).size_);
  DurableResult(h.node->ShareObjectRange(view, {h.space, ids[0]},
                                         {h.space, 1000}, 0, length, 0));
  auto read = h.node->ReadObject(h.node->Objects(), {h.space, 1000}, 0, length);
  read.Wait();
  Bytes expected(length);
  read.CopyTo(expected.data(), length);
  const auto writes = data_writes.load();
  Rounds(h);
  EXPECT_EQ(data_writes.load(), writes)
      << "shared old units cannot pay for a new allocation";
  auto after =
      h.node->ReadObject(h.node->Objects(), {h.space, 1000}, 0, length);
  after.Wait();
  Bytes actual(length);
  after.CopyTo(actual.data(), length);
  EXPECT_EQ(actual, expected);
  ObjectTransaction remove{{{ObjectOperation::Remove,
                             {h.space, 1000},
                             0,
                             ObjectSizeMode::Variable,
                             {}}},
                           {}};
  auto d = h.node->SubmitObjects(remove);
  ASSERT_EQ(d.admission_, IOAdmission::Accepted);
  d.ticket_->Wait();
  DurableResult(d.ticket_->Result());
  Rounds(h);
  EXPECT_GT(data_writes.load(), writes);
  EXPECT_EQ(log->Entries(1, 3), model);
}
TEST(F29Cleaning, InterruptedCandidateDoesNotReplacePublishedHistory) {
  Harness h(CleaningLimits());
  auto log = LogStore::OpenObjects(h.objects, 0, 0, 0);
  auto model = Fragmented(h, *log);
  log.reset();
  h.Close();
  const auto child = fork();
  ASSERT_GE(child, 0);
  if (child == 0) {
    try {
      h.Open();
      auto logs = LogStore::OpenObjects(h.objects, 0, 0, 0);
      crash_write = true;
      Rounds(h);
      _exit(73);
    } catch (...) {
      _exit(75);
    }
  }
  int status = 0;
  ASSERT_EQ(waitpid(child, &status, 0), child);
  ASSERT_TRUE(WIFEXITED(status));
  ASSERT_EQ(WEXITSTATUS(status), 72);
  h.Open();
  log = LogStore::OpenObjects(h.objects, 0, 0, 0);
  EXPECT_EQ(log->Entries(1, 3), model);
  Rounds(h);
  log.reset();
  h.Close();
  h.Open();
  log = LogStore::OpenObjects(h.objects, 0, 0, 0);
  EXPECT_EQ(log->Entries(1, 3), model);
}
TEST(F29Cleaning, OptionalRelocationLeavesCompletionCreditsAvailable) {
  Harness h(CleaningLimits());
  h.Close();
  h.options.memory_budget_ = ResourceBudgetOptions{4 * MIB, 16384, MIB};
  h.options.transactions_->gc_interval_ =
      1h; // Explicit scheduling in this pressure scenario.
  h.Open();
  auto log = LogStore::OpenObjects(h.objects, 0, 0, 0);
  const auto model = Fragmented(h, *log);
  h.objects->Collect(
      1); // Unmap the dead suffix before testing optional relocation.
  auto ordinary = ResourceAccount::Create(h.node->MemoryBudget());
  size_t occupied = 0;
  for (size_t step : {size_t{65536}, size_t{1024}, size_t{1}})
    while (ordinary->Reserve(step, false))
      occupied += step;
  ResourceCharge held(ordinary, occupied, false);
  Bytes resident(
      occupied,
      std::byte{0x71}); // Actual owner of the reserved pressure memory.
  auto completion = ResourceAccount::Create(h.node->MemoryBudget());
  auto available = [&] {
    size_t bytes = 0;
    while (completion->Reserve(1024, true))
      bytes += 1024;
    completion->Release(bytes, true);
    return bytes;
  };
  const auto before = available();
  ASSERT_GT(before, 0U);
  // A retained optional candidate must not consume completion credits. One
  // round may only visit ownership; three rounds reach the log planning role.
  for (int i = 0; i < 3; ++i)
    h.objects->Collect(1);
  EXPECT_EQ(available(), before)
      << "optional relocation consumed completion credits";
  resident.clear();
  resident.shrink_to_fit();
  held.Reset();
  Rounds(h);
  EXPECT_EQ(log->Entries(1, 3), model);
}
TEST(F29Cleaning, MissingStagingSpaceLeavesHistoryUsableAndCleanupCanResume) {
  Harness h(CleaningLimits(), 3);
  const auto u = h.options.objects_->allocator_.allocation_bytes_;
  auto log = LogStore::OpenObjects(h.objects, 0, 0, 0);
  const auto model = Fragmented(h, *log);
  WriteObject(h, 1000, u);
  Rounds(h, 30);
  EXPECT_EQ(log->Entries(1, 3), model);
  EXPECT_FALSE(h.node->State().error_);
  EXPECT_FALSE(h.node->State().object_error_);
  ObjectTransaction t{{{ObjectOperation::Unmap,
                        {h.space, 1000},
                        0,
                        ObjectSizeMode::Variable,
                        {},
                        std::nullopt,
                        u}},
                      {}};
  auto s = h.node->SubmitObjects(t);
  ASSERT_EQ(s.admission_, IOAdmission::Accepted);
  s.ticket_->Wait();
  DurableResult(s.ticket_->Result());
  const auto deadline = std::chrono::steady_clock::now() + 10s;
  bool wrote = false;
  while (std::chrono::steady_clock::now() < deadline) {
    h.objects->Collect(1);
    auto result = AppendObject(h, 1000, 2 * u);
    if (result.outcome_ == JournalOutcome::Durable) {
      wrote = true;
      break;
    }
    NoSpace(result);
    std::this_thread::sleep_for(2ms);
  }
  ASSERT_TRUE(wrote);
  EXPECT_EQ(log->Entries(1, 3), model);
}

TEST(F29Cleaning, HeldReadResultsYieldCleaningThenResumeWhenIOSlotsReturn) {
  Harness h(CleaningLimits());
  h.Close();
  h.options.io_.max_operations_ = 64;
  h.options.io_.progress_operations_ = 16;
  h.options.transactions_->gc_interval_ = 1h;
  h.Open();
  auto log = LogStore::OpenObjects(h.objects, 0, 0, 0);
  const auto model = Fragmented(h, *log);
  const auto ids = Segments(h);
  std::vector<ObjectRead> readers;
  bool full = false;
  for (size_t i = 0; i <= h.options.io_.max_operations_; ++i) {
    try {
      auto r = h.node->ReadObject(h.node->Objects(), {h.space, ids[0]}, 0, 1);
      r.Wait();
      Bytes byte(1);
      r.CopyTo(byte.data(), byte.size());
      readers.push_back(std::move(r));
    } catch (const ObjectIOBusy &) {
      full = true;
      break;
    }
  }
  ASSERT_TRUE(full) << "setup did not exhaust actual IO slots";
  const auto writes = data_writes.load();
  try {
    Rounds(h, 10);
  } catch (const ObjectIOBusy &) {
    FAIL() << "temporary IO capacity escaped cleaning as a failure";
  }
  EXPECT_FALSE(h.node->State().object_error_);
  EXPECT_EQ(data_writes.load(), writes);
  readers.clear();
  Rounds(h);
  EXPECT_EQ(Segments(h).size(), 1U)
      << "cleaning did not resume after IO slots returned";
  EXPECT_EQ(log->Entries(1, 3), model);
  log.reset();
  h.Close();
  h.Open();
  log = LogStore::OpenObjects(h.objects, 0, 0, 0);
  EXPECT_EQ(log->Entries(1, 3), model);
}
TEST(F29Cleaning, SmallerFeasibleTailRespectsAtomicPublicationCapacity) {
  Harness h(CleaningLimits());
  auto log = LogStore::OpenObjects(h.objects, 0, 0, 0);
  auto model = Fragmented(h, *log);
  model[2] = Entry(3, 67, 239, 5);
  log->ReplaceSuffix(3, {model[2]});
  ASSERT_EQ(Segments(h).size(), 3U);
  log.reset();
  h.Close();
  // Existing history is valid. A three-segment replacement needs nine control
  // records; replacing two at a time fits seven. Do not change the log format.
  h.options.transactions_->max_operations_ = 7;
  h.options.transactions_->gc_interval_ = 1h;
  h.Open();
  log = LogStore::OpenObjects(h.objects, 0, 0, 0);
  try {
    Rounds(h);
  } catch (const std::invalid_argument &) {
    FAIL() << "optional tail exceeded publication budget instead of choosing a "
              "feasible tail";
  }
  EXPECT_FALSE(h.node->State().object_error_);
  EXPECT_EQ(Segments(h).size(), 1U) << "bounded tail cleaning did not progress";
  EXPECT_EQ(log->Entries(1, 3), model);
  log.reset();
  h.Close();
  h.Open();
  log = LogStore::OpenObjects(h.objects, 0, 0, 0);
  EXPECT_EQ(log->Entries(1, 3), model);
}

} // namespace
