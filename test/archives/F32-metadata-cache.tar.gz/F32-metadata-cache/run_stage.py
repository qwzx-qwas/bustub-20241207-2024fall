#!/usr/bin/env python3
import argparse,subprocess,os,pathlib,json,time,tarfile,hashlib
p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--build',required=True);p.add_argument('--out',required=True);p.add_argument('--compiler',default='/tmp/bustub-gcc16/bin/x86_64-focal-linux-gnu-g++');p.add_argument('--case',default='F32Cache.*');a=p.parse_args()
r=pathlib.Path(a.repo).resolve();b=pathlib.Path(a.build).resolve();o=pathlib.Path(a.out).resolve();o.mkdir(parents=True,exist_ok=True);pkg=pathlib.Path(__file__).resolve().parent
manifest=pkg/'MANIFEST.json'
if manifest.exists():
 m=json.loads(manifest.read_text())
 for base,key in [(r,'production_sha256'),(r,'dependency_sha256'),(pkg,'test_sha256')]:
  for name,expected in m[key].items():
   assert hashlib.sha256((base/name).read_bytes()).hexdigest()==expected,str(base/name)
with tarfile.open(r/'test/archives/S5-journal-recycling.tar.gz') as t:t.extractall(o,filter='data')
env=dict(os.environ,S5_WORKDIR=str(o),ASAN_OPTIONS='detect_leaks=1:abort_on_error=1',LD_LIBRARY_PATH='/tmp/bustub-gcc16/native-runtime')
flags=[a.compiler,'--sysroot=/','-isystem','/usr/include/x86_64-linux-gnu','-std=c++17','-pthread','-g','-O0','-Wall','-Wextra','-Werror','-Wno-unused-parameter','-Wno-attributes','-fsanitize=address','-fno-omit-frame-pointer','-fno-pie']
flags+=['-I'+str(x) for x in [o,r/'src/include',r/'third_party',r/'third_party/fmt/include',o/'S5-journal-recycling/test/storage_redesign']]+['-isystem',str(r/'third_party/googletest/googletest/include')]
libs=[b/'lib'/('lib'+n+'.a') for n in ['bustub','bustub_lz4','bustub_murmur3','duckdb_pg_query','fmtd','fort','gmock_main','gmock','gtest']]
cmds=[('compile',flags+['-no-pie',pkg/'tests/cache_test.cpp',*libs,'-Wl,--wrap=_Znwm','-Wl,--wrap=pread','-Wl,--wrap=pwrite','-o',o/'cache']),('tests',[o/'cache','--gtest_filter='+a.case,'--gtest_output=xml:'+str(o/'cache.xml')])]
results=[]
for name,cmd in cmds:
 start=time.monotonic()
 with (o/(name+'.log')).open('w') as log: completed=subprocess.run(list(map(str,cmd)),env=env,stdout=log,stderr=subprocess.STDOUT,timeout=240)
 results.append(dict(command=list(map(str,cmd)),exit=completed.returncode,seconds=time.monotonic()-start,log=name+'.log'));(o/'commands.json').write_text(json.dumps(results,indent=2))
 if completed.returncode:raise SystemExit(completed.returncode)

# A misspelled filter must not turn an empty run into a successful verification.
import xml.etree.ElementTree as ET
report=ET.parse(o/'cache.xml').getroot()
assert int(report.get('tests','0'))>0, 'no tests selected'
assert all(int(report.get(k,'0'))==0 for k in ['failures','errors','disabled']),report.attrib
assert not report.findall('.//skipped'), 'unexpected skipped test'
