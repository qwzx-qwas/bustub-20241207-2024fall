#!/usr/bin/env python3
"""Reuse frozen tests; adapt runners, never pretend old source hashes match new production."""
import argparse,pathlib,subprocess,tarfile,os,json,time
p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--build',required=True);p.add_argument('--out',required=True);a=p.parse_args()
r=pathlib.Path(a.repo).resolve();b=pathlib.Path(a.build).resolve();o=pathlib.Path(a.out).resolve();o.mkdir(parents=True,exist_ok=False)
for name in ['F30-integrity-scanning','F26-array-buffer-pool']:
 with tarfile.open(r/f'test/archives/{name}.tar.gz') as t:t.extractall(o,filter='data')
f=o/'F30-integrity-scanning/run_stage.py';s=f.read_text();start=s.index('if manifest.exists():');end=s.index('for n in ',start);f.write_text(s[:start]+s[end:])
f=o/'F26-array-buffer-pool/run_pages.py';s=f.read_text();start=s.index('if manifest.exists():');end=s.index('out.mkdir',start);f.write_text(s[:start]+s[end:])
env=dict(os.environ,LD_LIBRARY_PATH='/tmp/bustub-gcc16/native-runtime',ASAN_OPTIONS='detect_leaks=1:abort_on_error=1');commands=[]
def run(cmd,name,timeout=300):
 start=time.monotonic()
 with (o/(name+'.log')).open('w') as f:x=subprocess.run(list(map(str,cmd)),env=env,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
 commands.append(dict(command=list(map(str,cmd)),exit=x.returncode,seconds=time.monotonic()-start,log=name+'.log'));(o/'commands.json').write_text(json.dumps(commands,indent=2));assert x.returncode==0,(name,x.returncode)
run(['python3',o/'F30-integrity-scanning/run_stage.py','--repo',r,'--build',b,'--out',o/'integrity','--case','F30Integrity.*:S10Deferred.*'],'integrity')
run(['python3',o/'F30-integrity-scanning/run_regressions.py','--repo',r,'--build',b,'--out',o/'raft'],'raft')
run(['python3',o/'F26-array-buffer-pool/run_pages.py','--repo',r,'--build',b,'--out',o/'pages','--compiler','/tmp/bustub-gcc16/bin/x86_64-focal-linux-gnu-g++','--extra-cxxflags=--sysroot=/ -isystem /usr/include/x86_64-linux-gnu -Wno-dangling-else','--sanitizer','address'],'pages')
run(['cmake','--build',b,'--target','page_guard_test','buffer_pool_manager_test','b_plus_tree_insert_test','b_plus_tree_delete_test','lru_k_replacer_test','bpm-bench','btree-bench','htable-bench','-j','3'],'build')
run(['ctest','--test-dir',b,'-R',r'^(PageGuardTest|BufferPoolManagerTest|BPlusTreeTests|LRUKReplacerTest)\.', '--timeout','180','--output-on-failure'],'existing')
assert '100% tests passed' in (o/'existing.log').read_text()
