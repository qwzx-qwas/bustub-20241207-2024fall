#!/usr/bin/env python3
import argparse,pathlib,json,subprocess,os,time
p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--build',required=True);p.add_argument('--normal',required=True);p.add_argument('--out',required=True);a=p.parse_args()
r=pathlib.Path(a.repo).resolve();b=pathlib.Path(a.build).resolve();n=pathlib.Path(a.normal).resolve();out=pathlib.Path(a.out).resolve();out.mkdir(parents=True,exist_ok=True)
cmd=json.loads((n/'commands.json').read_text())[0]['command'];flags=cmd[:cmd.index('-no-pie')]+['-I'+str(r/'src/storage/disk'),'-I'+str(r/'src/buffer')];source=cmd[cmd.index('-no-pie')+1]
libs=[b/'lib'/('lib'+x+'.a') for x in ['bustub','bustub_lz4','bustub_murmur3','duckdb_pg_query','fmtd','fort','gmock_main','gmock','gtest']]
env=dict(os.environ,S5_WORKDIR=str(out),LD_LIBRARY_PATH='/tmp/bustub-gcc16/native-runtime',ASAN_OPTIONS='detect_leaks=1:abort_on_error=1');commands=[]
def run(command,name,expected=0):
 start=time.monotonic()
 with (out/(name+'.log')).open('w') as f:ret=subprocess.run(list(map(str,command)),env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
 commands.append(dict(command=list(map(str,command)),exit=ret.returncode,seconds=time.monotonic()-start,log=name+'.log'));(out/'commands.json').write_text(json.dumps(commands,indent=2))
 assert ret.returncode==expected,(name,ret.returncode,expected)
changes=[
 ('no-eviction','src/storage/disk/metadata_engine.cpp','auto MetadataCache::Reclaim() -> bool {','auto MetadataCache::Reclaim() -> bool { return false;','WorkingSetExceedsBodiesAndRestartsFromCheckpointAndRedo','metadata bodies held'),
 ('skip-held-candidate','src/storage/disk/metadata_engine.cpp','policy_.SetEvictable(*frame, false);\n      skipped_.push_back(*frame);','/* wrongly keep the held candidate eligible */','WorkingSetExceedsBodiesAndRestartsFromCheckpointAndRedo','metadata bodies held'),
 ('old-version-reload','src/storage/disk/metadata_engine.cpp','old->reloadable_ = false;\n    policy_.SetEvictable(old->frame_, false);','old->reloadable_ = true;\n    policy_.SetEvictable(old->frame_, true);','ColdOldVersionSurvivesOverwriteAndPressure','metadata page checksum/version mismatch'),
 ('new-pending-lost','src/storage/disk/metadata_engine.cpp','if (slot.pending_ == page) Unqueue(slot);','Unqueue(slot);','OlderCompletionKeepsNewerPendingAndQueueDeduplicates','writes.empty()'),
 ('load-recheck','src/storage/disk/metadata_engine.cpp','auto position = LockPosition(page->id_);','/* wrongly load without serializing the physical position */','SameVersionLoadsCoalesceAndUnrelatedHitsProgress','duplicate load'),
 ('load-crc','src/storage/disk/metadata_engine.cpp','trailer.ReadU32() == Crc32cExtend(Crc32c(bytes, BODY), bytes + BODY, 40)','(trailer.ReadU32(), true)','ColdReadChecksActualPersistentBytes','Expected:'),
 ('close-drain','src/storage/disk/metadata_engine.cpp','changed_.wait(lock, [&] { return calls_ == 0; });','/* wrongly return before admitted queries finish */','CloseDrainsAdmittedColdRead','state'),
 ('ignore-pin','src/buffer/clock_pro_replacer.cpp','if (!flags_[n.frame].evictable.load(std::memory_order_relaxed)) continue;','/* wrongly ignore pin */','ClockProFindsSoleEligibleFrameDuringChurn','Value of:'),
 ('stranded-hot','src/buffer/clock_pro_replacer.cpp',' || work >= 2 * capacity_','','ClockProFindsSoleEligibleFrameDuringChurn','chosen'),
 ('owner-double-release', 'src/storage/disk/metadata_engine.cpp', '      if (image) {\n        auto budget = budget_;\n        // shared_ptr invokes its deleter if allocating the control block fails.\n        // From this handoff onward, only that deleter owns the live-page charge.\n        return {image.release(), [budget](PageImage *p) {\n                  delete p;\n                  budget->live_.fetch_sub(1);\n                }};\n      }', '      if (image) {\n        try {\n          auto budget = budget_;\n          return {image.release(), [budget](PageImage *p) {\n                    delete p;\n                    budget->live_.fetch_sub(1);\n                  }};\n        } catch (...) {\n          budget_->live_.fetch_sub(1);\n          throw;\n        }\n      }', 'WorkingSetExceedsBodiesAndRestartsFromCheckpointAndRedo', 'metadata residency exceeds image budget'),
 ('ignore-history', 'src/buffer/clock_pro_replacer.cpp', 'nodes_[id].hot = true;\n    nodes_[id].test = false;\n    ++hot_;', 'nodes_[id].hot = false;\n    nodes_[id].test = true;', 'ClockProProtectsReusedPagesAcrossScansAndHotsetChanges', 'test-period history'),
 ('ignore-hits','src/buffer/clock_pro_replacer.cpp','void ClockProReplacer::RecordAccess(frame_id_t frame) {','void ClockProReplacer::RecordAccess(frame_id_t frame) { return;','ClockProProtectsReusedPagesAcrossScansAndHotsetChanges','second chance'),
]
run(flags+['-c',source,'-o',out/'tests.o'],'tests-compile')
for name,path,old,new,case,oracle in changes:
 s=(r/path).read_text();assert s.count(old)==1,(name,s.count(old));(out/(name+'.cpp')).write_text(s.replace(old,new))
 run(flags+['-c',out/(name+'.cpp'),'-o',out/(name+'.o')],name+'-compile')
 run(flags+['-no-pie',out/'tests.o',out/(name+'.o'),*libs,'-Wl,--wrap=_Znwm','-Wl,--wrap=pread','-Wl,--wrap=pwrite','-o',out/name],name+'-link')
 run([out/name,'--gtest_filter=F32Cache.'+case,'--gtest_output=xml:'+str(out/(name+'.xml'))],name,1)
 log=(out/(name+'.log')).read_text();assert oracle in log,(name,log);assert '[  FAILED  ] F32Cache.'+case in log
(out/'summary.json').write_text(json.dumps({'caught':len(changes),'mutations':changes},indent=2))
