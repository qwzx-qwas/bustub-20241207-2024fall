#include "buffer/buffer_pool_manager.h"
#include "buffer/clock_pro_replacer.h"
#include "fixture.h"
#include "storage/disk/disk_manager_memory.h"
#include "storage/disk/node_storage.h"
#include "gtest/gtest.h"
#include <atomic>
#include <condition_variable>
#include <future>
#include <new>
#include <thread>
#include <unordered_map>
using namespace bustub;
using namespace s5;
using namespace std::chrono_literals;
// Link-only fault injection: fail the allocation immediately after a page-sized
// body, on this thread only. The following allocation is its shared owner.
extern "C" void *__real__Znwm(size_t);
namespace {
thread_local bool fail_owner = false, saw_body = false, owner_failed = false;
thread_local size_t body_allocation = 0, owner_allocation = 0;
} // namespace
extern "C" void *__wrap__Znwm(size_t bytes) {
  if (fail_owner) {
    if (saw_body) {
      fail_owner = false;
      owner_failed = true;
      owner_allocation = bytes;
      throw std::bad_alloc();
    }
    if (bytes >= BUSTUB_PAGE_SIZE && bytes < BUSTUB_PAGE_SIZE + 256) {
      saw_body = true;
      body_allocation = bytes;
    }
  }
  return __real__Znwm(bytes);
}
extern "C" ssize_t __real_pread(int, void *, size_t, off_t);
extern "C" ssize_t __real_pwrite(int, const void *, size_t, off_t);
namespace {
std::mutex gate_mu;
std::condition_variable gate_cv;
std::map<off_t, size_t> reads, writes;
char gate = 0;
bool entered = false, release_gate = true, fail_write = false;
off_t blocked_offset = 0;
bool IsMetadata(int fd, off_t off) {
  return (fcntl(fd, F_GETFL) & O_DIRECT) &&
         off >= static_cast<off_t>(2 * MIB) &&
         off < static_cast<off_t>(3 * MIB);
}
void Arm(char c, bool fail = false) {
  std::lock_guard l(gate_mu);
  gate = c;
  entered = false;
  release_gate = false;
  fail_write = fail;
}
void Release() {
  std::lock_guard l(gate_mu);
  release_gate = true;
  gate_cv.notify_all();
}
void Reset() {
  std::lock_guard l(gate_mu);
  gate = 0;
  release_gate = true;
  fail_write = false;
  reads.clear();
  writes.clear();
  gate_cv.notify_all();
}
bool Entered() {
  std::unique_lock l(gate_mu);
  return gate_cv.wait_for(l, 10s, [] { return entered; });
}
size_t ReadCount() {
  std::lock_guard l(gate_mu);
  size_t n = 0;
  for (auto [_, c] : reads)
    n += c;
  return n;
}
struct GateCleanup {
  ~GateCleanup() { Release(); }
};
} // namespace
extern "C" ssize_t __wrap_pread(int fd, void *buf, size_t n, off_t off) {
  if (IsMetadata(fd, off)) {
    std::unique_lock l(gate_mu);
    ++reads[off];
    if (gate == 'r') {
      gate = 0;
      entered = true;
      blocked_offset = off;
      gate_cv.notify_all();
      gate_cv.wait(l, [] { return release_gate; });
    }
  }
  return __real_pread(fd, buf, n, off);
}
extern "C" ssize_t __wrap_pwrite(int fd, const void *buf, size_t n, off_t off) {
  if (IsMetadata(fd, off)) {
    std::unique_lock l(gate_mu);
    ++writes[off];
    if (gate == 'w') {
      gate = 0;
      entered = true;
      blocked_offset = off;
      gate_cv.notify_all();
      gate_cv.wait(l, [] { return release_gate; });
      if (fail_write) {
        errno = EIO;
        return -1;
      }
    }
  }
  return __real_pwrite(fd, buf, n, off);
}
namespace {
void Drain(MetadataEngine &e) {
  for (size_t i = 0; i < 256; ++i) {
    auto r = e.Writeback(4);
    ASSERT_NE(r.outcome_, MetadataWritebackOutcome::Failed);
    if (r.outcome_ == MetadataWritebackOutcome::Clean)
      return;
  }
  FAIL() << "writeback queue failed to drain";
}
struct Database {
  Image image;
  Stack stack{image.path, true};
  std::unique_ptr<MetadataEngine> engine;
  Model model;
  explicit Database(uint32_t frames = 24) {
    Reset();
    stack.metadata.max_live_pages_ = frames;
    engine = std::make_unique<MetadataEngine>(stack.boot, stack.jid,
                                              stack.journal, stack.metadata);
    engine->Create();
  }
  void Fill(size_t n = 48) {
    for (size_t i = 0; i < n; ++i) {
      Put(*engine, i, 4300 + (i % 5) * 83, i + 1, model);
      Drain(*engine);
      if (i % 6 == 5) {
        ASSERT_EQ(engine->Checkpoint(4).outcome_,
                  MetadataCheckpointOutcome::Durable);
      }
    }
  }
  void Check(const MetadataSnapshot &v) {
    auto all = v.Scan({0, 0, 0}, 10000);
    ASSERT_EQ(all.size(), model.size());
    size_t i = 0;
    for (const auto &[k, value] : model) {
      EXPECT_EQ(std::make_tuple(all[i].key_.category_, all[i].key_.owner_,
                                all[i].key_.item_),
                k);
      EXPECT_EQ(all[i++].value_, value);
    }
  }
  void Reopen() {
    engine->Close();
    engine.reset();
    engine = std::make_unique<MetadataEngine>(stack.boot, stack.jid,
                                              stack.journal, stack.metadata);
    engine->Open();
  }
  ~Database() {
    Release();
    engine->Close();
    Reset();
  }
};
auto Options(const Image &image) -> NodeStorageOptions {
  BlockDevice dev(image.path, {});
  const auto u = static_cast<uint32_t>(
      std::lcm<uint64_t>(4096, 4ULL * std::max(dev.Info().offset_alignment_,
                                               dev.Info().memory_alignment_)));
  Require(u <= 16384, "alignment exceeds fixture budget");
  BootstrapIdentity id{};
  id.storage_.fill(11);
  id.device_.fill(31);
  JournalIdentity jid{};
  jid.fill(73);
  return {image.path,
          {},
          {3, 2048, 16 * MIB},
          id,
          jid,
          {4ULL * u, u, 32 * u, MIB, 128, 2 * MIB, 8, 32, 4 * MIB},
          {256, 2048, 16384, 64 * 1024},
          {1, 1ms, 1000ms},
          ObjectStorageOptions{{u, 64, MIB, 2 * MIB, 8, 1024, 4096},
                               {2, 512, 128 * 1024, 256, 32},
                               {64, 64, 1024, 8, 2 * MIB, 16},
                               2 * MIB,
                               2 * MIB},
          ObjectTransactionOptions{16, 16, 32 * u, 4 * MIB, 2ms, 1h, 16 * u,
                                   128 * u, 16}};
}
auto Layout(const NodeStorageOptions &o) -> BootstrapLayout {
  return {o.identity_,
          8 * MIB,
          {Range(2 * MIB, MIB), Range(JOURNAL_START, 2 * MIB),
           Range(6 * MIB, 2 * MIB)}};
}
TEST(F32Cache, ObjectCommonDeferredAndReopenWithSmallMetadataCache) {
  Image image;
  auto opts = Options(image);
  opts.metadata_.max_live_pages_ = 32;
  opts.memory_budget_ = ResourceBudgetOptions{64 * MIB, 4096, 4 * MIB};
  auto node = std::make_unique<NodeStorage>(opts);
  node->Create(Layout(opts));
  node->InitializeObjects();
  const auto space = node->CreateObjectSpace(node->Objects());
  ASSERT_TRUE(space.space_);
  ObjectKey key{*space.space_, 71};
  ASSERT_EQ(
      node->CreateObject(node->Objects(), key, 0, ObjectSizeMode::Variable)
          .outcome_,
      JournalOutcome::Durable);
  const auto unit = opts.objects_->allocator_.allocation_bytes_;
  std::vector<Bytes> values;
  for (uint64_t i = 0; i < 64; ++i) {
    values.push_back(s5::Value(unit, i + 5));
    ObjectMutation op{ObjectOperation::Write, key, (3 * i + 1) * unit,
                      ObjectSizeMode::Variable, values.back()};
    op.common_only_ = i % 2 == 0;
    ObjectTransaction transaction{{op}, {}};
    auto submitted = node->SubmitObjects(transaction);
    ASSERT_EQ(submitted.admission_, IOAdmission::Accepted);
    submitted.ticket_->Wait();
    ASSERT_EQ(submitted.ticket_->Result().outcome_, JournalOutcome::Durable);
    for (;;) {
      auto r = node->Writeback(4);
      ASSERT_NE(r.outcome_, MetadataWritebackOutcome::Failed);
      if (r.outcome_ == MetadataWritebackOutcome::Clean)
        break;
    }
    if (i % 4 == 3) {
      ASSERT_EQ(node->Checkpoint(4).outcome_,
                MetadataCheckpointOutcome::Durable);
    }
  }
  auto check = [&] {
    for (uint64_t i = 0; i < values.size(); ++i) {
      auto ticket =
          node->ReadObject(node->Objects(), key, (3 * i + 1) * unit, unit);
      ticket.Wait();
      Bytes got(unit);
      ticket.CopyTo(got.data(), got.size());
      EXPECT_EQ(got, values[i]);
    }
  };
  check();
  node->Close();
  node.reset();
  node = std::make_unique<NodeStorage>(opts);
  node->Open();
  check();
  node->Close();
}
TEST(F32Cache, WorkingSetExceedsBodiesAndRestartsFromCheckpointAndRedo) {
  Database db;
  db.Fill();
  // Cold load fails after the PageImage allocation, before its shared owner is
  // created. Retrying beyond cache capacity must not undercount live bodies.
  // This value is larger than the body-detection band, so allocating the
  // returned value cannot be mistaken for allocating a cached page body.
  const auto fault_key = Key(2);
  ASSERT_GT(
      db.model.at({fault_key.category_, fault_key.owner_, fault_key.item_})
          .size(),
      BUSTUB_PAGE_SIZE + 256);
  bool threw = false;
  {
    struct Disarm {
      ~Disarm() { fail_owner = false; }
    } disarm;
    fail_owner = true;
    saw_body = owner_failed = false;
    try {
      db.engine->Read().Get(fault_key);
    } catch (const std::bad_alloc &) {
      threw = true;
    }
  }
  ASSERT_TRUE(owner_failed) << "shared owner allocation injection did not run";
  ASSERT_TRUE(threw);
  std::cout << "body allocation=" << body_allocation
            << " following allocation=" << owner_allocation << '\n';
  auto before = ReadCount();
  db.Check(db.engine->Read());
  EXPECT_GT(ReadCount(), before);
  db.Reopen();
  db.Check(db.engine->Read());
  // Suffix has dirty updates; recovery must reconstruct latest values with the
  // same small cache, without requiring all persistent bodies to fit in RAM.
  for (auto k : {1U, 19U, 41U}) {
    SCOPED_TRACE(k);
    Put(*db.engine, k, 4901, k + 100, db.model);
    if (k != 41)
      Drain(*db.engine);
  }
  db.Reopen();
  db.Check(db.engine->Read());
  auto copy = db.engine->Read().Get(Key(19));
  auto stale = db.engine->Read();
  db.engine->Close();
  EXPECT_THROW(stale.Get(Key(19)), MetadataError);
  EXPECT_EQ(copy, db.model.at({Key(19).category_, Key(19).owner_, 19}));
}
TEST(F32Cache, HeldOldViewsBackpressureThenResumeAfterRelease) {
  Database db(32);
  db.Fill(6);
  std::vector<MetadataSnapshot> held;
  bool busy = false;
  for (unsigned i = 0; i < 48 && !busy; ++i) {
    held.push_back(db.engine->Read());
    try {
      Put(*db.engine, 1, 4603, i + 300, db.model);
      Drain(*db.engine);
      if (i % 2 == 1) {
        ASSERT_EQ(db.engine->Checkpoint(4).outcome_,
                  MetadataCheckpointOutcome::Durable);
      }
    } catch (const MetadataCommitBusy &) {
      busy = true;
    }
  }
  EXPECT_TRUE(busy) << "retained overwritten versions must remain bounded";
  held.clear();
  Drain(*db.engine);
  Put(*db.engine, 1, 4777, 555, db.model);
  Drain(*db.engine);
  db.Check(db.engine->Read());
}
TEST(F32Cache, ColdOldVersionSurvivesOverwriteAndPressure) {
  Database db(32);
  db.Fill();
  auto old = db.engine->Read();
  const auto original = db.model.at({Key(1).category_, Key(1).owner_, 1});
  ASSERT_EQ(old.Get(Key(1)), original);
  db.Check(
      old); // Evict most old bodies, including early record/overflow pages.
  Put(*db.engine, 1, 5007, 211, db.model);
  Drain(*db.engine);
  db.Check(db.engine->Read());
  EXPECT_EQ(old.Get(Key(1)), original);
  EXPECT_EQ(db.engine->Read().Get(Key(1)),
            db.model.at({Key(1).category_, Key(1).owner_, 1}));
}
TEST(F32Cache, SameVersionLoadsCoalesceAndUnrelatedHitsProgress) {
  Database db;
  db.Fill();
  auto view = db.engine->Read();
  db.Check(view); // sweep so the selected early value is cold
  const auto hot = Key(47);
  const auto hot_value = db.model.at({hot.category_, hot.owner_, hot.item_});
  ASSERT_EQ(view.Get(hot), hot_value); // warm the independent hit
  Reset();
  Arm('r');
  auto cold = std::async(std::launch::async, [&] { return view.Get(Key(0)); });
  GateCleanup cleanup;
  ASSERT_TRUE(Entered());
  std::vector<std::future<std::optional<Bytes>>> peers;
  for (int i = 0; i < 6; ++i)
    peers.push_back(
        std::async(std::launch::async, [&] { return view.Get(Key(0)); }));
  auto hit = std::async(std::launch::async, [&] { return view.Get(hot); });
  const auto ready = hit.wait_for(2s);
  Release();
  EXPECT_EQ(ready, std::future_status::ready)
      << "unrelated resident hit blocked by cold IO";
  EXPECT_EQ(hit.get(), hot_value);
  const auto expected = db.model.at({Key(0).category_, Key(0).owner_, 0});
  auto check = [&](auto &future) {
    try {
      EXPECT_EQ(future.get(), expected);
    } catch (const std::exception &error) {
      ADD_FAILURE() << error.what();
    }
  };
  check(cold);
  for (auto &p : peers)
    check(p);
  std::lock_guard l(gate_mu);
  EXPECT_EQ(reads[blocked_offset], 1U) << "duplicate load of one version";
}
TEST(F32Cache, OlderCompletionKeepsNewerPendingAndQueueDeduplicates) {
  Database db(64);
  Put(*db.engine, 7, 101, 4, db.model);
  Drain(*db.engine);
  Put(*db.engine, 7, 101, 5, db.model);
  Arm('w');
  auto pending =
      std::async(std::launch::async, [&] { return db.engine->Writeback(16); });
  GateCleanup cleanup;
  ASSERT_TRUE(Entered());
  Put(*db.engine, 7, 101, 6, db.model);
  Put(*db.engine, 7, 101, 7, db.model);
  Release();
  EXPECT_EQ(pending.get().outcome_, MetadataWritebackOutcome::Durable);
  Reset();
  Drain(*db.engine);
  {
    std::lock_guard l(gate_mu);
    ASSERT_FALSE(writes.empty());
    for (auto [_, n] : writes)
      EXPECT_EQ(n, 1U) << "same physical page queued repeatedly";
  }
  ASSERT_EQ(db.engine->Checkpoint(4).outcome_,
            MetadataCheckpointOutcome::Durable);
  db.Reopen();
  db.Check(db.engine->Read());
}
TEST(F32Cache, FailedOverwriteRetainsOldViewAndPendingWork) {
  Database db(48);
  Put(*db.engine, 9, 4401, 12, db.model);
  Drain(*db.engine);
  auto old = db.engine->Read();
  const auto expected = db.model.at({Key(9).category_, Key(9).owner_, 9});
  ASSERT_EQ(old.Get(Key(9)), expected);
  Put(*db.engine, 9, 4503, 13, db.model);
  Arm('w', true);
  auto pending =
      std::async(std::launch::async, [&] { return db.engine->Writeback(8); });
  GateCleanup cleanup;
  ASSERT_TRUE(Entered());
  Release();
  EXPECT_EQ(pending.get().outcome_, MetadataWritebackOutcome::Failed);
  EXPECT_EQ(old.Get(Key(9)), expected);
  Reset();
  Drain(*db.engine);
  db.Check(db.engine->Read());
  db.Reopen();
  db.Check(db.engine->Read());
}
TEST(F32Cache, ColdReadChecksActualPersistentBytes) {
  Database db;
  db.Fill();
  db.Check(db.engine->Read());
  // Observe the real missing position, then corrupt it without changing CRC.
  Arm('r');
  auto read = std::async(std::launch::async,
                         [&] { return db.engine->Read().Get(Key(0)); });
  GateCleanup cleanup;
  ASSERT_TRUE(Entered());
  off_t offset;
  {
    std::lock_guard l(gate_mu);
    offset = blocked_offset;
  }
  auto bytes = db.image.Read(offset + 97, 1);
  bytes[0] ^= 0x40;
  db.image.Write(offset + 97, bytes);
  Release();
  EXPECT_THROW(read.get(), MetadataError);
}
TEST(F32Cache, CloseDrainsAdmittedColdRead) {
  Database db;
  db.Fill();
  db.Check(db.engine->Read());
  auto view = db.engine->Read();
  Arm('r');
  auto read = std::async(std::launch::async, [&] { return view.Get(Key(0)); });
  GateCleanup cleanup;
  ASSERT_TRUE(Entered());
  auto close = std::async(std::launch::async, [&] { db.engine->Close(); });
  auto state = close.wait_for(30ms);
  Release();
  EXPECT_EQ(state, std::future_status::timeout);
  EXPECT_EQ(read.get(), db.model.at({Key(0).category_, Key(0).owner_, 0}));
  close.get();
  EXPECT_THROW(view.Scan({0, 0, 0}, 1), MetadataError);
}
TEST(F32Cache, ClockProFindsSoleEligibleFrameDuringChurn) {
  for (size_t capacity : {1U, 3U, 16U}) {
    ClockProReplacer policy(capacity, nullptr);
    std::vector<uint64_t> keys(capacity);
    for (size_t i = 0; i < capacity; ++i) {
      keys[i] = i;
      policy.Admit(i, {i, 0, 0});
    }
    EXPECT_FALSE(policy.Candidate());
    for (uint64_t round = 0; round < 800; ++round) {
      auto f = round % capacity;
      policy.SetEvictable(f, true);
      auto chosen = policy.Candidate();
      ASSERT_EQ(chosen, static_cast<frame_id_t>(f));
      policy.Evicted(f);
      keys[f] = round % 2 ? round + capacity : keys[f];
      policy.Admit(f, {keys[f], 0, 0});
      policy.RecordAccess(f);
    }
    for (size_t i = 0; i < capacity; ++i)
      policy.Remove(i);
    EXPECT_FALSE(policy.Candidate());
  }
}
TEST(F32Cache, ClockProProtectsReusedPagesAcrossScansAndHotsetChanges) {
  // CLOCK's second-chance contract, without reading its private hands/classes.
  // All four initial pages are eligible; only the oldest page is referenced.
  ClockProReplacer initial(4, nullptr);
  for (frame_id_t i = 0; i < 4; ++i) {
    initial.Admit(i, {static_cast<uint64_t>(i), 0, 0});
    initial.SetEvictable(i, true);
  }
  initial.RecordAccess(0);
  auto victim = initial.Candidate();
  ASSERT_TRUE(victim);
  EXPECT_NE(*victim, 0) << "referenced page must receive a second chance";

  // A recently evicted identity is promoted on a test-period re-access.
  // A new identity (including a new B generation/LSN) has no such history.
  // Observe victims only; never inspect the private hands or hot/cold counters.
  for (unsigned kind = 0; kind < 4; ++kind) {
    SCOPED_TRACE(kind);
    constexpr frame_id_t frames = 4;
    ClockProReplacer history(frames, nullptr);
    for (frame_id_t f = 0; f < frames; ++f) {
      history.Admit(f, {static_cast<uint64_t>(f), 7, 99});
      history.SetEvictable(f, true);
    }
    const auto first = history.Candidate();
    ASSERT_TRUE(first);
    history.Evicted(*first);
    ClockProReplacer::Key key{static_cast<uint64_t>(*first), 7, 99};
    if (kind != 0)
      ++key[kind - 1];
    // Changing page id must not collide with another resident identity.
    if (kind == 1)
      key[0] += 100;
    history.Admit(*first, key);
    history.SetEvictable(*first, true);
    bool lost = false;
    for (unsigned round = 0; round < frames; ++round) {
      auto f = history.Candidate();
      ASSERT_TRUE(f);
      if (*f == *first) {
        lost = true;
        break;
      }
      history.Evicted(*f);
      history.Admit(*f, {1000 + round, 7, 99});
      history.SetEvictable(*f, true);
    }
    EXPECT_EQ(lost, kind != 0)
        << "test-period history must protect the same full page identity only";
  }

  constexpr size_t capacity = 12;
  ClockProReplacer policy(capacity, nullptr);
  std::unordered_map<uint64_t, frame_id_t> resident;
  std::vector<uint64_t> owners(capacity);
  size_t hot_misses = 0;
  auto touch = [&](uint64_t key, bool hot) {
    auto it = resident.find(key);
    if (it != resident.end()) {
      policy.RecordAccess(it->second);
      return;
    }
    if (hot)
      ++hot_misses;
    frame_id_t f;
    if (resident.size() < capacity)
      f = resident.size();
    else {
      auto victim = policy.Candidate();
      ASSERT_TRUE(victim);
      f = *victim;
      resident.erase(owners[f]);
      policy.Evicted(f);
    }
    policy.Admit(f, {key, 0, 0});
    policy.SetEvictable(f, true);
    owners[f] = key;
    resident[key] = f;
  };
  for (uint64_t phase = 0; phase < 2; ++phase) {
    hot_misses = 0;
    for (uint64_t i = 0; i < 300; ++i) {
      for (uint64_t h = 0; h < 3; ++h)
        touch(phase * 10 + h, true);
      touch(100 + i + phase * 1000, false);
    }
    std::cout << "phase=" << phase << " hot_misses=" << hot_misses << "/900\n";
    EXPECT_LT(hot_misses, 30U)
        << "repeated hot set must not be swept out by one-use pages";
  }
}
} // namespace
