# F32 阶段验证恢复

基准提交为 `8b1805c`，本轮生产实现及测试哈希以 MANIFEST.json 为准；源码包只包含最终测试和 runner，不包含构建/设备文件。源码在当前工作树，若恢复历史版本，可将本地 `F32-results.tar.gz` 中 `source/` 覆盖隔离基准 checkout 后核对 production_sha256。

## 环境与构建

本次 Linux 文件设备支持 O_DIRECT，对齐通过正式 F01 查询。使用 `/tmp/bustub-gcc16` 的 GCC16/libstdc++，以满足已有共享零页实现需要的 C++23 库接口；其余目标仍按项目语言标准编译。ASan/LSan 开启。工具链下载 https://github.com/tttapa/toolchains/releases/download/1.4.0/x-tools-x86_64-focal-linux-gnu-gcc16.tar.xz ，SHA256 `204d2e395e59eb4d81f8bb8bc7fa06928b9735cb7f0a83cbbf7f6b4219870e18`；将 x-tools/x86_64-focal-linux-gnu 移到 /tmp/bustub-gcc16，native-runtime 只放该工具链的 libstdc++/libgcc_s/libasan/libubsan/libtsan，不放旧 libc。需要 Python 支持 tarfile 的 data filter。LSan 必须在允许其运行的环境执行，ptrace 环境报错不能算通过。

将包解压到仓库外，所有 --out 路径使用新的临时目录。命令以实际路径替换 `<repo>`、`<build>`、`<package>`、`<normal>` 等占位符：

```sh
cmake -S <repo> -B <build> -DCMAKE_BUILD_TYPE=Debug \
 -DCMAKE_C_COMPILER=/tmp/bustub-gcc16/bin/x86_64-focal-linux-gnu-gcc \
 -DCMAKE_CXX_COMPILER=/tmp/bustub-gcc16/bin/x86_64-focal-linux-gnu-g++ \
 '-DCMAKE_C_FLAGS=--sysroot=/ -isystem /usr/include/x86_64-linux-gnu' \
 '-DCMAKE_CXX_FLAGS=--sysroot=/ -isystem /usr/include/x86_64-linux-gnu'
cmake --build <build> --target bustub gtest gmock_main -j3
python3 <package>/run_stage.py --repo <repo> --build <build> --out <normal>
python3 <package>/run_regressions.py --repo <repo> --build <build> --out <regression>
python3 <package>/run_mutations.py --repo <repo> --build <build> --normal <normal> --out <mutation>
```

先运行 run_stage 校验当前 production/test/dependency 哈希。回归 runner 在临时解包目录移除旧模块对旧生产版本的 hash 限制，不修改原测试的输入/oracle；依赖包本身由本包 MANIFEST 固定，不能将历史结果当作当前结果。变异 runner 依赖本轮正常运行的 commands.json 和解包夹具，复制生产文件后单独编译，绝不编辑工作树。

## 证据与交接

最终 11 个新场景 + 66 个复用检查，共 77 项通过；66 中有 1 项历史 LRU-K 课程兼容检查，非新策略证据。12 个变异必须返回指定测试失败及对应 oracle，编译错误、超时、sanitizer 崩溃不计。具体目标、输入、真实路径、独立 oracle、重复/污染/稳定性审查见 docs/storage_redesign/s12_cache_execution_20261008.md。

2026-10-09 前次复审修复 NewImage 计账并扩展 T2/T11，完整运行 77/12。本次再次复审未改生产库逻辑，三个 benchmark 改为直接包含 AccessType 头并重编译，T4/T5/T7 改用独立输入模型，删除 T5 冗余预热；旧版重读变异收紧失败判据。重跑 F32 11 项与 12 个变异，另 66 项沿用相同生产库及依赖哈希的前次证据，不能声称全 77 项均在此次重新执行。当前 MANIFEST 固定新断言，旧 F32 包原位替换。

风险交接：B/version-reload、held-body-budget、coalesced-IO、pending-version、close-drain、A/competing-load、policy/pin-and-second-chance。共同生产 E2E 接管同一风险后合并退出阶段用例。未运行完整 C/P、SS/RS/PL/GT 性能对照、TSan、裸设备或真实掉电；热点轨迹不代表性能结论。

阶段源码只保留此包，结果只保留最终本地结果包；运行后删除解包源码、构建、镜像及变异副本。本次原位替换旧 F32 源码/结果包，不保留旧版本。有效 S5/F26/F27/F29/F30/F31/S8 依赖包继续保留。
