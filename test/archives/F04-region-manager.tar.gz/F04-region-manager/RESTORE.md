# F04 archived stage checks

This is an opt-in component suite, not a permanent CTest target or SQL/Raft E2E.
Restore under a separate /tmp directory, not test/ in the production checkout.

1. Use the manifest's base commit plus its recorded working-tree implementation.
   The local results archive contains exact production bytes under source/. On a
   later checkout use an isolated checkout and those snapshots; do not overwrite
   unrelated current work. Verify every production_sha256 before running.
2. Keep test/archives/F03-bootstrap.tar.gz from that checkout. The runner checks
   its SHA-256, reuses its unchanged eight tests and never registers them.
3. Linux, clang/clang++/clang-format/clang-tidy 14, CMake, GCC and the repository's
   third_party dependencies are required. The test file system must support the
   actual Direct IO queries/geometry; failure is not an implicit Buffered fallback.
4. Run from anywhere (substitute the two absolute paths):

```sh
python3 /tmp/f04-source/F04-region-manager/test/storage_redesign/run_stage.py \
  --repo /path/to/matching-checkout --work /tmp/f04-run --mutations
```

The runner builds with -j2, ASan/UBSan/LeakSanitizer enabled, checks every expected
XML case, then compiles and runs six isolated mutations. Review their assertion
messages: exit code alone is insufficient. No real raw disk is touched. At most
two 16 MiB private device files are used; they are removed by RAII. Five seconds
is an IO watchdog and 120 seconds the process cap, not a performance objective.

Keep final source/results compressed after review and remove the dedicated build,
restored files and binaries. In sandbox environments where LeakSanitizer or the
runner cannot execute, use an authorized compatible environment rather than
turning off checks or counting skipped cases as passed. The original F03 archive
remains a valid historical dependency and must not be deleted as an F04 old copy.
