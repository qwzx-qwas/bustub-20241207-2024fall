"""Opt-in F04 real component checks; restore outside the regular test tree."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tarfile
import time
import xml.etree.ElementTree as ET

TESTS = {'RegionsUseIndependentPhysicalOraclesAcrossLayouts',
         'InvalidBindingOrMemberRejectsTheWholePreparation',
         'F02AdmissionLeasesAndDeviceFailuresKeepTheirMeaning'}
F03_TESTS = {'CreationAndIndependentFixturesAgreeOnDurableLayout',
             'OpenRejectsAmbiguityAndUnknownFormatsWithoutWriting',
             'CreateProtectsExistingContentsAndRejectsInvalidRegions',
             'CreationFailureCannotBecomeDurableSuccessOrBlindRecreate',
             'RepairIsAsyncPreservesSourceAndAllowsIndependentIO',
             'RepairRetriesRequireSuccessfulFlushAndReadback',
             'AdmissionFailureIsBoundedAndDoesNotChangeCopies',
             'CloseDrainsAcceptedRepairAndWakesAdmissionWait'}
F03_ARCHIVE_SHA256 = '1e58ef0eb395a9b4d951e3eddbd2eb5c345971f1165516b4a76c69fc3be27c60'

def check_xml(path, suite, names):
    x = ET.parse(path).getroot()
    cases = x.findall('./testsuite/testcase')
    if (len(cases) != len(names) or {(c.get('classname'), c.get('name')) for c in cases} != {(suite, n) for n in names}
        or any(x.get(k) != '0' for k in ('errors', 'failures', 'disabled'))
        or any(c.get('status') != 'run' or c.get('result') != 'completed'
               or any(c.find(t) is not None for t in ('failure', 'error', 'skipped')) for c in cases)):
        raise RuntimeError(f'{suite}: incomplete or failed run')

parser = argparse.ArgumentParser()
parser.add_argument('--repo', type=Path, required=True)
parser.add_argument('--work', type=Path, required=True)
parser.add_argument('--mutations', action='store_true')
args = parser.parse_args()
repo, work = args.repo.resolve(), args.work.resolve()
work.mkdir(parents=True, exist_ok=True)
source = Path(__file__).with_name('region_manager_test.cpp')
build = work / 'build'
commands = []
env = {k: v for k, v in os.environ.items() if not k.startswith('GTEST_')}
env.update(ASAN_OPTIONS='detect_leaks=1:halt_on_error=1', UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1',
           F04_WORKDIR=str(work), F03_WORKDIR=str(work))
(work / 'environment.json').write_text(json.dumps({k:env[k] for k in ('ASAN_OPTIONS','UBSAN_OPTIONS','F04_WORKDIR','F03_WORKDIR')},indent=2)+'\n')

def call(argv, log, expected=0, timeout=180):
    start = time.monotonic()
    entry = {'command': argv, 'log': log}
    commands.append(entry)
    try:
        with (work/log).open('w') as f:
            result = subprocess.run(argv,cwd=repo,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
        entry['returncode'] = result.returncode
        if expected is not None and result.returncode != expected:
            raise RuntimeError(f'{log}: exit {result.returncode}; expected {expected}')
        return result.returncode
    except subprocess.TimeoutExpired:
        entry['timeout_seconds'] = timeout
        raise
    finally:
        entry['elapsed_seconds'] = time.monotonic()-start
        (work/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')

call(['cmake','-S',str(repo),'-B',str(build),'-DCMAKE_BUILD_TYPE=Debug','-DCMAKE_C_COMPILER=clang-14',
      '-DCMAKE_CXX_COMPILER=clang++-14','-DBUSTUB_SANITIZER=address,undefined','-DCMAKE_EXE_LINKER_FLAGS=-no-pie'], 'configure.log')
call(['cmake','--build',str(build),'--target','bustub_storage_disk','gtest_main','-j2'],'build.log')
flags=['clang++-14','-std=c++17','-Wall','-Wextra','-Werror','-Wno-unused-parameter','-pthread','-g','-O0',
       '-fsanitize=address,undefined','-fno-omit-frame-pointer','-I'+str(repo/'src/include'),
       '-I'+str(repo/'third_party/googletest/googletest/include')]
objects=build/'src/storage/disk/CMakeFiles/bustub_storage_disk.dir'
codec=work/'byte-codec.o'
call(flags+['-c',str(repo/'src/common/byte_codec.cpp'),'-o',str(codec)],'codec-compile.log')
common=[str(objects/'block_device.cpp.o'),str(objects/'io_executor.cpp.o'),str(codec),
        str(build/'lib/libgtest_main.a'),str(build/'lib/libgtest.a'),'-Wl,--wrap=pwrite','-Wl,--wrap=fdatasync']
test_obj=work/'stage-test.o'
call(flags+['-c',str(source),'-o',str(test_obj)],'test-compile.log')
bootstrap_obj=objects/'bootstrap_store.cpp.o'
region_obj=objects/'region_manager.cpp.o'
def link(exe, region, bootstrap):
    call(flags+['-no-pie',str(region),str(bootstrap),str(test_obj)]+common+['-o',str(exe)],exe.name+'-link.log')
binary=work/'stage-test';link(binary,region_obj,bootstrap_obj)
xml=work/'results.xml';xml.unlink(missing_ok=True)
call([str(binary),'--gtest_filter=RegionTest.*','--gtest_repeat=1','--gtest_shuffle=0','--gtest_output=xml:'+str(xml)],'run.log',timeout=120)
check_xml(xml,'RegionTest',TESTS)
print('F04: 3/3 real component checks passed',flush=True)

# Reuse the existing exact F03 test source; do not copy its suite into the F04 archive.
archive=repo/'test/archives/F03-bootstrap.tar.gz'
if hashlib.sha256(archive.read_bytes()).hexdigest()!=F03_ARCHIVE_SHA256:
    raise RuntimeError('F03 dependency changed; review the regression source before running')
with tarfile.open(archive) as t:
    f03_source=t.extractfile('F03-bootstrap/test/storage_redesign/bootstrap_store_test.cpp').read()
f03=work/'f03-regression.cpp';f03.write_bytes(f03_source)
f03_obj=work/'f03-regression.o'
call(flags+['-c',str(f03),'-o',str(f03_obj)],'f03-compile.log')
f03_exe=work/'f03-regression'
call(flags+['-no-pie',str(bootstrap_obj),str(f03_obj)]+common+
     ['-Wl,--wrap=pread','-Wl,--wrap=pthread_cond_clockwait','-o',str(f03_exe)],'f03-link.log')
f03_xml=work/'f03-results.xml';f03_xml.unlink(missing_ok=True)
call([str(f03_exe),'--gtest_filter=BootstrapTest.*','--gtest_repeat=1','--gtest_shuffle=0',
      '--gtest_output=xml:'+str(f03_xml)],'f03-run.log',timeout=120)
check_xml(f03_xml,'BootstrapTest',F03_TESTS)
print('F03: 8/8 unchanged archived regression checks passed',flush=True)

if args.mutations:
    original=(repo/'src/storage/disk/region_manager.cpp').read_text()
    original_boot=(repo/'src/storage/disk/bootstrap_store.cpp').read_text()
    mutations=[]
    def add(name,old,new,test,bootstrap=False):
        s=original_boot if bootstrap else original
        if s.count(old)!=1: raise RuntimeError(name+': source drift')
        mutations.append((name,s.replace(old,new),test,bootstrap))
    add('wrong_base','region.Subrange(request.offset_, request.size_)',
        '(static_cast<void>(region), StorageByteRange::Create(request.offset_, request.size_))',
        'RegionsUseIndependentPhysicalOraclesAcrossLayouts')
    add('ignore_binding','if (request.region_.context_ != context_)',
        'if (false && request.region_.context_ != context_)','InvalidBindingOrMemberRejectsTheWholePreparation')
    add('escape_region','region.Subrange(request.offset_, request.size_)',
        'StorageByteRange::Create(region.Offset() + request.offset_, request.size_)',
        'InvalidBindingOrMemberRejectsTheWholePreparation')
    add('drop_owned_flush','TryPrepare(Resolve(requests), flush_after_writes)',
        'TryPrepare(Resolve(requests), false && flush_after_writes)','RegionsUseIndependentPhysicalOraclesAcrossLayouts')
    add('drop_external_flush','TryPrepareExternal(Resolve(requests), leases, flush_after_writes)',
        'TryPrepareExternal(Resolve(requests), leases, false && flush_after_writes)',
        'InvalidBindingOrMemberRejectsTheWholePreparation')
    add('bind_closed','if (impl_->closed_ || !impl_->opened_) {\n    throw std::logic_error("region binding requires',
        'if (!impl_->opened_) {\n    throw std::logic_error("region binding requires',
        'InvalidBindingOrMemberRejectsTheWholePreparation',True)
    results=[]
    for name,content,test,boot in mutations:
        cpp,obj,exe=work/(name+'.cpp'),work/(name+'.o'),work/name
        cpp.write_text(content)
        call(flags+['-c',str(cpp),'-o',str(obj)],name+'-compile.log')
        link(exe,region_obj if boot else obj,obj if boot else bootstrap_obj)
        result=call([str(exe),'--gtest_filter=RegionTest.'+test],name+'-run.log',expected=None,timeout=120)
        log=(work/(name+'-run.log')).read_text()
        caught=(result==1 and '[  FAILED  ] RegionTest.'+test in log and
                not any(x in log for x in ('AddressSanitizer:','LeakSanitizer:','runtime error:')))
        results.append({'mutation':name,'test':test,'returncode':result,'caught':caught,
                        'source_sha256':hashlib.sha256(content.encode()).hexdigest()})
        (work/'mutations.json').write_text(json.dumps(results,indent=2)+'\n')
        if not caught: raise RuntimeError(name+': inspect failure; not an intended assertion detection')
    print('F04: 6/6 isolated mutations caught; inspect individual failure logs',flush=True)
