#include <fcntl.h>
#include <unistd.h>

#include <algorithm>
#include <atomic>
#include <cerrno>
#include <chrono>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <limits>
#include <memory>
#include <optional>
#include <stdexcept>
#include <string>
#include <system_error>
#include <vector>

#include "gtest/gtest.h"
#include "storage/disk/bootstrap_store.h"
#include "storage/disk/region_manager.h"

extern "C" ssize_t __real_pwrite(int, const void *, size_t, off_t);
extern "C" int __real_fdatasync(int);
namespace {
std::atomic<bool> fail_write{false};
std::atomic<bool> fail_flush{false};
std::atomic<size_t> successful_flushes{0};
}  // namespace
extern "C" ssize_t __wrap_pwrite(int fd, const void *buffer, size_t size, off_t offset) {
  if (fail_write.exchange(false)) {
    errno = EIO;
    return -1;
  }
  return __real_pwrite(fd, buffer, size, offset);
}
extern "C" int __wrap_fdatasync(int fd) {
  if (fail_flush.exchange(false)) {
    errno = EIO;
    return -1;
  }
  const auto result = __real_fdatasync(fd);
  if (result == 0) {
    successful_flushes.fetch_add(1);
  }
  return result;
}

namespace bustub {
namespace {
using namespace std::chrono_literals;
constexpr uint64_t MIB = 1024 * 1024;
constexpr size_t CAPACITY = 16 * MIB;
using Bytes = std::vector<unsigned char>;

auto Range(uint64_t offset, uint64_t size) -> StorageByteRange {
  auto result = StorageByteRange::Create(offset, size);
  if (!result) {
    throw std::invalid_argument("bad test layout");
  }
  return *result;
}

struct RawFile {
  int fd_{-1};
  std::string path_;
  explicit RawFile(unsigned seed) {
    const char *directory = std::getenv("F04_WORKDIR");
    if (directory == nullptr) {
      throw std::runtime_error("runner must set F04_WORKDIR");
    }
    std::string name = std::string(directory) + "/device-XXXXXX";
    fd_ = mkstemp(name.data());
    if (fd_ < 0) {
      throw std::system_error(errno, std::generic_category(), "mkstemp");
    }
    path_ = name;
    try {
      Bytes image(CAPACITY);
      for (size_t i = 0; i < image.size(); ++i) {
        image[i] = static_cast<unsigned char>((i * 17 + (i / 131) * 7 + seed * 19) % 251);
      }
      std::fill_n(image.begin(), 65536, 0);
      std::fill_n(image.begin() + MIB, 65536, 0);
      size_t done = 0;
      while (done < image.size()) {
        const auto n = __real_pwrite(fd_, image.data() + done, image.size() - done, static_cast<off_t>(done));
        if (n < 0 && errno == EINTR) {
          continue;
        }
        if (n <= 0) {
          throw std::runtime_error("fixture write failed");
        }
        done += static_cast<size_t>(n);
      }
      if (__real_fdatasync(fd_) != 0) {
        throw std::system_error(errno, std::generic_category(), "fixture sync");
      }
    } catch (...) {
      close(fd_);
      unlink(path_.c_str());
      throw;
    }
  }
  ~RawFile() {
    close(fd_);
    unlink(path_.c_str());
  }
  auto ReadAll() const -> Bytes {
    if (std::filesystem::file_size(path_) != CAPACITY) {
      throw std::runtime_error("device size changed");
    }
    Bytes image(CAPACITY);
    size_t done = 0;
    while (done < image.size()) {
      const auto n = pread(fd_, image.data() + done, image.size() - done, static_cast<off_t>(done));
      if (n < 0 && errno == EINTR) {
        continue;
      }
      if (n <= 0) {
        throw std::runtime_error("independent oracle read failed");
      }
      done += static_cast<size_t>(n);
    }
    return image;
  }
};

struct Store {
  RawFile file_;
  BlockDevice device_;
  IOExecutor io_;
  BootstrapStore bootstrap_;
  BootstrapLayout layout_;
  size_t length_;
  explicit Store(unsigned variant)
      : file_(variant),
        device_(file_.path_, BlockDeviceOptions{}),
        io_(device_, {2, 8, MIB}, MIB),
        bootstrap_(io_),
        layout_{{},
                CAPACITY,
                {Range((2 + variant) * MIB, MIB), Range((4 + variant) * MIB, 2 * MIB),
                 Range((8 + variant) * MIB, (7 - variant) * MIB)}} {
    layout_.identity_.storage_.fill(static_cast<uint8_t>(11 + variant));
    layout_.identity_.device_.fill(static_cast<uint8_t>(31 + variant));
    const size_t alignment = device_.Info().offset_alignment_;
    length_ = ((4096 + alignment - 1) / alignment) * alignment;
    if (length_ * 8 > MIB) {
      throw std::runtime_error("fixture too small for this device geometry");
    }
    bootstrap_.Create(layout_);
    bootstrap_.Open(layout_.identity_);
  }
};

auto Payload(size_t size, unsigned seed) -> Bytes {
  Bytes result(size);
  for (size_t i = 0; i < size; ++i) {
    result[i] = static_cast<unsigned char>((i * 23 + seed * 41 + i / 19) % 253);
  }
  return result;
}

void Finish(IOExecutor &io, IOBatch &batch) {
  if (io.TrySubmit(batch) != IOAdmission::Accepted || !batch.WaitFor(5s)) {
    throw std::runtime_error("accepted IO did not complete within watchdog");
  }
}

auto Aligned(size_t size, uint32_t alignment) -> std::shared_ptr<char> {
  void *p = nullptr;
  const int error = posix_memalign(&p, std::max<size_t>(alignment, sizeof(void *)), size);
  if (error != 0) {
    throw std::system_error(error, std::generic_category(), "test buffer allocation");
  }
  return {static_cast<char *>(p), std::free};
}

TEST(RegionTest, RegionsUseIndependentPhysicalOraclesAcrossLayouts) {
  for (unsigned variant : {0U, 1U}) {
    SCOPED_TRACE(variant);
    Store s(variant);
    RegionManager manager(s.bootstrap_);
    auto expected = s.file_.ReadAll();
    const std::vector<uint64_t> offsets{0, 2 * s.length_, (7 - variant) * MIB - s.length_};
    const std::vector<uint64_t> starts{(2 + variant) * MIB, (4 + variant) * MIB, (8 + variant) * MIB};
    const std::vector<RegionKind> kinds{RegionKind::Metadata, RegionKind::Journal, RegionKind::Data};
    std::vector<RegionIORequest> requests;
    std::vector<Bytes> payloads;
    for (size_t i = 0; i < 3; ++i) {
      requests.push_back({manager.Region(kinds[i]), IOOperation::Write, offsets[i], s.length_});
      payloads.push_back(Payload(s.length_, static_cast<unsigned>(i + variant * 5)));
      std::copy(payloads.back().begin(), payloads.back().end(), expected.begin() + starts[i] + offsets[i]);
    }
    successful_flushes = 0;
    {
      auto prepared = manager.TryPrepare(requests, true);
      ASSERT_EQ(prepared.admission_, IOAdmission::Accepted);
      auto &batch = *prepared.batch_;
      for (size_t i = 0; i < 3; ++i) {
        std::memcpy(batch.Buffer(i), payloads[i].data(), s.length_);
      }
      Finish(s.io_, batch);
      ASSERT_EQ(batch.Phase(), IOBatchPhase::Succeeded);
      EXPECT_TRUE(batch.Result().writes_durable_);
      EXPECT_GT(successful_flushes.load(), 0U);
    }
    EXPECT_EQ(s.file_.ReadAll(),
              expected);  // Never use F04 to locate the oracle bytes.
    for (auto &request : requests) {
      request.operation_ = IOOperation::Read;
    }
    auto prepared = manager.TryPrepare(requests, false);
    ASSERT_EQ(prepared.admission_, IOAdmission::Accepted);
    Finish(s.io_, *prepared.batch_);
    ASSERT_EQ(prepared.batch_->Phase(), IOBatchPhase::Succeeded);
    for (size_t i = 0; i < 3; ++i) {
      EXPECT_EQ(std::memcmp(prepared.batch_->Buffer(i), payloads[i].data(), s.length_), 0);
    }
  }
}

TEST(RegionTest, InvalidBindingOrMemberRejectsTheWholePreparation) {
  Store a(0);
  Store b(1);  // Same capacity; identity and region locations intentionally differ.
  BootstrapStore unopened(a.io_);
  EXPECT_THROW({ RegionManager invalid(unopened); }, std::logic_error);
  RegionManager manager(a.bootstrap_);
  RegionManager other(b.bootstrap_);
  const auto meta = manager.Region(RegionKind::Metadata);
  const auto before_a = a.file_.ReadAll();
  const auto before_b = b.file_.ReadAll();
  auto reject = [&](const RegionHandle &handle, uint64_t offset, uint64_t size) {
    EXPECT_THROW(manager.TryPrepare(
                     {{meta, IOOperation::Write, a.length_, a.length_}, {handle, IOOperation::Write, offset, size}}, true),
                 std::invalid_argument);
  };
  reject(other.Region(RegionKind::Metadata), 0, a.length_);
  RegionManager same_device(a.bootstrap_);
  reject(same_device.Region(RegionKind::Metadata), 0, a.length_);
  std::optional<RegionHandle> stale;
  {
    RegionManager retired(a.bootstrap_);
    stale = retired.Region(RegionKind::Metadata);
  }
  reject(*stale, 0, a.length_);
  reject(meta, MIB - a.length_ + a.device_.Info().offset_alignment_, a.length_);
  reject(meta, MIB, a.length_);
  reject(meta, std::numeric_limits<uint64_t>::max(), a.length_);
  reject(meta, 0, std::numeric_limits<uint64_t>::max());
  reject(meta, 0, 0);
  EXPECT_THROW(manager.Region(static_cast<RegionKind>(-1)), std::invalid_argument);
  if (a.device_.Info().offset_alignment_ > 1) {
    reject(meta, 3 * a.length_ + 1,
           a.length_);  // Delegated alignment check still happens before IO.
  }
  auto releases = std::make_shared<std::atomic<unsigned>>(0);
  auto data = Aligned(a.length_, a.device_.Info().memory_alignment_);
  std::vector<IOBufferLease> leases;
  leases.push_back(IOBufferLease::ForWrite(data.get(), a.length_, [data, releases] { ++*releases; }));
  EXPECT_THROW(manager.TryPrepareExternal({{other.Region(RegionKind::Metadata), IOOperation::Write, 0, a.length_}},
                                          leases, true),
               std::invalid_argument);
  ASSERT_EQ(leases.size(), 1U);
  EXPECT_EQ(releases->load(), 0U);
  // A rejected range did not consume the only permission; reuse it
  // successfully.
  auto payload = Payload(a.length_, 71);
  std::memcpy(data.get(), payload.data(), payload.size());
  auto prepared = manager.TryPrepareExternal({{meta, IOOperation::Write, 0, a.length_}}, leases, true);
  ASSERT_EQ(prepared.admission_, IOAdmission::Accepted);
  EXPECT_TRUE(leases.empty());
  Finish(a.io_, *prepared.batch_);
  ASSERT_EQ(prepared.batch_->Phase(), IOBatchPhase::Succeeded);
  EXPECT_TRUE(prepared.batch_->Result().writes_durable_);
  EXPECT_EQ(releases->load(), 1U);
  auto expected_a = before_a;
  std::copy(payload.begin(), payload.end(), expected_a.begin() + 2 * MIB);
  EXPECT_EQ(a.file_.ReadAll(), expected_a);
  EXPECT_EQ(b.file_.ReadAll(), before_b);
  a.bootstrap_.Close();
  EXPECT_THROW({ RegionManager invalid(a.bootstrap_); }, std::logic_error);
}

TEST(RegionTest, F02AdmissionLeasesAndDeviceFailuresKeepTheirMeaning) {
  Store s(0);
  RegionManager manager(s.bootstrap_);
  const auto data_region = manager.Region(RegionKind::Data);
  const uint64_t relative = 3 * s.length_;
  const uint64_t absolute = 8 * MIB + relative;
  const std::vector<RegionIORequest> write{{data_region, IOOperation::Write, relative, s.length_}};
  const auto before = s.file_.ReadAll();
  auto releases = std::make_shared<std::atomic<unsigned>>(0);
  auto data = Aligned(s.length_, s.device_.Info().memory_alignment_);
  auto payload = Payload(s.length_, 99);
  std::memcpy(data.get(), payload.data(), payload.size());
  std::vector<IOBufferLease> leases;
  leases.push_back(IOBufferLease::ForWrite(data.get(), s.length_, [data, releases] { ++*releases; }));
  {
    std::vector<RegionIORequest> held;
    for (size_t i = 0; i < 8; ++i) {
      held.push_back({data_region, IOOperation::Read, i * s.length_, s.length_});
    }
    auto reservation = manager.TryPrepare(held, false);
    ASSERT_EQ(reservation.admission_, IOAdmission::Accepted);
    EXPECT_EQ(manager.TryPrepare(write, true).admission_, IOAdmission::Full);
    EXPECT_EQ(manager.TryPrepareExternal(write, leases, true).admission_, IOAdmission::Full);
    ASSERT_EQ(leases.size(), 1U);
    EXPECT_EQ(releases->load(), 0U);
    EXPECT_EQ(s.file_.ReadAll(), before);
  }
  {
    fail_write = true;
    auto prepared = manager.TryPrepareExternal(write, leases, true);
    ASSERT_EQ(prepared.admission_, IOAdmission::Accepted);
    EXPECT_TRUE(leases.empty());
    Finish(s.io_, *prepared.batch_);
    const auto &result = prepared.batch_->Result();
    ASSERT_EQ(result.operations_.size(), 1U);
    EXPECT_EQ(prepared.batch_->Phase(), IOBatchPhase::Failed);
    EXPECT_FALSE(result.writes_durable_);
    EXPECT_EQ(result.operations_[0].outcome_, IOOutcome::Failed);
    ASSERT_TRUE(result.operations_[0].error_);
    try {
      std::rethrow_exception(result.operations_[0].error_);
      FAIL() << "missing original device error";
    } catch (const BlockDeviceIOError &e) {
      EXPECT_EQ(e.code().value(), EIO);
      EXPECT_EQ(e.Range().Offset(), absolute);
      EXPECT_EQ(e.Range().Size(), s.length_);
    }
    EXPECT_EQ(releases->load(), 1U);
    EXPECT_EQ(s.file_.ReadAll(), before);
  }
  {
    fail_flush = true;
    auto prepared = manager.TryPrepare(write, true);
    ASSERT_EQ(prepared.admission_, IOAdmission::Accepted);
    std::memcpy(prepared.batch_->Buffer(0), payload.data(), payload.size());
    Finish(s.io_, *prepared.batch_);
    const auto &result = prepared.batch_->Result();
    EXPECT_EQ(prepared.batch_->Phase(), IOBatchPhase::Failed);
    EXPECT_EQ(result.operations_[0].outcome_, IOOutcome::Succeeded);
    ASSERT_TRUE(result.flush_error_);
    EXPECT_FALSE(result.writes_durable_);
    try {
      std::rethrow_exception(result.flush_error_);
      FAIL() << "missing Flush error";
    } catch (const std::system_error &e) {
      EXPECT_EQ(e.code().value(), EIO);
    }
    auto expected = before;
    std::copy(payload.begin(), payload.end(), expected.begin() + absolute);
    EXPECT_EQ(s.file_.ReadAll(), expected);  // Failure does not imply rollback.
  }
  std::memset(data.get(), 0, s.length_);  // A skipped read must not reuse expected bytes.
  leases.push_back(IOBufferLease::ForRead(data.get(), s.length_, [data, releases] { ++*releases; }));
  {
    auto read = write;
    read[0].operation_ = IOOperation::Read;
    auto prepared = manager.TryPrepareExternal(read, leases, false);
    ASSERT_EQ(prepared.admission_, IOAdmission::Accepted);
    Finish(s.io_, *prepared.batch_);
    ASSERT_EQ(prepared.batch_->Phase(), IOBatchPhase::Succeeded);
    EXPECT_EQ(releases->load(), 2U);
    EXPECT_EQ(std::memcmp(data.get(), payload.data(), payload.size()), 0);
  }
  s.io_.Shutdown();
  EXPECT_EQ(manager.TryPrepare(write, true).admission_, IOAdmission::Stopped);
  leases.push_back(IOBufferLease::ForWrite(data.get(), s.length_, [data, releases] { ++*releases; }));
  EXPECT_EQ(manager.TryPrepareExternal(write, leases, true).admission_, IOAdmission::Stopped);
  EXPECT_EQ(leases.size(), 1U);
  EXPECT_EQ(releases->load(), 2U);
  leases.clear();
  EXPECT_EQ(releases->load(), 3U);
}
}  // namespace
}  // namespace bustub
