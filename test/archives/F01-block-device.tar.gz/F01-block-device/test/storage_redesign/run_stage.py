"""Opt-in F01 archive runner. Never registers a project test or edits production."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess

parser = argparse.ArgumentParser()
parser.add_argument('--repo', type=Path, required=True)
parser.add_argument('--work', type=Path, required=True)
parser.add_argument('--build-only', action='store_true')
parser.add_argument('--mutations', action='store_true')
args = parser.parse_args()
repo = args.repo.resolve()
work = args.work.resolve()
work.mkdir(parents=True, exist_ok=True)
build = work / 'build'
source = Path(__file__).with_name('block_device_test.cpp')
commands = []


def call(argv, log, env=None, timeout=180, expected=0):
    commands.append(argv)
    with (work / log).open('w') as out:
        result = subprocess.run(argv, cwd=repo, stdout=out, stderr=subprocess.STDOUT,
                                env=env, timeout=timeout)
    (work / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
    if expected is not None and result.returncode != expected:
        raise RuntimeError(f'{log}: exit {result.returncode}, expected {expected}')
    return result.returncode


call(['cmake', '-S', str(repo), '-B', str(build), '-DCMAKE_BUILD_TYPE=Debug',
      '-DCMAKE_C_COMPILER=clang-14', '-DCMAKE_CXX_COMPILER=clang++-14',
      '-DBUSTUB_SANITIZER=address,undefined', '-DCMAKE_EXE_LINKER_FLAGS=-no-pie'], 'configure-final.log')
call(['cmake', '--build', str(build), '--target', 'bustub_storage_disk', 'gtest_main', '-j2'], 'build-final.log')
flags = ['clang++-14', '-std=c++17', '-Wall', '-Wextra', '-Werror', '-Wno-unused-parameter',
         '-pthread', '-g', '-O0', '-fsanitize=address,undefined', '-fno-omit-frame-pointer',
         '-I' + str(repo / 'src/include'),
         '-I' + str(repo / 'third_party/googletest/googletest/include')]
test_object = work / 'stage-test.o'
call(flags + ['-c', str(source), '-o', str(test_object)], 'stage-compile.log')
production_object = build / 'src/storage/disk/CMakeFiles/bustub_storage_disk.dir/block_device.cpp.o'
link_tail = [str(test_object), str(build / 'lib/libgtest_main.a'), str(build / 'lib/libgtest.a'),
             '-Wl,--wrap=pread', '-Wl,--wrap=pwrite', '-Wl,--wrap=fdatasync', '-Wl,--wrap=statx']
binary = work / 'stage-test'
call(flags + ['-no-pie', str(production_object)] + link_tail + ['-o', str(binary)], 'stage-link.log')
env = dict(os.environ, F01_WORKDIR=str(work), ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',
           UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
if args.build_only:
    raise SystemExit(0)
call([str(binary), '--gtest_output=xml:' + str(work / 'results-final.xml')], 'run-final.log', env, 60)
if not args.mutations:
    raise SystemExit(0)

original = (repo / 'src/storage/disk/block_device.cpp').read_text()
mutations = []


def replace(name, old, new, count, test):
    if original.count(old) != count:
        raise RuntimeError(f'{name}: source drift; review before restoring these mutations')
    mutations.append((name, original.replace(old, new), test))


replace('wrong_both_offsets', 'static_cast<off_t>(range.Offset() + completed)',
        'static_cast<off_t>(range.Offset() + completed + info_.offset_alignment_)', 2,
        'DirectRangesHaveIndependentPhysicalOracle')
replace('hardcode_4096', 'info_.memory_alignment_ = alignment.stx_dio_mem_align;\n'
        '      info_.offset_alignment_ = alignment.stx_dio_offset_align;',
        'info_.memory_alignment_ = 4096;\n      info_.offset_alignment_ = 4096;', 1,
        'DirectRangesHaveIndependentPhysicalOracle')
replace('remove_request_checks', '  Validate(range, buffer, buffer_size);', '', 2,
        'InvalidRequestsCannotReachIOOrChangeNeighbors')
replace('accept_short_read', 'throw BlockDeviceIOError(EIO, "unexpected device EOF", range, completed);',
        'return;', 1, 'TruncatedAllocatedRangeIsAnErrorNotZeroFill')
start = original.index('void BlockDevice::Flush() const {')
end = original.index('void BlockDevice::Close()', start)
mutations.append(('empty_flush', original[:start] + 'void BlockDevice::Flush() const {}\n\n' + original[end:],
                  'FlushMustReachOSAndMustPropagateFailure'))
replace('swallow_flush_error', 'Fail(errno, "flush device", path_);', 'return;', 1,
        'FlushMustReachOSAndMustPropagateFailure')
results = []
for name, text, test in mutations:
    mutant = work / (name + '.cpp')
    mutant.write_text(text)
    obj = work / (name + '.o')
    exe = work / name
    call(flags + ['-c', str(mutant), '-o', str(obj)], name + '-compile.log')
    call(flags + ['-no-pie', str(obj)] + link_tail + ['-o', str(exe)], name + '-link.log')
    status = call([str(exe), '--gtest_filter=BlockDeviceTest.' + test], name + '-run.log', env, 60, None)
    log = (work / (name + '-run.log')).read_text()
    caught = status == 1 and '[  FAILED  ] BlockDeviceTest.' + test in log
    results.append(dict(mutation=name, test=test, returncode=status, caught_by_assertion=caught,
                        source_sha256=hashlib.sha256(text.encode()).hexdigest()))
    if not caught:
        (work / 'mutations.json').write_text(json.dumps(results, indent=2) + '\n')
        raise RuntimeError(f'{name}: not caught by the intended test; inspect {name}-run.log')
(work / 'mutations.json').write_text(json.dumps(results, indent=2) + '\n')
print('7 stage checks passed; all 6 isolated mutations caught by assertions.')
