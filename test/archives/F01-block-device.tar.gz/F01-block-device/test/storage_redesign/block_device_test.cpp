// F01 temporary integration checks. Link-time observers live only in this file.
#include "storage/disk/block_device.h"

#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>

#include <algorithm>
#include <atomic>
#include <cerrno>
#include <cstdlib>
#include <cstring>
#include <deque>
#include <filesystem>
#include <future>
#include <limits>
#include <memory>
#include <numeric>
#include <stdexcept>
#include <string>
#include <vector>

#include "gtest/gtest.h"

extern "C" ssize_t __real_pread(int, void *, size_t, off_t);
extern "C" ssize_t __real_pwrite(int, const void *, size_t, off_t);
extern "C" int __real_fdatasync(int);
extern "C" int __real_statx(int, const char *, int, unsigned, struct statx *);

namespace observation {
thread_local std::deque<long> reads;
thread_local std::deque<long> writes;
thread_local std::deque<int> sync_errors;
// 0 = normal; 1 = missing mask; 2 = zero fields; 3 = ENOSYS.
thread_local int alignment_fault = 0;
std::atomic<size_t> read_calls{0};
std::atomic<size_t> write_calls{0};
std::atomic<size_t> successful_syncs{0};
std::atomic<bool> saw_buffered_io{false};

void Reset() {
  reads.clear();
  writes.clear();
  sync_errors.clear();
  alignment_fault = 0;
  read_calls = 0;
  write_calls = 0;
  successful_syncs = 0;
  saw_buffered_io = false;
}

void CheckMode(int fd) {
  if ((fcntl(fd, F_GETFL) & O_DIRECT) == 0) {
    saw_buffered_io = true;
  }
}

auto Next(std::deque<long> *steps, size_t count) -> long {
  if (steps->empty()) {
    return static_cast<long>(count);
  }
  auto next = steps->front();
  steps->pop_front();
  return next > 0 ? std::min(next, static_cast<long>(count)) : next;
}
}  // namespace observation

extern "C" ssize_t __wrap_pread(int fd, void *buffer, size_t count, off_t offset) {
  ++observation::read_calls;
  observation::CheckMode(fd);
  auto next = observation::Next(&observation::reads, count);
  if (next < 0) {
    errno = static_cast<int>(-next);
    return -1;
  }
  return next == 0 ? 0 : __real_pread(fd, buffer, static_cast<size_t>(next), offset);
}

extern "C" ssize_t __wrap_pwrite(int fd, const void *buffer, size_t count, off_t offset) {
  ++observation::write_calls;
  observation::CheckMode(fd);
  auto next = observation::Next(&observation::writes, count);
  if (next < 0) {
    errno = static_cast<int>(-next);
    return -1;
  }
  return next == 0 ? 0 : __real_pwrite(fd, buffer, static_cast<size_t>(next), offset);
}

extern "C" int __wrap_fdatasync(int fd) {
  if (!observation::sync_errors.empty()) {
    int error = observation::sync_errors.front();
    observation::sync_errors.pop_front();
    errno = error;
    return -1;
  }
  auto result = __real_fdatasync(fd);
  if (result == 0) {
    ++observation::successful_syncs;
  }
  return result;
}

extern "C" int __wrap_statx(int fd, const char *path, int flags, unsigned mask, struct statx *result) {
  if (observation::alignment_fault == 3) {
    errno = ENOSYS;
    return -1;
  }
  auto status = __real_statx(fd, path, flags, mask, result);
  if (status == 0 && observation::alignment_fault == 1) {
    result->stx_mask &= ~STATX_DIOALIGN;
  }
  if (status == 0 && observation::alignment_fault == 2) {
    result->stx_dio_mem_align = 0;
    result->stx_dio_offset_align = 0;
  }
  return status;
}

namespace bustub {
namespace {
class Fd {
 public:
  explicit Fd(int fd) : fd_(fd) {
    if (fd < 0) {
      throw std::system_error(errno, std::generic_category());
    }
  }
  ~Fd() { close(fd_); }
  auto Get() const -> int { return fd_; }
  Fd(const Fd &) = delete;
  auto operator=(const Fd &) -> Fd & = delete;

 private:
  int fd_;
};

class AlignedBuffer {
 public:
  AlignedBuffer(size_t alignment, size_t size) : size_(size) {
    auto error = posix_memalign(&data_, std::max(alignment, sizeof(void *)), size);
    if (error != 0) {
      throw std::system_error(error, std::generic_category());
    }
    std::memset(data_, 0, size);
  }
  ~AlignedBuffer() { free(data_); }
  auto Data() -> char * { return static_cast<char *>(data_); }
  auto Size() const -> size_t { return size_; }
  AlignedBuffer(const AlignedBuffer &) = delete;
  auto operator=(const AlignedBuffer &) -> AlignedBuffer & = delete;

 private:
  void *data_{nullptr};
  size_t size_;
};

auto Range(uint64_t offset, uint64_t size) -> StorageByteRange {
  return StorageByteRange::Create(offset, size).value();
}

auto Pattern(size_t size, uint64_t base, unsigned seed) -> std::vector<char> {
  std::vector<char> result(size);
  for (size_t i = 0; i < size; ++i) {
    auto address = base + i;
    result[i] = static_cast<char>((address * 131 + (address >> 8) * 17 + seed) ^ (address >> 16));
  }
  return result;
}

class BlockDeviceTest : public ::testing::Test {
 protected:
  void SetUp() override {
    observation::Reset();
    auto *root = std::getenv("F01_WORKDIR");
    ASSERT_NE(root, nullptr);
    std::string name = std::string(root) + "/device-XXXXXX";
    std::vector<char> writable(name.begin(), name.end());
    writable.push_back('\0');
    auto *created = mkdtemp(writable.data());
    ASSERT_NE(created, nullptr);
    directory_ = created;
    path_ = directory_ / "image";
    Fd fd(open(path_.c_str(), O_RDWR | O_CREAT | O_EXCL | O_CLOEXEC, 0600));
    struct statx alignment {};
    ASSERT_EQ(__real_statx(fd.Get(), "", AT_EMPTY_PATH, STATX_DIOALIGN, &alignment), 0);
    ASSERT_NE(alignment.stx_mask & STATX_DIOALIGN, 0U) << "Direct prerequisite unavailable; no Buffered fallback";
    ASSERT_GT(alignment.stx_dio_mem_align, 0U);
    ASSERT_GT(alignment.stx_dio_offset_align, 0U);
    memory_alignment_ = alignment.stx_dio_mem_align;
    offset_alignment_ = alignment.stx_dio_offset_align;
    unit_ = std::lcm<size_t>(memory_alignment_, offset_alignment_);
    ASSERT_LE(unit_, 256U * 1024U) << "fixture exceeds agreed resource budget";
    capacity_ = unit_ * 256;
    initial_ = Pattern(capacity_, 0, 13);
    size_t done = 0;
    while (done != capacity_) {
      auto result = __real_pwrite(fd.Get(), initial_.data() + done, capacity_ - done, static_cast<off_t>(done));
      ASSERT_GT(result, 0);
      done += static_cast<size_t>(result);
    }
    ASSERT_EQ(__real_fdatasync(fd.Get()), 0);
  }

  void TearDown() override {
    observation::Reset();
    std::error_code error;
    if (!directory_.empty()) {
      std::filesystem::remove_all(directory_, error);
      EXPECT_FALSE(error) << error.message();
    }
  }

  auto Oracle() -> std::vector<char> {
    // The independent oracle is used only after production operations have
    // ended.
    Fd fd(open(path_.c_str(), O_RDONLY | O_CLOEXEC));
    struct stat st {};
    if (fstat(fd.Get(), &st) != 0) {
      throw std::runtime_error("oracle stat failed");
    }
    std::vector<char> result(static_cast<size_t>(st.st_size));
    size_t done = 0;
    while (done < result.size()) {
      auto count = __real_pread(fd.Get(), result.data() + done, result.size() - done, static_cast<off_t>(done));
      if (count <= 0) {
        throw std::runtime_error("oracle short read");
      }
      done += static_cast<size_t>(count);
    }
    return result;
  }

  std::filesystem::path directory_;
  std::filesystem::path path_;
  size_t memory_alignment_{0};
  size_t offset_alignment_{0};
  size_t unit_{0};
  size_t capacity_{0};
  std::vector<char> initial_;
};

TEST_F(BlockDeviceTest, DirectRangesHaveIndependentPhysicalOracle) {
  BlockDevice device(path_, BlockDeviceOptions{});
  ASSERT_EQ(device.Info().memory_alignment_, memory_alignment_);
  ASSERT_EQ(device.Info().offset_alignment_, offset_alignment_);
  ASSERT_EQ(device.Info().capacity_, capacity_);
  ASSERT_EQ(device.Info().access_mode_, DeviceAccessMode::Direct);
  std::cout << "DIRECT capacity_=" << capacity_ << " memory_alignment_=" << memory_alignment_
            << " offset_alignment_=" << offset_alignment_ << '\n';
  auto expected = initial_;
  // Include an operation of exactly the discovered unit: 4 KiB hardcoding
  // must not pass merely because all test writes happen to be 4 KiB aligned.
  for (const auto offset : {unit_ * 7, capacity_ - unit_}) {
    auto payload = Pattern(unit_, offset, 97);
    AlignedBuffer data(memory_alignment_, unit_);
    std::copy(payload.begin(), payload.end(), data.Data());
    device.WriteAt(Range(offset, unit_), data.Data(), data.Size());
    std::copy(payload.begin(), payload.end(), expected.begin() + offset);
  }
  device.Flush();
  EXPECT_GT(observation::successful_syncs.load(), 0U);
  EXPECT_FALSE(observation::saw_buffered_io.load());
  device.Close();
  EXPECT_EQ(Oracle(),
            expected);  // Also checks every unmodified neighboring byte.
  BlockDevice reopened(path_, BlockDeviceOptions{});
  AlignedBuffer readback(memory_alignment_, capacity_);
  reopened.ReadAt(Range(0, capacity_), readback.Data(), readback.Size());
  EXPECT_EQ(std::vector<char>(readback.Data(), readback.Data() + capacity_), expected);
  reopened.Close();
  EXPECT_THROW(reopened.Flush(), std::system_error);
  EXPECT_THROW(reopened.ReadAt(Range(0, unit_), readback.Data(), readback.Size()), BlockDeviceIOError);
  EXPECT_FALSE(observation::saw_buffered_io.load());
}

TEST_F(BlockDeviceTest, InvalidRequestsCannotReachIOOrChangeNeighbors) {
  BlockDevice device(path_, BlockDeviceOptions{});
  AlignedBuffer data(memory_alignment_, unit_ * 2);
  std::memset(data.Data(), 71, data.Size());
  EXPECT_THROW(device.WriteAt(Range(capacity_, unit_), data.Data(), data.Size()), BlockDeviceIOError);
  EXPECT_THROW(device.ReadAt(Range(capacity_ - unit_, unit_ * 2), data.Data(), data.Size()), BlockDeviceIOError);
  EXPECT_THROW(device.WriteAt(Range(0, unit_ * 2), data.Data(), unit_), BlockDeviceIOError);
  if (memory_alignment_ > 1) {
    EXPECT_THROW(device.WriteAt(Range(0, unit_), data.Data() + 1, unit_), BlockDeviceIOError);
  }
  if (offset_alignment_ > 1) {
    EXPECT_THROW(device.ReadAt(Range(1, unit_), data.Data(), data.Size()), BlockDeviceIOError);
    EXPECT_THROW(device.WriteAt(Range(0, unit_ - 1), data.Data(), data.Size()), BlockDeviceIOError);
  }
  EXPECT_EQ(observation::write_calls.load(), 0U);
  EXPECT_EQ(observation::read_calls.load(), 0U);
  device.Close();
  EXPECT_EQ(Oracle(), initial_);
}

TEST_F(BlockDeviceTest, TruncatedAllocatedRangeIsAnErrorNotZeroFill) {
  BlockDevice device(path_, BlockDeviceOptions{});
  AlignedBuffer data(memory_alignment_, unit_ * 2);
  // Deliberately violate external size stability to reproduce unexpected EOF.
  ASSERT_EQ(truncate(path_.c_str(), static_cast<off_t>(unit_)), 0);
  try {
    device.ReadAt(Range(0, unit_ * 2), data.Data(), data.Size());
    FAIL() << "short allocated range accepted";
  } catch (const BlockDeviceIOError &error) {
    EXPECT_EQ(error.code().value(), EIO);
    EXPECT_EQ(error.CompletedBytes(), unit_);
    EXPECT_EQ(error.Range().Size(), unit_ * 2);
  }
  // An unaligned EOF exercises the Direct remainder rule on an actual file.
  ASSERT_EQ(truncate(path_.c_str(), static_cast<off_t>(unit_ + 1)), 0);
  try {
    device.ReadAt(Range(0, unit_ * 2), data.Data(), data.Size());
    FAIL() << "unaligned short read accepted";
  } catch (const BlockDeviceIOError &error) {
    EXPECT_EQ(error.code().value(), EIO);
    EXPECT_EQ(error.CompletedBytes(), unit_ + 1);
  }
}

TEST_F(BlockDeviceTest, ConcurrentIndependentRangesDoNotCrossWire) {
  BlockDevice device(path_, BlockDeviceOptions{});
  std::promise<void> start;
  auto ready = start.get_future().share();
  std::vector<std::future<void>> workers;
  // Allocate before starting tasks: a failed push_back allocation could destroy
  // an async future waiting on the start gate before the catch can release it.
  workers.reserve(4);
  auto expected = initial_;
  try {
    for (size_t worker = 0; worker < 4; ++worker) {
      auto offset = (worker * 13 + 1) * unit_;
      auto final_payload = Pattern(unit_, offset, static_cast<unsigned>(100 + worker + 15));
      std::copy(final_payload.begin(), final_payload.end(), expected.begin() + offset);
      workers.push_back(std::async(std::launch::async, [&, worker, offset, ready] {
        AlignedBuffer data(memory_alignment_, unit_);
        AlignedBuffer readback(memory_alignment_, unit_);
        ready.wait();
        for (unsigned round = 0; round < 16; ++round) {
          auto payload = Pattern(unit_, offset, static_cast<unsigned>(100 + worker + round));
          std::copy(payload.begin(), payload.end(), data.Data());
          device.WriteAt(Range(offset, unit_), data.Data(), data.Size());
          device.ReadAt(Range(offset, unit_), readback.Data(), readback.Size());
          if (!std::equal(payload.begin(), payload.end(), readback.Data())) {
            throw std::runtime_error("concurrent range content mismatch");
          }
        }
      }));
    }
  } catch (...) {
    start.set_value();
    throw;
  }
  start.set_value();
  for (auto &worker : workers) {
    worker.get();
  }
  device.Flush();
  device.Close();
  EXPECT_FALSE(observation::saw_buffered_io.load());
  EXPECT_EQ(Oracle(), expected);
}

TEST_F(BlockDeviceTest, MissingAlignmentNeverFallsBackToBuffered) {
  for (int fault : {1, 2, 3}) {
    observation::alignment_fault = fault;
    EXPECT_THROW({ BlockDevice unsupported(path_, BlockDeviceOptions{}); }, std::system_error);
  }
  // Explicit compatibility choice is independent of missing Direct capability.
  BlockDeviceOptions options;
  options.access_mode_ = DeviceAccessMode::Buffered;
  BlockDevice buffered(path_, options);
  EXPECT_EQ(buffered.Info().access_mode_, DeviceAccessMode::Buffered);
  const std::string payload = "explicit buffered content";
  buffered.WriteAt(Range(3, payload.size()), payload.data(), payload.size());
  buffered.Flush();
  buffered.Close();
  auto expected = initial_;
  std::copy(payload.begin(), payload.end(), expected.begin() + 3);
  EXPECT_EQ(Oracle(), expected);
}

TEST_F(BlockDeviceTest, ShortIOAndInterruptionsPreserveProgressAndErrors) {
  BlockDevice device(path_, BlockDeviceOptions{});
  AlignedBuffer data(memory_alignment_, unit_ * 3);
  auto payload = Pattern(data.Size(), unit_ * 2, 147);
  std::copy(payload.begin(), payload.end(), data.Data());
  observation::writes = {-EINTR, static_cast<long>(unit_), -EINTR, static_cast<long>(unit_)};
  device.WriteAt(Range(unit_ * 2, data.Size()), data.Data(), data.Size());
  AlignedBuffer readback(memory_alignment_, data.Size());
  observation::reads = {-EINTR, static_cast<long>(unit_), -EINTR};
  device.ReadAt(Range(unit_ * 2, data.Size()), readback.Data(), readback.Size());
  EXPECT_EQ(std::vector<char>(readback.Data(), readback.Data() + data.Size()), payload);

  observation::writes = {static_cast<long>(unit_), -EIO};
  try {
    device.WriteAt(Range(unit_ * 10, data.Size()), data.Data(), data.Size());
    FAIL() << "partial failure accepted";
  } catch (const BlockDeviceIOError &error) {
    EXPECT_EQ(error.code().value(), EIO);
    EXPECT_EQ(error.CompletedBytes(), unit_);
    EXPECT_EQ(error.Range().Offset(), unit_ * 10);
  }
  observation::writes = {0};
  EXPECT_THROW(device.WriteAt(Range(unit_ * 20, unit_), data.Data(), data.Size()), BlockDeviceIOError);
  observation::reads = {-EIO};
  EXPECT_THROW(device.ReadAt(Range(unit_ * 20, unit_), readback.Data(), readback.Size()), BlockDeviceIOError);
  device.Flush();
  device.Close();
  auto expected = initial_;
  std::copy(payload.begin(), payload.end(), expected.begin() + unit_ * 2);
  std::copy(payload.begin(), payload.begin() + unit_, expected.begin() + unit_ * 10);
  EXPECT_EQ(Oracle(), expected);
}

TEST_F(BlockDeviceTest, FlushMustReachOSAndMustPropagateFailure) {
  BlockDevice device(path_, BlockDeviceOptions{});
  AlignedBuffer data(memory_alignment_, unit_);
  auto payload = Pattern(unit_, unit_ * 5, 181);
  std::copy(payload.begin(), payload.end(), data.Data());
  device.WriteAt(Range(unit_ * 5, unit_), data.Data(), data.Size());
  observation::sync_errors = {EINTR};
  device.Flush();
  EXPECT_TRUE(observation::sync_errors.empty());
  EXPECT_GT(observation::successful_syncs.load(), 0U);
  observation::sync_errors = {EIO};
  try {
    device.Flush();
    FAIL() << "flush failure swallowed";
  } catch (const std::system_error &error) {
    EXPECT_EQ(error.code().value(), EIO);
  }
  EXPECT_TRUE(observation::sync_errors.empty());
  device.Close();
}
}  // namespace
}  // namespace bustub
