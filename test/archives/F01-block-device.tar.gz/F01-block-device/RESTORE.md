# F01 阶段测试恢复

这是 7 项组件集成验证与执行脚本的源码归档，不是独立项目或常驻套件。

依赖：Linux 支持文件 O_DIRECT 与 STATX_DIOALIGN、CMake、Clang/clang++ 14、Python3，以及本仓库匹配版本的 GoogleTest 等源码依赖。没有网络下载步骤。测试会创建专用文件，不接受裸设备路径。

版本：基准 d8ad4a0666640849f52f12b96ce6bb852e5c4177 **本身不含 F01**。使用具有 MANIFEST.json 所列生产文件哈希的 checkout，或在基准隔离副本上覆盖修正版复验包 `test-results/storage-f01-review-20260922/F01-review-results.tar.gz` 中的 source/ 快照。不能将本包解压进长期测试树，也不能对较新实现直接套用旧 mutation。

先校验 test/archives/SHA256SUMS，在仓库外创建目录并解压。下面用三个显式路径变量（按实际位置设置）：

```sh
F01_REPO=/path/to/matching/checkout
F01_PACKAGE=/tmp/unpacked/F01-block-device
F01_WORK=$(mktemp -d /tmp/f01-recheck-XXXXXX)
python3 "$F01_PACKAGE/test/storage_redesign/run_stage.py" --repo "$F01_REPO" --work "$F01_WORK" --mutations
```

runner 构建真实 bustub_storage_disk 对象和 GoogleTest，阶段测试在外部独立链接；不改生产接口或常驻注册。故障观察/注入通过测试链接器 --wrap；变异只在 F01_WORK 副本进行。正常运行应 7 项通过，6 个变异应被指定断言发现；编译/超时/检测器失败不能算抓到变异。--build-only 只构建，默认不传 --mutations 时仅运行 7 项。

ASan/UBSan/LeakSanitizer 全部开启；WSL 使用临时 no-PIE。受 ptrace 限制的沙箱无法完成泄漏检查时保留诊断并换受支持执行环境，不静默关闭检测器；缺 Direct 能力也不能改用 Buffered 冒充通过。

复核后保存命令/日志/版本；删除工作目录中的构建和设备文件。归档风险与后续 F02/S8/S9 接管说明见执行记录；原 C/P 套件独立保留。

提交前复审修正了并发测试的 future 容器扩容异常路径，当前包为修正版；7 项已重新运行通过，6 个 mutation 沿用首轮核验过的证据，本次未重跑。包含问题测试的首轮结果包现已按用户要求删除，首轮 mutation 原始日志不可用，仅保留历史摘要；现存修正版复验入口为 `test-results/storage-f01-review-20260922/README.md`。
