# F09 测试恢复与复现

本包只含最终修正版四项测试和 runner，不注册到常驻测试树。生产基准与三份改动文件 SHA-256 在 MANIFEST.json；基准自身未包含 F09。

在隔离源码目录检出 manifest 的 base_commit，再从 F09-results.tar.gz 的 source/ 恢复三份生产改动（或使用与 manifest 完全匹配的后续提交）。先核验哈希，不覆盖用户工作树。结果包为本地文件，clone 不含它。

将本测试包解压到仓库外 scratch，使用以下命令；--work 必须位于源码仓库外，具备 Linux Direct 文件支持及 manifest 中的工具。runner 从指定源码仓库的 F08 压缩包读取原测试并校验内容，不复制另一套常驻 F08 测试：

```bash
python3 /tmp/f09-package/F09-metadata-page-writer/test/storage_redesign/run_stage.py --repo /path/to/isolated-source --work /tmp/f09-run --mutations
```

此次实测命令与 XML/日志见结果包 commands.json、xml/ 和 logs/。每个变异必须编译/链接成功、指定场景退出 1 且出现预定断言，不能把超时或编译错误算检出。正常场景 ASan/UBSan；运行耗时不作为性能对比。

4 项 F09 + 6 项原 F08 + 8 个变异是本次范围，不是节点 E2E。原 A/共同 C/P 本次未重跑。F10/F11 仍需实现与检验从最终页/checkpoint 恢复、日志裁剪等风险。

2026-09-26 review: the original concurrency scenario now targets the exact stalled overflow page slot. Production hashes are unchanged; the four/six/eight runtime results were all regenerated.
