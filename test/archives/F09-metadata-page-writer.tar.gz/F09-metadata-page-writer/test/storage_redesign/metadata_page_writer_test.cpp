#include <fcntl.h>
#include <unistd.h>

#include <algorithm>
#include <array>
#include <cerrno>
#include <chrono>
#include <condition_variable>
#include <cstdlib>
#include <future>
#include <map>
#include <mutex>
#include <numeric>
#include <set>
#include <string>
#include <tuple>
#include <vector>

#include "gtest/gtest.h"
#include "storage/disk/block_device.h"
#include "storage/disk/io_executor.h"
#include "storage/disk/metadata_engine.h"

extern "C" int __real_fdatasync(int);
extern "C" ssize_t __real_pwrite(int, const void *, size_t, off_t);
namespace {
constexpr uint64_t MIB = 1024 * 1024;
constexpr uint64_t META_START = 2 * MIB;
constexpr uint64_t META_SIZE = 4 * MIB;
std::mutex gate_mutex;
std::condition_variable gate_cv;
enum class GateKind { None, PageWrite, OverflowWrite, Flush };
GateKind gate_kind = GateKind::None;
bool gate_claimed = false;
bool gate_entered = false;
bool gate_released = false;
bool gate_fail = false;
size_t completed_other_writes = 0;
uint32_t stalled_page = 0;
uint64_t stalled_generation = 0;
void Release() {
  std::lock_guard<std::mutex> lock(gate_mutex);
  gate_released = true;
  gate_cv.notify_all();
}
struct ReleaseOnExit {
  ~ReleaseOnExit() { Release(); }
};
void Arm(GateKind kind, bool pause, bool fail) {
  std::lock_guard<std::mutex> lock(gate_mutex);
  gate_kind = kind;
  gate_claimed = false;
  gate_entered = false;
  gate_released = !pause;
  gate_fail = fail;
  completed_other_writes = 0;
}
auto Enter(GateKind kind, off_t offset = 0, const void *data = nullptr) -> bool {
  std::unique_lock<std::mutex> lock(gate_mutex);
  if (gate_kind != kind || gate_claimed) {
    return false;
  }
  if (kind == GateKind::OverflowWrite) {
    stalled_page = static_cast<uint32_t>((offset - META_START) / 4096);
    stalled_generation = 0;
    const auto *bytes = static_cast<const uint8_t *>(data);
    for (size_t i = 4056; i < 4064; i++) {
      stalled_generation = (stalled_generation << 8) | bytes[i];
    }
  }
  completed_other_writes = 0;
  gate_claimed = gate_entered = true;
  gate_cv.notify_all();
  gate_cv.wait(lock, [] { return gate_released; });
  return gate_fail;
}
auto WaitEntered() -> bool {
  std::unique_lock<std::mutex> lock(gate_mutex);
  return gate_cv.wait_for(lock, std::chrono::seconds(10), [] { return gate_entered; });
}
auto WaitOtherWrite() -> bool {
  std::unique_lock<std::mutex> lock(gate_mutex);
  return gate_cv.wait_for(lock, std::chrono::seconds(10), [] { return completed_other_writes > 0; });
}
}  // namespace
extern "C" int __wrap_fdatasync(int fd) {
  if (Enter(GateKind::Flush)) {
    errno = EIO;
    return -1;
  }
  return __real_fdatasync(fd);
}
extern "C" ssize_t __wrap_pwrite(int fd, const void *data, size_t size, off_t offset) {
  bool metadata = offset >= static_cast<off_t>(META_START) && offset < static_cast<off_t>(META_START + META_SIZE);
  const auto *bytes = static_cast<const uint8_t *>(data);
  bool overflow =
      metadata && size == 4096 && bytes[4044] == 0 && bytes[4045] == 0 && bytes[4046] == 0 && bytes[4047] == 4;
  if ((overflow && Enter(GateKind::OverflowWrite, offset, data)) || (metadata && Enter(GateKind::PageWrite))) {
    errno = EIO;
    return -1;
  }
  auto result = __real_pwrite(fd, data, size, offset);
  if (metadata && result > 0) {
    std::lock_guard<std::mutex> lock(gate_mutex);
    ++completed_other_writes;
    gate_cv.notify_all();
  }
  return result;
}
namespace bustub {
namespace {
using Bytes = std::vector<std::byte>;
using Key = std::tuple<uint64_t, uint64_t, uint64_t>;
using Model = std::map<Key, Bytes>;
using Page = std::array<uint8_t, 4096>;
constexpr uint32_t NONE = UINT32_MAX;
void Require(bool condition, const char *message) {
  if (!condition) {
    throw std::runtime_error(message);
  }
}
auto Value(size_t length, unsigned seed) -> Bytes {
  Bytes result(length);
  for (size_t i = 0; i < length; i++) {
    result[i] = std::byte((i * 17 + i / 19 + seed * 23) % 251);
  }
  return result;
}
auto KeyFor(uint64_t id) -> MetadataKey { return {id % 3, id % 11, id}; }
auto Range(uint64_t start, uint64_t size) -> StorageByteRange { return *StorageByteRange::Create(start, size); }
struct Image {
  std::string path;
  Image() {
    auto *work = std::getenv("F09_WORKDIR");
    Require(work != nullptr, "F09_WORKDIR must be explicit");
    path = std::string(work) + "/page-writer-device-XXXXXX";
    int fd = mkstemp(path.data());
    Require(fd >= 0, "cannot create scratch image");
    auto result = ftruncate(fd, 48 * MIB);
    close(fd);
    if (result != 0) {
      unlink(path.c_str());
      throw std::runtime_error("cannot size scratch image");
    }
  }
  ~Image() { unlink(path.c_str()); }
  auto ReadRegion() const -> std::vector<uint8_t> {
    std::vector<uint8_t> bytes(META_SIZE);
    int fd = open(path.c_str(), O_RDONLY);
    Require(fd >= 0, "cannot open disk oracle");
    auto count = pread(fd, bytes.data(), bytes.size(), META_START);
    close(fd);
    Require(count == static_cast<ssize_t>(bytes.size()), "short disk oracle read");
    return bytes;
  }
};
struct Stack {
  BlockDevice device;
  IOExecutor io;
  BootstrapStore bootstrap;
  JournalIdentity journal_id{};
  BootstrapIdentity identity{};
  JournalOptions journal;
  MetadataOptions options{1024, 4096, 65536, 2 * MIB};
  Stack(const std::string &path, bool create)
      : device(path, BlockDeviceOptions{}), io(device, {3, 4096, 32 * MIB}), bootstrap(io) {
    auto unit = static_cast<uint32_t>(std::lcm<uint64_t>(4096, device.Info().offset_alignment_));
    Require(unit <= 65536, "queried alignment exceeds fixture budget");
    journal = {64ULL * unit, unit, 8192, 2 * MIB, 1024, 4 * MIB, 8, 32, 8 * MIB};
    journal_id.fill(73);
    identity.storage_.fill(11);
    identity.device_.fill(31);
    if (create) {
      bootstrap.Create(
          {identity, 48 * MIB, {Range(META_START, META_SIZE), Range(8 * MIB, 32 * MIB), Range(40 * MIB, 8 * MIB)}});
    }
    bootstrap.Open(identity);
  }
  ~Stack() {
    bootstrap.Close();
    io.Shutdown();
  }
};
void Apply(MetadataEngine &engine, const std::vector<MetadataMutation> &mutations, Model *model) {
  auto result = engine.Commit(engine.Read(), mutations);
  Require(result.outcome_ == JournalOutcome::Durable, "setup commit was not durable");
  for (const auto &m : mutations) {
    Key key{m.key_.category_, m.key_.owner_, m.key_.item_};
    if (m.value_) {
      (*model)[key] = *m.value_;
    } else {
      model->erase(key);
    }
  }
}
auto Fill(size_t count, unsigned seed) -> std::vector<MetadataMutation> {
  std::vector<MetadataMutation> result;
  for (size_t i = 0; i < count; i++) {
    result.push_back({KeyFor(i), Value(i % 31 == 0 ? 9013 : 43 + i % 109, seed + i % 7)});
  }
  return result;
}
auto Drain(MetadataEngine &engine, size_t limit) -> size_t {
  size_t pages = 0;
  for (size_t n = 0; n < 2048; n++) {
    auto result = engine.Writeback(limit);
    if (result.outcome_ == MetadataWritebackOutcome::Clean) {
      Require(result.page_count_ == 0 && !result.error_, "invalid clean result");
      return pages;
    }
    Require(result.outcome_ == MetadataWritebackOutcome::Durable && !result.error_, "writeback did not become durable");
    Require(result.page_count_ > 0 && result.page_count_ <= limit, "writeback exceeded explicit page bound");
    pages += result.page_count_;
  }
  throw std::runtime_error("bounded writeback did not converge without concurrent writers");
}
// Disk oracle intentionally does not call the production key/page/CRC codec.
auto BE(const Page &p, size_t offset, size_t width = 4) -> uint64_t {
  Require(offset + width <= p.size(), "oracle field outside page");
  uint64_t value = 0;
  for (size_t i = 0; i < width; i++) {
    value = (value << 8) | p[offset + i];
  }
  return value;
}
auto CRC(const Page &page) -> uint32_t {
  uint32_t crc = ~0U;
  for (size_t i = 0; i < 4072; i++) {
    crc ^= page[i];
    for (int b = 0; b < 8; b++) {
      crc = (crc >> 1) ^ ((crc & 1U) ? 0x82f63b78U : 0U);
    }
  }
  return ~crc;
}
struct DiskView {
  std::vector<Page> pages;
  Model values;
  explicit DiskView(const Image &image) {
    auto bytes = image.ReadRegion();
    Page header{};
    std::copy_n(bytes.begin(), 4096, header.begin());
    auto count = BE(header, 4);
    Require(count > 0 && count <= META_SIZE / 4096, "canonical page high-water is invalid");
    pages.resize(count);
    for (size_t i = 0; i < count; i++) {
      std::copy_n(bytes.begin() + i * 4096, 4096, pages[i].begin());
      auto &p = pages[i];
      Require(std::string(reinterpret_cast<const char *>(p.data() + 4032), 8) == "BUSTMETA", "missing page trailer");
      Require(BE(p, 4040) == 1 && BE(p, 4048) == i && BE(p, 4052) == 4096, "wrong durable page identity");
      Require(BE(p, 4056, 8) > 0 && BE(p, 4064, 8) > 0, "page generation/LSN was not sealed");
      Require(BE(p, 4072) == CRC(p), "canonical page checksum mismatch");
    }
    Require(BE(pages[0], 4044) == 1, "page zero is not the allocation root");
    std::set<uint32_t> visited;
    auto root = static_cast<uint32_t>(BE(pages[0], 0));
    if (root != NONE) {
      Walk(root, &visited);
    }
  }
  auto At(uint32_t id, uint32_t kind) const -> const Page & {
    Require(id < pages.size(), "disk reference is out of bounds");
    Require(BE(pages[id], 4044) == kind, "disk reference has wrong page kind");
    return pages[id];
  }
  auto ReadValue(uint32_t id, uint32_t slot) const -> Bytes {
    const auto &p = At(id, 3);
    Require(slot < BE(p, 4), "RID points outside slots");
    auto pos = 8 + slot * 16;
    auto offset = BE(p, pos), size = BE(p, pos + 4), next = BE(p, pos + 8), total = BE(p, pos + 12);
    Require(total <= 65536 && offset + size <= 4032, "invalid disk value bounds");
    Bytes value;
    for (size_t i = 0; i < size; i++) {
      value.push_back(std::byte(p[offset + i]));
    }
    std::set<uint32_t> seen;
    while (next != NONE) {
      Require(seen.insert(next).second, "overflow cycle");
      const auto &o = At(next, 4);
      auto length = BE(o, 4);
      Require(length <= 4024, "overflow beyond body");
      for (size_t i = 0; i < length; i++) {
        value.push_back(std::byte(o[8 + i]));
      }
      next = BE(o, 0);
    }
    Require(value.size() == total, "durable value is truncated");
    return value;
  }
  void Walk(uint32_t id, std::set<uint32_t> *visited) {
    Require(visited->insert(id).second, "tree has repeated child");
    const auto &p = At(id, 2);
    auto count = BE(p, 4);
    Require(count > 0 && count <= 113, "invalid disk tree count");
    if (BE(p, 0) == 1) {
      for (size_t i = 0; i < count; i++) {
        auto key = 16 + i * 32;
        Key decoded{BE(p, key, 8), BE(p, key + 8, 8), BE(p, key + 16, 8)};
        auto value = ReadValue(BE(p, 3280 + i * 8), BE(p, 3284 + i * 8));
        Require(values.emplace(decoded, std::move(value)).second, "duplicate durable key");
      }
    } else {
      Require(BE(p, 0) == 2, "unknown disk tree type");
      for (size_t i = 0; i < count; i++) {
        Walk(BE(p, 3628 + i * 4), visited);
      }
    }
  }
};
void ExpectIOError(const MetadataWritebackResult &result) {
  ASSERT_EQ(result.outcome_, MetadataWritebackOutcome::Failed) << "accepted IO failure must not report durable";
  ASSERT_GT(result.page_count_, 0U);
  ASSERT_TRUE(result.error_);
  try {
    std::rethrow_exception(result.error_);
  } catch (const std::system_error &error) {
    EXPECT_EQ(error.code().value(), EIO);
  }
}
TEST(MetadataPageWriterTest, CanonicalPagesAndReopenWriteback) {
  Image file;
  Model model;
  {
    Stack s(file.path, true);
    MetadataEngine engine(s.bootstrap, s.journal_id, s.journal, s.options);
    engine.Create();
    auto batch = Fill(350, 13);
    batch.push_back({{UINT64_MAX, UINT64_MAX, UINT64_MAX}, Value(19017, 5)});
    Apply(engine, batch, &model);
    auto written = Drain(engine, 7);
    auto disk = DiskView(file);
    EXPECT_EQ(disk.values, model) << "final Metadata region must equal committed input";
    EXPECT_EQ(written, disk.pages.size());
    EXPECT_EQ(Drain(engine, 7), 0U);
    Apply(engine, {{KeyFor(7), Value(17111, 43)}, {KeyFor(31), std::nullopt}}, &model);
    EXPECT_GT(Drain(engine, 3), 0U);
    EXPECT_EQ(DiskView(file).values, model);
  }
  Stack s(file.path, false);
  MetadataEngine reopened(s.bootstrap, s.journal_id, s.journal, s.options);
  reopened.Open();
  EXPECT_GT(Drain(reopened, 11), 0U) << "reopen must establish page persistence again without a checkpoint";
  EXPECT_EQ(DiskView(file).values, model);
}
TEST(MetadataPageWriterTest, UncommittedChangesStayOutOfPageRegion) {
  Image file;
  Stack s(file.path, true);
  MetadataEngine engine(s.bootstrap, s.journal_id, s.journal, s.options);
  engine.Create();
  Model model;
  Apply(engine, Fill(70, 9), &model);
  Drain(engine, 32);
  auto original = file.ReadRegion();
  std::future<JournalResult> commit;
  ReleaseOnExit release;
  Arm(GateKind::Flush, true, false);
  commit = std::async(std::launch::async, [&] {
    return engine.Commit(engine.Read(), {{KeyFor(3), Value(14017, 99)}});
  });
  ASSERT_TRUE(WaitEntered());
  auto wb = engine.Writeback(32);
  EXPECT_EQ(wb.outcome_, MetadataWritebackOutcome::Clean) << "uncommitted pages must not enter writeback";
  EXPECT_EQ(file.ReadRegion(), original) << "pending WAL must leave final page region unchanged";
  Release();
  ASSERT_EQ(commit.get().outcome_, JournalOutcome::Durable);
  model[{0, 3, 3}] = Value(14017, 99);
  EXPECT_GT(Drain(engine, 32), 0U);
  EXPECT_EQ(DiskView(file).values, model);
}
TEST(MetadataPageWriterTest, ReusedSlotsKeepNewerWorkPending) {
  Image file;
  Stack s(file.path, true);
  MetadataEngine engine(s.bootstrap, s.journal_id, s.journal, s.options);
  engine.Create();
  Model model;
  Apply(engine, Fill(160, 1), &model);
  Drain(engine, 128);
  auto old = engine.Read();
  auto original = model;
  Apply(engine, {{KeyFor(0), Value(21019, 11)}}, &model);
  std::future<MetadataWritebackResult> writing;
  std::future<void> changing;
  ReleaseOnExit release;
  Arm(GateKind::OverflowWrite, true, false);
  writing = std::async(std::launch::async, [&] { return engine.Writeback(1024); });
  ASSERT_TRUE(WaitEntered());
  ASSERT_TRUE(WaitOtherWrite()) << "independent pages must progress while one page IO is stalled";
  uint32_t blocked_id;
  uint64_t blocked_generation;
  {
    std::lock_guard<std::mutex> lock(gate_mutex);
    blocked_id = stalled_page;
    blocked_generation = stalled_generation;
  }
  try {
    engine.Writeback(1024);
    FAIL() << "overlapping writeback must reject before IO";
  } catch (const MetadataError &e) {
    EXPECT_EQ(e.Code(), MetadataErrorCode::ResourceUnavailable);
  }
  changing = std::async(std::launch::async, [&] {
    std::vector<MetadataMutation> replace;
    for (uint64_t i = 0; i < 160; i++) {
      replace.push_back({KeyFor(i), std::nullopt});
    }
    // More live pages than before: the allocator must consume the old free
    // slots, including the exact overflow page whose old write is paused.
    auto fresh = Fill(320, 47);
    replace.insert(replace.end(), fresh.begin(), fresh.end());
    Apply(engine, replace, &model);
  });
  ASSERT_EQ(changing.wait_for(std::chrono::seconds(10)), std::future_status::ready)
      << "page IO must not hold the transaction mutex";
  changing.get();
  Release();
  ASSERT_EQ(writing.get().outcome_, MetadataWritebackOutcome::Durable);
  EXPECT_GT(Drain(engine, 9), 0U) << "older completion must leave newer versions pending";
  auto disk = DiskView(file);
  EXPECT_EQ(disk.values, model);
  ASSERT_LT(blocked_id, disk.pages.size());
  EXPECT_GT(BE(disk.pages[blocked_id], 4056, 8), blocked_generation)
      << "the stalled physical page slot must actually be reused";
  EXPECT_NE(BE(disk.pages[blocked_id], 4044), 5U)
      << "the stalled slot must hold a new live page, not just a free marker";
  for (const auto &[key, value] : original) {
    EXPECT_EQ(old.Get({std::get<0>(key), std::get<1>(key), std::get<2>(key)}), value);
  }
}
TEST(MetadataPageWriterTest, FailuresRetainWorkAndCloseDrains) {
  Image file;
  Stack s(file.path, true);
  MetadataEngine engine(s.bootstrap, s.journal_id, s.journal, s.options);
  engine.Create();
  Model model;
  Apply(engine, Fill(80, 2), &model);
  auto before = file.ReadRegion();
  {
    // Reserve all existing F02 operation slots; no fake capacity setter.
    auto held = s.io.TryPrepare(std::vector<IORequest>(4096, {IOOperation::Read, Range(40 * MIB, 4096)}), false);
    ASSERT_EQ(held.admission_, IOAdmission::Accepted);
    try {
      engine.Writeback(32);
      FAIL() << "writeback must report real executor pressure";
    } catch (const MetadataError &e) {
      EXPECT_EQ(e.Code(), MetadataErrorCode::ResourceUnavailable);
    }
    EXPECT_EQ(file.ReadRegion(), before);
  }
  for (auto failure : {GateKind::PageWrite, GateKind::Flush}) {
    Arm(failure, false, true);
    ExpectIOError(engine.Writeback(1024));
    ASSERT_FALSE(HasFatalFailure());
    EXPECT_GT(Drain(engine, 7), 0U) << "failed writes must remain pending for explicit retry";
    EXPECT_EQ(DiskView(file).values, model);
    Apply(engine, {{KeyFor(1), Value(12013, failure == GateKind::PageWrite ? 91 : 71)}}, &model);
  }
  std::future<MetadataWritebackResult> writing;
  std::future<void> closing;
  ReleaseOnExit release;
  Arm(GateKind::Flush, true, false);
  writing = std::async(std::launch::async, [&] { return engine.Writeback(1024); });
  ASSERT_TRUE(WaitEntered());
  EXPECT_EQ(writing.wait_for(std::chrono::milliseconds(0)), std::future_status::timeout)
      << "writeback must await Flush before reporting durable";
  std::promise<void> close_started;
  closing = std::async(std::launch::async, [&] {
    close_started.set_value();
    engine.Close();
  });
  close_started.get_future().wait();
  EXPECT_EQ(closing.wait_for(std::chrono::milliseconds(100)), std::future_status::timeout)
      << "Close must drain the accepted page writeback";
  Release();
  ASSERT_EQ(writing.get().outcome_, MetadataWritebackOutcome::Durable);
  closing.get();
  EXPECT_EQ(DiskView(file).values, model);
}
}  // namespace
}  // namespace bustub
