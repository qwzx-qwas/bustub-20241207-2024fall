"""Opt-in F09 real page writeback; reuse archived F08 regressions unchanged."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tarfile
import time
import xml.etree.ElementTree as ET

TESTS = {'CanonicalPagesAndReopenWriteback', 'UncommittedChangesStayOutOfPageRegion',
         'ReusedSlotsKeepNewerWorkPending', 'FailuresRetainWorkAndCloseDrains'}
F08 = {'MixedValuesSplitMergeAndReopen', 'OldViewsConflictAndSpaceReuse', 'RejectedPrivateChangesDoNotLeak',
       'PublicationWaitsForDurabilityAndFaultsOnUnknownResult', 'ProcessExitReplaysConfirmedNonemptyTransactions',
       'ValidJournalCannotHideWrongMetadataRedoBase'}
p = argparse.ArgumentParser()
p.add_argument('--repo', required=True)
p.add_argument('--work', required=True)
p.add_argument('--mutations', action='store_true')
a = p.parse_args()
repo, work = Path(a.repo).resolve(), Path(a.work).resolve()
if repo == work or repo in work.parents:
    raise RuntimeError('work must be outside the repository')
work.mkdir(parents=True, exist_ok=True)
build = work/'build'
env = {k:v for k,v in os.environ.items() if not k.startswith('GTEST_')}
env.update(F09_WORKDIR=str(work), F08_WORKDIR=str(work), ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',
           UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
commands = []
def call(argv, log, expected=0, timeout=300):
    argv = list(map(str, argv))
    item={'command':argv, 'log':log}; commands.append(item)
    start=time.monotonic()
    try:
        with (work/log).open('w') as f:
            done=subprocess.run(argv,cwd=work,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
        item['exit']=done.returncode
        if done.returncode != expected: raise RuntimeError(f'{log}: {done.returncode}, expected {expected}')
    except subprocess.TimeoutExpired:
        item['timeout_seconds']=timeout
        raise
    finally:
        item['elapsed_seconds']=time.monotonic()-start
        (work/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
def cases(path): return ET.parse(path).getroot().findall('./testsuite/testcase')
def check(path,names):
    found=cases(path)
    if len(found)!=len(names) or {x.get('name') for x in found}!=names:
        raise RuntimeError('wrong test discovery: '+str(path))
    if any(x.get('status')!='run' or x.get('result')!='completed' or
           any(x.find(tag) is not None for tag in ('failure','error','skipped')) for x in found):
        raise RuntimeError('test failed or skipped: '+str(path))
call(['cmake','-S',repo,'-B',build,'-DCMAKE_BUILD_TYPE=Debug','-DCMAKE_C_COMPILER=clang-14',
      '-DCMAKE_CXX_COMPILER=clang++-14','-DBUSTUB_SANITIZER=address,undefined','-DCMAKE_EXE_LINKER_FLAGS=-no-pie'], 'configure-runner.log')
call(['cmake','--build',build,'--target','bustub','gtest_main','-j3'],'build-runner.log',timeout=900)
flags=['clang++-14','-std=c++17','-g','-O0','-Wall','-Wextra','-Werror','-Wno-unused-parameter',
       '-fsanitize=address,undefined','-fno-omit-frame-pointer','-pthread',
       '-I'+str(repo/'src/include'),'-I'+str(repo/'third_party/fmt/include'),
       '-I'+str(repo/'third_party/googletest/googletest/include')]
libs=[build/'lib'/x for x in ('libbustub.a','libfmtd.a','libgtest_main.a','libgtest.a')]
source=Path(__file__).with_name('metadata_page_writer_test.cpp')
obj=work/'f09-test.o'
call(flags+['-c',source,'-o',obj],'test-compile.log')
def link(exe,extra=()):
    call(flags+['-no-pie',obj,*extra,*libs,'-Wl,--wrap=fdatasync','-Wl,--wrap=pwrite','-o',exe],exe.name+'-link.log')
def run(exe,suite,names,xml,log):
    xml.unlink(missing_ok=True)
    call([exe,'--gtest_filter='+suite+'.*','--gtest_repeat=1','--gtest_shuffle=0','--gtest_output=xml:'+str(xml)],log)
    check(xml,names)
exe=work/'f09-test';link(exe)
run(exe,'MetadataPageWriterTest',TESTS,work/'f09.xml','f09-run.log')
print('F09: four real page-writeback scenarios passed',flush=True)
archive=repo/'test/archives/F08-metadata-engine.tar.gz'
with tarfile.open(archive) as t:
    source_bytes=t.extractfile('F08-metadata-engine/test/storage_redesign/metadata_engine_test.cpp').read()
    manifest=json.load(t.extractfile('F08-metadata-engine/MANIFEST.json'))
assert hashlib.sha256(source_bytes).hexdigest()==manifest['files']['test/storage_redesign/metadata_engine_test.cpp']['sha256']
f08source=work/'f08-regression.cpp'; f08source.write_bytes(source_bytes)
f08obj=work/'f08-regression.o';f08exe=work/'f08-regression'
call(flags+['-c',f08source,'-o',f08obj],'f08-compile.log')
call(flags+['-no-pie',f08obj,*libs,'-Wl,--wrap=fdatasync','-o',f08exe],'f08-link.log')
run(f08exe,'MetadataEngineTest',F08,work/'f08.xml','f08-run.log')
print('F08: six archived regression cases passed unchanged',flush=True)
(work/'regression-provenance.json').write_text(json.dumps({'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
    'test_sha256':hashlib.sha256(source_bytes).hexdigest()},indent=2)+'\n')
if a.mutations:
    original=(repo/'src/storage/disk/metadata_engine.cpp').read_text()
    mutants=[]
    def add(name,old,new,test,oracle):
        if original.count(old)!=1: raise RuntimeError('mutation source drift: '+name)
        mutants.append((name,original.replace(old,new),test,oracle))
    canonical='CanonicalPagesAndReopenWriteback'
    failure='FailuresRetainWorkAndCloseDrains'
    concurrent='ReusedSlotsKeepNewerWorkPending'
    add('native_page_body','std::memcpy(buffer, body.data(), BODY);','std::memcpy(buffer, page.data_.data(), BODY); (void)body;',
        canonical,'canonical page high-water is invalid')
    add('omit_page_trailer','std::memcpy(buffer + BODY, page.data_.data() + BODY, TRAILER);',
        'std::memset(buffer + BODY, 0, TRAILER);',canonical,'missing page trailer')
    add('ignore_changed_lsn','durable_[id].generation_ != page.generation_ || durable_[id].lsn_ != page.lsn_',
        'durable_[id].generation_ != page.generation_',canonical,'DiskView(file).values')
    add('advance_failed_progress','    if (!result.writes_durable_) {',
        '    if (!result.writes_durable_) {\n      for (size_t i = 0; i < requests.size(); i++) { durable_[requests[i].page_id_] = versions[i]; }',
        failure,'failed writes must remain pending')
    add('skip_page_flush','backend_.TryPrepare(requests, true)','backend_.TryPrepare(requests, false)',
        canonical,'writeback did not become durable')
    add('accept_overlapping_writeback','    throw MetadataError(MetadataErrorCode::ResourceUnavailable, "metadata writeback is already active");',
        '    return {MetadataWritebackOutcome::Clean, 0, nullptr};',concurrent,'overlapping writeback must reject before IO')
    add('skip_close_drain','  std::lock_guard<std::mutex> writeback(impl_->writeback_mutex_);','  /* mutated: Close does not drain page IO */',
        failure,'Close must drain the accepted page writeback')
    add('block_transactions_on_page_io','  return s.page_writer_.Write(std::move(view), max_pages);',
        '  std::lock_guard<std::mutex> writer(s.writer_mutex_);\n  return s.page_writer_.Write(std::move(view), max_pages);',
        concurrent,'page IO must not hold the transaction mutex')
    results=[]
    for name,code,test,oracle in mutants:
        cpp=work/(name+'.cpp');cpp.write_text(code)
        mo=work/(name+'.o');me=work/name
        call(flags+['-c',cpp,'-o',mo],name+'-compile.log')
        link(me,[mo]);xml=work/(name+'.xml');xml.unlink(missing_ok=True)
        call([me,'--gtest_filter=MetadataPageWriterTest.'+test,'--gtest_repeat=1','--gtest_shuffle=0',
              '--gtest_output=xml:'+str(xml)],name+'-run.log',expected=1)
        found=cases(xml);errors=[f for c in found for f in c.findall('failure')]
        if len(found)!=1 or found[0].get('name')!=test or not any(oracle in (f.text or '') for f in errors):
            raise RuntimeError('wrong mutant failure: '+name)
        results.append({'name':name,'test':test,'oracle':oracle,'exit':1})
        (work/'mutations.json').write_text(json.dumps(results,indent=2)+'\n')
        cpp.unlink();mo.unlink();me.unlink()
        print('caught '+name,flush=True)
(work/'environment.json').write_text(json.dumps({k:env[k] for k in ('F09_WORKDIR','F08_WORKDIR','ASAN_OPTIONS','UBSAN_OPTIONS')},indent=2)+'\n')
