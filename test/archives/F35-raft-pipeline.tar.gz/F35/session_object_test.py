#!/usr/bin/env python3
"""Window protocol through the formal CLI and existing Direct-node harness."""
import argparse, json, os, pathlib, subprocess, sys, time
p=argparse.ArgumentParser(); p.add_argument('--repo',type=pathlib.Path,required=True); p.add_argument('--build',type=pathlib.Path,required=True); p.add_argument('--output',type=pathlib.Path,required=True); p.add_argument('--port-base',type=int,default=36100)
a=p.parse_args(); repo=a.repo.resolve(); build=a.build.resolve(); root=a.output.resolve();root.mkdir(parents=True,exist_ok=False)
sys.path.insert(0,str(repo/'test/storage_acceptance'))
from runtime import Cluster
source=(repo/'docs/storage_redesign/node-storage.example.conf').read_text()
source=source.replace('memory.bytes=268435456','memory.bytes=67108864').replace('memory.progress_bytes=33554432','memory.progress_bytes=16777216').replace('metadata.max_live_pages=512','metadata.max_live_pages=64')
template=root/'template.conf';template.write_text(source)
config={'port_base':a.port_base,'buffer_pages':64,'snapshot_threshold':4,'storage_template':str(template)}
(root/'config.json').write_text(json.dumps(config,indent=2))
cluster=None;history=[];number=1000

def send(node,action,request,sql=None,client=None,ack=None):
    argv=[str(build/'bin/bustub-client'),action,'--endpoint',f'127.0.0.1:{a.port_base+100+node}','--request-id',str(request),'--timeout-ms','12000']
    if sql is not None: argv+=['--sql',sql]
    if client is not None: argv+=['--client-id',str(client)]
    if ack is not None: argv+=['--ack-through',str(ack)]
    result=subprocess.run(argv,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=15)
    history.append({'argv':argv,'returncode':result.returncode,'stdout':result.stdout,'stderr':result.stderr})
    (root/'history.json').write_text(json.dumps(history,indent=2))
    fields={}
    for line in result.stdout.splitlines():
        for token in line.split():
            if '=' in token:
                key,value=token.split('=',1);fields[key]=value
    return fields,result.stdout

def leader():
    global number
    deadline=time.monotonic()+30
    while time.monotonic()<deadline:
        for node in list(cluster.running):
            number+=1
            fields,_=send(node,'status',number)
            if fields.get('status')=='OK' and fields.get('leader_ready')=='1' and fields.get('leader_id')==str(node): return node
        time.sleep(.05)
    raise AssertionError('no ready leader')

def expected(node,action,request,status,**kwargs):
    fields,output=send(node,action,request,**kwargs)
    assert fields.get('status')==status,(fields,output)
    return fields,output

def restart_all():
    for node in list(cluster.running):cluster.kill(node,time.monotonic()+15)
    for node in (1,2,3):cluster.start(node,time.monotonic()+15)
    return leader()

try:
    cluster=Cluster(build,root,config); owner=leader()
    expected(owner,'write',1,'COMMITTED',client=1800,sql='CREATE TABLE win(id int PRIMARY KEY,v int);')
    requests={str(i):('INSERT INTO win VALUES(83,10);' if i==1 else 'UPDATE win SET v=v+1 WHERE id=83;') for i in range(1,10)}
    # Simulate an application retaining its exact retry inputs across restart.
    (root/'client-journal.json').write_text(json.dumps({'client':1801,'requests':requests,'acknowledged':0},indent=2))
    receipts={}
    for i in range(1,9): receipts[i]=expected(owner,'window-write',i,'COMMITTED',client=1801,sql=requests[str(i)])[0]['response_bytes']
    expected(owner,'window-write',9,'WINDOW_FULL',client=1801,sql=requests['9'])
    (root/'client-journal.json').write_text(json.dumps({'client':1801,'requests':requests,'acknowledged':4}))
    expected(owner,'ack',900,'OK',client=1801,ack=4)
    expected(owner,'window-write',1,'RESULT_EXPIRED',client=1801,sql=requests['1'])
    owner=restart_all()
    requests=json.loads((root/'client-journal.json').read_text())['requests']
    fields,_=expected(owner,'window-write',5,'COMMITTED',client=1801,sql=requests['5'])
    assert fields['response_bytes']==receipts[5]
    expected(owner,'window-write',1,'RESULT_EXPIRED',client=1801,sql=requests['1'])
    (root/'client-journal.json').write_text(json.dumps({'client':1801,'requests':requests,'acknowledged':8}))
    expected(owner,'window-write',9,'COMMITTED',client=1801,sql=requests['9'],ack=8)
    (root/'client-journal.json').write_text(json.dumps({'client':1801,'requests':requests,'acknowledged':9}))
    closed,_=expected(owner,'close',901,'OK',client=1801,ack=9)
    close_index=int(closed['published_applied_index'])
    # Force a snapshot beyond CLOSE using the original protocol, retaining mixed-mode compatibility.
    for i in range(2,10):expected(owner,'write',i,'COMMITTED',client=1800,sql='UPDATE win SET v=v+1 WHERE id=83;')
    deadline=time.monotonic()+15
    while time.monotonic()<deadline:
        fields,_=send(owner,'status',902)
        if int(fields.get('snapshot_base_index','0'))>=close_index:break
        time.sleep(.05)
    assert int(fields.get('snapshot_base_index','0'))>=close_index,fields
    owner=restart_all()
    expected(owner,'window-write',9,'SESSION_CLOSED',client=1801,sql=requests['9'])
    _,output=expected(owner,'read',903,'OK',sql='SELECT v FROM win WHERE id=83;')
    assert output.splitlines()[-1]=='26',output
    (root/'summary.json').write_text(json.dumps({'passed':True,'backend':'Direct object','memory_bytes':67108864,'metadata_live_pages':64,'expected_value':26,'restarts':2,'snapshot_base_before_restart':fields['snapshot_base_index']},indent=2))
finally:
    if cluster is not None:
        status=cluster.close()
        (root/'close.json').write_text(json.dumps({'exit_status':status}))
        assert status==0,('cluster shutdown',status)
