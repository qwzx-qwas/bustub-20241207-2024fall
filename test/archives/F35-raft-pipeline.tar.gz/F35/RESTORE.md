# F35 / S13.2b 定向验证

阶段源码仅压缩交付，不接入常驻 CMake。原共同正确性和性能测试继续使用 `test/storage_acceptance/run.py`；既有 Raft/SQL/TCP 回归继续在原文件维护。

## 恢复与运行

1. 在临时目录解压，核对包内 `SHA256SUMS` 与 `SOURCE_SHA256.json` 的项目源码指纹。
2. 使用支持项目 F26 C++23 生命周期 API 的 GCC 16.2.0 或兼容工具链配置 Release：`cmake -S <repo> -B <build> -DCMAKE_BUILD_TYPE=Release -DCMAKE_EXPORT_COMPILE_COMMANDS=ON`，同时按本机设置 C/C++ 编译器。项目仍按原目标选择 C++ 标准。
3. 构建 `sql_command_preparer_test`、`distributed_node_test`、`raft_node_test`、`read_timestamp_test`。前两者提供 runner 复用的编译/链接参数；原 TCP fixture 从项目测试文件直接引用，不复制第二套集群。
4. 为自定义 GCC 设置 `LD_LIBRARY_PATH`，在允许本机 TCP 的环境执行：

```sh
python3 <解压目录>/run.py --repo <repo> --build <build> --output <新结果目录> --nodes --mutations
```

默认执行9项组件场景；`--nodes` 增加4项真实节点场景；`--mutations` 执行10个组件变异，并在启用节点时执行5个节点变异。`--nodes-only` 用于只跳过组件变异的分轮复验，仍执行组件正常基线。该选项不表示只运行节点正常场景。

## 判据、资源和重复职责

先核对代码逻辑与完整协议，再运行测试。输入模型、日志持久边界、真实 ACK、SQL 最终内容和重开后的去重结果共同判定；不固定 slot/RID 排列，不新增生产 getter、延时分支或线程池。原6项组件风险保留在同一个9项组件集合中。最新组合场景还覆盖OR后续键、AND剩余条件、被过滤键的登记和Prepare失败释放。

变异隔离编译修改的 TU，不修改项目库或源码；仅返回1且指定测试出现 assertion failure 算检出，异常、构建失败、超时、崩溃不算。runner 清除外部 GTEST 过滤/重复设置，并验证正常测试 XML 的实际名称和状态。构建/变异可耗时数分钟，运行后清理临时输出，避免留下二进制或设备。

真实节点测试复用原 TCP fixture，覆盖独立键重叠、冲突/缺失键等待、整表谓词与其他表进展、快照发布和冷重开。原共同 C/P 承担 Direct 对象后端、独立线性一致性检查和低缓存压力；本包不是设备掉电或性能提升证据。

当前证据：44项既有回归、13项阶段场景、15个隔离变异；本次复审实际重跑13项阶段场景和5项节点变异，其他核验源码一致后沿用；各分轮结果与失败测试修正说明见 `docs/storage_redesign/s132b_execution_20261009.md`。最终结果入口为 `test-results/storage-s13-20261009/README.md`。已将旧 `node_mutation.py` 并入唯一 runner，不再保留重复入口。
