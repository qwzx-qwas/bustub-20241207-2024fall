# F35 / S13.3 阶段测试

仅压缩交付，不注册常驻 CMake 测试。既有回归及原共同 C/P 保持原入口。

## 运行

1. 解压至临时目录，校验 SHA256SUMS 和 SOURCE_SHA256.json。
2. 用 GCC16.2.0（或满足 F26 C++23 生命周期要求的工具链）配置 Release，启用 compile_commands.json。
3. 构建 sql_command_preparer_test、distributed_node_test、bustub-node、bustub-client；共同C/P另需 storage-e2e-driver。
4. 配置自定义工具链的 LD_LIBRARY_PATH，在允许本机 TCP 的环境运行：

```
python3 run.py --repo <repo> --build <build> --output <新结果目录> --nodes --mutations --direct
```

默认10项组件；--nodes增加7项真实节点；--mutations为13组件＋9节点变异；--window-mutations仅执行新增3个窗口变异及组件正常基线。--nodes-only跳过组件变异，不跳过组件正常基线。--direct使用正式CLI、原runtime.Cluster/cluster.sh、64MiB预算和B正文64页，运行独立的对象后端窗口场景，可用--port-base指定本地端口段。

原共同C1复用 test/storage_acceptance/run.py，内容和判据不变；在WSL上先按其要求核实宿主磁盘余量。测试不会把预先存在的设备用于格式化，只创建本次新结果目录内的测试文件。

## 判据与边界

人工输入产生独立业务值115/26；结果按原始收据比较；有多数派/无多数派、退休/保留、旧/新协议相互配对。新组件测试另检查快照边界与完整窗口恢复。2026-10-10扩充既有输入错误节点场景：同条重复主键、INSERT/UPDATE NULL主键、重复索引列必须持久拒绝，合法请求8随后得到(27,14)、(43,21)、(59,34)。新增4个对应错误分类变异。前13项既有阶段风险继续保留，新4项C++和1个Direct脚本填补同客户端窗口缺口，不用多个client_id冒充单会话并发。

变异只编译隔离TU；异常、崩溃、超时和构建失败不算检出，须指定测试出现断言失败。没有生产hook或测试getter。Node测试直接包含原fixture；Direct脚本导入既有Cluster，不复制集群和存储实现。

2026-10-09初轮66项原回归、17项F35场景、18项变异、原共同C1和Direct窗口通过。2026-10-10复验成绩及对应源码见执行审查§6和结果包当前summary；旧Direct/C1证据保留在prior-20261009，不能冒充本次重跑。失败诊断、测试修正、八项设计审查及限制见 docs/storage_redesign/s133_execution_20261009.md。结果包位于 test-results/storage-s13-20261009/F35-results.tar.gz，旧包被替换。运行后删除临时设备、二进制与解压源码。

没有性能提升结论、全量C/P矩阵、ASan/TSan或设备掉电证据。首次新会话创建串行；SDK仍无状态，客户端持久重试输入/确认承诺由应用管理；旧二进制不能读取新增V3。
