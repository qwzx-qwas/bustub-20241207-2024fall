# F35 S13.1 / S13.2a 定向验证

这是阶段场景，不接入常驻 CMake。共同正确性与性能测试继续使用 `test/storage_acceptance/run.py`。

## 恢复与运行

1. 在临时目录解压本包。
2. 使用支持项目 F26 C++23 生命周期 API 的工具链配置 Release 构建。构建 `sql_command_preparer_test`（提供本脚本复用的编译/链接参数）及正式节点和所需共同测试目标。
3. 为自定义 GCC 设置相应 `LD_LIBRARY_PATH`，执行：

```
python3 <解压目录>/run.py --repo <项目路径> --build <构建路径> --output <新的结果目录> --mutations
```

脚本读取 CMake 编译参数，隔离编译七处 mutation（六项阶段测试与一个既有SQL用例），不修改项目源码或库。只有指定测试的 assertion 失败计为 mutation kill；构建失败、超时和崩溃不算。

## 判断依据与限制

六项场景分别覆盖慢 Apply 的协议进展、迟到准备的任期失效、持久化 ACK 边界、匹配前缀之外的旧后缀、完整残余谓词、有界稀疏范围。阻塞适配器仅利用已有虚函数，正文预期由输入整数独立计算。没有生产测试 hook。

Gate 用条件变量确认交错，超时只作挂死上限。文件在 fixture 析构中清理，节点排空后才删目录。正常业务/Direct 对象路径、真实网络、线性一致性、重启追赶由原 C1–C5/P2 接管；本包不证明设备掉电或性能提升。

八项测试设计审查及实际结果：`docs/storage_redesign/s13_execution_20261009.md`。

本次还强化了既有真实 TCP 用例 `DistributedNodeTest.LiveOldLeaderClearsOverwrittenProposalAfterDifferentPayloadCommitsElsewhere`，保留在原测试文件中，不复制一套集群。构建 `distributed_node_test` 并正常运行后，可执行以下隔离变异（需要允许本机 TCP）：

```
python3 <解压目录>/node_mutation.py --repo <项目路径> --build <构建路径> --output <另一新结果目录>
```

该脚本删除 ActiveWrite 的任期失效检查，链接原测试的对象文件与单独编译的变异 TU。总共六个阶段正常场景、八个可执行的指定变异（七个由run.py执行，另一个由node_mutation.py执行）；原 TCP 用例计入既有回归，不重复计为阶段新增测试。

2026-10-09 类型复审：run.py 新增移除等值键类型检查的变异，直接复用已有 `SqlCommandPreparerTest.BigIntPrimaryKeyIsPreparedAppliedAndRecovered`，不复制该测试。runner 隔离 GTEST 环境并核验六个阶段用例的 XML 名称、执行状态。最新复验为9项相关既有回归、6项阶段测试、7项run.py变异；TCP变异及共同C/P保留此前版本证据，本次未重跑。详见执行审查§12。
