// Reuse the existing real TCP cluster and business codecs; no second cluster adapter.
#include "test/legacy_raft/distributed/distributed_node_test.cpp"
#include <future>

namespace bustub {
TEST(F35Node, IndependentKeysAdvanceWhileConflictsAndMissingKeysWait) {
  ThreeNodeInProcessCluster cluster;
  const auto leader = cluster.AwaitLeader();
  ASSERT_EQ(cluster.Send(leader, ClientWriteRequestV1{170, 1, "CREATE TABLE p(id int PRIMARY KEY,v int);"}).status_, ClientResponseStatus::COMMITTED);
  ASSERT_EQ(cluster.Send(leader, ClientWriteRequestV1{170, 2, "INSERT INTO p VALUES(17,10),(91,20);"}).status_, ClientResponseStatus::COMMITTED);
  cluster.AwaitCommit(3);
  std::vector<NodeId> peers;
  for (NodeId id = 1; id <= 3; ++id) if (id != leader) { peers.push_back(id); cluster.StopAndDestroy(id); }
  const auto before = cluster.LogJournalSize(leader);
  const ClientWriteRequestV1 a{171,1,"UPDATE p SET v=v+1 WHERE id=17;"};
  const ClientWriteRequestV1 b{172,1,"UPDATE p SET v=v+7 WHERE id=91;"};
  const ClientWriteRequestV1 conflict{173,1,"UPDATE p SET v=v+3 WHERE id=17;"};
  const ClientWriteRequestV1 absent{174,1,"DELETE FROM p WHERE id=43;"};
  const ClientWriteRequestV1 insert{175,1,"INSERT INTO p VALUES(43,99);"};
  EXPECT_EQ(cluster.Send(leader,a).status_,ClientResponseStatus::TIMEOUT);
  const auto after_a=cluster.LogJournalSize(leader);
  EXPECT_GT(after_a,before);
  EXPECT_EQ(cluster.Send(leader,b).status_,ClientResponseStatus::TIMEOUT);
  const auto after_b=cluster.LogJournalSize(leader);
  ASSERT_GT(after_b,after_a) << "independent request must reach durable log without publishing the first";
  EXPECT_EQ(cluster.Send(leader,conflict).status_,ClientResponseStatus::TIMEOUT);
  ASSERT_EQ(cluster.LogJournalSize(leader),after_b) << "conflict must re-prepare after publication";
  EXPECT_EQ(cluster.Send(leader,absent).status_,ClientResponseStatus::TIMEOUT);
  const auto after_absent=cluster.LogJournalSize(leader);
  EXPECT_GT(after_absent,after_b);
  EXPECT_EQ(cluster.Send(leader,insert).status_,ClientResponseStatus::TIMEOUT);
  ASSERT_EQ(cluster.LogJournalSize(leader),after_absent) << "an absent key is still a dependency";
  auto old=cluster.Send(leader,ClientReadRequestV1{177,ClientReadConsistency::STALE,"SELECT * FROM p ORDER BY id;"});
  ASSERT_EQ(old.status_,ClientResponseStatus::OK);
  EXPECT_EQ(old.commit_index_,3);
  EXPECT_EQ(ClientQueryResultCodec::Decode(old.payload_).rows_,(std::vector<std::vector<std::string>>{{"17","10"},{"91","20"}}));
  cluster.Restart(peers.front());
  cluster.AwaitCommit(8);
  cluster.Restart(peers.back());
  for (const auto &request : {a,b,conflict,absent,insert}) EXPECT_EQ(cluster.Send(leader,request).status_,ClientResponseStatus::COMMITTED);
  cluster.AwaitCommit(8);
  for (NodeId id=1;id<=3;++id) {
    auto rows=cluster.Send(id,ClientReadRequestV1{180+id,ClientReadConsistency::STALE,"SELECT * FROM p ORDER BY id;"});
    ASSERT_EQ(rows.status_,ClientResponseStatus::OK);
    EXPECT_EQ(ClientQueryResultCodec::Decode(rows.payload_).rows_,(std::vector<std::vector<std::string>>{{"17","14"},{"43","99"},{"91","27"}}));
  }
}

TEST(F35Node, ContinuousClientsPublishSnapshotsAndReopenExactContent) {
  ThreeNodeInProcessCluster cluster(6);
  auto leader=cluster.AwaitLeader();
  ASSERT_EQ(cluster.Send(leader,ClientWriteRequestV1{280,1,"CREATE TABLE p(id int PRIMARY KEY,v int);"}).status_,ClientResponseStatus::COMMITTED);
  ASSERT_EQ(cluster.Send(leader,ClientWriteRequestV1{280,2,"INSERT INTO p VALUES(17,10),(43,20),(91,30),(127,40);"}).status_,ClientResponseStatus::COMMITTED);
  const std::array<int,4> keys{17,43,91,127};
  std::vector<std::future<bool>> clients;
  for (size_t c=0;c<keys.size();++c) clients.push_back(std::async(std::launch::async,[&,c] {
    for(uint64_t r=1;r<=12;++r) {
      auto response=cluster.Send(leader,ClientWriteRequestV1{300+c,r,"UPDATE p SET v=v+1 WHERE id="+std::to_string(keys[c])+";"});
      if(response.status_!=ClientResponseStatus::COMMITTED) return false;
    }
    return true;
  }));
  for(auto &client:clients) EXPECT_TRUE(client.get());
  cluster.AwaitCommit(51);
  cluster.AwaitSnapshotGenerationCount(leader,2,51-6);
  cluster.StopAll();
  for(NodeId id=1;id<=3;++id) cluster.Restart(id);
  leader=cluster.AwaitLeader();
  auto rows=cluster.Send(leader,ClientReadRequestV1{401,ClientReadConsistency::LINEARIZABLE,"SELECT * FROM p ORDER BY id;"});
  ASSERT_EQ(rows.status_,ClientResponseStatus::OK);
  EXPECT_EQ(ClientQueryResultCodec::Decode(rows.payload_).rows_,(std::vector<std::vector<std::string>>{{"17","22"},{"43","32"},{"91","42"},{"127","52"}}));
  auto duplicate=cluster.Send(leader,ClientWriteRequestV1{300,12,"UPDATE p SET v=v+1 WHERE id=17;"});
  ASSERT_EQ(duplicate.status_,ClientResponseStatus::COMMITTED);
  auto one=cluster.Send(leader,ClientReadRequestV1{402,ClientReadConsistency::LINEARIZABLE,"SELECT v FROM p WHERE id=17;"});
  ASSERT_EQ(one.status_,ClientResponseStatus::OK);
  EXPECT_EQ(ClientQueryResultCodec::Decode(one.payload_).rows_,(std::vector<std::vector<std::string>>{{"22"}}));
}
} // namespace bustub

namespace bustub {
TEST(F35Node, TablePredicateBlocksPointsButOtherTablesProgress) {
  ThreeNodeInProcessCluster cluster;
  const auto leader=cluster.AwaitLeader();
  ASSERT_EQ(cluster.Send(leader,ClientWriteRequestV1{410,1,"CREATE TABLE p(id int PRIMARY KEY,v int);"}).status_,ClientResponseStatus::COMMITTED);
  ASSERT_EQ(cluster.Send(leader,ClientWriteRequestV1{410,2,"CREATE TABLE q(id int PRIMARY KEY,v int);"}).status_,ClientResponseStatus::COMMITTED);
  ASSERT_EQ(cluster.Send(leader,ClientWriteRequestV1{410,3,"INSERT INTO p VALUES(17,10),(43,20),(91,30);"}).status_,ClientResponseStatus::COMMITTED);
  cluster.AwaitCommit(4);
  std::vector<NodeId> peers;
  for(NodeId id=1;id<=3;++id) if(id!=leader) { peers.push_back(id); cluster.StopAndDestroy(id); }
  const auto before=cluster.LogJournalSize(leader);
  const ClientWriteRequestV1 range{411,1,"UPDATE p SET v=v+100 WHERE id>=40;"};
  const ClientWriteRequestV1 point{412,1,"UPDATE p SET v=v+1 WHERE id=17;"};
  const ClientWriteRequestV1 other{413,1,"INSERT INTO q VALUES(73,11);"};
  ASSERT_EQ(cluster.Send(leader,range).status_,ClientResponseStatus::TIMEOUT);
  const auto after_range=cluster.LogJournalSize(leader);
  ASSERT_GT(after_range,before);
  ASSERT_EQ(cluster.Send(leader,point).status_,ClientResponseStatus::TIMEOUT);
  ASSERT_EQ(cluster.LogJournalSize(leader),after_range) << "range plan holds the whole-table dependency";
  ASSERT_EQ(cluster.Send(leader,other).status_,ClientResponseStatus::TIMEOUT);
  ASSERT_GT(cluster.LogJournalSize(leader),after_range) << "table dependency must not become global";
  cluster.Restart(peers.front());
  cluster.AwaitCommit(7);
  cluster.Restart(peers.back());
  cluster.AwaitCommit(7);
  for(const auto &request:{range,point,other}) ASSERT_EQ(cluster.Send(leader,request).status_,ClientResponseStatus::COMMITTED);
  auto rows=cluster.Send(leader,ClientReadRequestV1{450,ClientReadConsistency::LINEARIZABLE,"SELECT * FROM p ORDER BY id;"});
  ASSERT_EQ(rows.status_,ClientResponseStatus::OK);
  EXPECT_EQ(ClientQueryResultCodec::Decode(rows.payload_).rows_,(std::vector<std::vector<std::string>>{{"17","11"},{"43","120"},{"91","130"}}));
  auto second=cluster.Send(leader,ClientReadRequestV1{451,ClientReadConsistency::LINEARIZABLE,"SELECT * FROM q;"});
  ASSERT_EQ(second.status_,ClientResponseStatus::OK);
  EXPECT_EQ(ClientQueryResultCodec::Decode(second.payload_).rows_,(std::vector<std::vector<std::string>>{{"73","11"}}));
}
} // namespace bustub

namespace bustub {
TEST(F35Node, MultiKeyPredicatesProtectExcludedRowsAndReleaseFailedClaims) {
  ThreeNodeInProcessCluster cluster;
  const auto leader = cluster.AwaitLeader();
  ASSERT_EQ(cluster.Send(leader, ClientWriteRequestV1{510, 1, "CREATE TABLE p(id int PRIMARY KEY,v int);"}).status_,
            ClientResponseStatus::COMMITTED);
  ASSERT_EQ(cluster.Send(leader, ClientWriteRequestV1{510, 2, "INSERT INTO p VALUES(17,10),(43,20),(91,30),(127,40);"}).status_,
            ClientResponseStatus::COMMITTED);
  cluster.AwaitCommit(3);

  // This is rejected by Prepare after it has acquired the logical keys. Neither
  // the log nor the later requests may retain any effect of the failed attempt.
  const auto before_failure = cluster.LogJournalSize(leader);
  auto rejected = cluster.Send(leader, ClientWriteRequestV1{
      511, 1, "UPDATE p SET id=id+1 WHERE id=17 OR id=91 OR id=127;"});
  ASSERT_EQ(rejected.status_, ClientResponseStatus::REJECTED);
  EXPECT_EQ(cluster.LogJournalSize(leader), before_failure);

  std::vector<NodeId> peers;
  for (NodeId id = 1; id <= 3; ++id) {
    if (id != leader) {
      peers.push_back(id);
      cluster.StopAndDestroy(id);
    }
  }
  // The second OR key is modified; the third fails the residual predicate but
  // still belongs to the footprint. A disjoint key must be able to progress.
  const ClientWriteRequestV1 multi{512, 1, "UPDATE p SET v=v+5 WHERE (id=17 OR id=91 OR id=127) AND v<35;"};
  const ClientWriteRequestV1 second_key{513, 1, "UPDATE p SET v=v+3 WHERE id=91;"};
  const ClientWriteRequestV1 excluded_key{515, 1, "UPDATE p SET v=v+2 WHERE id=127;"};
  const ClientWriteRequestV1 independent{514, 1, "UPDATE p SET v=v+7 WHERE id=43;"};
  ASSERT_EQ(cluster.Send(leader, multi).status_, ClientResponseStatus::TIMEOUT);
  const auto after_multi = cluster.LogJournalSize(leader);
  ASSERT_GT(after_multi, before_failure) << "failed Prepare must release its acquired key set";
  ASSERT_EQ(cluster.Send(leader, second_key).status_, ClientResponseStatus::TIMEOUT);
  ASSERT_EQ(cluster.LogJournalSize(leader), after_multi) << "second OR key must remain protected";
  ASSERT_EQ(cluster.Send(leader, excluded_key).status_, ClientResponseStatus::TIMEOUT);
  ASSERT_EQ(cluster.LogJournalSize(leader), after_multi) << "residual filtering must not shrink the declared key footprint";
  ASSERT_EQ(cluster.Send(leader, independent).status_, ClientResponseStatus::TIMEOUT);
  ASSERT_GT(cluster.LogJournalSize(leader), after_multi) << "finite AND/OR footprint must not become a table barrier";

  cluster.Restart(peers.front());
  cluster.AwaitCommit(7);
  cluster.Restart(peers.back());
  cluster.AwaitCommit(7);
  for (const auto &request : {multi, second_key, excluded_key, independent})
    ASSERT_EQ(cluster.Send(leader, request).status_, ClientResponseStatus::COMMITTED);
  for (NodeId id = 1; id <= 3; ++id) {
    auto read = cluster.Send(id, ClientReadRequestV1{520 + id, ClientReadConsistency::STALE,
                                                   "SELECT * FROM p ORDER BY id;"});
    ASSERT_EQ(read.status_, ClientResponseStatus::OK);
    EXPECT_EQ(ClientQueryResultCodec::Decode(read.payload_).rows_,
              (std::vector<std::vector<std::string>>{{"17", "15"}, {"43", "27"}, {"91", "38"}, {"127", "42"}}));
  }
}
}  // namespace bustub
