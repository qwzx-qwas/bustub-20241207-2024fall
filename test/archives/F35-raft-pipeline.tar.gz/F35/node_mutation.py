#!/usr/bin/env python3
"""Run a real TCP regression with only the ActiveWrite term check removed.
No production files or libraries are modified. Requires a build of distributed_node_test.
"""
import argparse,json,pathlib,shlex,subprocess
p=argparse.ArgumentParser();p.add_argument('--repo',type=pathlib.Path,required=True);p.add_argument('--build',type=pathlib.Path,required=True);p.add_argument('--output',type=pathlib.Path,required=True);a=p.parse_args()
repo=a.repo.resolve();build=a.build.resolve();out=a.output.resolve();out.mkdir(parents=True,exist_ok=False)
old="""  if (!raft_node_->LeaderReady() || raft_node_->CurrentTerm() != active->proposal_term_) {
    finish(ClientResponseStatus::NOT_LEADER);
    return;
  }
"""
body=(repo/'src/distributed/node.cpp').read_text();assert body.count(old)==1
source=out/'node.cpp';source.write_text(body.replace(old,'  // mutation: lost ActiveWrite term invalidation\n'))
commands=json.loads((build/'compile_commands.json').read_text());base=next(c for c in commands if c['file'].endswith('/src/distributed/node.cpp'))
argv=shlex.split(base['command']);argv[argv.index('-c')+1]=str(source);argv[argv.index('-o')+1]=str(out/'node.o')
def run(args,name):
    with (out/(name+'.log')).open('w') as f:
        f.write(shlex.join(args)+'\n');f.flush()
        return subprocess.run(args,cwd=build,stdout=f,stderr=subprocess.STDOUT,timeout=180).returncode
assert run(argv,'compile')==0
argv=shlex.split((build/'test/CMakeFiles/distributed_node_test.dir/link.txt').read_text())
argv=[str((build/'test'/v).resolve()) if (v.endswith('.a') or v.endswith('.o')) and not v.startswith('/') else v for v in argv]
argv[argv.index('-o')+1]=str(out/'node-mutant');argv.insert(1,str(out/'node.o'));assert run(argv,'link')==0
name='DistributedNodeTest.LiveOldLeaderClearsOverwrittenProposalAfterDifferentPayloadCommitsElsewhere'
rc=run([str(out/'node-mutant'),'--gtest_filter='+name],'mutation')
log=(out/'mutation.log').read_text();killed=rc==1 and '[  FAILED  ] '+name in log and ': Failure\n' in log and 'C++ exception' not in log
(out/'summary.json').write_text(json.dumps({'test':name,'returncode':rc,'assertion_kill':killed},indent=2)+'\n')
assert killed,'mutation survived or failed without test failure'
print('ActiveWrite term mutation detected by real TCP regression')
