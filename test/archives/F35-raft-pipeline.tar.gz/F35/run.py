#!/usr/bin/env python3
"""Compile archived F35 scenarios against a configured production build.
Mutations compile isolated copies; source tree and existing library stay intact.
"""
import argparse, hashlib, json, os, pathlib, shlex, subprocess, xml.etree.ElementTree as ET
p=argparse.ArgumentParser(); p.add_argument('--repo',type=pathlib.Path,required=True); p.add_argument('--build',type=pathlib.Path,required=True); p.add_argument('--output',type=pathlib.Path,required=True); p.add_argument('--mutations',action='store_true'); p.add_argument('--window-mutations',action='store_true'); p.add_argument('--nodes',action='store_true'); p.add_argument('--direct',action='store_true'); p.add_argument('--port-base',type=int,default=36100); p.add_argument('--nodes-only',action='store_true'); a=p.parse_args()
repo=a.repo.resolve(); build=a.build.resolve(); out=a.output.resolve(); out.mkdir(parents=True,exist_ok=False)
commands=json.loads((build/'compile_commands.json').read_text())
records=[]
test_env={k:v for k,v in os.environ.items() if not k.startswith('GTEST_')}
def run(argv,name,check=True):
    with (out/(name+'.log')).open('w') as log:
        log.write(shlex.join(map(str,argv))+'\n'); log.flush()
        proc=subprocess.run(list(map(str,argv)),cwd=build,env=test_env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
    records.append({'name':name,'returncode':proc.returncode})
    if check and proc.returncode: raise RuntimeError(name+' failed; inspect log')
    return proc.returncode

def compile(source,template,output,name):
    base=next(c for c in commands if c['file'].endswith(template))
    argv=shlex.split(base['command']); argv.insert(1,'-I'+str(repo)); argv.insert(1,'-I'+str(pathlib.Path(base['file']).parent)); ci=argv.index('-c'); argv[ci+1]=str(source); oi=argv.index('-o'); argv[oi+1]=str(output)
    run(argv,name)

obj=out/'test.o'; source=pathlib.Path(__file__).with_name('f35_test.cpp')
compile(source,'/sql_command_preparer_test.cpp',obj,'compile-test')
link=shlex.split((build/'test/CMakeFiles/sql_command_preparer_test.dir/link.txt').read_text())
link=[str(obj) if arg.endswith('sql_command_preparer_test.cpp.o') else arg for arg in link]
# CMake link file is relative to build/test.
link=[str((build/'test'/arg).resolve()) if (arg.endswith('.o') or arg.endswith('.a')) and not arg.startswith('/') else arg for arg in link]
def executable(name,extra=None,existing_sql_test=False):
    argv=link.copy(); argv[argv.index('-o')+1]=str(out/name)
    if existing_sql_test:
        sqlobj=build/'test/CMakeFiles/sql_command_preparer_test.dir/legacy_raft/distributed/sql_command_preparer_test.cpp.o'
        argv=[str(sqlobj) if arg==str(obj) else arg for arg in argv]
    if extra: argv.insert(1,str(extra))
    run(argv,'link-'+name)
    return out/name
baseline=executable('f35-test')
run([baseline,'--gtest_filter=F35.*','--gtest_output=xml:'+str(out/'baseline.xml')],'baseline')
expected={'SlowApplyDoesNotBlockHeartbeatOrPublishEarly','LatePrepareCannotAppendAfterHigherTerm',
          'AppendIsNotAcknowledgedBeforeDurability','PartialAppendCannotCommitUnmatchedLocalSuffix',
          'IndexedPrepareRetainsResidualPredicateAndLogicalRows','RangeCandidatesPreserveBoundsResidualsAndMissingKeys',
          'BatchDurabilityAndBoundedSuffixDoNotPublishWithoutQuorum','InvalidBatchRejectsEveryEntryBeforeAppending','ReusedIndexDoesNotInheritRejectionFromPreviousLeadership','SessionWindowSnapshotPreservesResultsAndRetirementBoundary'}
cases=ET.parse(out/'baseline.xml').getroot().findall('.//testcase')
assert len(cases)==len(expected) and {c.get('name') for c in cases}==expected
assert all(c.get('classname')=='F35' and c.get('status')=='run' and c.get('result')=='completed'
           and not any(c.find(tag) is not None for tag in ('failure','error','skipped')) for c in cases)
mutations=[
 ('unmatched-commit','src/raft/raft_node.cpp','std::min(request.leader_commit_, match_index)','std::min(request.leader_commit_, durable_tip_)','PartialAppendCannotCommitUnmatchedLocalSuffix'),
 ('early-ack','src/raft/raft_node.cpp','co_await AppendLogDurably(suffix);','Send(from, AppendEntriesResponse{hard_state_.current_term_, request.request_id_, true, suffix.back().index_, std::nullopt, 0, std::nullopt});\n      co_await AppendLogDurably(suffix);','AppendIsNotAcknowledgedBeforeDurability'),
 ('late-term','src/raft/raft_node.cpp','if (!LeaderReady() || observed_term_ != entries.front().term_) co_return;','/* mutation: missing term check */','LatePrepareCannotAppendAfterHigherTerm'),
 ('early-publish','src/raft/raft_node.cpp','    try {\n      co_await Slow(\n          [&] {\n            state_machine_->Apply(*entry);','    published_applied_index_ = next;\n    try {\n      co_await Slow(\n          [&] {\n            state_machine_->Apply(*entry);','SlowApplyDoesNotBlockHeartbeatOrPublishEarly'),
 ('drop-residual','src/execution/index_scan_executor.cpp','if (plan_->filter_predicate_ != nullptr) {','if (false) {','IndexedPrepareRetainsResidualPredicateAndLogicalRows'),
 ('exclusive-upper','src/storage/index/b_plus_tree_index.cpp','return cmp > 0 || (cmp == 0 && !upper_inclusive);','return cmp >= 0;','RangeCandidatesPreserveBoundsResidualsAndMissingKeys'),
 ('mixed-key-type','src/optimizer/seqscan_as_indexscan.cpp',
  'column_expr->GetReturnType().GetType() == constant_expr->GetReturnType().GetType()',
  'true','SqlCommandPreparerTest.BigIntPrimaryKeyIsPreparedAppliedAndRecovered')]
mutations += [
 ('old-rejection','src/raft/raft_node.cpp','  proposal_errors_.clear();','  /* mutation: retained rejection */','ReusedIndexDoesNotInheritRejectionFromPreviousLeadership'),
 ('batch-first-only','src/raft/raft_node.cpp',
  'for (const auto &entry : entries) state_machine_->ValidateProposalPayload(entry.type_, entry.payload_);',
  'state_machine_->ValidateProposalPayload(entries.front().type_, entries.front().payload_);',
  'InvalidBatchRejectsEveryEntryBeforeAppending'),
 ('unbounded-suffix','src/raft/log_store.cpp','while (last != end && count < maximum_entries)',
  'while (last != end)','BatchDurabilityAndBoundedSuffixDoNotPublishWithoutQuorum')]
window_mutations=[
 ('expired-can-execute','src/distributed/session_table.cpp',
  'if (request <= r.retired_through_) return RequestDisposition::TOO_OLD;',
  'if (request <= r.retired_through_) return RequestDisposition::NEW_REQUEST;',
  'SessionWindowSnapshotPreservesResultsAndRetirementBoundary'),
 ('last-result-only','src/distributed/session_table.cpp',
  'auto result = r.results_.find(request);','auto result = r.results_.find(r.last_request_id_);',
  'SessionWindowSnapshotPreservesResultsAndRetirementBoundary'),
 ('forget-close','src/distributed/session_table.cpp',
  'r.closed_ = r.closed_ || close;','/* mutation: forget replicated close */',
  'SessionWindowSnapshotPreservesResultsAndRetirementBoundary')]
if a.window_mutations: mutations=window_mutations
elif a.mutations: mutations+=window_mutations
kills=[]
if (a.mutations or a.window_mutations) and not a.nodes_only:
    for name,path,old,new,test in mutations:
        body=(repo/path).read_text(); assert body.count(old)==1,(name,body.count(old))
        changed=out/(name+'.cpp'); changed.write_text(body.replace(old,new)); mutobj=out/(name+'.o')
        # quoted includes local to raft_node.cpp must still find snapshot_tasks.h
        if path=='src/raft/raft_node.cpp': (out/'snapshot_tasks.h').write_bytes((repo/'src/raft/snapshot_tasks.h').read_bytes())
        compile(changed,'/'+path,mutobj,'compile-'+name)
        full_test=test if '.' in test else 'F35.'+test
        binary=executable(name,mutobj,existing_sql_test=name=='mixed-key-type')
        rc=run([binary,'--gtest_filter='+full_test],'run-'+name,False)
        log=(out/('run-'+name+'.log')).read_text()
        killed=rc==1 and '[  FAILED  ] '+full_test in log and ': Failure\n' in log and 'C++ exception' not in log
        kills.append({'mutation':name,'test':test,'assertion_kill':killed,'returncode':rc})
        assert killed,(name,'mutation survived or failed without assertion')
node_cases=[]
if a.nodes or a.nodes_only:
    nodeobj=out/'node-test.o'
    compile(pathlib.Path(__file__).with_name('pipeline_node_test.cpp'),'/distributed_node_test.cpp',nodeobj,'compile-node-test')
    node_link=shlex.split((build/'test/CMakeFiles/distributed_node_test.dir/link.txt').read_text())
    node_link=[str(nodeobj) if v.endswith('distributed_node_test.cpp.o') else v for v in node_link]
    node_link=[str((build/'test'/v).resolve()) if (v.endswith('.o') or v.endswith('.a')) and not v.startswith('/') else v for v in node_link]
    def node_executable(name,extra=None):
        argv=node_link.copy();argv[argv.index('-o')+1]=str(out/name)
        if extra: argv.insert(1,str(extra))
        run(argv,'link-'+name)
        return out/name
    binary=node_executable('node-tests')
    run([binary,'--gtest_filter=F35Node.*','--gtest_output=xml:'+str(out/'node.xml')],'node-baseline')
    node_cases=ET.parse(out/'node.xml').getroot().findall('.//testcase')
    assert {c.get('name') for c in node_cases}=={'IndependentKeysAdvanceWhileConflictsAndMissingKeysWait','ContinuousClientsPublishSnapshotsAndReopenExactContent','TablePredicateBlocksPointsButOtherTablesProgress','MultiKeyPredicatesProtectExcludedRowsAndReleaseFailedClaims','SessionWindowOrdersQueuedRequestsAndRetainsOriginalResults','SessionWindowRejectionConfirmationAndCloseSurviveSnapshots','SessionWindowGapsAndTerminalInputErrorsDoNotStallProgress'}
    assert all(c.get('status')=='run' and not any(c.find(t) is not None for t in ('failure','error','skipped')) for c in node_cases)
    if a.mutations:
        for name,old,new,test in [
          ('input-duplicate-values', '    throw SqlRequestError("INSERT contains duplicate primary keys");', '    /* mutation: leave duplicate VALUES to command validation */;', 'F35Node.SessionWindowGapsAndTerminalInputErrorsDoNotStallProgress'),
          ('input-null-insert', 'if (key.IsNull()) throw SqlRequestError("INSERT primary key cannot be NULL");', '/* mutation: send NULL to internal key codec */', 'F35Node.SessionWindowGapsAndTerminalInputErrorsDoNotStallProgress'),
          ('input-index-refusal', 'throw SqlRequestError(error.what());', 'throw;', 'F35Node.SessionWindowGapsAndTerminalInputErrorsDoNotStallProgress'),
          ('input-null-update', 'replacement_key.IsNull() || !(PrimaryKeyCodecV1::Encode(replacement_key) == key)', '!(PrimaryKeyCodecV1::Encode(replacement_key) == key)', 'F35Node.SessionWindowGapsAndTerminalInputErrorsDoNotStallProgress'),
          ('or-first-only','    left->insert(left->end(), right->begin(), right->end());',
           '    /* mutation: omit the second OR branch */','F35Node.MultiKeyPredicatesProtectExcludedRowsAndReleaseFailedClaims'),
          ('retain-failed-claims','  ReleaseWrite(active);\n  active->response_',
           '  if (status != ClientResponseStatus::REJECTED) ReleaseWrite(active);\n  active->response_',
           'F35Node.MultiKeyPredicatesProtectExcludedRowsAndReleaseFailedClaims'),
          ('skip-key-owner','if (owner != table.keys_.end()) {\n          blocker = owner->second;\n          break;\n        }',
           '/* mutation: ignore key owner */','F35Node.IndependentKeysAdvanceWhileConflictsAndMissingKeysWait'),
          ('single-window','if (!ready.empty() && !raft_node_->Busy())',
           'if (!ready.empty() && !raft_node_->Busy() && raft_node_->LastLogIndex() == raft_node_->PublishedAppliedIndex())',
           'F35Node.IndependentKeysAdvanceWhileConflictsAndMissingKeysWait'),
          ('stale-term','if (!raft_node_->LeaderReady() || raft_node_->CurrentTerm() != active->proposal_term_)',
           'if (false)','DistributedNodeTest.LiveOldLeaderClearsOverwrittenProposalAfterDifferentPayloadCommitsElsewhere')]:
            path='src/distributed/sql_command_preparer.cpp' if name=='or-first-only' or name.startswith('input-') else 'src/distributed/node.cpp'
            source=repo/path;body=source.read_text();assert body.count(old)==1
            changed=out/(name+'.cpp');changed.write_text(body.replace(old,new));mutobj=out/(name+'.o')
            compile(changed,'/'+path,mutobj,'compile-'+name)
            binary=node_executable(name,mutobj)
            rc=run([binary,'--gtest_filter='+test],'run-'+name,False)
            log=(out/('run-'+name+'.log')).read_text()
            killed=rc==1 and '[  FAILED  ] '+test in log and ': Failure\n' in log and 'C++ exception' not in log
            kills.append({'mutation':name,'test':test,'assertion_kill':killed,'returncode':rc})
            assert killed,(name,'mutation survived or failed without assertion')
direct_result=None
if a.direct:
    run(['python3',pathlib.Path(__file__).with_name('session_object_test.py'),'--repo',repo,'--build',build,
         '--output',out/'direct','--port-base',str(a.port_base)],'direct-window')
    direct_result=json.loads((out/'direct/summary.json').read_text()); assert direct_result['passed']
(out/'summary.json').write_text(json.dumps({'baseline_tests':len(cases),'node_tests':len(node_cases),'mutations':kills,'direct':direct_result,'commands':records},indent=2)+'\n')
print('F35:',len(cases),'component tests,',len(node_cases),'node tests;',len(kills),'assertion kills',flush=True)
