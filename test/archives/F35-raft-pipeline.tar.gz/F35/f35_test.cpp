#include <unistd.h>
#include <chrono>
#include <condition_variable>
#include <filesystem>
#include <mutex>
#include <thread>
#include "gtest/gtest.h"
#include "raft/in_memory_raft_transport.h"
#include "raft/raft_node.h"
#include "recovery/single_node_runtime.h"
#include "type/value_factory.h"

namespace bustub {
namespace {
using namespace std::chrono_literals;
struct Gate {
  std::mutex mutex;
  std::condition_variable cv;
  bool armed{false}, entered{false};
  void Arm() {
    std::lock_guard lock(mutex);
    armed = true;
    entered = false;
  }
  void Block() {
    std::unique_lock lock(mutex);
    if (!armed) return;
    entered = true;
    cv.notify_all();
    if (!cv.wait_for(lock, 5s, [&] { return !armed; })) throw std::runtime_error("test gate timed out");
  }
  bool Entered() {
    std::lock_guard lock(mutex);
    return entered;
  }
  void Release() {
    std::lock_guard lock(mutex);
    armed = false;
    cv.notify_all();
  }
};
struct Machine : KvStateMachine {
  mutable Gate validate;
  Gate apply;
  void ValidateProposalPayload(EntryType type, const std::vector<std::byte> &payload) const override {
    validate.Block();
    KvStateMachine::ValidateProposalPayload(type, payload);
  }
  void Apply(const ReplicatedLogEntry &entry) override {
    apply.Block();
    KvStateMachine::Apply(entry);
  }
};
struct Disk : PosixDurableStorage {
  Gate append;
  void AppendFileDurable(const std::filesystem::path &path, const std::vector<std::byte> &data) override {
    append.Block();
    PosixDurableStorage::AppendFileDurable(path, data);
  }
};
struct Fixture {
  std::filesystem::path root{std::filesystem::temp_directory_path() / ("f35-raft-" + std::to_string(getpid()))};
  std::shared_ptr<Disk> disk{std::make_shared<Disk>()};
  std::shared_ptr<Machine> machine{std::make_shared<Machine>()};
  std::shared_ptr<InMemoryRaftTransport> transport{std::make_shared<InMemoryRaftTransport>()};
  std::unique_ptr<RaftNode> node;
  Fixture() {
    disk->RemoveTree(root);
    OpenNode();
  }
  void OpenNode() {
    auto stable = StableStore::Open(root, disk);
    const auto commit = stable->State().commit_index_;
    node = std::make_unique<RaftNode>(
        RaftNodeConfig{1, {1, 2, 3}, 100, 300, 50, "f35", [](uint64_t, uint64_t) { return 100; }}, transport,
        std::move(stable), LogStore::Open(root / "log", disk, commit), machine);
  }
  ~Fixture() {
    machine->validate.Release();
    machine->apply.Release();
    disk->append.Release();
    node.reset();
    disk->RemoveTree(root);
  }
  template <class F>
  void Until(F condition) {
    auto deadline = std::chrono::steady_clock::now() + 5s;
    while (true) {
      node->Poll();
      if (condition()) return;
      if (std::chrono::steady_clock::now() > deadline) throw std::runtime_error("protocol did not progress");
      std::this_thread::yield();
    }
  }
  void Idle() {
    Until([&] { return !node->Busy(); });
  }
  void Leader() {
    node->Tick(100);
    Idle();
    node->Receive(2, RequestVoteResponse{1, true});
    Idle();
    node->Receive(2, AppendEntriesResponse{1, 1, true, 1, std::nullopt, 0, std::nullopt});
    Idle();
    ASSERT_TRUE(node->LeaderReady());
    transport->Clear();
  }
  auto Command() { return KvCommandCodec::Encode({1, KvOperation::PUT, "k", "v"}); }
};
struct SqlFixture {
  std::filesystem::path root{std::filesystem::temp_directory_path() / ("f35-sql-" + std::to_string(getpid()))};
  std::shared_ptr<PosixDurableStorage> disk{std::make_shared<PosixDurableStorage>()};
  std::unique_ptr<SingleNodeCommandRuntime> runtime;
  uint64_t request{0};
  SqlFixture() {
    disk->RemoveTree(root);
    runtime = SingleNodeCommandRuntime::Open(root, disk);
  }
  ~SqlFixture() {
    runtime.reset();
    disk->RemoveTree(root);
  }
  void Run(const std::string &sql) { runtime->CommitSql(sql, 1, ++request); }
  void Reopen() {
    runtime.reset();
    runtime = SingleNodeCommandRuntime::Open(root, disk);
  }
  void Check(int key, std::optional<int> expected) {
    const auto row = runtime->GetRow(0, PrimaryKeyCodecV1::Encode(ValueFactory::GetIntegerValue(key)));
    if (!expected) {
      EXPECT_FALSE(row.has_value()) << key;
      return;
    }
    ASSERT_TRUE(row.has_value()) << key;
    EXPECT_EQ(row->second.GetValue(&runtime->CatalogForRead()->GetTable(0)->schema_, 1).GetAs<int32_t>(), *expected)
        << key;
  }
};
}  // namespace

TEST(F35, SlowApplyDoesNotBlockHeartbeatOrPublishEarly) {
  Fixture f;
  f.Leader();
  f.machine->apply.Arm();
  ASSERT_EQ(f.node->Propose(EntryType::KV_COMMAND, f.Command()), 2);
  f.Idle();
  f.node->Receive(2, AppendEntriesResponse{1, 2, true, 2, std::nullopt, 0, std::nullopt});
  f.Until([&] { return f.machine->apply.Entered(); });
  f.transport->Clear();
  f.node->Tick(200);
  EXPECT_EQ(f.node->CommitIndex(), 2);
  EXPECT_EQ(f.node->PublishedAppliedIndex(), 1);
  size_t heartbeats = 0;
  for (const auto &envelope : f.transport->TakeAll()) {
    if (auto *request = std::get_if<AppendEntriesRequest>(&envelope.message_)) {
      EXPECT_TRUE(request->entries_.empty());
      EXPECT_EQ(request->leader_commit_, 2);
      ++heartbeats;
    }
  }
  EXPECT_EQ(heartbeats, 2);
  f.machine->apply.Release();
  f.Idle();
  EXPECT_EQ(f.node->PublishedAppliedIndex(), 2);
  EXPECT_EQ(f.machine->Get("k"), "v");
}
TEST(F35, LatePrepareCannotAppendAfterHigherTerm) {
  Fixture f;
  f.Leader();
  f.machine->validate.Arm();
  ASSERT_EQ(f.node->Propose(EntryType::KV_COMMAND, f.Command()), 2);
  f.Until([&] { return f.machine->validate.Entered(); });
  f.node->Receive(2, RequestVoteRequest{2, 2, 1, 1});
  f.machine->validate.Release();
  f.Idle();
  EXPECT_EQ(f.node->CurrentTerm(), 2);
  EXPECT_EQ(f.node->LastLogIndex(), 1);
  EXPECT_FALSE(f.machine->Get("k"));
}
TEST(F35, AppendIsNotAcknowledgedBeforeDurability) {
  Fixture f;
  f.disk->append.Arm();
  f.node->Receive(2, AppendEntriesRequest{1, 2, 77, 0, 0, {{1, 1, 1, EntryType::NOOP, {}}}, 1, std::nullopt});
  f.Until([&] { return f.disk->append.Entered(); });
  EXPECT_EQ(f.node->LastLogIndex(), 0);
  EXPECT_EQ(f.node->PublishedAppliedIndex(), 0);
  for (const auto &envelope : f.transport->TakeAll()) {
    if (auto *response = std::get_if<AppendEntriesResponse>(&envelope.message_)) EXPECT_FALSE(response->success_);
  }
  f.disk->append.Release();
  f.Idle();
  bool ack = false;
  for (const auto &envelope : f.transport->TakeAll()) {
    if (auto *response = std::get_if<AppendEntriesResponse>(&envelope.message_))
      ack |= response->request_id_ == 77 && response->success_ && response->match_index_ == 1;
  }
  EXPECT_TRUE(ack);
  EXPECT_EQ(f.node->LastLogIndex(), 1);
  EXPECT_EQ(f.node->PublishedAppliedIndex(), 1);
}
TEST(F35, PartialAppendCannotCommitUnmatchedLocalSuffix) {
  Fixture f;
  f.node.reset();
  {
    auto log = LogStore::Open(f.root / "log", f.disk, 0);
    log->Append({{1, 1, 1, EntryType::NOOP, {}},
                 {1, 2, 1, EntryType::KV_COMMAND,
                  KvCommandCodec::Encode({1, KvOperation::PUT, "stale", "old"})},
                 {1, 3, 1, EntryType::NOOP, {}}});
  }
  f.OpenNode();
  // Both an empty heartbeat and a matching partial append prove only index 1.
  for (bool heartbeat : {true, false}) {
    const std::vector<ReplicatedLogEntry> entries =
        heartbeat ? std::vector<ReplicatedLogEntry>{}
                  : std::vector<ReplicatedLogEntry>{{1, 1, 1, EntryType::NOOP, {}}};
    f.node->Receive(2, AppendEntriesRequest{2, 2, heartbeat ? 80U : 81U, heartbeat ? 1U : 0U,
                                           heartbeat ? 1U : 0U, entries, 3, std::nullopt});
    f.Idle();
    ASSERT_EQ(f.node->CommitIndex(), 1);
    EXPECT_EQ(f.node->PublishedAppliedIndex(), 1);
    EXPECT_EQ(f.node->LastLogIndex(), 3);
    EXPECT_FALSE(f.machine->Get("stale"));
  }
  // An uncommitted conflicting suffix must remain replaceable by the leader.
  f.node->Receive(2, AppendEntriesRequest{2, 2, 82, 1, 1,
                                         {{1, 2, 2, EntryType::KV_COMMAND, f.Command()},
                                          {1, 3, 2, EntryType::NOOP, {}}},
                                         3, std::nullopt});
  f.Idle();
  ASSERT_EQ(f.node->CommitIndex(), 3);
  EXPECT_EQ(f.machine->Get("k"), "v");
  EXPECT_FALSE(f.machine->Get("stale"));
  f.node.reset();
  f.machine = std::make_shared<Machine>();
  f.OpenNode();
  EXPECT_EQ(f.node->PublishedAppliedIndex(), 3);
  EXPECT_EQ(f.machine->Get("k"), "v");
  EXPECT_FALSE(f.machine->Get("stale"));
}
TEST(F35, IndexedPrepareRetainsResidualPredicateAndLogicalRows) {
  SqlFixture f;
  f.Run("CREATE TABLE t(id int PRIMARY KEY,v int);");
  f.Run("INSERT INTO t VALUES (17,10),(43,20),(91,30);");
  f.Run("UPDATE t SET v=999 WHERE id=43 AND v=19;");
  f.Run("UPDATE t SET v=22 WHERE id=43 AND v=20;");
  f.Run("DELETE FROM t WHERE id=17 AND v=999;");
  f.Run("UPDATE t SET v=v+1 WHERE id=17 OR id=91;");
  for (int phase = 0; phase < 2; ++phase) {
    f.Check(17, 11);
    f.Check(43, 22);
    f.Check(91, 31);
    if (phase == 0) f.Reopen();
  }
}
TEST(F35, RangeCandidatesPreserveBoundsResidualsAndMissingKeys) {
  SqlFixture f;
  f.Run("CREATE TABLE t(id int PRIMARY KEY,v int);");
  for (int begin = 0; begin < 512; begin += 64) {
    std::string sql = "INSERT INTO t VALUES ";
    for (int i = begin; i < begin + 64; ++i) {
      if (i != begin) sql += ",";
      sql += "(" + std::to_string(1000 + 3 * i) + "," + std::to_string(i) + ")";
    }
    f.Run(sql + ";");
  }
  f.Run("UPDATE t SET v=v+7 WHERE id>=1501 AND id<1999 AND v<250;");
  f.Run("UPDATE t SET v=v+11 WHERE 2198<id AND 2203>=id;");
  f.Run("UPDATE t SET v=9999 WHERE id>1800 AND id<1700;");
  f.Run("DELETE FROM t WHERE id<1010 OR id>=2500;");
  f.Run("DELETE FROM t WHERE id>=1751 AND id<1757;");
  for (int phase = 0; phase < 2; ++phase) {
    for (int i = 0; i < 512; ++i) {
      int key = 1000 + 3 * i, value = i;
      if (key >= 1501 && key < 1999 && i < 250) value += 7;
      if (key > 2198 && key <= 2203) value += 11;
      f.Check(key,
              (key < 1010 || key >= 2500 || (key >= 1751 && key < 1757)) ? std::nullopt : std::optional<int>{value});
    }
    if (phase == 0) f.Reopen();
  }
}
}  // namespace bustub
