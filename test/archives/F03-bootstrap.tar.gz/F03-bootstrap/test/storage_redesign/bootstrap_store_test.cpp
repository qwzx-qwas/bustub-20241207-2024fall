#include <fcntl.h>
#include <pthread.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

#include <algorithm>
#include <array>
#include <cerrno>
#include <chrono>
#include <condition_variable>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <functional>
#include <future>
#include <iostream>
#include <memory>
#include <mutex>
#include <optional>
#include <stdexcept>
#include <string>
#include <thread>
#include <utility>
#include <vector>

#include "gtest/gtest.h"
#include "storage/disk/bootstrap_store.h"
#include "storage/disk/io_executor.h"

extern "C" ssize_t __real_pread(int, void *, size_t, off_t);
extern "C" ssize_t __real_pwrite(int, const void *, size_t, off_t);
extern "C" int __real_fdatasync(int);
extern "C" int __real_pthread_cond_clockwait(pthread_cond_t *, pthread_mutex_t *, clockid_t, const timespec *);
namespace {
using namespace std::chrono_literals;
constexpr size_t SLOT = 65536;
constexpr size_t SECOND = 1048576;
constexpr size_t CAPACITY = 8 * 1048576;
struct Faults {
  std::mutex mutex;
  std::condition_variable cv;
  off_t pause_write{-1};
  off_t fail_write{-1};
  off_t fail_read{-1};
  bool held{false};
  bool entered{false};
  bool watch_admission_wait{false};
  bool admission_wait_entered{false};
  off_t corrupt_verification_offset{-1};
  int fail_flushes{0};
  unsigned writes{0};
  std::vector<std::pair<off_t, size_t>> attempted_writes;
  uint64_t successful_write_bytes{0};
  unsigned flushes{0};
  unsigned reads{0};
  unsigned successful_flushes{0};
  void Reset() {
    std::lock_guard<std::mutex> lock(mutex);
    pause_write = fail_write = fail_read = -1;
    held = entered = watch_admission_wait = admission_wait_entered = false;
    corrupt_verification_offset = -1;
    fail_flushes = 0;
    writes = flushes = reads = successful_flushes = 0;
    attempted_writes.clear();
    successful_write_bytes = 0;
  }
  void Release() {
    std::lock_guard<std::mutex> lock(mutex);
    held = false;
    cv.notify_all();
  }
} faults;
struct ReleaseGate {
  ~ReleaseGate() { faults.Release(); }
};
}  // namespace
extern "C" ssize_t __wrap_pwrite(int fd, const void *buffer, size_t size, off_t offset) {
  {
    std::unique_lock<std::mutex> lock(faults.mutex);
    ++faults.writes;
    faults.attempted_writes.emplace_back(offset, size);
    if (offset == faults.pause_write) {
      faults.entered = true;
      faults.cv.notify_all();
      faults.cv.wait(lock, [] { return !faults.held; });
    }
    if (offset == faults.fail_write) {
      errno = EIO;
      return -1;
    }
  }
  const auto result = __real_pwrite(fd, buffer, size, offset);
  if (result > 0) {
    std::lock_guard<std::mutex> lock(faults.mutex);
    faults.successful_write_bytes += result;
  }
  return result;
}
extern "C" ssize_t __wrap_pread(int fd, void *buffer, size_t size, off_t offset) {
  bool corrupt;
  {
    std::lock_guard<std::mutex> lock(faults.mutex);
    ++faults.reads;
    if (offset == faults.fail_read) {
      errno = EIO;
      return -1;
    }
    corrupt = faults.writes > 0 && offset == faults.corrupt_verification_offset;
  }
  const auto result = __real_pread(fd, buffer, size, offset);
  if (corrupt && result > 0) {
    static_cast<unsigned char *>(buffer)[0] ^= 1;
  }
  return result;
}
extern "C" int __wrap_fdatasync(int fd) {
  {
    std::lock_guard<std::mutex> lock(faults.mutex);
    ++faults.flushes;
    if (faults.fail_flushes > 0) {
      --faults.fail_flushes;
      errno = EIO;
      return -1;
    }
  }
  const auto result = __real_fdatasync(fd);
  if (result == 0) {
    std::lock_guard<std::mutex> lock(faults.mutex);
    ++faults.successful_flushes;
  }
  return result;
}
// Observe the actual long admission wait, while F03 still holds its mutex.
// Close cannot pass its stop decision until real cond_wait atomically releases
// that mutex. No production hook or timing guess is needed to establish overlap.
// This opt-in runner targets the Linux/libstdc++ clockwait build recorded below.
extern "C" int __wrap_pthread_cond_clockwait(pthread_cond_t *condition, pthread_mutex_t *mutex, clockid_t clock,
                                             const timespec *deadline) {
  timespec now{};
  if (clock_gettime(clock, &now) == 0 && deadline->tv_sec - now.tv_sec > 20) {
    std::lock_guard<std::mutex> lock(faults.mutex);
    if (faults.watch_admission_wait) {
      faults.admission_wait_entered = true;
      faults.cv.notify_all();
    }
  }
  return __real_pthread_cond_clockwait(condition, mutex, clock, deadline);
}

namespace bustub {
namespace {
using Bytes = std::vector<uint8_t>;
auto Range(uint64_t offset, uint64_t size) -> StorageByteRange { return *StorageByteRange::Create(offset, size); }
// Independent table-driven reference; no production byte codec or CRC calls.
auto ReferenceCrc(const uint8_t *bytes, size_t length) -> uint32_t {
  std::array<uint32_t, 256> table{};
  for (uint32_t n = 0; n < table.size(); ++n) {
    uint32_t value = n;
    for (int bit = 0; bit < 8; ++bit) {
      value = (value >> 1) ^ ((value & 1) ? 0x82f63b78U : 0);
    }
    table[n] = value;
  }
  uint32_t crc = 0xffffffffU;
  for (size_t i = 0; i < length; ++i) {
    crc = table[(crc ^ bytes[i]) & 0xff] ^ (crc >> 8);
  }
  return ~crc;
}
void Put(Bytes &bytes, size_t offset, uint64_t value, size_t width) {
  for (size_t i = width; i > 0; --i) {
    bytes.at(offset + i - 1) = value & 255;
    value >>= 8;
  }
}
void Checksum(Bytes &bytes) { Put(bytes, SLOT - 4, ReferenceCrc(bytes.data(), SLOT - 4), 4); }
auto Fixture(const BootstrapLayout &layout) -> Bytes {
  Bytes image(SLOT, 0);
  std::memcpy(image.data(), "BUSTBOOT", 8);
  Put(image, 8, 1, 4);
  Put(image, 12, 112, 4);
  std::copy(layout.identity_.storage_.begin(), layout.identity_.storage_.end(), image.begin() + 24);
  std::copy(layout.identity_.device_.begin(), layout.identity_.device_.end(), image.begin() + 40);
  Put(image, 56, layout.capacity_, 8);
  for (size_t i = 0; i < 3; ++i) {
    Put(image, 64 + i * 16, layout.regions_[i].Offset(), 8);
    Put(image, 72 + i * 16, layout.regions_[i].Size(), 8);
  }
  Checksum(image);
  return image;
}
void ExpectCode(const std::function<void()> &action, BootstrapErrorCode code) {
  try {
    action();
    FAIL() << "expected a specific bootstrap rejection";
  } catch (const BootstrapError &e) {
    EXPECT_EQ(e.Code(), code) << e.what();
  }
}
void ExpectIOError(const std::function<void()> &action) {
  try {
    action();
    FAIL() << "IO failure was swallowed";
  } catch (const std::system_error &e) {
    EXPECT_EQ(e.code().value(), EIO);
  }
}
auto Terminal(BootstrapRepairState state) -> bool {
  return state == BootstrapRepairState::Succeeded || state == BootstrapRepairState::Failed ||
         state == BootstrapRepairState::Stopped;
}
auto Await(BootstrapStore &store) -> BootstrapStatus {
  const auto deadline = std::chrono::steady_clock::now() + 5s;
  while (std::chrono::steady_clock::now() < deadline) {
    auto status = store.Status();
    if (Terminal(status.repair_state_)) {
      return status;
    }
    std::this_thread::yield();
  }
  throw std::runtime_error("repair watchdog expired");
}
class BootstrapTest : public ::testing::Test {
 protected:
  void SetUp() override {
    faults.Reset();
    EXPECT_EQ(ReferenceCrc(reinterpret_cast<const uint8_t *>("123456789"), 9), 0xe3069283U);
    const char *work = std::getenv("F03_WORKDIR");
    ASSERT_NE(work, nullptr);
    std::string pattern = std::string(work) + "/device-XXXXXX";
    std::vector<char> name(pattern.begin(), pattern.end());
    name.push_back(0);
    fd_ = mkstemp(name.data());
    ASSERT_GE(fd_, 0);
    path_ = name.data();
    base_.resize(CAPACITY);
    for (size_t i = 0; i < base_.size(); ++i) {
      base_[i] = static_cast<uint8_t>((i * 37 + (i >> 9) + 83) & 255);
    }
    std::fill_n(base_.begin(), SLOT, 0);
    std::fill_n(base_.begin() + SECOND, SLOT, 0);
    WriteRaw(0, base_);
    BootstrapIdentity id{};
    for (size_t i = 0; i < 16; ++i) {
      id.storage_[i] = 3 * i + 1;
      id.device_[i] = 7 * i + 19;
    }
    layout_ = std::make_unique<BootstrapLayout>(BootstrapLayout{
        id, CAPACITY, {Range(2 * SECOND, SECOND), Range(3 * SECOND, SECOND), Range(4 * SECOND, 4 * SECOND)}});
  }
  void TearDown() override {
    faults.Release();
    if (fd_ >= 0) {
      EXPECT_EQ(close(fd_), 0);
    }
    if (!path_.empty()) {
      EXPECT_EQ(unlink(path_.c_str()), 0);
    }
    faults.Reset();
  }
  void WriteRaw(size_t offset, const Bytes &data) {
    size_t done = 0;
    while (done < data.size()) {
      auto count = __real_pwrite(fd_, data.data() + done, data.size() - done, offset + done);
      if (count <= 0) {
        throw std::runtime_error("fixture write failed");
      }
      done += count;
    }
    if (__real_fdatasync(fd_) != 0) {
      throw std::runtime_error("fixture sync failed");
    }
  }
  auto ReadRaw() -> Bytes {
    Bytes result(CAPACITY);
    size_t done = 0;
    while (done < result.size()) {
      auto count = __real_pread(fd_, result.data() + done, result.size() - done, done);
      if (count <= 0) {
        throw std::runtime_error("oracle read failed");
      }
      done += count;
    }
    struct stat statbuf {};
    if (fstat(fd_, &statbuf) != 0 || statbuf.st_size != CAPACITY) {
      throw std::runtime_error("device unexpectedly resized");
    }
    return result;
  }
  auto Expected(const Bytes &first, const Bytes &second) -> Bytes {
    auto result = base_;
    std::copy(first.begin(), first.end(), result.begin());
    std::copy(second.begin(), second.end(), result.begin() + SECOND);
    return result;
  }
  void Seed(const Bytes &first, const Bytes &second) { WriteRaw(0, Expected(first, second)); }
  void CheckLayout(const BootstrapLayout &actual) {
    EXPECT_EQ(actual.identity_.storage_, layout_->identity_.storage_);
    EXPECT_EQ(actual.identity_.device_, layout_->identity_.device_);
    EXPECT_EQ(actual.capacity_, layout_->capacity_);
    for (size_t i = 0; i < 3; ++i) {
      EXPECT_EQ(actual.regions_[i].Offset(), layout_->regions_[i].Offset());
      EXPECT_EQ(actual.regions_[i].Size(), layout_->regions_[i].Size());
    }
  }
  void CheckTargetWrites(size_t target) {
    // No attempt may touch the source, even if it would rewrite identical bytes.
    // Count transferred bytes, not syscalls: a legal short write may take several.
    std::lock_guard<std::mutex> lock(faults.mutex);
    EXPECT_EQ(faults.successful_write_bytes, SLOT);
    ASSERT_FALSE(faults.attempted_writes.empty());
    for (const auto &[offset, size] : faults.attempted_writes) {
      EXPECT_GE(offset, static_cast<off_t>(target));
      EXPECT_LE(static_cast<uint64_t>(offset) + size, target + SLOT);
    }
  }
  void ArmPause() {
    std::lock_guard<std::mutex> lock(faults.mutex);
    faults.pause_write = SECOND;
    faults.held = true;
  }
  auto WaitForPause() -> bool {
    std::unique_lock<std::mutex> lock(faults.mutex);
    return faults.cv.wait_for(lock, 5s, [] { return faults.entered; });
  }
  std::string path_;
  int fd_{-1};
  Bytes base_;
  std::unique_ptr<BootstrapLayout> layout_;
};

TEST_F(BootstrapTest, CreationAndIndependentFixturesAgreeOnDurableLayout) {
  const auto fixture = Fixture(*layout_);
  {
    BlockDevice device(path_, BlockDeviceOptions{});
    std::cout << "geometry memory=" << device.Info().memory_alignment_ << " offset=" << device.Info().offset_alignment_
              << " capacity=" << device.Info().capacity_ << '\n';
    IOExecutor io(device, {2, 8, 1024 * 1024});
    BootstrapStore store(io);
    store.Create(*layout_);
    EXPECT_EQ(ReadRaw(), Expected(fixture, fixture));
    std::lock_guard<std::mutex> lock(faults.mutex);
    EXPECT_GT(faults.successful_flushes, 0U);
  }
  {
    BlockDevice device(path_, BlockDeviceOptions{});
    IOExecutor io(device, {2, 8, 1024 * 1024});
    BootstrapStore reopened(io);
    const auto opened = reopened.Open(layout_->identity_);
    CheckLayout(opened.layout_);
    EXPECT_FALSE(opened.redundancy_lost_);
    reopened.StartRepair({2, 1ms, 100ms});
    EXPECT_EQ(reopened.Status().repair_state_, BootstrapRepairState::Idle);
  }
  // Decoder must also accept an independently constructed image, not only its
  // own encoder.
  Seed(fixture, fixture);
  faults.Reset();
  BlockDevice device(path_, BlockDeviceOptions{});
  IOExecutor io(device, {2, 8, 1024 * 1024});
  BootstrapStore independent(io);
  CheckLayout(independent.Open(layout_->identity_).layout_);
  EXPECT_EQ(ReadRaw(), Expected(fixture, fixture));
  EXPECT_EQ(faults.writes, 0U);
}

TEST_F(BootstrapTest, OpenRejectsAmbiguityAndUnknownFormatsWithoutWriting) {
  const auto fixture = Fixture(*layout_);
  const Bytes empty(SLOT, 0);
  auto corrupt = fixture;
  corrupt[200] ^= 1;  // Corruption outside the 112-byte fields must be covered, too.
  auto check = [&](Bytes first, Bytes second, std::optional<BootstrapErrorCode> error, bool degraded) {
    Seed(first, second);
    faults.Reset();
    BlockDevice device(path_, BlockDeviceOptions{});
    IOExecutor io(device, {2, 8, 1024 * 1024});
    BootstrapStore store(io);
    if (error) {
      ExpectCode([&] { store.Open(layout_->identity_); }, *error);
    } else {
      auto result = store.Open(layout_->identity_);
      CheckLayout(result.layout_);
      EXPECT_EQ(result.redundancy_lost_, degraded);
    }
    EXPECT_EQ(faults.writes, 0U);
    EXPECT_EQ(faults.flushes, 0U);
    EXPECT_EQ(ReadRaw(), Expected(first, second));
  };
  check(fixture, corrupt, std::nullopt, true);
  check(empty, fixture, std::nullopt, true);
  check(empty, empty, BootstrapErrorCode::Unformatted, false);
  check(corrupt, corrupt, BootstrapErrorCode::Corrupt, false);
  auto conflict = fixture;
  Put(conflict, 80, 3 * SECOND + 65536, 8);
  Put(conflict, 88, SECOND - 65536, 8);
  Checksum(conflict);
  check(fixture, conflict, BootstrapErrorCode::ConflictingCopies, false);
  for (const auto offset : {0U, 8U, 12U, 16U, 20U, 200U}) {
    auto unknown = fixture;
    unknown[offset] ^= 4;
    Checksum(unknown);
    check(fixture, unknown, BootstrapErrorCode::UnsupportedFormat, false);
  }
  for (const auto offset : {24U, 40U}) {
    auto wrong_id = fixture;
    wrong_id[offset] ^= 1;
    Checksum(wrong_id);
    check(fixture, wrong_id, BootstrapErrorCode::IdentityMismatch, false);
  }
  auto bad_layout = fixture;
  Put(bad_layout, 64, 0, 8);
  Checksum(bad_layout);
  check(fixture, bad_layout, BootstrapErrorCode::InvalidLayout, false);
  Put(bad_layout, 64, UINT64_MAX - 16, 8);
  Checksum(bad_layout);
  check(fixture, bad_layout, BootstrapErrorCode::InvalidLayout, false);
  Seed(fixture, empty);
  faults.Reset();
  faults.fail_read = SECOND;
  BlockDevice device(path_, BlockDeviceOptions{});
  IOExecutor io(device, {2, 8, 1024 * 1024});
  BootstrapStore store(io);
  ExpectIOError([&] { store.Open(layout_->identity_); });
  EXPECT_EQ(faults.writes,
            0U);  // An unreadable peer is not overwrite permission.
}

TEST_F(BootstrapTest, CreateProtectsExistingContentsAndRejectsInvalidRegions) {
  BlockDevice device(path_, BlockDeviceOptions{});
  IOExecutor io(device, {2, 8, 1024 * 1024});
  BootstrapStore store(io);
  auto invalid = *layout_;
  invalid.regions_[0] = Range(0, SECOND);
  ExpectCode([&] { store.Create(invalid); }, BootstrapErrorCode::InvalidLayout);
  invalid = *layout_;
  invalid.regions_[1] = invalid.regions_[0];
  ExpectCode([&] { store.Create(invalid); }, BootstrapErrorCode::InvalidLayout);
  invalid = *layout_;
  invalid.capacity_ += SECOND;
  ExpectCode([&] { store.Create(invalid); }, BootstrapErrorCode::InvalidLayout);
  invalid = *layout_;
  invalid.regions_[2] = Range(CAPACITY, SECOND);
  ExpectCode([&] { store.Create(invalid); }, BootstrapErrorCode::InvalidLayout);
  invalid = *layout_;
  invalid.regions_[0] = Range(2 * SECOND, 0);
  ExpectCode([&] { store.Create(invalid); }, BootstrapErrorCode::InvalidLayout);
  if (device.Info().offset_alignment_ > 1) {
    invalid = *layout_;
    invalid.regions_[0] = Range(2 * SECOND + 1, SECOND - 1);
    ExpectCode([&] { store.Create(invalid); }, BootstrapErrorCode::InvalidLayout);
  }
  EXPECT_EQ(faults.writes, 0U);
  EXPECT_EQ(ReadRaw(), base_);
  auto nonzero = Bytes(SLOT, 0);
  nonzero.back() = 7;
  Seed(Bytes(SLOT, 0), nonzero);
  ExpectCode([&] { store.Create(*layout_); }, BootstrapErrorCode::NotEmpty);
  EXPECT_EQ(faults.writes, 0U);
  EXPECT_EQ(ReadRaw(), Expected(Bytes(SLOT, 0), nonzero));
}

TEST_F(BootstrapTest, CreationFailureCannotBecomeDurableSuccessOrBlindRecreate) {
  const auto fixture = Fixture(*layout_);
  {
    BlockDevice device(path_, BlockDeviceOptions{});
    IOExecutor io(device, {1, 8, 1024 * 1024});
    BootstrapStore store(io);
    faults.fail_write = SECOND;
    ExpectIOError([&] { store.Create(*layout_); });
    EXPECT_EQ(ReadRaw(), Expected(fixture, Bytes(SLOT, 0)));
    ExpectCode([&] { store.Create(*layout_); }, BootstrapErrorCode::NotEmpty);
    faults.fail_write = -1;
    EXPECT_TRUE(store.Open(layout_->identity_).redundancy_lost_);
  }
  Seed(Bytes(SLOT, 0), Bytes(SLOT, 0));
  faults.Reset();
  {
    BlockDevice device(path_, BlockDeviceOptions{});
    IOExecutor io(device, {2, 8, 1024 * 1024});
    BootstrapStore store(io);
    faults.fail_flushes = 1;
    ExpectIOError([&] { store.Create(*layout_); });
    EXPECT_EQ(ReadRaw(), Expected(fixture, fixture));
    EXPECT_EQ(faults.successful_flushes, 0U);
    ExpectCode([&] { store.Create(*layout_); }, BootstrapErrorCode::NotEmpty);
    // Readable bytes after simulated Flush failure are not a power-loss claim.
    EXPECT_FALSE(store.Open(layout_->identity_).redundancy_lost_);
  }
}

TEST_F(BootstrapTest, RepairIsAsyncPreservesSourceAndAllowsIndependentIO) {
  const auto fixture = Fixture(*layout_);
  Seed(fixture, Bytes(SLOT, 0));
  BlockDevice device(path_, BlockDeviceOptions{});
  IOExecutor io(device, {2, 8, 1024 * 1024});
  BootstrapStore store(io);
  EXPECT_TRUE(store.Open(layout_->identity_).redundancy_lost_);
  EXPECT_EQ(faults.writes, 0U);
  ArmPause();
  ReleaseGate release;
  store.StartRepair({2, 1ms, 100ms});
  ASSERT_TRUE(WaitForPause());
  store.StartRepair({2, 1ms, 100ms});
  EXPECT_TRUE(store.Status().redundancy_lost_);
  const size_t length = device.Info().offset_alignment_;
  auto prepared = io.TryPrepare({{IOOperation::Read, Range(6 * SECOND, length)}}, false);
  ASSERT_EQ(prepared.admission_, IOAdmission::Accepted);
  auto batch = std::move(*prepared.batch_);
  ASSERT_EQ(io.TrySubmit(batch), IOAdmission::Accepted);
  ASSERT_TRUE(batch.WaitFor(5s));
  ASSERT_EQ(batch.Phase(), IOBatchPhase::Succeeded);
  EXPECT_EQ(std::memcmp(batch.Buffer(0), base_.data() + 6 * SECOND, length), 0);
  EXPECT_TRUE(store.Status().redundancy_lost_);
  faults.Release();
  auto status = Await(store);
  EXPECT_EQ(status.repair_state_, BootstrapRepairState::Succeeded);
  EXPECT_FALSE(status.redundancy_lost_);
  EXPECT_FALSE(status.last_error_);
  store.Close();
  CheckTargetWrites(SECOND);
  EXPECT_GT(faults.successful_flushes, 0U);
  EXPECT_EQ(ReadRaw(), Expected(fixture, fixture));
  // Reverse the source/target; a hard-coded source or target must not survive.
  Seed(Bytes(SLOT, 0), fixture);
  faults.Reset();
  BootstrapStore reversed(io);
  EXPECT_TRUE(reversed.Open(layout_->identity_).redundancy_lost_);
  reversed.StartRepair({1, 1ms, 100ms});
  EXPECT_EQ(Await(reversed).repair_state_, BootstrapRepairState::Succeeded);
  reversed.Close();
  CheckTargetWrites(0);
  EXPECT_EQ(ReadRaw(), Expected(fixture, fixture));
}

TEST_F(BootstrapTest, RepairRetriesRequireSuccessfulFlushAndReadback) {
  const auto fixture = Fixture(*layout_);
  auto run = [&](int failures, bool corrupt, uint32_t limit, BootstrapRepairState expected, uint32_t attempts) {
    Seed(fixture, Bytes(SLOT, 0));
    faults.Reset();
    BlockDevice device(path_, BlockDeviceOptions{});
    IOExecutor io(device, {2, 8, 1024 * 1024});
    BootstrapStore store(io);
    ASSERT_TRUE(store.Open(layout_->identity_).redundancy_lost_);
    faults.fail_flushes = failures;
    faults.corrupt_verification_offset = corrupt ? SECOND : -1;
    store.StartRepair({limit, 1ms, 100ms});
    auto status = Await(store);
    store.Close();
    EXPECT_EQ(status.repair_state_, expected);
    EXPECT_EQ(status.attempts_, attempts);
    EXPECT_EQ(status.redundancy_lost_, expected != BootstrapRepairState::Succeeded);
    EXPECT_EQ(static_cast<bool>(status.last_error_), expected != BootstrapRepairState::Succeeded);
    EXPECT_EQ(ReadRaw(), Expected(fixture, fixture));
    if (expected == BootstrapRepairState::Succeeded) {
      EXPECT_GT(faults.successful_flushes, 0U);
    }
  };
  run(1, false, 2, BootstrapRepairState::Succeeded, 2);
  run(8, false, 2, BootstrapRepairState::Failed, 2);
  run(0, true, 1, BootstrapRepairState::Failed, 1);
  // Losing the fixed source during post-write verification is immediately fatal,
  // just as during preflight. It must not enter an ordinary checksum retry.
  for (bool first_is_source : {true, false}) {
    Seed(first_is_source ? fixture : Bytes(SLOT, 0), first_is_source ? Bytes(SLOT, 0) : fixture);
    faults.Reset();
    BlockDevice device(path_, BlockDeviceOptions{});
    IOExecutor io(device, {2, 8, 1024 * 1024});
    BootstrapStore store(io);
    ASSERT_TRUE(store.Open(layout_->identity_).redundancy_lost_);
    faults.corrupt_verification_offset = first_is_source ? 0 : SECOND;
    store.StartRepair({3, 1ms, 100ms});
    auto status = Await(store);
    store.Close();
    EXPECT_EQ(status.repair_state_, BootstrapRepairState::Failed);
    EXPECT_EQ(status.attempts_, 1U);
    EXPECT_TRUE(status.redundancy_lost_);
    ASSERT_TRUE(status.last_error_);
    ExpectCode([&] { std::rethrow_exception(status.last_error_); }, BootstrapErrorCode::SourceChanged);
    EXPECT_EQ(ReadRaw(), Expected(fixture, fixture));
  }

  // Late identity conflict or lost source cannot be repaired by overwriting it.
  for (bool lose_source : {false, true}) {
    Seed(fixture, Bytes(SLOT, 0));
    faults.Reset();
    BlockDevice device(path_, BlockDeviceOptions{});
    IOExecutor io(device, {2, 8, 1024 * 1024});
    BootstrapStore store(io);
    ASSERT_TRUE(store.Open(layout_->identity_).redundancy_lost_);
    auto altered = fixture;
    altered[24] ^= 1;
    Checksum(altered);
    if (lose_source) {
      Seed(Bytes(SLOT, 0), Bytes(SLOT, 0));
    } else {
      Seed(fixture, altered);
    }
    auto before = ReadRaw();
    store.StartRepair({3, 1ms, 100ms});
    auto status = Await(store);
    store.Close();
    EXPECT_EQ(status.repair_state_, BootstrapRepairState::Failed);
    EXPECT_EQ(status.attempts_, 1U);
    EXPECT_TRUE(status.redundancy_lost_);
    ASSERT_TRUE(status.last_error_);
    ExpectCode([&] { std::rethrow_exception(status.last_error_); },
               lose_source ? BootstrapErrorCode::SourceChanged : BootstrapErrorCode::IdentityMismatch);
    EXPECT_EQ(faults.writes, 0U);
    EXPECT_EQ(ReadRaw(), before);
  }
}

TEST_F(BootstrapTest, AdmissionFailureIsBoundedAndDoesNotChangeCopies) {
  const auto fixture = Fixture(*layout_);
  Seed(fixture, Bytes(SLOT, 0));
  BlockDevice device(path_, BlockDeviceOptions{});
  IOExecutor io(device, {2, 2, 1024 * 1024});
  BootstrapStore store(io);
  auto reserve = io.TryPrepare(
      {{IOOperation::Read, Range(6 * SECOND, SLOT)}, {IOOperation::Read, Range(7 * SECOND, SLOT)}}, false);
  ASSERT_EQ(reserve.admission_, IOAdmission::Accepted);
  ExpectCode([&] { store.Open(layout_->identity_); }, BootstrapErrorCode::ResourceUnavailable);
  EXPECT_EQ(faults.reads, 0U);
  reserve.batch_.reset();
  ASSERT_TRUE(store.Open(layout_->identity_).redundancy_lost_);
  reserve = io.TryPrepare({{IOOperation::Read, Range(6 * SECOND, SLOT)}, {IOOperation::Read, Range(7 * SECOND, SLOT)}},
                          false);
  ASSERT_EQ(reserve.admission_, IOAdmission::Accepted);
  store.StartRepair({2, 1ms, 5ms});
  auto status = Await(store);
  store.Close();
  EXPECT_EQ(status.repair_state_, BootstrapRepairState::Failed);
  EXPECT_EQ(status.attempts_, 2U);
  EXPECT_TRUE(status.redundancy_lost_);
  ASSERT_TRUE(status.last_error_);
  ExpectCode([&] { std::rethrow_exception(status.last_error_); }, BootstrapErrorCode::ResourceUnavailable);
  EXPECT_EQ(faults.writes, 0U);
  EXPECT_EQ(ReadRaw(), Expected(fixture, Bytes(SLOT, 0)));
}

TEST_F(BootstrapTest, CloseDrainsAcceptedRepairAndWakesAdmissionWait) {
  const auto fixture = Fixture(*layout_);
  Seed(fixture, Bytes(SLOT, 0));
  BlockDevice device(path_, BlockDeviceOptions{});
  IOExecutor io(device, {2, 8, 1024 * 1024});
  {
    BootstrapStore store(io);
    ASSERT_TRUE(store.Open(layout_->identity_).redundancy_lost_);
    ArmPause();
    std::promise<void> entering_close;
    auto entering = entering_close.get_future();
    std::future<void> close;
    ReleaseGate release;  // Must release before the future destructor can block.
    store.StartRepair({2, 1ms, 100ms});
    ASSERT_TRUE(WaitForPause());
    close = std::async(std::launch::async, [&] {
      entering_close.set_value();
      store.Close();
      std::lock_guard<std::mutex> lock(faults.mutex);
      EXPECT_FALSE(faults.held) << "Close returned while accepted IO was still held";
    });
    ASSERT_EQ(entering.wait_for(5s), std::future_status::ready);
    EXPECT_EQ(close.wait_for(20ms), std::future_status::timeout);
    faults.Release();
    ASSERT_EQ(close.wait_for(5s), std::future_status::ready);
    close.get();
    const auto status = store.Status();
    // The promise precedes entering Close, not the internal stop decision.
    // If that thread is descheduled, repair may finish first; both orders are legal.
    EXPECT_TRUE(status.repair_state_ == BootstrapRepairState::Stopped ||
                status.repair_state_ == BootstrapRepairState::Succeeded);
    EXPECT_EQ(status.redundancy_lost_, status.repair_state_ == BootstrapRepairState::Stopped);
    EXPECT_EQ(ReadRaw(), Expected(fixture, fixture));
  }
  Seed(fixture, Bytes(SLOT, 0));
  faults.Reset();
  {
    BootstrapStore store(io);
    ASSERT_TRUE(store.Open(layout_->identity_).redundancy_lost_);
    std::vector<IORequest> held;
    for (size_t i = 0; i < 8; ++i) {
      held.push_back({IOOperation::Read, Range(6 * SECOND + i * 65536, 65536)});
    }
    auto reservation = io.TryPrepare(held, false);
    ASSERT_EQ(reservation.admission_, IOAdmission::Accepted);
    {
      std::lock_guard<std::mutex> lock(faults.mutex);
      faults.watch_admission_wait = true;
    }
    store.StartRepair({2, 30s, 60s});
    {
      std::unique_lock<std::mutex> lock(faults.mutex);
      ASSERT_TRUE(faults.cv.wait_for(lock, 5s, [] { return faults.admission_wait_entered; }));
    }
    ASSERT_EQ(store.Status().attempts_, 1U);
    auto close = std::async(std::launch::async, [&] { store.Close(); });
    ASSERT_EQ(close.wait_for(5s), std::future_status::ready);
    close.get();
    EXPECT_EQ(store.Status().repair_state_, BootstrapRepairState::Stopped);
    EXPECT_EQ(faults.writes, 0U);
    EXPECT_EQ(ReadRaw(), Expected(fixture, Bytes(SLOT, 0)));
  }
}
}  // namespace
}  // namespace bustub
