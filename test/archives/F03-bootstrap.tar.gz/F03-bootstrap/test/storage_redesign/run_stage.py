"""Opt-in F03 integration checks. Restore outside the production test tree."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET

EXPECTED_TESTS = {
    'CreationAndIndependentFixturesAgreeOnDurableLayout',
    'OpenRejectsAmbiguityAndUnknownFormatsWithoutWriting',
    'CreateProtectsExistingContentsAndRejectsInvalidRegions',
    'CreationFailureCannotBecomeDurableSuccessOrBlindRecreate',
    'RepairIsAsyncPreservesSourceAndAllowsIndependentIO',
    'RepairRetriesRequireSuccessfulFlushAndReadback',
    'AdmissionFailureIsBoundedAndDoesNotChangeCopies',
    'CloseDrainsAcceptedRepairAndWakesAdmissionWait',
}

def check_results(path):
    root = ET.parse(path).getroot()
    cases = root.findall('./testsuite/testcase')
    actual = [(c.get('classname'), c.get('name')) for c in cases]
    expected = {('BootstrapTest', name) for name in EXPECTED_TESTS}
    if (len(cases) != len(expected) or set(actual) != expected or
            root.get('tests') != str(len(expected)) or
            any(root.get(k) != '0' for k in ('failures', 'errors', 'disabled')) or
            any(c.get('status') != 'run' or c.get('result') != 'completed' or
                any(c.find(t) is not None for t in ('failure', 'error', 'skipped')) for c in cases)):
        raise RuntimeError('F03 verification incomplete: every agreed case must run and pass')
    return len(cases)

parser = argparse.ArgumentParser()
parser.add_argument('--repo', type=Path, required=True)
parser.add_argument('--work', type=Path, required=True)
parser.add_argument('--mutations', action='store_true')
args = parser.parse_args()
repo, work = args.repo.resolve(), args.work.resolve()
work.mkdir(parents=True, exist_ok=True)
build = work / 'build'
source = Path(__file__).with_name('bootstrap_store_test.cpp')
commands = []

def call(argv, log, env=None, timeout=180, expected=0):
    entry = {'command': argv, 'log': log}
    commands.append(entry)
    try:
        with (work / log).open('w') as output:
            result = subprocess.run(argv, cwd=repo, stdout=output, stderr=subprocess.STDOUT,
                                    env=env, timeout=timeout)
        entry['returncode'] = result.returncode
    except subprocess.TimeoutExpired:
        entry['timeout_seconds'] = timeout
        raise
    finally:
        (work / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
    if expected is not None and result.returncode != expected:
        raise RuntimeError(f'{log}: exit {result.returncode}, expected {expected}')
    return result.returncode

call(['cmake', '-S', str(repo), '-B', str(build), '-DCMAKE_BUILD_TYPE=Debug',
      '-DCMAKE_C_COMPILER=clang-14', '-DCMAKE_CXX_COMPILER=clang++-14',
      '-DBUSTUB_SANITIZER=address,undefined', '-DCMAKE_EXE_LINKER_FLAGS=-no-pie'], 'configure-final.log')
call(['cmake', '--build', str(build), '--target', 'bustub_storage_disk', 'gtest_main', '-j2'], 'build-final.log')
flags = ['clang++-14', '-std=c++17', '-Wall', '-Wextra', '-Werror', '-Wno-unused-parameter',
         '-pthread', '-g', '-O0', '-fsanitize=address,undefined', '-fno-omit-frame-pointer',
         '-I' + str(repo / 'src/include'), '-I' + str(repo / 'third_party/googletest/googletest/include')]
test_object = work / 'stage-test.o'
call(flags + ['-c', str(source), '-o', str(test_object)], 'test-compile-final.log')
codec_object = work / 'byte-codec.o'
call(flags + ['-c', str(repo / 'src/common/byte_codec.cpp'), '-o', str(codec_object)], 'codec-compile-final.log')
objects = build / 'src/storage/disk/CMakeFiles/bustub_storage_disk.dir'
link_tail = [str(objects / 'block_device.cpp.o'), str(objects / 'io_executor.cpp.o'), str(codec_object),
             str(test_object), str(build / 'lib/libgtest_main.a'), str(build / 'lib/libgtest.a'),
             '-Wl,--wrap=pread', '-Wl,--wrap=pwrite', '-Wl,--wrap=fdatasync',
             '-Wl,--wrap=pthread_cond_clockwait']
binary = work / 'stage-test'
call(flags + ['-no-pie', str(objects / 'bootstrap_store.cpp.o')] + link_tail + ['-o', str(binary)], 'test-link-final.log')
ignored = sorted(k for k in os.environ if k.startswith('GTEST_'))
env = {k: v for k, v in os.environ.items() if not k.startswith('GTEST_')}
env.update(F03_WORKDIR=str(work), ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',
           UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
(work / 'run-environment.json').write_text(json.dumps({k: env[k] for k in
    ('F03_WORKDIR', 'ASAN_OPTIONS', 'UBSAN_OPTIONS')}, indent=2) + '\n')
(work / 'ignored-gtest-environment.json').write_text(json.dumps(ignored, indent=2) + '\n')
xml = work / 'results-final.xml'
xml.unlink(missing_ok=True)
call([str(binary), '--gtest_filter=BootstrapTest.*', '--gtest_repeat=1', '--gtest_shuffle=0',
      '--gtest_output=xml:' + str(xml)], 'run-final.log', env, 120)
checked = check_results(xml)
if not args.mutations:
    print(f'{checked} complete F03 checks passed.')
    raise SystemExit(0)

original = (repo / 'src/storage/disk/bootstrap_store.cpp').read_text()
mutations = []
def replace(name, old, new, test):
    if original.count(old) != 1:
        raise RuntimeError(f'{name}: production source changed, review the mutation')
    mutations.append((name, original.replace(old, new), test))

replace('overwrite_nonzero', 'if (!IsZero(image.data(), image.data() + image.size())) {',
        'if (false && !IsZero(image.data(), image.data() + image.size())) {',
        'CreateProtectsExistingContentsAndRejectsInvalidRegions')
replace('ignore_crc', 'if (Crc32c(image.data(), BOOTSTRAP_CHECKSUM_OFFSET) != checksum.ReadU32()) {',
        'if (false && Crc32c(image.data(), BOOTSTRAP_CHECKSUM_OFFSET) != checksum.ReadU32()) {',
        'OpenRejectsAmbiguityAndUnknownFormatsWithoutWriting')
replace('ignore_identity', 'if (!SameIdentity(identity, expected)) {',
        'if (false && !SameIdentity(identity, expected)) {',
        'OpenRejectsAmbiguityAndUnknownFormatsWithoutWriting')
replace('ignore_valid_conflict', 'if (images[0] != images[1]) {',
        'if (false && images[0] != images[1]) {',
        'OpenRejectsAmbiguityAndUnknownFormatsWithoutWriting')
# Remove the barrier AND the durability-result check so ordinary readback alone cannot catch it.
old1, old2 = 'auto batch = Prepare(requests, true, options);', 'Execute(batch, true, options);'
if original.count(old1) != 1 or original.count(old2) != 1:
    raise RuntimeError('skip_flush: source drift')
mutations.append(('skip_flush', original.replace(old1, 'auto batch = Prepare(requests, false, options);')
                  .replace(old2, 'Execute(batch, false, options);'),
                  'CreationAndIndependentFixturesAgreeOnDurableLayout'))
replace('forget_failed_flush', 'selected.degraded_ || needs_durability',
        'selected.degraded_ || (false && needs_durability)', 'RepairRetriesRequireSuccessfulFlushAndReadback')
replace('skip_verification', 'verified.degraded_ || images[0] != source_image_ || images[1] != source_image_',
        'false && (verified.degraded_ || images[0] != source_image_ || images[1] != source_image_)',
        'RepairRetriesRequireSuccessfulFlushAndReadback')
replace('overwrite_source', 'Write(source_image_, {1 - source_slot_}, &options);',
        'Write(source_image_, {source_slot_}, &options);', 'RepairRetriesRequireSuccessfulFlushAndReadback')
replace('skip_source_readback_check', 'images = Read(&options);\n          CheckRepairSource(images);',
        'images = Read(&options);', 'RepairRetriesRequireSuccessfulFlushAndReadback')
replace('rewrite_valid_source', 'Write(source_image_, {1 - source_slot_}, &options);',
        'Write(source_image_, {source_slot_, 1 - source_slot_}, &options);',
        'RepairIsAsyncPreservesSourceAndAllowsIndependentIO')
replace('skip_repair_wakeup', 'wake_.notify_all();', 'static_cast<void>(wake_);',
        'CloseDrainsAcceptedRepairAndWakesAdmissionWait')
results = []
for name, content, test in mutations:
    cpp, obj, exe = work / (name + '.cpp'), work / (name + '.o'), work / name
    cpp.write_text(content)
    call(flags + ['-c', str(cpp), '-o', str(obj)], name + '-compile.log')
    call(flags + ['-no-pie', str(obj)] + link_tail + ['-o', str(exe)], name + '-link.log')
    code = call([str(exe), '--gtest_filter=BootstrapTest.' + test], name + '-run.log', env, 120, None)
    output = (work / (name + '-run.log')).read_text()
    caught = code == 1 and '[  FAILED  ] BootstrapTest.' + test in output
    results.append({'mutation': name, 'test': test, 'returncode': code, 'caught_by_assertion': caught,
                    'source_sha256': hashlib.sha256(content.encode()).hexdigest()})
    (work / 'mutations.json').write_text(json.dumps(results, indent=2) + '\n')
    if not caught:
        raise RuntimeError(f'{name}: intended assertion did not catch the mutation; inspect logs')
print(f'{checked} complete F03 checks passed; {len(results)} isolated mutations caught by assertions.')
