# F03 阶段测试恢复

本包为 2026-09-23 再次复审后的版本，8 项场景/11 个隔离变异。仅在仓库外恢复，不注册常驻 CTest。需要 Linux、Direct/statx 支持、Clang14/CMake/Python3 和本仓库 GoogleTest。测试每例一个 8 MiB 临时文件，最多两 IO worker 与一个 F03 协调线程，构建 -j2；故障仅在测试链接边界注入，绝不向裸设备路径自动运行。

从仓库根目录执行（路径参数必须明确）：

```sh
stage_repo=$(pwd)
stage_restore=$(mktemp -d /tmp/bustub-f03-restore-XXXXXX)
(cd test/archives && sha256sum -c SHA256SUMS)
tar -xzf test/archives/F03-bootstrap.tar.gz -C "$stage_restore"
python3 "$stage_restore/F03-bootstrap/test/storage_redesign/run_stage.py" \
  --repo "$stage_repo" --work "$stage_restore/run" --mutations
```

生产源需匹配 MANIFEST.json 的 SHA-256。本包的基准提交 37fa7f2 本身尚无 F03，必须结合当轮变更；需要原样复现时，在该基准的隔离 checkout 中覆盖本地 F03-results.tar.gz 的 source/ 快照，再校验哈希。不要向用户当前工作树覆盖源码。结果包的 commands.json、source/、tests/、mutations/ 和日志共同标识实际验证版本。

runner 清除 GTEST_* 环境过滤/重复/分片，核验八个完整 XML 用例。ASan/UBSan/LeakSanitizer 全开启；若所在调试/沙箱阻止 LSan，不得把禁用检测器当相同验收。二进制每次上限 120 秒，测试内 5 秒为挂起保护，均不是性能阈值。变异仅在 --work 副本构建，编译失败或超时不算命中。

F03 v1 固定引导/修复是真实组件路径，尚非 SQL/Raft 或物理掉电验证。用例编号、oracle、接口/重复/稳定性审查见 docs/storage_redesign/f03_execution_20260923.md。后续优先复用同一风险到正式共同 C/P，不按模块复制 E2E。

关闭场景通过测试链接包装 pthread_cond_clockwait 观察 F03 真实的长准入等待；适用当前 Linux/libstdc++ 路径，未观察到目标等待明确失败，不能当作通过。它不修改生产状态或加入 getter。漏唤醒变异在关闭的 5 秒判断处失败，随后等待原 30 秒时限后正常退出 1；runner 未超时。
