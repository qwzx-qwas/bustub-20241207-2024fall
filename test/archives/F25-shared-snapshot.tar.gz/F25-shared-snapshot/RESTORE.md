# F25 / S11 自动追赶与去重验证（2026-10-07）

仅压缩保留；基线 `3a298eb` 加本轮修改。MANIFEST 固定生产源码、独立依赖包和测试源码哈希。本包替换同名旧包，不包含旧 F25 源码包或结果包。

```bash
stage_work=$(mktemp -d /tmp/bustub-f25-XXXXXX)
tar xzf test/archives/F25-shared-snapshot.tar.gz -C "$stage_work"
cmake -S . -B "$stage_work/build" -DCMAKE_BUILD_TYPE=Debug \
  -DCMAKE_C_COMPILER=clang-14 -DCMAKE_CXX_COMPILER=clang++-14 \
  -DBUSTUB_SANITIZER=address,undefined -DCMAKE_EXE_LINKER_FLAGS=-no-pie
cmake --build "$stage_work/build" --target bustub gmock_main gtest_main catalog_snapshot_test -j3
python3 "$stage_work/F25-shared-snapshot/run_stage.py" --repo "$PWD" \
  --build "$stage_work/build" --out "$stage_work/results"
"$stage_work/build/test/catalog_snapshot_test" --gtest_output=xml:"$stage_work/catalog.xml"
python3 "$stage_work/F25-shared-snapshot/run_mutations.py" --repo "$PWD" \
  --baseline "$stage_work/results" --out "$stage_work/mutations"
```

默认 **42 项**：F25 共享 6、增量 9、F28 7、S8 8、F27 12；另复用 Catalog 5 项，共 47 个不同场景。checkpoint-only 执行 30 项；case 与 checkpoint-only 配合只执行一个明确场景。需要允许本机 socket 与 LSan 线程检查的环境，不能关闭 sanitizer 规避失败。

新增四项分别保护准备候选一次安装、三节点自动追赶/轮换、低收益回退和 v1 兼容、多种索引恢复。自然追赶测试使用真实 RaftNode/TCP/BusTub/Direct 存储；初始化由既有 Business 夹具准备基础内容及日志缺口，随后只控制离线链路和逻辑时钟，不手造协议消息；不是 CLI/客户端网关 E2E。原手工发送 TCP 场景单独保护消息乱序/续期/term 边界。Catalog 五项直接运行原源码，不在包内复制。期望来自明确的业务数据、恢复进度、Session 和实际生产消息；全量对比不是唯一 oracle。

夹具用固定可区分的 180 行稳定数据，30 行一次提交，16 KiB 日志段；保留其他 S8 的 1 KiB 跨段测试。内部格式兼容样本仅为 v1 阶段证据。候选/全量安装调用正式 PrepareSnapshot，测试适配用 OfferDelta，不保留已失去生产调用方的 PlanDelta 转发 API。

变异脚本含 19 项，均隔离编译/链接故意改坏的源码，不改仓库。必须检查正常测试通过、变异编译链接成功、指定场景断言失败；编译失败/超时不算检出。详细审查与证据边界见 docs/storage_redesign/s11_automatic_execution_20261007.md。

阶段测试不注册为常驻套件；未来共同 C/P E2E 接管后按风险去重。未做真实掉电、裸设备、跨机性能、TSan 或 SS/RS/PL/GT 新评测。正常启动完整性检查保留，20% 成本代理不等于实测性能改进。F35 全面异步、S12 通用后台调度和压缩仍属后续阶段。

## 2026-10-07 再审补强

自动追赶场景现在从真实 Leader 提交业务后缀，重启后由 RaftNode 构造自动接续，检查业务值和重试去重；测试不再手工 Apply 修复恢复结果。传输目标在发送消息处立即核对，移除末尾重复检查及目标列表；更换目标的变异同步修改目标选择和会话重建，必须命中身份错误，不能以等待超时计为检出。新增 skip-restart-committed-suffix 变异要求命中恢复进度断言。

本次只增强这一项既有场景，没有新增正常测试函数或改 production；最终 47 场景的证据由本次定向复验和其余未变场景的上轮结果组成，具体复验命令/XML 见审查 §7。

## 判据复审

19 项变异都要求对应的失败内容，核对指定测试全名、执行状态及 skip/error；不接受任意失败或场景内部进度超时。原始 XML 经新判定函数复核，19 项仍有效；临时核对错误报告均拒绝。本次只更新变异 runner，未重编译/重跑 C++，正常场景和变异种类仍为 47/19。详见审查 §8。
