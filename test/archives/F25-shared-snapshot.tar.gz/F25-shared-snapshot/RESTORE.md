# F25 / S11 共享及增量接收验证（2026-10-07）

仅压缩保留。基准 d92829c 加本轮改动；MANIFEST 记录生产、依赖、测试哈希。
**增量整轮未完成**：自然追赶中传输基础的保留策略仍待用户选择；测试不代表自动 Leader 增量 E2E 已完成。

```bash
stage_work=$(mktemp -d /tmp/bustub-f25-XXXXXX)
tar xzf test/archives/F25-shared-snapshot.tar.gz -C "$stage_work"
cmake -S . -B "$stage_work/build" -DCMAKE_BUILD_TYPE=Debug \
  -DCMAKE_C_COMPILER=clang-14 -DCMAKE_CXX_COMPILER=clang++-14 \
  -DBUSTUB_SANITIZER=address,undefined -DCMAKE_EXE_LINKER_FLAGS=-no-pie
cmake --build "$stage_work/build" --target bustub gmock_main gtest_main -j3
python3 "$stage_work/F25-shared-snapshot/run_stage.py" --repo "$PWD" \
  --build "$stage_work/build" --out "$stage_work/results"
python3 "$stage_work/F25-shared-snapshot/run_mutations.py" --repo "$PWD" \
  --baseline "$stage_work/results" --out "$stage_work/mutations"
```

默认 38 项：增量 5、原 F25 6、F28 7、S8 8、F27 12；checkpoint-only 执行前 26 项。case 与 checkpoint-only 一起使用，严格执行一个场景。run_mutations 只保留本轮十三个相关变异；旧轮其他变异不继续作为本轮默认内容维护。其 --only 参数必须给出至少一个已知变异名称；空选择或拼错名称均报错，不静默跳过。

新测试通过真实 SQL/F28/F25/FS 与正式 codec。TCP 测试的接收端是实际 RaftNode，发送端由测试驱动；原 S8 三节点场景继续检验全量。预期来自独立业务输入、明确的 Session request/term/commit 与 RETRY_LAST、恢复边界；与全量字节对照是补充，不是唯一 oracle。测试观察实际 pwrite 是否复制未变化正文，包装仅在测试可执行文件中，不新增生产 hook。错误基础、重复正文冲突、损坏复用、旧会话、重启候选、接收期间穿插退役/Collect（非多线程同时调用 Store）和大于页的分配单位均有具体场景。新增预算拒绝场景不读取内部分配计数：连续拒绝后仍须完成合法全量发布。TCP 场景通过实际 Offer/Install 和显式逻辑时钟，验证旧协商/旧全量块不取消新接收、重发协商续期，以及新 term 允许请求编号重新开始。详细八项审查见 docs/storage_redesign/s11_incremental_execution_20261007.md。

原 F25 六项直接保留，F28/S8/F27 从各自有效包解出复用。旧 F28 portable/local 重复场景仍由共享 T1 接管，未改独立依赖包。未修改共同 C/P 内容，不声称真实掉电/裸设备/TSan/性能比较完成。需要允许本机 socket 与 LSan 线程检查的环境，不关闭 sanitizer 规避限制。

2026-10-07 再次复核仅修正本说明和一处测试注释，production/测试行为/runner 未改，沿用上一轮 38 项及十三个变异实测，未重复运行。重复分块的进度/内容断言不独立证明所有物理空间释放，见审查 §10。
