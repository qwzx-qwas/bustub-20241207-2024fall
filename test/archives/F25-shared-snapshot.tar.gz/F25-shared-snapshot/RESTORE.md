# F25 / S11 共享快照验证

仅压缩保留本阶段增量测试。基准 8b80b6f 加本轮 source/ 快照；生产源与依赖哈希见 MANIFEST.json。不得用旧库运行新测试冒充复验。

```bash
stage_work=$(mktemp -d /tmp/bustub-f25-XXXXXX)
tar xzf test/archives/F25-shared-snapshot.tar.gz -C "$stage_work"
cmake -S . -B "$stage_work/build" -DCMAKE_BUILD_TYPE=Debug \
  -DCMAKE_C_COMPILER=clang-14 -DCMAKE_CXX_COMPILER=clang++-14 \
  -DBUSTUB_SANITIZER=address,undefined -DCMAKE_EXE_LINKER_FLAGS=-no-pie
cmake --build "$stage_work/build" --target bustub gmock_main gtest_main -j3
python3 "$stage_work/F25-shared-snapshot/run_stage.py" --repo "$PWD" \
  --build "$stage_work/build" --out "$stage_work/results"
python3 "$stage_work/F25-shared-snapshot/run_mutations.py" --repo "$PWD" \
  --baseline "$stage_work/results" --out "$stage_work/mutations"
```

默认 33 项：本轮 6、F28 的 7、S8 的 8、F27 的 12。`--checkpoint-only` 只运行前 21；`--case` 必须同时带它，严格执行一个 gtest。`--regressions` 可补跑原 F19/S5/F36，属于按需范围，不算本轮已跑。使用真实 SQL、Direct 普通文件和本机 TCP。兼容场景还采用两倍于实际基准的 F12 分配单位，检验与数据库页大小不相等的部署。需要系统允许回环端口及 LSan 线程检查；不能禁用 sanitizer 或删断言规避环境限制。

本轮只适配原 F28 ShareObjectRange 新增的显式目标偏移；测试夹具允许选择已存在的 Deferred 部署预算，原 F28/S8 用例业务内容与 oracle 未修改。S8 的文件 SQL 恢复场景保留原 canonical 后端，三节点改用当前对象页部署。原 F28 `NewerPortableSnapshotSupersedesLocalCheckpointWithoutLosingSuffix` 不计入本轮：新 Capture 会推进本地 checkpoint，使该旧测试不再经过其原定分支；复审后的 T1 让接收端先建立较旧本地 checkpoint，再接收更新快照并重启，真正验证新快照取代旧 checkpoint 及日志后缀恢复。没有本地 checkpoint 的接收仍由复用的三节点场景覆盖。旧归档作为历史证据保留，不篡改它。

link 包装 pwrite/fdatasync 用于观察正文是否被复制和设置确定性 IO 闸门；无生产测试 hook。六个新测试通过已存在生产接口与新增正式共享入口，预期来自 SQL 输入、会话结果、固定字节和明确错误条件。与原公共 C/P 内容独立，不能作为性能对比或真实掉电结论。

九个变异在 /tmp 编译成独立目标文件，链接时覆盖原符号，不修改源树或生产库。必须编译成功并在指定断言失败；超时、LSan 环境错误、编译失败不算检出。各次执行和失败诊断见结果包；只把最终修正版通过计入验收。
