# F25 / S11 DATA 压缩、自动追赶与任务交接（2026-10-07）

仅压缩保留；基线 `c20bd98` 加当前修改。MANIFEST 固定生产源码、7 个依赖包和本包源码。原 F25 包已替换，不含旧源码/结果包。

```bash
stage_work=$(mktemp -d /tmp/bustub-f25-XXXXXX)
tar xzf test/archives/F25-shared-snapshot.tar.gz -C "$stage_work"
cmake -S . -B "$stage_work/build" -DCMAKE_BUILD_TYPE=Debug \
  -DCMAKE_C_COMPILER=clang-14 -DCMAKE_CXX_COMPILER=clang++-14 \
  -DBUSTUB_SANITIZER=address,undefined -DCMAKE_EXE_LINKER_FLAGS=-no-pie
cmake --build "$stage_work/build" --target bustub gmock_main gtest_main catalog_snapshot_test rpc_codec_test tcp_transport_test snapshot_store_test -j3
python3 "$stage_work/F25-shared-snapshot/run_stage.py" --repo "$PWD" \
  --build "$stage_work/build" --out "$stage_work/results"
"$stage_work/build/test/catalog_snapshot_test" --gtest_output=xml:"$stage_work/catalog.xml"
"$stage_work/build/test/rpc_codec_test" --gtest_output=xml:"$stage_work/rpc.xml"
"$stage_work/build/test/tcp_transport_test" --gtest_output=xml:"$stage_work/tcp.xml"
"$stage_work/build/test/snapshot_store_test" --gtest_output=xml:"$stage_work/snapshot-store.xml"
python3 "$stage_work/F25-shared-snapshot/run_mutations.py" --repo "$PWD" \
  --baseline "$stage_work/results" --out "$stage_work/mutations" \
  --only pending-admission-no-heartbeat block-protocol-on-snapshot-read lose-admission-bound
# 可选局部编码测量：需要本机 Zstd 开发库；production 只依赖仓库 LZ4。
python3 "$stage_work/F25-shared-snapshot/run_codec_benchmark.py" --repo "$PWD" \
  --baseline "$stage_work/results" --out "$stage_work/codec-metrics"
```

默认 47 项（checkpoint 35 + Deferred 12），另原 Catalog 5，再加原 RPC 3、TCP 4，共 59 个不同正常场景。35 项包含共享 6、增量 9、F28 7、S8 8、压缩 5。单独 case 仍配合 checkpoint-only。需要允许 loopback socket 和 LSan 的执行环境，不能以关 sanitizer 规避错误。真实 SQL/Direct 文件/三 RaftNode，并非 CLI E2E。

新增五项及增强自动追赶的路径、独立 Oracle、资源、重复与污染审查见 `docs/storage_redesign/s11_compression_execution_20261007.md`。前次实施 12 个指定变异检出；本次复查重跑队列上限、协议阻塞与新增 pending 漏心跳共 3 个变异；脚本保留其他旧变异以供后续审查，不把未重跑项累计进本轮结果。必须检查指定测试/失败内容；编译失败和进度超时不是检出。

队列/策略组件场景仅为阶段证据，未来由共同正确性/性能 E2E 接管后按风险删减。原 C/P 未改，未测试真实掉电、裸设备、TSan、跨机网络性能或 SS/RS/PL/GT。Offer 头探测/差异规划、Stage/安装依旧同步，F35 全面异步化仍待后续。

局部 benchmark 用真实 SQL 混合正文生成快照，只测 codec CPU/字节/块延迟，不给出网络端到端提升结论。临时产物均应在复验完成后清理。

复查补强 C2 的独占寿命标记与排空后释放判断；C4 同时覆盖已接纳及未接纳任务的心跳。取消后消息采样不是所有迟到时序的穷举，见审查限制。源码包只保留修正后的测试，不嵌套旧包。

提交前再次复查仅改 `ReadPayloadChunk` 文件路径，复用 `PayloadFile`；原 SnapshotStoreTest 9 项在 ASan/UBSan/LSan 下通过（2026-10-07）。前次 59 项及 3 项变异没有全部重跑，分别保留证据。恢复脚本包含全部复验命令，不表示这些命令在最后一次审查全部执行。没有新增测试源码，原测试哈希纳入 MANIFEST。
