#include "snapshot_tasks.h"
#include <random>
namespace {
struct CompressionTransport : RaftTransport {
  std::deque<RaftEnvelope> messages;
  void Send(RaftEnvelope e) override { messages.push_back(std::move(e)); }
};
auto ThroughWire(const RaftMessage &message) -> RaftMessage {
  return RaftRpcCodec::Decode(RaftRpcCodec::Encode({1, 2, message, "compression"})).message_;
}
TEST(S11Compression, FullRestoreRejectsDamagedBlocksThenRetriesWithoutChangingPublishedState) {
  DeltaBusiness source;
  Business receiver;
  auto store = SnapshotStore::OpenObjects(receiver.h.objects);
  InstallFull(receiver, *store, source.snapshots->Input(source.base), source.base);
  auto transport = std::make_shared<CompressionTransport>();
  RaftNode node({2, {1,2,3}, 1000,1800,100,"compression",MakeSeededElectionTimeoutSource(6)}, transport,
                std::move(receiver.stable),std::move(receiver.log),receiver.machine,std::move(store));
  auto exchange = [&](const RaftMessage &m) -> RaftMessage {
    transport->messages.clear();
    node.Receive(1,ThroughWire(m));
    const auto deadline = std::chrono::steady_clock::now()+10s;
    while (transport->messages.empty() && std::chrono::steady_clock::now()<deadline) {
      node.Tick(0); std::this_thread::yield();
    }
    Require(!transport->messages.empty(),"snapshot response completion");
    auto out = transport->messages.front().message_; transport->messages.clear(); return out;
  };
  auto offer = std::get<SnapshotOfferResponse>(exchange(SnapshotOfferRequest{3,1,10,source.target,{},true}));
  ASSERT_TRUE(offer.extended_); ASSERT_EQ(offer.status_,SnapshotOfferStatus::Unsupported);
  // Capability negotiation is idempotent independently of an optional delta base.
  EXPECT_TRUE(std::get<SnapshotOfferResponse>(exchange(SnapshotOfferRequest{3,1,10,source.target,{},true})).extended_);
  const auto input=source.snapshots->Input(source.target);
  auto make = [&](uint64_t offset,uint64_t id) {
    auto size=std::min<uint64_t>(65536,input.size_-offset);
    InstallSnapshotRequest r{3,1,id,source.target.snapshot_id_,source.target.last_included_index_,3,
      offset,input.size_,source.target.payload_checksum_,offset+size==input.size_,input.Read(offset,size)};
    CompressSnapshotChunk(&r,10);return r;
  };
  const auto valid=make(0,11);ASSERT_EQ(valid.encoding_,SnapshotEncoding::Lz4);
  for (int failure=0;failure<3;++failure) {
    auto bad=valid;
    if (failure==0) bad.data_.resize(1); // truncated block, valid outer frame CRC
    if (failure==1) --bad.raw_size_; // false decoded size; keep RPC range semantics valid
    if (failure==2) bad.encoding_session_=9; // obsolete capability/session
    auto response=std::get<InstallSnapshotResponse>(exchange(bad));
    EXPECT_FALSE(response.success_);
    EXPECT_EQ(node.LatestSnapshot()->snapshot_id_,source.base.snapshot_id_);
    EXPECT_EQ(receiver.Query("SELECT value FROM delta_mutable WHERE id=1;"),(Rows{{"11"}}));
  }
  uint64_t offset=0,id=11;size_t compressed=0;
  while(offset<input.size_) {
    auto r=make(offset,id++);
    compressed+=r.encoding_==SnapshotEncoding::Lz4;
    auto response=std::get<InstallSnapshotResponse>(exchange(r));ASSERT_TRUE(response.success_);
    const auto next=offset+(r.encoding_==SnapshotEncoding::Lz4?r.raw_size_:r.data_.size());
    if (!response.complete_) {
      EXPECT_EQ(response.next_offset_,next);
      // The same encoded block must be accepted as a duplicate, without changing progress.
      auto retry=std::get<InstallSnapshotResponse>(exchange(r));
      ASSERT_TRUE(retry.success_);EXPECT_EQ(retry.next_offset_,next);
    }
    offset=next;
  }
  EXPECT_GT(compressed,0U);source.ExpectContents(receiver);
  EXPECT_EQ(node.LatestSnapshot()->snapshot_id_,source.target.snapshot_id_);
  // Declarations beyond our block contract must fail before allocation/decompression.
  auto oversized=valid;oversized.raw_size_=65537;
  EXPECT_THROW(ThroughWire(oversized),std::runtime_error);
}
TEST(S11Compression, WorkerAdmissionKeepsInputsAliveAndReturnsFailuresWithoutBlockingProtocolOwner) {
  DeltaBusiness source;
  auto input=source.snapshots->Input(source.target);
  const auto expected=input.Read(4096,4096);
  auto tasks=std::make_unique<SnapshotTasks>();
  std::promise<void> release;auto gate=release.get_future().share();
  // Release even if an assertion aborts; the executor must drain its accepted tasks.
  struct Release {std::promise<void> &p;~Release(){try{p.set_value();}catch(const std::future_error &){}}} done{release};
  std::mutex mutex;std::condition_variable cv;size_t started=0;
  std::vector<std::future<InstallSnapshotRequest>> jobs;
  auto token=std::make_shared<int>(1);std::weak_ptr<int> lifetime=token;
  for (int i=0;i<4;++i) {
    auto f=tasks->Submit([&,input,token=i==0 ? token : std::shared_ptr<int>{},i] {
      {std::lock_guard lock(mutex);++started;cv.notify_all();}
      gate.wait();
      if(i==3)throw std::runtime_error("body read failed");
      InstallSnapshotRequest r;r.data_=input.Read(4096,4096);return r;
    });ASSERT_TRUE(f);jobs.push_back(std::move(*f));
  }
  {std::unique_lock lock(mutex);ASSERT_TRUE(cv.wait_for(lock,10s,[&]{return started==2;}));}
  EXPECT_FALSE(tasks->Submit([]{return InstallSnapshotRequest{};}));
  token.reset();jobs[0]=std::future<InstallSnapshotRequest>{};
  EXPECT_FALSE(lifetime.expired()); // dropping a consumer does not drop executing ownership
  release.set_value();
  for(size_t i=1;i<3;++i) EXPECT_EQ(jobs[i].get().data_,expected);
  EXPECT_THROW(jobs[3].get(),std::runtime_error);
  tasks.reset(); // join accepted work before checking release, not merely future readiness
  EXPECT_TRUE(lifetime.expired());
}
TEST(S11Compression, AdaptiveEncodingKeepsIncompressibleAndSmallDataRaw) {
  // This checks our admission/savings policy, not LZ4's algorithm internals.
  std::mt19937 random(729);
  for(size_t size : {size_t{173},size_t{65536}}) {
    InstallSnapshotRequest r;r.data_.resize(size);
    for(auto &b:r.data_) b=std::byte(random()&255);
    auto original=r.data_;CompressSnapshotChunk(&r,8);
    EXPECT_EQ(r.encoding_,SnapshotEncoding::Raw);EXPECT_EQ(r.data_,original);
  }
}
} // namespace
namespace {
struct PausedSnapshotFiles : PosixDurableStorage {
  std::mutex mutex;std::condition_variable cv;
  bool arm=false,entered=false,released=false,finished=false;
  auto ReadFileRange(const std::filesystem::path &p,uint64_t o,size_t n)->std::vector<std::byte> override {
    {std::unique_lock lock(mutex);if(arm){entered=true;cv.notify_all();cv.wait(lock,[&]{return released;});}}
    auto data=PosixDurableStorage::ReadFileRange(p,o,n);
    {std::lock_guard lock(mutex);finished=true;cv.notify_all();}return data;
  }
  void Release(){std::lock_guard lock(mutex);released=true;cv.notify_all();}
};
TEST(S11Compression, SlowBodyReadDoesNotHoldProtocolAndOldTermCompletionCannotSend) {
  Business source;
  source.Apply("CREATE TABLE compress_lock(id INT PRIMARY KEY, value INT);");
  source.Apply("INSERT INTO compress_lock VALUES (91,713);");
  auto files=std::make_shared<PausedSnapshotFiles>();
  auto store=SnapshotStore::Open(source.root/"codec-legacy",files);
  auto snapshot=store->Capture(source.index,3,*source.machine);
  source.log->InstallSnapshotBase(source.index,3,true);
  auto transport=std::make_shared<CompressionTransport>();
  RaftNode node({1,{1,2,3},1000,1800,100,"compression",MakeSeededElectionTimeoutSource(9)},transport,
    std::move(source.stable),std::move(source.log),source.machine,std::move(store));
  struct Release {std::shared_ptr<PausedSnapshotFiles> f;~Release(){f->Release();}} cleanup{files};
  uint64_t clock=0;
  {std::lock_guard lock(files->mutex);files->arm=true;files->finished=false;}
  // Four accepted jobs retain their inputs after cancellation by a newer term.
  // The fifth transfer is pending admission, rather than an executing future.
  for (int attempt=0;attempt<5;++attempt) {
    clock+=2000;transport->messages.clear();node.Tick(clock);
    const auto term=node.CurrentTerm();
    node.Receive(2,RequestVoteResponse{term,true});ASSERT_EQ(node.Role(),RaftRole::LEADER);
    uint64_t append=0;
    for(auto &e:transport->messages)if(e.to_==3)if(auto *r=std::get_if<AppendEntriesRequest>(&e.message_))append=r->request_id_;
    ASSERT_NE(append,0U);transport->messages.clear();
    node.Receive(3,AppendEntriesResponse{term,append,false,0,std::nullopt,1,std::nullopt});
    uint64_t offer=0;
    for(auto &e:transport->messages)if(e.to_==3)if(auto *r=std::get_if<SnapshotOfferRequest>(&e.message_))offer=r->request_id_;
    ASSERT_NE(offer,0U);transport->messages.clear();
    auto protocol=std::async(std::launch::async,[&]{node.Receive(3,SnapshotOfferResponse{term,offer,SnapshotOfferStatus::Unsupported,true});});
    bool entered;
    {std::unique_lock lock(files->mutex);entered=files->cv.wait_for(lock,10s,[&]{return files->entered;});}
    const bool returned=protocol.wait_for(1s)==std::future_status::ready;
    if(!entered || !returned) files->Release();
    protocol.get();ASSERT_TRUE(entered);ASSERT_TRUE(returned)<<"protocol waited for snapshot body IO";
    transport->messages.clear();
    node.Tick(clock+100);
    bool heartbeat=false;
    for(auto &e:transport->messages)if(e.to_==3)if(auto *r=std::get_if<AppendEntriesRequest>(&e.message_)){
      heartbeat=true;EXPECT_EQ(r->term_,term);EXPECT_TRUE(r->entries_.empty());
    }
    EXPECT_TRUE(heartbeat)<<"pending admission must not suppress follower heartbeats, attempt="<<attempt;
    node.Receive(2,RequestVoteRequest{term+1,2,node.Log().LastLogIndex(),node.Log().LastLogTerm()});
    EXPECT_EQ(node.CurrentTerm(),term+1);EXPECT_EQ(node.Role(),RaftRole::FOLLOWER);
  }
  files->Release();
  {std::unique_lock lock(files->mutex);ASSERT_TRUE(files->cv.wait_for(lock,10s,[&]{return files->finished;}));}
  node.Tick(clock+101);
  for(auto &e:transport->messages)EXPECT_FALSE(std::holds_alternative<InstallSnapshotRequest>(e.message_));
}
} // namespace
