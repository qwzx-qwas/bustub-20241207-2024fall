#include "raft/rpc_codec.h"
namespace {
struct DeltaBusiness {
  Business source;
  std::unique_ptr<SnapshotStore> snapshots;
  RaftSnapshot base, target;
  Rows stable_rows;
  DeltaBusiness() {
    source.Apply(
        "CREATE TABLE delta_stable(id INT PRIMARY KEY, body VARCHAR(400));");
    std::string values;
    for (int i = 0; i < 38; ++i) {
      const auto body = shared_marker + "-incremental-" + std::to_string(i) +
                        std::string(260, char('a' + i % 21));
      if (i)
        values += ',';
      values += '(' + std::to_string(i + 70) + ",'" + body + "')";
      stable_rows.push_back({std::to_string(i + 70), body});
    }
    source.Apply("INSERT INTO delta_stable VALUES " + values + ';');
    source.Apply("CREATE TABLE delta_mutable(id INT PRIMARY KEY, value INT);");
    source.Apply("INSERT INTO delta_mutable VALUES (1,11),(2,22),(3,33);");
    snapshots = SnapshotStore::OpenObjects(source.h.objects);
    base = snapshots->Capture(source.index, 3, *source.machine);
    source.Apply("UPDATE delta_mutable SET value=111 WHERE id=1;");
    source.Apply("DELETE FROM delta_mutable WHERE id=2;");
    source.Apply("INSERT INTO delta_mutable VALUES (4,44);");
    target = snapshots->Capture(source.index, 3, *source.machine);
  }
  void ExpectContents(Business &b) {
    EXPECT_EQ(b.Query("SELECT id,body FROM delta_stable ORDER BY id;"),
              stable_rows);
    EXPECT_EQ(b.Query("SELECT id,value FROM delta_mutable ORDER BY id;"),
              (Rows{{"1", "111"}, {"3", "33"}, {"4", "44"}}));
    const auto response = b.machine->GetLastResponse(71);
    ASSERT_TRUE(response.has_value());
    EXPECT_EQ(WriteResponseCodec::Decode(*response),
              (WriteResponseV1{1, WriteStatus::COMMITTED, 7, 3, 7}));
    EXPECT_EQ(b.machine->ClassifyRequest(
                  71, 7,
                  ComputeWriteIntentFingerprintV1(
                      "INSERT INTO delta_mutable VALUES (4,44);")),
              RequestDisposition::RETRY_LAST);
  }
};
void InstallFull(Business &b, SnapshotStore &store, const SnapshotInput &input,
                 const RaftSnapshot &info) {
  Transfer(store, input, info);
  auto staged = store.StagedInput(info.snapshot_id_);
  Require(staged.has_value(), "complete full input");
  b.machine->ValidateSnapshot(*staged, info.last_included_index_);
  store.PublishStaged(info.snapshot_id_, true);
  b.machine->LoadSnapshot(*staged, info.last_included_index_);
  b.log->InstallSnapshotBase(info.last_included_index_,
                             info.last_included_term_, false);
  b.stable->Update(info.last_included_term_, 1, info.last_included_index_);
  b.index = info.last_included_index_;
}
auto WireChunk(SnapshotChunk chunk) -> SnapshotChunk {
  InstallSnapshotRequest r{3,
                           1,
                           91,
                           chunk.snapshot_id_,
                           chunk.last_included_index_,
                           chunk.last_included_term_,
                           chunk.offset_,
                           chunk.total_size_,
                           chunk.payload_checksum_,
                           chunk.done_,
                           chunk.data_,
                           chunk.delta_session_,
                           chunk.reuse_};
  auto decoded = RaftRpcCodec::Decode(
      RaftRpcCodec::Encode({1, 2, r, "delta-production-path"}));
  auto &q = std::get<InstallSnapshotRequest>(decoded.message_);
  return {q.snapshot_id_, q.last_included_index_, q.last_included_term_,
          q.offset_,      q.total_size_,          q.payload_checksum_,
          q.done_,        std::move(q.data_),     q.delta_session_,
          q.reuse_};
}
TEST(S11Incremental,
     FullAndDeltaRestoreSameSqlSessionSuffixWithLargeAllocationAndRetiredBase) {
  DeltaBusiness data;
  Business delta(false, true), full;
  auto incoming = SnapshotStore::OpenObjects(delta.h.objects);
  auto full_store = SnapshotStore::OpenObjects(full.h.objects);
  InstallFull(delta, *incoming, data.snapshots->Input(data.base), data.base);
  // Produce a valid intermediate snapshot, so the negotiated base can retire
  // while receiving.
  delta.Apply("UPDATE delta_mutable SET value=111 WHERE id=1;");
  incoming->Capture(delta.index, 3, *delta.machine);
  auto plan = data.snapshots->PlanDelta(data.target);
  ASSERT_TRUE(plan);
  ASSERT_TRUE(incoming->BeginDelta(data.target, plan->base_, 45));
  incoming->RetainOnlyLatest();
  for (int i = 0; i < 32; ++i)
    delta.h.objects->Collect(8);
  struct WatchCopies {
    ~WatchCopies() { watch_snapshot_body = false; }
  } watch;
  snapshot_body_copies = 0;
  watch_snapshot_body = true;
  size_t new_bytes = 0, reused_bytes = 0;
  for (uint64_t offset = 0; offset < data.target.payload_size_;) {
    auto chunk = plan->chunk_(offset, 3 * BUSTUB_PAGE_SIZE);
    chunk.delta_session_ = 45;
    chunk = WireChunk(std::move(chunk));
    if (chunk.reuse_)
      reused_bytes += chunk.reuse_->length_;
    else
      new_bytes += chunk.data_.size();
    const auto done = incoming->StageChunk(chunk);
    offset = done.next_offset_;
    // A repeated chunk preserves progress and final contents. This assertion
    // alone does not prove that every persistent reference is later released.
    EXPECT_EQ(incoming->StageChunk(chunk).next_offset_, offset);
  }
  EXPECT_GT(reused_bytes, 0U);
  EXPECT_LT(new_bytes, data.target.payload_size_);
  EXPECT_EQ(new_bytes + reused_bytes, data.target.payload_size_);
  watch_snapshot_body = false;
  EXPECT_EQ(snapshot_body_copies.load(), 0U)
      << "unchanged snapshot body was copied on receiver";
  auto staged = incoming->StagedInput(data.target.snapshot_id_);
  ASSERT_TRUE(staged);
  auto target_input = data.snapshots->Input(data.target);
  for (uint64_t off = 0; off < staged->size_;) {
    const auto take = std::min<uint64_t>(1733, staged->size_ - off);
    EXPECT_EQ(staged->Read(off, take), target_input.Read(off, take));
    off += take;
  }
  delta.machine->ValidateSnapshot(*staged, data.target.last_included_index_);
  incoming->PublishStaged(data.target.snapshot_id_, false);
  delta.machine->LoadSnapshot(*staged, data.target.last_included_index_);
  delta.log->InstallSnapshotBase(data.target.last_included_index_, 3, false);
  delta.stable->Update(3, 1, data.target.last_included_index_);
  delta.index = data.target.last_included_index_;
  InstallFull(full, *full_store, target_input, data.target);
  data.ExpectContents(delta);
  data.ExpectContents(full);
  // Release scratch/base and original checkpoint owners, then reopen the
  // published snapshot.
  staged.reset();
  incoming.reset();
  for (int i = 0; i < 48; ++i)
    delta.h.objects->Collect(8);
  delta.Apply("INSERT INTO delta_mutable VALUES (9,99);");
  delta.Restart();
  ASSERT_EQ(delta.machine->LastApplied(), data.target.last_included_index_);
  data.ExpectContents(delta);
  delta.machine->Apply(*delta.log->EntryAt(delta.index));
  EXPECT_EQ(delta.Query("SELECT id,value FROM delta_mutable ORDER BY id;"),
            (Rows{{"1", "111"}, {"3", "33"}, {"4", "44"}, {"9", "99"}}));
}
TEST(S11Incremental, WrongBaseConflictingRetryAndDamagedReuseNeverPublish) {
  DeltaBusiness data;
  Business receiver;
  auto store = SnapshotStore::OpenObjects(receiver.h.objects);
  InstallFull(receiver, *store, data.snapshots->Input(data.base), data.base);
  auto plan = data.snapshots->PlanDelta(data.target);
  ASSERT_TRUE(plan);
  auto wrong = data.base;
  wrong.payload_checksum_ ^= 1;
  EXPECT_FALSE(store->BeginDelta(data.target, wrong, 50));
  ASSERT_TRUE(store->BeginDelta(data.target, data.base, 51));
  auto first = plan->chunk_(0, BUSTUB_PAGE_SIZE);
  first.delta_session_ = 51;
  store->StageChunk(first);
  first.data_[37] ^= std::byte{1};
  EXPECT_THROW(store->StageChunk(first), std::exception);
  store->CancelStaged(data.target.snapshot_id_);
  EXPECT_EQ(store->Latest()->snapshot_id_, data.base.snapshot_id_);
  ASSERT_TRUE(store->BeginDelta(data.target, data.base, 52));
  bool damaged = false, rejected = false;
  for (uint64_t offset = 0; offset < data.target.payload_size_;) {
    auto chunk = plan->chunk_(offset, BUSTUB_PAGE_SIZE);
    chunk.delta_session_ = 52;
    if (chunk.reuse_ && !damaged) {
      chunk.reuse_->offset_ = 0;
      damaged = true;
    }
    const auto size = chunk.reuse_ ? chunk.reuse_->length_ : chunk.data_.size();
    try {
      store->StageChunk(WireChunk(chunk));
    } catch (const std::exception &) {
      rejected = true;
      break;
    }
    offset += size;
  }
  EXPECT_TRUE(damaged);
  EXPECT_TRUE(rejected);
  EXPECT_FALSE(store->Staged(data.target.snapshot_id_));
  EXPECT_EQ(store->Latest()->snapshot_id_, data.base.snapshot_id_);
  EXPECT_EQ(receiver.Query("SELECT id,value FROM delta_mutable ORDER BY id;"),
            (Rows{{"1", "11"}, {"2", "22"}, {"3", "33"}}));
  store->CancelStaged(data.target.snapshot_id_);
}
TEST(S11Incremental,
     UnpublishableDeltaRejectsBeforeAllocationAndFullStillWorks) {
  DeltaBusiness data;
  Business receiver;
  auto store = SnapshotStore::OpenObjects(receiver.h.objects);
  InstallFull(receiver, *store, data.snapshots->Input(data.base), data.base);
  store.reset();
  receiver.Close();
  // Candidate creation fits three operations. Delta publication also needs
  // scratch retirement when the old recovery base is not retained. This
  // budget cannot cover that final publication.
  receiver.h.options.transactions_->max_operations_ = 3;
  receiver.h.raft_options.max_owned_objects_ = 16;
  receiver.h.Open();
  store = SnapshotStore::OpenObjects(receiver.h.objects);
  for (uint64_t attempt = 0; attempt < 12; ++attempt) {
    EXPECT_THROW(store->BeginDelta(data.target, data.base, 100 + attempt),
                 std::invalid_argument);
    store->CancelStaged(data.target.snapshot_id_);
  }
  EXPECT_EQ(store->Latest()->snapshot_id_, data.base.snapshot_id_);
  // No Collect: rejected offers must leave capacity for real accepted work.
  // Full publication fits the same budget and must still succeed.
  const auto target = data.snapshots->Input(data.target);
  Transfer(*store, target, data.target);
  const auto published = store->PublishStaged(data.target.snapshot_id_, false);
  EXPECT_EQ(published.snapshot_id_, data.target.snapshot_id_);
  EXPECT_EQ(store->Input(published).Read(0, target.size_),
            target.Read(0, target.size_));
}
TEST(S11Incremental, InterruptedCandidateRestartsFromBaseAndRejectsOldSession) {
  DeltaBusiness data;
  Business receiver;
  auto store = SnapshotStore::OpenObjects(receiver.h.objects);
  InstallFull(receiver, *store, data.snapshots->Input(data.base), data.base);
  auto plan = data.snapshots->PlanDelta(data.target);
  ASSERT_TRUE(plan);
  ASSERT_TRUE(store->BeginDelta(data.target, data.base, 61));
  auto first = plan->chunk_(0, BUSTUB_PAGE_SIZE);
  first.delta_session_ = 61;
  store->StageChunk(first);
  store.reset();
  receiver.Restart();
  store = SnapshotStore::OpenObjects(receiver.h.objects);
  EXPECT_EQ(store->Latest()->snapshot_id_, data.base.snapshot_id_);
  EXPECT_FALSE(store->Staged(data.target.snapshot_id_));
  EXPECT_THROW(store->StageChunk(first), std::exception);
  ASSERT_TRUE(store->BeginDelta(data.target, data.base, 62));
  EXPECT_THROW(store->StageChunk(first), std::exception);
  for (uint64_t offset = 0; offset < data.target.payload_size_;) {
    auto c = plan->chunk_(offset, 64 * 1024);
    c.delta_session_ = 62;
    offset = store->StageChunk(c).next_offset_;
  }
  auto staged = store->StagedInput(data.target.snapshot_id_);
  ASSERT_TRUE(staged);
  receiver.machine->LoadSnapshot(*staged, data.target.last_included_index_);
  data.ExpectContents(receiver);
  store->CancelStaged(data.target.snapshot_id_);
}
} // namespace
namespace {
TEST(S11Incremental, TcpOfferAndDeltaInstallThroughRealRaftFollower) {
  DeltaBusiness data;
  Business receiver;
  auto incoming = SnapshotStore::OpenObjects(receiver.h.objects);
  InstallFull(receiver, *incoming, data.snapshots->Input(data.base), data.base);
  auto plan = data.snapshots->PlanDelta(data.target);
  ASSERT_TRUE(plan);
  std::vector<int> reservations;
  struct CloseFds {
    std::vector<int> &fds;
    ~CloseFds() {
      for (int fd : fds)
        close(fd);
    }
  } close_fds{reservations};
  std::array<TcpEndpoint, 2> endpoints;
  for (size_t i = 0; i < 2; ++i) {
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    ASSERT_GE(fd, 0);
    reservations.push_back(fd);
    sockaddr_in a{};
    a.sin_family = AF_INET;
    a.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    ASSERT_EQ(bind(fd, reinterpret_cast<sockaddr *>(&a), sizeof(a)), 0);
    socklen_t n = sizeof(a);
    ASSERT_EQ(getsockname(fd, reinterpret_cast<sockaddr *>(&a), &n), 0);
    endpoints[i] = {"127.0.0.1", ntohs(a.sin_port)};
  }
  const std::string group = "f25-delta-tcp";
  auto sender = std::make_shared<TcpRaftTransport>(
      1, group, endpoints[0], std::map<NodeId, TcpEndpoint>{{2, endpoints[1]}});
  auto transport = std::make_shared<TcpRaftTransport>(
      2, group, endpoints[1], std::map<NodeId, TcpEndpoint>{{1, endpoints[0]}});
  RaftNode follower({2,
                     {1, 2, 3},
                     1000,
                     1800,
                     100,
                     group,
                     MakeSeededElectionTimeoutSource(8)},
                    transport, std::move(receiver.stable),
                    std::move(receiver.log), receiver.machine,
                    std::move(incoming));
  std::mutex mutex;
  std::condition_variable cv;
  std::deque<RaftEnvelope> requests, replies;
  struct Stop {
    std::shared_ptr<TcpRaftTransport> a, b;
    std::vector<int> &fds;
    ~Stop() {
      a->Stop();
      b->Stop();
      for (int fd : fds)
        close(fd);
    }
  } stop{sender, transport, reservations};
  for (int fd : reservations)
    close(fd);
  reservations.clear();
  sender->Start([&](RaftEnvelope e) {
    std::lock_guard l(mutex);
    replies.push_back(std::move(e));
    cv.notify_all();
  });
  transport->Start([&](RaftEnvelope e) {
    std::lock_guard l(mutex);
    requests.push_back(std::move(e));
    cv.notify_all();
  });
  auto exchange = [&](RaftMessage msg) -> RaftMessage {
    sender->Send({1, 2, std::move(msg), group});
    std::unique_lock l(mutex);
    Require(cv.wait_for(l, 10s, [&] { return !requests.empty(); }),
            "TCP request arrived");
    auto e = std::move(requests.front());
    requests.pop_front();
    l.unlock();
    follower.Receive(e.from_, e.message_);
    l.lock();
    Require(cv.wait_for(l, 10s, [&] { return !replies.empty(); }),
            "TCP reply arrived");
    auto r = std::move(replies.front().message_);
    replies.pop_front();
    return r;
  };
  auto offer = exchange(SnapshotOfferRequest{3, 1, 90, data.target, data.base});
  ASSERT_EQ(std::get<SnapshotOfferResponse>(offer).status_,
            SnapshotOfferStatus::Accepted);
  // A new negotiation supersedes the old receive. Delayed control messages
  // must not replace it, including a full fallback from the old negotiation.
  auto replacement =
      exchange(SnapshotOfferRequest{3, 1, 100, data.target, data.base});
  ASSERT_EQ(std::get<SnapshotOfferResponse>(replacement).status_,
            SnapshotOfferStatus::Accepted);
  auto delayed =
      exchange(SnapshotOfferRequest{3, 1, 90, data.target, data.base});
  ASSERT_EQ(std::get<SnapshotOfferResponse>(delayed).status_,
            SnapshotOfferStatus::Error);
  const auto old_full = plan->chunk_(0, BUSTUB_PAGE_SIZE);
  const auto stale_full = exchange(InstallSnapshotRequest{
      3, 1, 91, old_full.snapshot_id_, old_full.last_included_index_,
      old_full.last_included_term_, 0, old_full.total_size_,
      old_full.payload_checksum_, old_full.done_, old_full.data_});
  ASSERT_FALSE(std::get<InstallSnapshotResponse>(stale_full).success_);
  // Initial deadline is in [1000,1800]. A duplicate at 900 renews it to at
  // least 1900: reaching 1801 must not cancel an acknowledged receive session.
  follower.Tick(900);
  const auto renewed =
      exchange(SnapshotOfferRequest{3, 1, 100, data.target, data.base});
  ASSERT_EQ(std::get<SnapshotOfferResponse>(renewed).status_,
            SnapshotOfferStatus::Accepted);
  follower.Tick(1801);
  uint64_t request = 100;
  size_t network_data = 0, reused = 0;
  for (uint64_t offset = 0; offset < data.target.payload_size_;) {
    auto c = plan->chunk_(offset, 64 * 1024);
    network_data += c.data_.size();
    if (c.reuse_)
      reused += c.reuse_->length_;
    auto response = exchange(InstallSnapshotRequest{
        3, 1, ++request, c.snapshot_id_, c.last_included_index_,
        c.last_included_term_, c.offset_, c.total_size_, c.payload_checksum_,
        c.done_, c.data_, 100, c.reuse_});
    const auto &r = std::get<InstallSnapshotResponse>(response);
    ASSERT_TRUE(r.success_);
    EXPECT_EQ(r.complete_, c.done_);
    offset = c.done_ ? data.target.payload_size_ : r.next_offset_;
  }
  EXPECT_GT(reused, 0U);
  EXPECT_LT(network_data, data.target.payload_size_);
  EXPECT_EQ(follower.LastApplied(), data.target.last_included_index_);
  EXPECT_EQ(follower.LatestSnapshot()->snapshot_id_, data.target.snapshot_id_);
  data.ExpectContents(receiver);
  // Real AppendEntries follows installation, using the new snapshot boundary.
  const auto sql = std::string("INSERT INTO delta_mutable VALUES (19,1919);");
  auto batch = receiver.machine->PrepareSql(
      sql, 71, data.target.last_included_index_ + 1,
      ComputeWriteIntentFingerprintV1(sql));
  ReplicatedLogEntry entry{1, data.target.last_included_index_ + 1, 3,
                           EntryType::COMMAND_BATCH,
                           CommandBatchCodec::Encode(batch)};
  auto response =
      exchange(AppendEntriesRequest{3,
                                    1,
                                    ++request,
                                    data.target.last_included_index_,
                                    3,
                                    {entry},
                                    entry.index_,
                                    std::nullopt});
  ASSERT_TRUE(std::get<AppendEntriesResponse>(response).success_);
  EXPECT_EQ(receiver.Query("SELECT value FROM delta_mutable WHERE id=19;"),
            (Rows{{"1919"}}));
  // Request numbers restart in a new term; the old term's receive fence must
  // not reject a valid new leader's first negotiation.
  data.source.Apply(sql);
  data.source.Apply("UPDATE delta_mutable SET value=333 WHERE id=3;");
  const auto later =
      data.snapshots->Capture(data.source.index, 3, *data.source.machine);
  const auto next_term =
      exchange(SnapshotOfferRequest{4, 1, 1, later, data.target});
  ASSERT_EQ(std::get<SnapshotOfferResponse>(next_term).status_,
            SnapshotOfferStatus::Accepted);
}
} // namespace
