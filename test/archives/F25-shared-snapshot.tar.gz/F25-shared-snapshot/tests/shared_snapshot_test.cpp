// Reuse F28's real SQL / device fixtures and 15 retained F28+S8 workloads.
#include "checkpoint-adapted.cpp"
namespace {
std::atomic<size_t> snapshot_body_copies{0};
std::atomic<bool> watch_snapshot_body{false};
const std::string shared_marker = "f25-native-page-must-remain-shared";
} // namespace
extern "C" ssize_t __wrap_pwrite(int fd, const void *data, size_t size,
                                 off_t offset) {
  const auto *begin = static_cast<const char *>(data);
  if (watch_snapshot_body && offset >= static_cast<off_t>(DATA) &&
      (fcntl(fd, F_GETFL) & O_DIRECT) &&
      std::search(begin, begin + size, shared_marker.begin(),
                  shared_marker.end()) != begin + size) {
    ++snapshot_body_copies;
  }
  return f28_pwrite(fd, data, size, offset);
}
namespace {
void Transfer(SnapshotStore &target, const SnapshotInput &input,
              const RaftSnapshot &info) {
  // Deliberately cross header/page boundaries; transport is byte-oriented.
  for (uint64_t offset = 0; offset < input.size_;) {
    const auto take = std::min<uint64_t>(1537, input.size_ - offset);
    auto bytes = input.Read(offset, take);
    const auto next = offset + take;
    const auto r =
        target.StageChunk({info.snapshot_id_, info.last_included_index_,
                           info.last_included_term_, offset, input.size_,
                           info.payload_checksum_, next == input.size_, bytes});
    Require(r.status_ == (next == input.size_
                              ? SnapshotStageStatus::COMPLETE
                              : SnapshotStageStatus::IN_PROGRESS),
            "snapshot transfer progress");
    offset = next;
  }
}
auto ReadRows(BusTubRaftStateMachine &machine, const std::string &sql) -> Rows {
  return ClientQueryResultCodec::Decode(
             machine.ExecuteReadSql(sql, machine.LastApplied()))
      .rows_;
}
TEST(
    S11SharedSnapshot,
    SharedPagesSurviveRootRetirementAndRestartThenInstallWithSessionsAndSuffix) {
  Business source;
  source.Apply(
      "CREATE TABLE shared_rows(id INT PRIMARY KEY, body VARCHAR(400));");
  std::string values;
  Rows expected;
  for (int n = 0; n < 35; ++n) {
    const auto body = shared_marker + std::to_string(n) +
                      std::string(250, char('a' + n % 23));
    if (n)
      values += ',';
    values += '(' + std::to_string(100 + n) + ",'" + body + "')";
    expected.push_back({std::to_string(100 + n), body});
  }
  source.Apply("INSERT INTO shared_rows VALUES " + values + ';');
  // Index pages / later tables make table page identities non-dense.
  source.Apply("CREATE TABLE second(id INT PRIMARY KEY, value INT);");
  source.Apply("INSERT INTO second VALUES (73,808);");
  source.Apply("CREATE INDEX value_idx ON second(value);");
  source.Checkpoint();
  const auto boundary = source.index;
  const auto response = source.machine->GetLastResponse(71);
  auto snapshots = SnapshotStore::OpenObjects(source.h.objects);
  snapshot_body_copies = 0;
  watch_snapshot_body = true;
  RaftSnapshot snap;
  try {
    snap = snapshots->Capture(boundary, 3, *source.machine);
  } catch (...) {
    watch_snapshot_body = false;
    throw;
  }
  watch_snapshot_body = false;
  EXPECT_EQ(snapshot_body_copies.load(), 0U)
      << "fixed page bytes were copied on sender";
  source.Apply(
      "UPDATE shared_rows SET body='current-new-version' WHERE id=127;");
  source.Checkpoint(); // Retires the workspace from which the snapshot shared
                       // its pages.
  for (int n = 0; n < 16; ++n)
    source.h.objects->Collect(8);
  snapshots.reset();
  source.Restart(); // Startup cleanup must not destroy snapshot-owned ranges.
  EXPECT_EQ(source.Query("SELECT body FROM shared_rows WHERE id=127;"),
            (Rows{{"current-new-version"}}));
  snapshots = SnapshotStore::OpenObjects(source.h.objects);
  auto input = snapshots->Input(*snapshots->Latest());
  EXPECT_EQ(snapshots->Latest()->last_included_index_, boundary);
  Business receiver;
  // The receiver has an older, valid local recovery point. Receiving a newer
  // portable snapshot must supersede it on restart, even if no new local
  // checkpoint has been built after installation.
  receiver.Apply(
      "CREATE TABLE shared_rows(id INT PRIMARY KEY, body VARCHAR(400));");
  receiver.Apply("INSERT INTO shared_rows VALUES " + values + ';');
  receiver.Checkpoint();
  ASSERT_LT(receiver.machine->PollCheckpoint(), boundary);
  auto incoming = SnapshotStore::OpenObjects(receiver.h.objects);
  Transfer(*incoming, input, snap);
  auto staged = incoming->StagedInput(snap.snapshot_id_);
  auto prepared = receiver.machine->PrepareSnapshot(*staged, boundary);
  incoming->PublishStaged(snap.snapshot_id_, false);
  prepared->Install();
  prepared.reset();
  EXPECT_EQ(receiver.Query("SELECT id,body FROM shared_rows ORDER BY id;"),
            expected);
  EXPECT_EQ(receiver.Query("SELECT id FROM second WHERE value=808;"),
            (Rows{{"73"}}));
  EXPECT_EQ(receiver.machine->GetLastResponse(71), response);
  receiver.log->InstallSnapshotBase(boundary, 3, false);
  receiver.stable->Update(3, 1, boundary);
  receiver.index = boundary;
  receiver.Apply("INSERT INTO second VALUES (97,909);");
  // Applying after installation must allocate beyond the restored page
  // highwater.
  receiver.Apply("CREATE TABLE after_restore(id INT PRIMARY KEY, value INT);");
  EXPECT_EQ(receiver.Query("SELECT id,body FROM shared_rows ORDER BY id;"),
            expected);
  staged.reset();
  incoming.reset();
  receiver.Restart();
  ASSERT_EQ(receiver.machine->LastApplied(), boundary);
  EXPECT_FALSE(receiver.machine->LocalRecoveryPoint().has_value());
  EXPECT_EQ(receiver.machine->GetLastResponse(71), response);
  for (auto i = receiver.machine->LastApplied() + 1; i <= receiver.index; ++i)
    receiver.machine->Apply(*receiver.log->EntryAt(i));
  EXPECT_EQ(receiver.Query("SELECT id FROM second ORDER BY id;"),
            (Rows{{"73"}, {"97"}}));
  EXPECT_EQ(receiver.Query("SELECT id,body FROM shared_rows ORDER BY id;"),
            expected);
}
TEST(S11SharedSnapshot, TransferLeaseOutlivesSnapshotAndCheckpointRetirement) {
  Business b;
  b.Apply("CREATE TABLE retained(id INT PRIMARY KEY, value VARCHAR(80));");
  b.Apply("INSERT INTO retained VALUES (47,'first-fixed-generation');");
  auto snapshots = SnapshotStore::OpenObjects(b.h.objects);
  const auto first = snapshots->Capture(b.index, 3, *b.machine);
  auto transfer = snapshots->Input(first);
  // Read part of the stream, then outlive both recovery and transfer-base
  // roles.
  const auto first_chunk = transfer.Read(0, 317);
  b.Apply("UPDATE retained SET value='second-generation' WHERE id=47;");
  snapshots->Capture(b.index, 3, *b.machine);
  b.Apply("UPDATE retained SET value='third-generation' WHERE id=47;");
  snapshots->Capture(b.index, 3, *b.machine);
  b.Apply("UPDATE retained SET value='fourth-generation' WHERE id=47;");
  snapshots->Capture(b.index, 3, *b.machine);
  snapshots->RetainOnlyLatest();
  for (int n = 0; n < 32; ++n)
    b.h.objects->Collect(8);
  EXPECT_THROW(snapshots->Input(first), std::exception);
  EXPECT_EQ(transfer.Read(0, 317), first_chunk);
  Business receiver;
  receiver.machine->LoadSnapshot(transfer, first.last_included_index_);
  EXPECT_EQ(receiver.Query("SELECT value FROM retained WHERE id=47;"),
            (Rows{{"first-fixed-generation"}}));
  transfer = {}; // Existing S8/F28 cases verify final object/physical release,
                 // not duplicated here.
  size_t removed = 0;
  for (int n = 0; n < 32; ++n)
    removed += b.h.objects->Collect(8);
  EXPECT_GT(removed, 0U);
}
TEST(S11SharedSnapshot,
     CorruptNativeBodyAndWrongBoundaryCannotReplacePublishedState) {
  Business source, target;
  source.Apply(
      "CREATE TABLE native_rows(id INT PRIMARY KEY, value VARCHAR(80));");
  source.Apply("INSERT INTO native_rows VALUES (83,'snapshot-row');");
  target.Apply("CREATE TABLE original(id INT PRIMARY KEY, value INT);");
  target.Apply("INSERT INTO original VALUES (91,123);");
  auto snapshots = SnapshotStore::OpenObjects(source.h.objects);
  const auto first = snapshots->Capture(source.index, 3, *source.machine);
  auto input = snapshots->Input(first);
  auto corrupted = input;
  corrupted.into_ = {}; // Fault source owns the complete read contract.
  corrupted.source_ = [input](uint64_t offset, size_t size) {
    auto bytes = input.Read(offset, size);
    // Damage a real payload byte; keep the stored checksum unchanged.
    const auto at = input.size_ - 5;
    if (at >= offset && at - offset < size)
      bytes[at - offset] ^= std::byte{1};
    return bytes;
  };
  EXPECT_THROW(target.machine->ValidateSnapshot(corrupted, source.index),
               std::exception);
  EXPECT_THROW(target.machine->LoadSnapshot(corrupted, source.index),
               std::exception);
  EXPECT_THROW(target.machine->LoadSnapshot(input, source.index + 1),
               std::exception);
  EXPECT_EQ(target.Query("SELECT value FROM original WHERE id=91;"),
            (Rows{{"123"}}));
  source.Apply("UPDATE native_rows SET value='newer' WHERE id=83;");
  EXPECT_THROW(snapshots->Capture(source.index, 9, *source.machine),
               std::exception);
  EXPECT_EQ(snapshots->Latest()->snapshot_id_, first.snapshot_id_);
}
TEST(S11SharedSnapshot,
     CanonicalCompatibilityAndNativeInstallUseExistingFileDeployment) {
  Business source(false, true); // Actual allocator unit twice the queried
                                // baseline, not a fixed 4 KiB assumption.
  source.Apply("CREATE TABLE compatible(id INT PRIMARY KEY, value INT);");
  source.Apply("INSERT INTO compatible VALUES (17,909);");
  Bytes legacy;
  source.machine->WriteSnapshot([&](const auto &bytes) {
    legacy.insert(legacy.end(), bytes.begin(), bytes.end());
  });
  Business target;
  target.machine->LoadSnapshot({0, legacy.size(),
                                [&legacy](uint64_t offset, size_t size) {
                                  return Bytes(legacy.begin() + offset,
                                               legacy.begin() + offset + size);
                                }},
                               source.index);
  EXPECT_EQ(target.Query("SELECT value FROM compatible WHERE id=17;"),
            (Rows{{"909"}}));
  auto snapshots = SnapshotStore::OpenObjects(source.h.objects);
  const auto native = snapshots->Capture(source.index, 3, *source.machine);
  const auto root = source.root / "file-receiver";
  auto directory = NodeDirectory::Open(root, source.files);
  auto file_machine =
      BusTubRaftStateMachine::Open(directory.get(), source.files, 32);
  file_machine->LoadSnapshot(snapshots->Input(native), source.index);
  EXPECT_EQ(
      ReadRows(*file_machine, "SELECT value FROM compatible WHERE id=17;"),
      (Rows{{"909"}}));
}
} // namespace

namespace {
TEST(S11SharedSnapshot,
     DeferredPageSharingKeepsBytesThroughSourceLocationSwitch) {
  Business source(true);
  source.Apply(
      "CREATE TABLE deferred_snapshot(id INT PRIMARY KEY, value VARCHAR(80));");
  source.Apply("INSERT INTO deferred_snapshot VALUES "
               "(131,'journal-held-snapshot-value');");
  ArmData("journal-held-snapshot-value");
  ResumeOnExit cleanup;
  source.Checkpoint();
  ASSERT_TRUE(AwaitData());
  auto snapshots = SnapshotStore::OpenObjects(source.h.objects);
  auto capture = std::async(std::launch::async, [&] {
    return snapshots->Capture(source.index, 3, *source.machine);
  });
  const auto completed = capture.wait_for(30s);
  if (completed != std::future_status::ready)
    ResumeData();
  ASSERT_EQ(completed, std::future_status::ready);
  const auto snapshot = capture.get();
  auto input = snapshots->Input(snapshot);
  const auto before = input.Read(0, input.size_);
  ResumeData();
  // Close drains actual Deferred writes. Reopen reconstructs all references;
  // neither a long-lived old metadata view nor a RAM payload can satisfy this.
  input = {};
  snapshots.reset();
  source.Restart();
  snapshots = SnapshotStore::OpenObjects(source.h.objects);
  input = snapshots->Input(*snapshots->Latest());
  EXPECT_EQ(input.Read(0, input.size_), before);
  Business receiver;
  receiver.machine->LoadSnapshot(input, snapshot.last_included_index_);
  EXPECT_EQ(receiver.Query("SELECT value FROM deferred_snapshot WHERE id=131;"),
            (Rows{{"journal-held-snapshot-value"}}));
}
} // namespace

namespace {
std::mutex sync_gate_mutex;
std::condition_variable sync_gate_changed;
bool arm_sync_gate = false, sync_entered = false, release_sync_gate = true;
void ReleaseSyncGate() {
  std::lock_guard lock(sync_gate_mutex);
  release_sync_gate = true;
  arm_sync_gate = false;
  sync_gate_changed.notify_all();
}
} // namespace
extern "C" int __wrap_fdatasync(int fd) {
  if (fcntl(fd, F_GETFL) & O_DIRECT) {
    std::unique_lock lock(sync_gate_mutex);
    if (arm_sync_gate) {
      arm_sync_gate = false;
      sync_entered = true;
      sync_gate_changed.notify_all();
      sync_gate_changed.wait(lock, [] { return release_sync_gate; });
    }
  }
  return s8_fdatasync(fd);
}
namespace {
TEST(S11SharedSnapshot,
     ReclaimOnlyFencesDeadUnitsWhileSharedMiddleRemainsReadable) {
  Harness h(Limits(), 0, true); // Existing explicit GC budget: no periodic
                                // background pass for this case.
  const auto unit = h.options.objects_->allocator_.allocation_bytes_;
  const ObjectKey original{h.space, 201}, retained{h.space, 202};
  const auto body = s5::Value(3 * unit, 547);
  auto submit = [&](ObjectTransaction tx) {
    for (auto &op : tx.objects_)
      op.common_only_ = true;
    auto s = h.node->SubmitObjects(tx);
    Require(bool(s.ticket_), "transaction accepted");
    s.ticket_->Wait();
    const auto r = s.ticket_->Result();
    if (r.error_)
      std::rethrow_exception(r.error_);
    Require(r.outcome_ == JournalOutcome::Durable, "transaction durable");
  };
  submit(
      {{{ObjectOperation::Create, original, 0, ObjectSizeMode::Variable, {}},
        {ObjectOperation::Create, retained, unit, ObjectSizeMode::Fixed, {}}},
       {}});
  submit(
      {{{ObjectOperation::Append, original, 0, ObjectSizeMode::Variable, body}},
       {}});
  auto view = h.node->Objects();
  const auto allocation =
      view.Resolve(original, 0, 3 * unit).spans_.front().data_->allocation_;
  ASSERT_EQ(h.node->ShareObjectRange(view, original, retained, unit, unit, 0)
                .outcome_,
            JournalOutcome::Durable);
  submit(
      {{{ObjectOperation::Remove, original, 0, ObjectSizeMode::Variable, {}}},
       {}});
  view = h.node->Objects();
  {
    std::lock_guard lock(sync_gate_mutex);
    arm_sync_gate = true;
    sync_entered = false;
    release_sync_gate = false;
  }
  auto reclaim = std::async(std::launch::async, [&] {
    return h.node->ReclaimObject(view, original, allocation);
  });
  struct Cleanup {
    ~Cleanup() { ReleaseSyncGate(); }
  } cleanup;
  {
    std::unique_lock lock(sync_gate_mutex);
    ASSERT_TRUE(
        sync_gate_changed.wait_for(lock, 15s, [] { return sync_entered; }));
  }
  EXPECT_NO_THROW({
    auto read = h.node->ReadObject(h.node->Objects(), retained, 0, unit);
    read.Wait();
    Bytes actual(unit);
    read.CopyTo(actual.data(), actual.size());
    EXPECT_EQ(actual, (Bytes(body.begin() + unit, body.begin() + 2 * unit)));
  });
  ReleaseSyncGate();
  const auto result = reclaim.get();
  EXPECT_EQ(result.released_bytes_, 2 * unit);
}
} // namespace

#include "incremental_snapshot_test.cpp"
