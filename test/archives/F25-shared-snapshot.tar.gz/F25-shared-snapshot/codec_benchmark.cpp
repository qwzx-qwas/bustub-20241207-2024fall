// Generates real SQL/native snapshots; benchmarks only independent wire blocks.
#include "tests/shared_snapshot_test.cpp"
#include "lz4.h"
#include <zstd.h>
#include <fstream>
#include <ctime>
#include <iostream>
static double CpuSeconds(){ timespec t{};clock_gettime(CLOCK_THREAD_CPUTIME_ID,&t);return t.tv_sec+t.tv_nsec*1e-9; }
int main(){
  Business source;std::mt19937 random(8912);
  source.Apply("CREATE TABLE codec_data(id INT PRIMARY KEY, body VARCHAR(700));");
  for(int batch=0;batch<12;++batch){
    std::string values;
    for(int j=0;j<20;++j){int id=batch*20+j;std::string body;
      if(id%3==0)body="order="+std::to_string(id)+";region=shanghai;status=paid;"+std::string(500,'a'+id%21);
      else if(id%3==1){for(int k=0;k<550;++k)body+=char('!'+random()%90);std::replace(body.begin(),body.end(),'\'','_');std::replace(body.begin(),body.end(),'\\','_');}
      else for(int k=0;k<25;++k)body+="item="+std::to_string(random()%10000)+";";
      if(j)values+=",";values+="("+std::to_string(id)+",'"+body+"')";
    }
    source.Apply("INSERT INTO codec_data VALUES "+values+";");
  }
  auto store=SnapshotStore::OpenObjects(source.h.objects);auto snap=store->Capture(source.index,3,*source.machine);auto input=store->Input(snap);
  std::vector<std::vector<std::byte>> blocks;
  for(uint64_t o=0;o<input.size_;o+=65536)blocks.push_back(input.Read(o,std::min<uint64_t>(65536,input.size_-o)));
  std::cout<<"# LZ4="<<LZ4_versionString()<<",Zstd="<<ZSTD_versionString()<<",blocks="<<blocks.size()<<",raw="<<input.size_<<"\n";
  std::cout<<"codec,wire_bytes,encode_cpu_ms_per_snapshot,decode_cpu_ms_per_snapshot,encode_p95_us_block,decode_p95_us_block\n";
  for(int algorithm=0;algorithm<4;++algorithm){
    double enc=0,dec=0;size_t wire=0;std::vector<double> enc_wall,dec_wall;
    for(int round=0;round<100;++round){
      for(auto &raw:blocks){
        std::vector<std::byte> out(std::max<size_t>(LZ4_compressBound(raw.size()),ZSTD_compressBound(raw.size()))),back(raw.size());
        auto t=CpuSeconds();auto w=std::chrono::steady_clock::now();size_t n;
        if(algorithm==0){std::memcpy(out.data(),raw.data(),raw.size());n=raw.size();}
        else if(algorithm==1)n=LZ4_compress_default(reinterpret_cast<const char*>(raw.data()),reinterpret_cast<char*>(out.data()),raw.size(),out.size());
        else {n=ZSTD_compress(out.data(),out.size(),raw.data(),raw.size(),algorithm==2?1:-1);if(ZSTD_isError(n))throw std::runtime_error("zstd encode");}
        enc+=CpuSeconds()-t;enc_wall.push_back(std::chrono::duration<double,std::micro>(std::chrono::steady_clock::now()-w).count());
        const bool compressed=algorithm && raw.size()>=4096 && n+21<=raw.size()-raw.size()/8;
        if(round==0)wire+=compressed?n+21:raw.size();
        t=CpuSeconds();w=std::chrono::steady_clock::now();
        if(!compressed)std::memcpy(back.data(),raw.data(),raw.size());
        else if(algorithm==1){if(LZ4_decompress_safe(reinterpret_cast<const char*>(out.data()),reinterpret_cast<char*>(back.data()),n,back.size())!=static_cast<int>(back.size()))throw std::runtime_error("lz4 decode");}
        else if(ZSTD_decompress(back.data(),back.size(),out.data(),n)!=back.size())throw std::runtime_error("zstd decode");
        dec+=CpuSeconds()-t;dec_wall.push_back(std::chrono::duration<double,std::micro>(std::chrono::steady_clock::now()-w).count());
        if(raw!=back)throw std::runtime_error("corpus mismatch");
      }
    }
    std::sort(enc_wall.begin(),enc_wall.end());std::sort(dec_wall.begin(),dec_wall.end());
    std::cout<<(algorithm==0?"raw":algorithm==1?"lz4":algorithm==2?"zstd-1":"zstd-fast1")<<","<<wire<<","<<enc*10<<","<<dec*10<<","<<enc_wall[enc_wall.size()*95/100]<<","<<dec_wall[dec_wall.size()*95/100]<<"\n";
  }
}
