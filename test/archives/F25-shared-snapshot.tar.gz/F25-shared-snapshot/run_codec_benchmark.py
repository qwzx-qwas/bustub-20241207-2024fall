#!/usr/bin/env python3
import argparse,pathlib,json,subprocess,os,resource
p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--baseline',required=True);p.add_argument('--out',required=True);a=p.parse_args()
r=pathlib.Path(a.repo).resolve();b=pathlib.Path(a.baseline).resolve();out=pathlib.Path(a.out).resolve();out.mkdir(exist_ok=False);pkg=pathlib.Path(__file__).resolve().parent
commands=json.loads((b/'commands.json').read_text());c=next(x['command'] for x in commands if x['log']=='checkpoint-compile.log').copy();link=next(x['command'] for x in commands if x['log']=='checkpoint-link.log').copy();calls=[]
def run(cmd,name):
 with (out/(name+'.log')).open('w') as f: q=subprocess.run(cmd,cwd=r,env={**os.environ,'S5_WORKDIR':str(out),'ASAN_OPTIONS':'detect_leaks=1:abort_on_error=1'},stdout=f,stderr=subprocess.STDOUT,timeout=180)
 calls.append(dict(command=list(map(str,cmd)),exit=q.returncode));(out/'commands.json').write_text(json.dumps(calls,indent=2));q.check_returncode()
run(['clang-14','-O3','-DNDEBUG','-c',str(r/'third_party/lz4/lz4.c'),'-o',str(out/'lz4.o')],'lz4-release')
c=[x for x in c if x not in ['-O0','-fsanitize=address,undefined']];c+=['-O3','-I'+str(r/'third_party/lz4'),'-I'+str(pkg)];c[c.index('-c')+1]=str(pkg/'codec_benchmark.cpp');c[c.index('-o')+1]=str(out/'benchmark.o');run(c,'compile')
link[link.index(str(b/'checkpoint.o'))]=str(out/'benchmark.o');link.insert(link.index(str(out/'benchmark.o'))+1,str(out/'lz4.o'));link+=['-lzstd'];link[link.index('-o')+1]=str(out/'benchmark');run(link,'link');run([str(out/'benchmark')],'metrics')
(out/'environment.json').write_text(json.dumps(dict(cpu=pathlib.Path('/proc/cpuinfo').read_text(),rss_max_kib=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,scope='Codec-only on real SQL snapshot; codec source compiled O3 without sanitizers; storage fixture ASan build; no throttled-network E2E'),indent=2))
