#!/usr/bin/env python3
"""F25 shared snapshots on real SQL/storage; archived workloads are reused."""
import argparse,pathlib,subprocess,tarfile,os,json,time,hashlib,resource,signal
import xml.etree.ElementTree as ET
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--build',required=True);p.add_argument('--out',required=True);p.add_argument('--regressions',action='store_true');p.add_argument('--checkpoint-only',action='store_true');p.add_argument('--case',help='One gtest filter; requires --checkpoint-only')
a=p.parse_args()
if a.case is not None and (not a.case or not a.checkpoint_only):
 p.error('--case requires a nonempty filter and --checkpoint-only')
repo=pathlib.Path(a.repo).resolve();build=pathlib.Path(a.build).resolve();out=pathlib.Path(a.out).resolve();pkg=pathlib.Path(__file__).resolve().parent
out.mkdir(parents=True,exist_ok=False)
if (pkg/'MANIFEST.json').exists():
 m=json.loads((pkg/'MANIFEST.json').read_text())
 for base,key in [(repo,'production_sha256'),(repo,'dependency_sha256'),(pkg,'test_sha256')]:
  for f,d in m[key].items():
   if hashlib.sha256((base/f).read_bytes()).hexdigest()!=d:raise SystemExit('source mismatch: '+str(base/f))
for n in ['S5-journal-recycling','F19-common-pipeline','F26-array-buffer-pool','F36-table-space','S8-raft-object-stores','F27-deferred','F28-business-checkpoint']:
 with tarfile.open(repo/f'test/archives/{n}.tar.gz') as t:t.extractall(out,filter='data')
env={k:v for k,v in os.environ.items() if not k.startswith('GTEST_')};env.update(S5_WORKDIR=str(out),ASAN_OPTIONS='detect_leaks=1:abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
flags=['clang++-14','-std=c++17','-pthread','-g','-O0','-Wall','-Wextra','-Werror','-Wno-unused-parameter','-Wno-attributes','-fsanitize=address,undefined','-fno-omit-frame-pointer','-fno-pie']
flags+=['-I'+str(x) for x in [repo/'src/include',repo/'src/buffer',repo/'src/storage/disk',repo/'src/raft',repo/'third_party',repo/'third_party/libfort/src',repo/'third_party/fmt/include',repo/'third_party/googletest/googletest/include',out/'S5-journal-recycling/test/storage_redesign',out/'F26-array-buffer-pool/tests']]
libs=[build/'lib'/('lib'+n+'.a') for n in ['bustub','bustub_murmur3','duckdb_pg_query','fmtd','fort','gmock_main','gmock','gtest']]
wrap=['-Wl,--wrap=pwrite','-Wl,--wrap=fdatasync'];deferred_wrap=wrap+['-Wl,--wrap=pread'];commands=[];counts={};evidence=[]
def run(cmd,name,expected=0,timeout=300):
 start=time.monotonic()
 with (out/(name+'.log')).open('w') as f:
  with subprocess.Popen(list(map(str,cmd)),cwd=repo,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True) as r:
   try:r.wait(timeout=timeout)
   except subprocess.TimeoutExpired:
    # A crash test may fork. Terminate this command's process group, including
    # its fixture children, rather than leaving a blocked device writer behind.
    os.killpg(r.pid,signal.SIGKILL);r.wait()
    commands.append(dict(command=list(map(str,cmd)),exit=r.returncode,timeout=True,seconds=time.monotonic()-start,log=name+'.log'))
    (out/'commands.json').write_text(json.dumps(commands,indent=2));raise
 commands.append(dict(command=list(map(str,cmd)),exit=r.returncode,seconds=time.monotonic()-start,log=name+'.log'));(out/'commands.json').write_text(json.dumps(commands,indent=2))
 if r.returncode!=expected:raise RuntimeError((name,r.returncode,expected))
def check(name,count,failed=False):
 cases=ET.parse(out/(name+'.xml')).getroot().findall('.//testcase')
 assert len(cases)==count and all(c.attrib.get('status')=='run' and c.find('skipped') is None and c.find('error') is None for c in cases),(name,'coverage')
 failures=[f.text or '' for c in cases for f in c.findall('failure')]
 assert bool(failures)==failed,(name,failures)
 if not failed:counts[name]=count
 return failures
def suite(name,source,count,wrappers):
 run(flags+['-c',source,'-o',out/(name+'.o')],name+'-compile')
 run(flags+['-no-pie',out/(name+'.o')]+libs+wrappers+['-o',out/name],name+'-link')
 run([out/name,'--gtest_output=xml:'+str(out/(name+'.xml'))]+(['--gtest_filter='+a.case] if a.case and name=='checkpoint' else ['--gtest_filter=-S11Checkpoint.NewerPortableSnapshotSupersedesLocalCheckpointWithoutLosingSuffix'] if name=='checkpoint' else []),name)
 check(name,count)
if not a.checkpoint_only:suite('deferred',out/'F27-deferred/tests/deferred_test.cpp',12,deferred_wrap)
if a.regressions and not a.checkpoint_only:
 suite('common',out/'F19-common-pipeline/tests/transaction_test.cpp',10,wrap+['-Wl,--wrap=pread'])
 # Old producer's B+Tree includes the modern BufferPool declarations. Isolate
 # unused object declarations at the pre-S10 production version; no fake values
 # or disk bytes are introduced, and the historic B/Journal writer stays intact.
 for header in ['object_mapping.h','data_allocator.h']:
  target=out/'legacy/src/include/storage/disk'/header;target.parent.mkdir(parents=True,exist_ok=True)
  target.write_bytes(subprocess.check_output(['git','show','2512675:src/include/storage/disk/'+header],cwd=repo))
 (out/'build').symlink_to(build,target_is_directory=True)
 # Existing legacy producer + recycling workload, same bodies and assertions.
 run(['python3',out/'S5-journal-recycling/test/storage_redesign/build_checks.py',repo,out],'s5-regression',timeout=300);check('s5',8)
 # F36 source includes the 9 F26 cases; run them once through this combined suite.
 suite('tables',out/'F36-table-space/tests/table_space_test.cpp',18,wrap+['-Wl,--wrap=pread','-Wl,--wrap=madvise'])
s=(out/'S8-raft-object-stores/tests/object_stores_test.cpp').read_text()
# Same fixture adaptation already used by F26/e and F36; no workload change.
for old,new,count in [
('ObjectTransactionOptions{32, 128, MIB, 8 * MIB, 2ms, 10ms}};','ObjectTransactionOptions{32, 128, MIB, 8 * MIB, 2ms, 10ms}, 2 * MIB};',1),
('RaftObjectDeployment{h.options, h.space, Limits()}','RaftObjectDeployment{h.options, h.space, Limits(), PageCacheDeployment{4U, BufferPoolOptions{8*MIB, 2*MIB, 32, false, 3}}}',1)]:
 assert s.count(old)==count;s=s.replace(old,new)
# Only the new shared-Deferred scenario provisions a larger record limit;
# Journal geometry must be established at Create, not changed during Open.
s=s.replace('size_t data_units = 0)', 'size_t data_units = 0, bool deferred = false, bool large_unit = false)')
marker='    int fd = open(image.path.c_str(), O_WRONLY);'
assert s.count(marker)==1
s=s.replace(marker, """    if (large_unit) options.objects_->allocator_.allocation_bytes_ *= 2;
    if (deferred) {
     const auto unit = options.objects_->allocator_.allocation_bytes_;
     options.journal_.max_record_bytes_ = static_cast<uint32_t>(32 * unit);
     options.transactions_->deferred_max_bytes_ = 16 * unit;
     options.transactions_->deferred_pending_bytes_ = 128 * unit;
     options.transactions_->deferred_pending_tasks_ = 16;
     options.transactions_->gc_interval_ = 1h;
   }
"""+marker)
checkpoint_source=(out/'F28-business-checkpoint/tests/checkpoint_test.cpp').read_text()
assert checkpoint_source.count('ShareObjectRange(view, a, b, 0, body.size())')==1
(out/'checkpoint-adapted.cpp').write_text(checkpoint_source.replace('Business() : root(h.image.path + "-checkpoint")', 'Business(bool deferred = false, bool large_unit = false) : h(Limits(), 0, deferred, large_unit), root(h.image.path + "-checkpoint")').replace('ShareObjectRange(view, a, b, 0, body.size())','ShareObjectRange(view, a, b, 0, body.size(), 0)').replace('__wrap_pwrite(', 'f28_pwrite('))
adapted=out/'s8-adapted.cpp';adapted.write_text(s.replace('__wrap_pwrite(', 's8_pwrite(').replace('__wrap_fdatasync(', 's8_fdatasync(')); flags.append('-I'+str(out)); suite('checkpoint',pkg/'tests/shared_snapshot_test.cpp',1 if a.case else 26,wrap)
(out/'summary.json').write_text(json.dumps(dict(passed=counts,scope='Real SQL, Direct file object storage and loopback TCP; not machine power loss or performance'),indent=2))
print(counts,flush=True)
