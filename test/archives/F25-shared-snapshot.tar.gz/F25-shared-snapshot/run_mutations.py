#!/usr/bin/env python3
"""Compile isolated broken production objects; never edit the repository or its library."""
import pathlib,subprocess,json,argparse,os,signal,time,xml.etree.ElementTree as ET
p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--baseline',required=True);p.add_argument('--out',required=True);p.add_argument('--only',nargs='*');a=p.parse_args()
repo=pathlib.Path(a.repo).resolve();base=pathlib.Path(a.baseline).resolve();out=pathlib.Path(a.out).resolve();out.mkdir(parents=True,exist_ok=False)
commands=json.loads((base/'commands.json').read_text());compile_cmd=next(c['command'] for c in commands if c['log']=='checkpoint-compile.log');link_cmd=next(c['command'] for c in commands if c['log']=='checkpoint-link.log')
env={k:v for k,v in os.environ.items() if not k.startswith('GTEST_')};env.update(S5_WORKDIR=str(out),ASAN_OPTIONS='detect_leaks=1:abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
results=[];calls=[]
def run(cmd,name,expected):
 start=time.monotonic()
 with (out/(name+'.log')).open('w') as log:
  with subprocess.Popen(cmd,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True) as process:
   try:process.wait(timeout=120)
   except subprocess.TimeoutExpired:
    os.killpg(process.pid,signal.SIGKILL);process.wait();raise
 calls.append(dict(command=cmd,exit=process.returncode,seconds=time.monotonic()-start,log=name+'.log'));(out/'commands.json').write_text(json.dumps(calls,indent=2))
 if process.returncode!=expected:raise RuntimeError((name,process.returncode,expected))
full='S11SharedSnapshot.'
fsm='src/distributed/raft_state_machine.cpp'
t1='SharedPagesSurviveRootRetirementAndRestartThenInstallWithSessionsAndSuffix'
t2='TransferLeaseOutlivesSnapshotAndCheckpointRetirement'
t3='CorruptNativeBodyAndWrongBoundaryCannotReplacePublishedState'
mutations=[
 ('prefer-stale-local-checkpoint','src/raft/persistent_state.cpp',
  'const bool use_local = local && local->index_ >= latest_index;',
  'const bool use_local = local.has_value();',t1,None),
 ('copy-instead-of-share',fsm,
  'if (index == 0 || !page_deployment_ || page_deployment_->storage_.get() != &storage || !checkpoint_)',
  'if (true)',t1,'snapshot_body_copies'),
 ('lose-target-offset','src/storage/disk/node_storage.cpp',
  'span.offset_ = destination_offset + (span.offset_ - offset);',
  '// broken: retain the source logical offset',t1,None),
 ('lose-transfer-lease','src/raft/object_snapshot_store.cpp',
  'auto use = storage_->Lease(body.object_);',
  'std::shared_ptr<void> use; // broken: gaps between reads are unprotected',t2,None),
 ('ignore-payload-checksum',fsm,
  'if (checksum.ReadU32() != ChecksumSlice(payload.Slice(header_size, payload.size_ - header_size), header_crc))',
  'if ((void)header_crc, false)',t3,None),
 ('ignore-applied-term',fsm,
  '(index == fsm_->LastApplied() && applied_term_ != 0 && term != applied_term_)',
  'false',t3,'throws nothing'),
]
ref=(repo/'src/storage/disk/object_reference.cpp').read_text()
start=ref.index('    // Persistent checkpoint/fork references');stop=ref.index('    Gate fence(*state_);',start)
mutations.append(('ignore-durable-owners','src/storage/disk/object_reference.cpp',ref[start:stop],
                  '    // broken: ignore durable shared ownership\n',t1,None))
mutations.append(('gate-live-shared-units','src/storage/disk/object_reference.cpp',
                  'for (const auto range : released) gates.push_back({object, allocation_id, range});',
                  'for (const auto range : candidates) gates.push_back({object, allocation_id, range});',
                  'ReclaimOnlyFencesDeadUnitsWhileSharedMiddleRemainsReadable','read range is being retired'))
mutations.append(('preexpand-header-destination',fsm,
                  '  ObjectTransaction tx;\n  for (uint64_t offset = 0; offset < bytes.size();)',
                  '  ObjectTransaction tx{{{ObjectOperation::Resize, destination, size, ObjectSizeMode::Variable, {}}}, {}};\n  SubmitCheckpoint(storage, tx);\n  for (uint64_t offset = 0; offset < bytes.size();)',
                  'CanonicalCompatibilityAndNativeInstallUseExistingFileDeployment','empty destination range'))
for name,file,old,new,test,marker in mutations:
 if a.only and name not in a.only:continue
 s=(repo/file).read_text();assert s.count(old)==1,(name,s.count(old));source=out/(name+'.cpp');source.write_text(s.replace(old,new));obj=out/(name+'.o');exe=out/name
 c=compile_cmd.copy();c.insert(1,'-I'+str(repo/'third_party/libpg_query/include'));i=c.index('-c');c[i+1]=str(source);c[c.index('-o')+1]=str(obj);run(c,name+'-compile',0)
 c=link_cmd.copy();i=c.index(str(base/'checkpoint.o'));c.insert(i+1,str(obj));c[c.index('-o')+1]=str(exe);run(c,name+'-link',0)
 xml=out/(name+'.xml');run([str(exe),'--gtest_filter='+full+test,'--gtest_output=xml:'+str(xml)],name,1)
 cases=ET.parse(xml).getroot().findall('.//testcase');assert len(cases)==1 and cases[0].attrib.get('status')=='run' and cases[0].find('skipped') is None
 failures=[f.text or '' for f in cases[0].findall('failure')];assert failures and (marker is None or any(marker in f for f in failures)),(name,failures)
 results.append(dict(mutation=name,file=file,test=full+test,old=old,new=new,failures=failures));(out/'mutations.json').write_text(json.dumps(results,indent=2));print(name+': detected',flush=True)
