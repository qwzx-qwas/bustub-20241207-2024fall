#!/usr/bin/env python3
"""Compile isolated broken production objects; never edit the repository or its library."""
import pathlib,subprocess,json,argparse,os,signal,time,xml.etree.ElementTree as ET
p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--baseline',required=True);p.add_argument('--out',required=True);p.add_argument('--only',nargs='+');a=p.parse_args()
repo=pathlib.Path(a.repo).resolve();base=pathlib.Path(a.baseline).resolve();out=pathlib.Path(a.out).resolve();out.mkdir(parents=True,exist_ok=False)
commands=json.loads((base/'commands.json').read_text());compile_cmd=next(c['command'] for c in commands if c['log']=='checkpoint-compile.log');link_cmd=next(c['command'] for c in commands if c['log']=='checkpoint-link.log')
env={k:v for k,v in os.environ.items() if not k.startswith('GTEST_')};env.update(S5_WORKDIR=str(out),ASAN_OPTIONS='detect_leaks=1:abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
results=[];calls=[]
def run(cmd,name,expected):
 start=time.monotonic()
 with (out/(name+'.log')).open('w') as log:
  with subprocess.Popen(cmd,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True) as process:
   try:process.wait(timeout=120)
   except subprocess.TimeoutExpired:
    os.killpg(process.pid,signal.SIGKILL);process.wait();raise
 calls.append(dict(command=cmd,exit=process.returncode,seconds=time.monotonic()-start,log=name+'.log'));(out/'commands.json').write_text(json.dumps(calls,indent=2))
 if process.returncode!=expected:raise RuntimeError((name,process.returncode,expected))
def check_mutation_result(xml,test,marker):
 cases=ET.parse(xml).getroot().findall('.//testcase')
 if len(cases)!=1:
  raise RuntimeError((test,'expected exactly one executed case'))
 case=cases[0]
 if (case.get('classname','')+'.'+case.get('name','')!=test or case.get('status')!='run'
     or case.find('skipped') is not None or case.find('error') is not None):
  raise RuntimeError((test,'wrong, skipped, or errored case'))
 failures=[f.text or '' for f in case.findall('failure')]
 if (not marker or not any(marker in f for f in failures)
     or any('real Raft exchange made progress' in f for f in failures)):
  raise RuntimeError((test,'expected mutation failure missing or progress timed out',failures))
 return failures
mutations=[
 ('ignore-payload-checksum','src/distributed/raft_state_machine.cpp',
  'if (body_crc != expected_crc)',
  'if ((void)body_crc, (void)expected_crc, false)',
  'S11SharedSnapshot.CorruptNativeBodyAndWrongBoundaryCannotReplacePublishedState','target.machine->ValidateSnapshot(corrupted, source.index)'),
]
delta_file='src/raft/object_snapshot_store.cpp'
delta=(repo/delta_file).read_text()
start=delta.index('    if (lo.space_'); stop=delta.index('    const auto take',start)
mutations += [
 ('delta-skip-publication-budget',delta_file,
  '  storage_->Check(check);\n  if (download_) Cancel(download_->body_.info_.snapshot_id_);',
  '  if (download_) Cancel(download_->body_.info_.snapshot_id_);',
  'S11Incremental.UnpublishableDeltaRejectsBeforeAllocationAndFullStillWorks','store->BeginDelta(data.target, data.base, 100 + attempt)'),
 ('missing-session-response-on-both-sides','src/distributed/raft_state_machine.cpp',
  'return fsm_->GetLastResponse(client_id);','return std::nullopt;',
  'S11Incremental.FullAndDeltaRestoreSameSqlSessionSuffixWithLargeAllocationAndRetiredBase','response.has_value()'),
 ('delta-ignore-content-identity',delta_file,delta[start:stop],
  '    (void)lo; (void)ro; // broken: unrelated allocations treated as equal\n',
  'S11Incremental.FullAndDeltaRestoreSameSqlSessionSuffixWithLargeAllocationAndRetiredBase','reconstructed delta snapshot checksum or format mismatch'),
 ('delta-copy-retained-body',delta_file,
  'const auto object = part.reuse_ ? delta.base_object_ : delta.scratch_;',
  'if (part.reuse_) storage_->Append(delta.scratch_, storage_->Read(delta.base_object_, part.source_, part.size_));\n    const auto object = part.reuse_ ? delta.base_object_ : delta.scratch_;',
  'S11Incremental.FullAndDeltaRestoreSameSqlSessionSuffixWithLargeAllocationAndRetiredBase','snapshot_body_copies'),
 ('delta-ignore-result-crc',delta_file,
  'Checksum(input) != d.body_.info_.payload_checksum_', 'false',
  'S11Incremental.WrongBaseConflictingRetryAndDamagedReuseNeverPublish','Value of: rejected'),
 ('delta-drop-base-lease',delta_file,'auto use = storage_->Lease(body.object_);',
  'std::shared_ptr<void> use; // broken: base can be removed during transfer',
  'S11Incremental.FullAndDeltaRestoreSameSqlSessionSuffixWithLargeAllocationAndRetiredBase','object was deleted'),
 ('delta-accept-old-session',delta_file,' || download_->delta_->session_ != chunk.delta_session_', '',
  'S11Incremental.InterruptedCandidateRestartsFromBaseAndRejectsOldSession','store->StageChunk(first)'),
 ('delta-ignore-duplicate-body',delta_file,
  'storage_->Read(delta.scratch_, it->source_, size) != chunk.data_', 'false',
  'S11Incremental.WrongBaseConflictingRetryAndDamagedReuseNeverPublish','store->StageChunk(first)'),
]
node_file='src/raft/raft_node.cpp'
node_test='S11Incremental.TcpOfferAndDeltaInstallThroughRealRaftFollower'
mutations += [
 ('delta-accept-stale-offer',node_file,
  'request.request_id_ <= snapshot_request_floor_', 'false', node_test,'std::get<SnapshotOfferResponse>(delayed).status_'),
 ('delta-old-full-cancels-new-session',node_file,
  'request.delta_session_ == 0 && request.request_id_ < snapshot_request_floor_',
  'false',node_test,'std::get<InstallSnapshotResponse>(stale_full).success_'),
 ('delta-duplicate-offer-does-not-renew',node_file,
  '          incoming_delta_->deadline_ = election_deadline_ms_;\n          status = SnapshotOfferStatus::Accepted;',
  '          status = SnapshotOfferStatus::Accepted;',node_test,'r.success_'),
 ('delta-request-floor-survives-term',node_file,
  '  CancelIncomingDelta();\n  snapshot_request_floor_ = 0;\n  role_ = RaftRole::TERM_PERSISTING;\n  leader_id_.reset();',
  '  CancelIncomingDelta();\n  role_ = RaftRole::TERM_PERSISTING;\n  leader_id_.reset();',node_test,'std::get<SnapshotOfferResponse>(next_term).status_'),
]
mutations += [
 ('omit-transfer-base',delta_file,
  'auto base = previous_ ? previous_ : transfer_base_;','auto base = std::optional<Body>{};',
  'S11Incremental.AutomaticLeaderCatchupUsesRetiredBaseAndKeepsTargetAcrossPublication','offer_base'),
 ('ignore-benefit-margin',delta_file,
  'if (saved <= overhead || saved - overhead < target.payload_size_ / 5)',
  'if ((void)saved, (void)overhead, false)',
  'S11Incremental.LowBenefitNegotiationFallsBackToCompleteLatestImage','offer->plan_()'),
 ('replace-transfer-target-on-publication',node_file,
  '  const auto snapshot = transfer == snapshot_transfers_.end() ? *snapshot_store_->Latest() : transfer->second.snapshot_;\n  if (transfer == snapshot_transfers_.end()) {',
  '  const auto snapshot = *snapshot_store_->Latest();\n  if (transfer == snapshot_transfers_.end() || transfer->second.snapshot_.snapshot_id_ != snapshot.snapshot_id_) {',
  'S11Incremental.AutomaticLeaderCatchupUsesRetiredBaseAndKeepsTargetAcrossPublication','snapshot target changed during ongoing transfer'),
 ('skip-prepared-install',node_file,'    prepared->Install();','    /* broken: skip installation */',
  'S11Incremental.AutomaticLeaderCatchupUsesRetiredBaseAndKeepsTargetAcrossPublication','BusTub state machine Apply is not continuous'),
 ('reread-native-body','src/distributed/raft_state_machine.cpp',
  '    payload.ReadInto(header_size + i * BUSTUB_PAGE_SIZE, data, BUSTUB_PAGE_SIZE, guard);',
  '    payload.ReadInto(header_size + i * BUSTUB_PAGE_SIZE, data, BUSTUB_PAGE_SIZE, guard);\n    (void)payload.Read(header_size + i * BUSTUB_PAGE_SIZE, BUSTUB_PAGE_SIZE);',
  'S11Incremental.PreparedCandidateIsBuiltOnceAndCancellationKeepsActiveDatabase','body_read'),
]
mutations += [
 ('skip-restart-committed-suffix',node_file,
  '  last_applied_ = state_machine_->LastApplied();\n  published_applied_index_ = last_applied_;\n  ApplyCommitted();\n  ResetElectionDeadline();',
  '  last_applied_ = state_machine_->LastApplied();\n  published_applied_index_ = last_applied_;\n  /* broken: committed suffix omitted on restart */\n  ResetElectionDeadline();',
  'S11Incremental.AutomaticLeaderCatchupUsesRetiredBaseAndKeepsTargetAcrossPublication','nodes[1]->LastApplied()'),
]
unknown=set(a.only or [])-{m[0] for m in mutations}
if unknown:p.error('unknown mutation selection: '+', '.join(sorted(unknown)))
for name,file,old,new,test,marker in mutations:
 if a.only and name not in a.only:continue
 s=(repo/file).read_text();assert s.count(old)==1,(name,s.count(old));source=out/(name+'.cpp');source.write_text(s.replace(old,new));obj=out/(name+'.o');exe=out/name
 c=compile_cmd.copy();c.insert(1,'-I'+str(repo/'third_party/libpg_query/include'));i=c.index('-c');c[i+1]=str(source);c[c.index('-o')+1]=str(obj);run(c,name+'-compile',0)
 c=link_cmd.copy();i=c.index(str(base/'checkpoint.o'));c.insert(i+1,str(obj));c[c.index('-o')+1]=str(exe);run(c,name+'-link',0)
 xml=out/(name+'.xml');run([str(exe),'--gtest_filter='+test,'--gtest_output=xml:'+str(xml)],name,1)
 failures=check_mutation_result(xml,test,marker)
 results.append(dict(mutation=name,file=file,test=test,old=old,new=new,failures=failures));(out/'mutations.json').write_text(json.dumps(results,indent=2));print(name+': detected',flush=True)
