# F05/S2 阶段测试恢复

两个组件集成场景，只在外部临时目录按需运行，不恢复到常驻 test/ 中。
基准是 69ed1dd 加本轮 F05/F04 改动；该基准本身不含 F05。
MANIFEST.json 中 production_sha256 固定实际版本。优先使用匹配的工作树；
若恢复历史环境，先 `git archive` 基准到外部目录，再用本地 F05-results.tar.gz
中的 source/ 覆盖同名文件，并逐项核对哈希。不要覆盖有用户改动的工作树。

需要 Linux、Clang14/CMake/Python3、仓库已有 googletest、支持 statx DIOALIGN
及 O_DIRECT 的真实文件系统。正常测试要求当前 4096 字节页面能满足实际偏移对齐，
不自动降级。8 KiB 不兼容分支为测试链接侧能力注入，不代表真实 8 KiB 硬件。

```sh
f05_repo=$(pwd)
f05_scratch=$(mktemp -d /tmp/bustub-f05-restore-XXXXXX)
(cd "$f05_repo/test/archives" && sha256sum -c SHA256SUMS)
tar -xzf "$f05_repo/test/archives/F05-metadata-backend.tar.gz" -C "$f05_scratch"
python3 "$f05_scratch/F05-metadata-backend/test/storage_redesign/run_stage.py" \
  --repo "$f05_repo" --work "$f05_scratch/run" --mutations
```

执行前用 MANIFEST 的 files/production_sha256 对应字节计算 SHA-256 核对；版本不匹配时先审查，
不能把通过结果套用到别的版本。runner 还会固定校验原 F04 包后从中读取三个回归测试，
不在本包复制其测试内容。正常结果必须是 2 项 F05、3 项 F04，六个变异均被指定断言发现；
不能把编译失败、零用例、检测器故障或超时视为成功。

构建 -j2；F05 单个文件 16 MiB，F04 回归最多两个。IO watchdog 5 秒、测试进程上限 120 秒，
并非性能门槛。results.xml、f04-results.xml、commands.json、mutations.json、各日志是证据。
测试结束核验并压缩证据后删除自己的整个临时目录；本包没有二进制/镜像，也没有注册 CTest。

不验证 B 事务/WAL/分配恢复、真实帧、SQL/Raft E2E、裸设备、掉电、TSan 或性能。
