#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>

#include <algorithm>
#include <atomic>
#include <cerrno>
#include <chrono>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <iostream>
#include <limits>
#include <memory>
#include <stdexcept>
#include <string>
#include <system_error>
#include <vector>

#include "storage/disk/bootstrap_store.h"
#include "storage/disk/metadata_backend.h"
#include "gtest/gtest.h"

extern "C" int __real_fdatasync(int);
extern "C" int __real_statx(int, const char *, int, unsigned int,
                            struct statx *);
namespace {
std::atomic<size_t> successful_flushes{0};
std::atomic<bool> strengthen_alignment{false};
} // namespace
extern "C" int __wrap_fdatasync(int fd) {
  const auto result = __real_fdatasync(fd);
  if (result == 0) {
    ++successful_flushes;
  }
  return result;
}
extern "C" int __wrap_statx(int fd, const char *path, int flags,
                            unsigned int mask, struct statx *out) {
  const int result = __real_statx(fd, path, flags, mask, out);
  if (result == 0 && strengthen_alignment &&
      (out->stx_mask & STATX_DIOALIGN) != 0) {
    // Test-only stronger capability, not a claim about the real hardware.
    if (out->stx_dio_offset_align != 0 &&
        8192 % out->stx_dio_offset_align == 0) {
      out->stx_dio_offset_align = 8192;
    }
  }
  return result;
}

namespace bustub {
namespace {
using namespace std::chrono_literals;
constexpr uint64_t MIB = 1024 * 1024;
constexpr size_t CAPACITY = 16 * MIB;
constexpr size_t PAGE = 4096; // Independent oracle for the approved S2 format.
using Bytes = std::vector<unsigned char>;

auto Range(uint64_t offset, uint64_t size) -> StorageByteRange {
  auto result = StorageByteRange::Create(offset, size);
  if (!result) {
    throw std::invalid_argument("bad test layout");
  }
  return *result;
}

struct RawFile {
  int fd_{-1};
  std::string path_;
  explicit RawFile(unsigned seed) {
    const char *directory = std::getenv("F05_WORKDIR");
    if (directory == nullptr) {
      throw std::runtime_error("runner must set F05_WORKDIR");
    }
    std::string name = std::string(directory) + "/device-XXXXXX";
    fd_ = mkstemp(name.data());
    if (fd_ < 0) {
      throw std::system_error(errno, std::generic_category(), "mkstemp");
    }
    path_ = name;
    try {
      Bytes image(CAPACITY);
      for (size_t i = 0; i < image.size(); ++i) {
        image[i] = static_cast<unsigned char>(
            (i * 17 + (i / 131) * 7 + seed * 19) % 251);
      }
      std::fill_n(image.begin(), 65536, 0);
      std::fill_n(image.begin() + MIB, 65536, 0);
      size_t done = 0;
      while (done < image.size()) {
        const auto n = pwrite(fd_, image.data() + done, image.size() - done,
                              static_cast<off_t>(done));
        if (n < 0 && errno == EINTR) {
          continue;
        }
        if (n <= 0) {
          throw std::runtime_error("fixture write failed");
        }
        done += static_cast<size_t>(n);
      }
      if (__real_fdatasync(fd_) != 0) {
        throw std::system_error(errno, std::generic_category(), "fixture sync");
      }
    } catch (...) {
      close(fd_);
      unlink(path_.c_str());
      throw;
    }
  }
  ~RawFile() {
    close(fd_);
    unlink(path_.c_str());
  }
  auto ReadAll() const -> Bytes {
    if (std::filesystem::file_size(path_) != CAPACITY) {
      throw std::runtime_error("device size changed");
    }
    Bytes image(CAPACITY);
    size_t done = 0;
    while (done < image.size()) {
      const auto n = pread(fd_, image.data() + done, image.size() - done,
                           static_cast<off_t>(done));
      if (n < 0 && errno == EINTR) {
        continue;
      }
      if (n <= 0) {
        throw std::runtime_error("independent oracle read failed");
      }
      done += static_cast<size_t>(n);
    }
    return image;
  }
};

auto Payload(size_t size, unsigned seed) -> Bytes {
  Bytes result(size);
  for (size_t i = 0; i < size; ++i) {
    result[i] = static_cast<unsigned char>((i * 23 + seed * 41 + i / 19) % 253);
  }
  return result;
}

void Finish(IOExecutor &io, IOBatch &batch) {
  if (io.TrySubmit(batch) != IOAdmission::Accepted || !batch.WaitFor(5s)) {
    throw std::runtime_error("accepted IO did not complete within watchdog");
  }
}

struct Buffer {
  Bytes storage_;
  char *data_;
  explicit Buffer(size_t size, uint32_t alignment) {
    if (alignment == 0 || alignment > MIB) {
      throw std::runtime_error("fixture alignment exceeds resource budget");
    }
    storage_.resize(size + alignment - 1);
    const auto address = reinterpret_cast<uintptr_t>(storage_.data());
    data_ = reinterpret_cast<char *>(
        storage_.data() + (alignment - address % alignment) % alignment);
  }
};

auto Layout(uint64_t start, uint64_t length) -> BootstrapLayout {
  BootstrapLayout result{
      {},
      CAPACITY,
      {Range(start, length), Range(6 * MIB, MIB), Range(9 * MIB, 6 * MIB)}};
  result.identity_.storage_.fill(17);
  result.identity_.device_.fill(37);
  return result;
}

TEST(MetadataTest, PageSlotsPreserveOtherRegionsAndReopen) {
  ASSERT_EQ(static_cast<size_t>(BUSTUB_PAGE_SIZE),
            PAGE); // A format change requires review, not silent adaptation.
  for (unsigned variant : {0U, 1U}) {
    SCOPED_TRACE(variant);
    RawFile file(variant);
    const uint64_t start = (2 + variant) * MIB;
    const std::vector<page_id_t> pages{0, 2, 3};
    const std::vector<Bytes> payloads{Payload(PAGE, 11 + variant),
                                      Payload(PAGE, 23 + variant),
                                      Payload(PAGE, 37 + variant)};
    Bytes expected;
    BootstrapIdentity identity;
    {
      BlockDevice device(file.path_, BlockDeviceOptions{});
      const auto &info = device.Info();
      ASSERT_EQ(info.access_mode_, DeviceAccessMode::Direct);
      ASSERT_EQ(PAGE % info.offset_alignment_, 0U)
          << "real geometry incompatible with this format";
      std::cout << "real geometry: memory=" << info.memory_alignment_
                << " offset=" << info.offset_alignment_ << '\n';
      IOExecutor io(device, {2, 8, MIB}, MIB);
      BootstrapStore bootstrap(io);
      // Test both an exact region and a region with an unaddressable partial
      // tail.
      const auto tail = variant == 0 || info.offset_alignment_ == PAGE
                            ? 0
                            : info.offset_alignment_;
      const auto layout = Layout(start, 4 * PAGE + tail);
      identity = layout.identity_;
      bootstrap.Create(layout);
      bootstrap.Open(identity);
      RegionManager regions(bootstrap);
      const auto desc = regions.Describe(regions.Region(RegionKind::Metadata));
      EXPECT_EQ(desc.size_, 4 * PAGE + tail);
      EXPECT_EQ(desc.memory_alignment_, info.memory_alignment_);
      EXPECT_EQ(desc.offset_alignment_, info.offset_alignment_);
      MetadataBackend backend(regions);
      ASSERT_EQ(backend.PageCapacity(), 4U);
      expected = file.ReadAll();
      for (size_t i = 0; i < pages.size(); ++i) {
        std::copy(payloads[i].begin(), payloads[i].end(),
                  expected.begin() + start + pages[i] * PAGE);
      }
      successful_flushes = 0;
      {
        auto prep = backend.TryPrepare(
            {{0, IOOperation::Write}, {3, IOOperation::Write}}, true);
        ASSERT_EQ(prep.admission_, IOAdmission::Accepted);
        std::memcpy(prep.batch_->Buffer(0), payloads[0].data(), PAGE);
        std::memcpy(prep.batch_->Buffer(1), payloads[2].data(), PAGE);
        Finish(io, *prep.batch_);
        ASSERT_EQ(prep.batch_->Phase(), IOBatchPhase::Succeeded);
        EXPECT_TRUE(prep.batch_->Result().writes_durable_);
        EXPECT_GT(successful_flushes.load(), 0U);
      }
      auto buffer = std::make_shared<Buffer>(PAGE, info.memory_alignment_);
      auto releases = std::make_shared<std::atomic<unsigned>>(0);
      std::memcpy(buffer->data_, payloads[1].data(), PAGE);
      std::vector<IOBufferLease> leases;
      leases.push_back(IOBufferLease::ForWrite(
          buffer->data_, PAGE, [buffer, releases] { ++*releases; }));
      successful_flushes = 0;
      {
        auto prep =
            backend.TryPrepareExternal({{2, IOOperation::Write}}, leases, true);
        ASSERT_EQ(prep.admission_, IOAdmission::Accepted);
        EXPECT_TRUE(leases.empty());
        Finish(io, *prep.batch_);
        ASSERT_EQ(prep.batch_->Phase(), IOBatchPhase::Succeeded);
        EXPECT_TRUE(prep.batch_->Result().writes_durable_);
        EXPECT_GT(successful_flushes.load(), 0U);
        EXPECT_EQ(releases->load(), 1U);
      }
      EXPECT_EQ(
          file.ReadAll(),
          expected); // Includes every other region, slot, gap, and the tail.
      std::memset(buffer->data_, 0, PAGE);
      leases.push_back(IOBufferLease::ForRead(
          buffer->data_, PAGE, [buffer, releases] { ++*releases; }));
      {
        auto prep =
            backend.TryPrepareExternal({{2, IOOperation::Read}}, leases, false);
        ASSERT_EQ(prep.admission_, IOAdmission::Accepted);
        Finish(io, *prep.batch_);
        ASSERT_EQ(prep.batch_->Phase(), IOBatchPhase::Succeeded);
        EXPECT_FALSE(prep.batch_->Result().writes_durable_);
        EXPECT_EQ(releases->load(), 2U);
        EXPECT_EQ(std::memcmp(buffer->data_, payloads[1].data(), PAGE), 0);
      }
    } // Drain and close the actual IO executor and device before reopening.
    {
      BlockDevice device(file.path_, BlockDeviceOptions{});
      IOExecutor io(device, {2, 8, MIB}, MIB);
      BootstrapStore bootstrap(io);
      bootstrap.Open(identity);
      RegionManager regions(bootstrap);
      MetadataBackend backend(regions);
      std::vector<MetadataPageRequest> reads;
      for (auto page : pages) {
        reads.push_back({page, IOOperation::Read});
      }
      auto prep = backend.TryPrepare(reads, false);
      ASSERT_EQ(prep.admission_, IOAdmission::Accepted);
      for (size_t i = 0; i < pages.size(); ++i) {
        std::memset(prep.batch_->Buffer(i), 0, PAGE);
      }
      Finish(io, *prep.batch_);
      ASSERT_EQ(prep.batch_->Phase(), IOBatchPhase::Succeeded);
      for (size_t i = 0; i < pages.size(); ++i) {
        EXPECT_EQ(std::memcmp(prep.batch_->Buffer(i), payloads[i].data(), PAGE),
                  0);
      }
      EXPECT_EQ(file.ReadAll(), expected);
    }
  }
}

TEST(MetadataTest, InvalidPagesAndGeometryRejectBeforeIO) {
  {
    RawFile file(7);
    BlockDevice device(file.path_, BlockDeviceOptions{});
    ASSERT_EQ(PAGE % device.Info().offset_alignment_, 0U);
    IOExecutor io(device, {2, 8, MIB}, MIB);
    BootstrapStore bootstrap(io);
    auto layout = Layout(2 * MIB, 4 * PAGE);
    bootstrap.Create(layout);
    bootstrap.Open(layout.identity_);
    RegionManager regions(bootstrap);
    RegionManager other(bootstrap);
    EXPECT_THROW(regions.Describe(other.Region(RegionKind::Metadata)),
                 std::invalid_argument);
    MetadataBackend backend(regions);
    const auto before = file.ReadAll();
    auto buffer =
        std::make_shared<Buffer>(PAGE, device.Info().memory_alignment_);
    auto releases = std::make_shared<std::atomic<unsigned>>(0);
    std::vector<IOBufferLease> leases;
    // Two immutable write permissions may share RAM; device ranges do not
    // overlap.
    for (unsigned i = 0; i < 2; ++i) {
      leases.push_back(IOBufferLease::ForWrite(
          buffer->data_, PAGE, [buffer, releases] { ++*releases; }));
    }
    for (page_id_t invalid :
         {-1, -2, 4, std::numeric_limits<page_id_t>::max()}) {
      SCOPED_TRACE(invalid);
      const std::vector<MetadataPageRequest> requests{
          {1, IOOperation::Write}, {invalid, IOOperation::Write}};
      EXPECT_THROW(backend.TryPrepare(requests, true), std::invalid_argument);
      EXPECT_THROW(backend.TryPrepareExternal(requests, leases, true),
                   std::invalid_argument);
      EXPECT_EQ(leases.size(), 2U);
      EXPECT_EQ(releases->load(), 0U);
    }
    EXPECT_EQ(file.ReadAll(), before);
    auto good = backend.TryPrepareExternal(
        {{1, IOOperation::Write}, {2, IOOperation::Write}}, leases, true);
    ASSERT_EQ(good.admission_, IOAdmission::Accepted);
    EXPECT_TRUE(leases.empty());
    // This prepared-only batch does no IO and returns both permissions on
    // destruction.
    good.batch_.reset();
    EXPECT_EQ(releases->load(), 2U);
    EXPECT_EQ(file.ReadAll(), before);
  }
  {
    RawFile file(8);
    BlockDevice device(file.path_, BlockDeviceOptions{});
    const auto alignment = device.Info().offset_alignment_;
    if (alignment < PAGE) { // A nonempty sub-page F03 region is only possible
                            // on this geometry.
      IOExecutor io(device, {2, 8, MIB}, MIB);
      BootstrapStore bootstrap(io);
      auto layout = Layout(2 * MIB, alignment);
      bootstrap.Create(layout);
      bootstrap.Open(layout.identity_);
      RegionManager regions(bootstrap);
      const auto before = file.ReadAll();
      EXPECT_THROW({ MetadataBackend invalid(regions); },
                   std::invalid_argument);
      EXPECT_EQ(file.ReadAll(), before);
    } else {
      std::cout << "sub-page region is not representable on real geometry\n";
    }
  }
  {
    struct StrongerGeometry {
      StrongerGeometry() { strengthen_alignment = true; }
      ~StrongerGeometry() { strengthen_alignment = false; }
    } injected;
    RawFile file(9);
    BlockDevice device(file.path_, BlockDeviceOptions{});
    ASSERT_EQ(device.Info().offset_alignment_, 8192U)
        << "capability injection prerequisite unmet";
    IOExecutor io(device, {2, 8, MIB}, MIB);
    BootstrapStore bootstrap(io);
    auto layout = Layout(2 * MIB, 8 * PAGE);
    bootstrap.Create(layout);
    bootstrap.Open(layout.identity_);
    RegionManager regions(bootstrap);
    EXPECT_EQ(regions.Describe(regions.Region(RegionKind::Metadata))
                  .offset_alignment_,
              8192U);
    const auto before = file.ReadAll();
    EXPECT_THROW({ MetadataBackend invalid(regions); }, std::invalid_argument);
    EXPECT_EQ(file.ReadAll(), before);
  }
}
} // namespace
} // namespace bustub
