"""Opt-in F05 component checks; keep expanded sources outside the regular test tree."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tarfile
import time
import xml.etree.ElementTree as ET

TESTS = {'PageSlotsPreserveOtherRegionsAndReopen', 'InvalidPagesAndGeometryRejectBeforeIO'}
F04_TESTS = {'RegionsUseIndependentPhysicalOraclesAcrossLayouts',
             'InvalidBindingOrMemberRejectsTheWholePreparation',
             'F02AdmissionLeasesAndDeviceFailuresKeepTheirMeaning'}
F04_SHA = 'e5447784ea1cc0a985bae3bcb5e7a361ff75f4f6bc828c2376ff8e9d8adbe6d6'


def check_xml(path, suite, names):
    x = ET.parse(path).getroot()
    cases = x.findall('./testsuite/testcase')
    if (len(cases) != len(names)
        or {(c.get('classname'), c.get('name')) for c in cases} != {(suite, n) for n in names}
        or any(x.get(k) != '0' for k in ('errors', 'failures', 'disabled'))
        or any(c.get('status') != 'run' or c.get('result') != 'completed'
               or any(c.find(t) is not None for t in ('failure', 'error', 'skipped')) for c in cases)):
        raise RuntimeError(f'{suite}: incomplete or failed run')


parser = argparse.ArgumentParser()
parser.add_argument('--repo', type=Path, required=True)
parser.add_argument('--work', type=Path, required=True)
parser.add_argument('--mutations', action='store_true')
args = parser.parse_args()
repo, work = args.repo.resolve(), args.work.resolve()
if work == repo or repo in work.parents:
    raise RuntimeError('use an isolated work directory outside the repository')
work.mkdir(parents=True, exist_ok=True)
source = Path(__file__).with_name('metadata_backend_test.cpp')
build = work / 'build'
commands = []
env = {k: v for k, v in os.environ.items() if not k.startswith('GTEST_')}
env.update(ASAN_OPTIONS='detect_leaks=1:halt_on_error=1', UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1',
           F05_WORKDIR=str(work), F04_WORKDIR=str(work))
(work / 'environment.json').write_text(json.dumps({k: env[k] for k in
    ('ASAN_OPTIONS', 'UBSAN_OPTIONS', 'F05_WORKDIR', 'F04_WORKDIR')}, indent=2)+'\n')


def call(argv, log, expected=0, timeout=180):
    start = time.monotonic()
    entry = {'command': argv, 'log': log}
    commands.append(entry)
    try:
        with (work/log).open('w') as f:
            result = subprocess.run(argv, cwd=repo, env=env, stdout=f, stderr=subprocess.STDOUT, timeout=timeout)
        entry['returncode'] = result.returncode
        if expected is not None and result.returncode != expected:
            raise RuntimeError(f'{log}: exit {result.returncode}; expected {expected}')
        return result.returncode
    except subprocess.TimeoutExpired:
        entry['timeout_seconds'] = timeout
        raise
    finally:
        entry['elapsed_seconds'] = time.monotonic()-start
        (work/'commands.json').write_text(json.dumps(commands, indent=2)+'\n')


call(['cmake', '-S', str(repo), '-B', str(build), '-DCMAKE_BUILD_TYPE=Debug', '-DCMAKE_C_COMPILER=clang-14',
      '-DCMAKE_CXX_COMPILER=clang++-14', '-DBUSTUB_SANITIZER=address,undefined',
      '-DCMAKE_EXE_LINKER_FLAGS=-no-pie'], 'configure.log')
call(['cmake', '--build', str(build), '--target', 'bustub_storage_disk', 'gtest_main', '-j2'], 'build.log')
flags = ['clang++-14', '-std=c++17', '-Wall', '-Wextra', '-Werror', '-Wno-unused-parameter', '-pthread', '-g', '-O0',
         '-fsanitize=address,undefined', '-fno-omit-frame-pointer', '-I'+str(repo/'src/include'),
         '-I'+str(repo/'third_party/googletest/googletest/include')]
objects = build/'src/storage/disk/CMakeFiles/bustub_storage_disk.dir'
codec = work/'byte-codec.o'
call(flags+['-c', str(repo/'src/common/byte_codec.cpp'), '-o', str(codec)], 'codec-compile.log')
common = [str(objects/'block_device.cpp.o'), str(objects/'io_executor.cpp.o'), str(objects/'bootstrap_store.cpp.o'),
          str(codec), str(build/'lib/libgtest_main.a'), str(build/'lib/libgtest.a'), '-Wl,--wrap=fdatasync']
test_obj = work/'stage-test.o'
call(flags+['-c', str(source), '-o', str(test_obj)], 'test-compile.log')
region_obj = objects/'region_manager.cpp.o'
metadata_obj = objects/'metadata_backend.cpp.o'


def link(exe, metadata, region):
    call(flags+['-no-pie', str(metadata), str(region), str(test_obj)]+common+
         ['-Wl,--wrap=statx', '-o', str(exe)], exe.name+'-link.log')


binary = work/'stage-test'
link(binary, metadata_obj, region_obj)
xml = work/'results.xml'
xml.unlink(missing_ok=True)
call([str(binary), '--gtest_filter=MetadataTest.*', '--gtest_repeat=1', '--gtest_shuffle=0',
      '--gtest_output=xml:'+str(xml)], 'run.log', timeout=120)
check_xml(xml, 'MetadataTest', TESTS)
print('F05: 2/2 real component checks passed', flush=True)

# Reuse original F04 content without copying its suite into this module's source archive.
archive = repo/'test/archives/F04-region-manager.tar.gz'
if hashlib.sha256(archive.read_bytes()).hexdigest() != F04_SHA:
    raise RuntimeError('F04 dependency changed; review regression content before running')
with tarfile.open(archive) as t:
    f04_content = t.extractfile('F04-region-manager/test/storage_redesign/region_manager_test.cpp').read()
f04_source = work/'f04-regression.cpp'
f04_source.write_bytes(f04_content)
f04_obj = work/'f04-regression.o'
call(flags+['-c', str(f04_source), '-o', str(f04_obj)], 'f04-compile.log')
f04_exe = work/'f04-regression'
call(flags+['-no-pie', str(region_obj), str(f04_obj)]+common+
     ['-Wl,--wrap=pwrite', '-o', str(f04_exe)], 'f04-link.log')
f04_xml = work/'f04-results.xml'
f04_xml.unlink(missing_ok=True)
call([str(f04_exe), '--gtest_filter=RegionTest.*', '--gtest_repeat=1', '--gtest_shuffle=0',
      '--gtest_output=xml:'+str(f04_xml)], 'f04-run.log', timeout=120)
check_xml(f04_xml, 'RegionTest', F04_TESTS)
print('F04: 3/3 unchanged archived regression checks passed', flush=True)

if args.mutations:
    originals = {name: (repo/'src/storage/disk'/f'{name}.cpp').read_text()
                 for name in ('metadata_backend', 'region_manager')}
    mutations = []

    def add(name, old, new, test, component='metadata_backend'):
        s = originals[component]
        if s.count(old) != 1:
            raise RuntimeError(name+': source drift')
        mutations.append((name, s.replace(old, new), test, component))

    add('wrong_page_slot', 'static_cast<uint64_t>(request.page_id_) * BUSTUB_PAGE_SIZE',
        'static_cast<uint64_t>(request.page_id_ ^ 1) * BUSTUB_PAGE_SIZE', 'PageSlotsPreserveOtherRegionsAndReopen')
    # Rounding up is indistinguishable from floor when IO alignment equals PAGE.
    # An extra addressable page is observable on both exact and partial regions.
    add('extra_page_capacity', 'info.size_ / BUSTUB_PAGE_SIZE',
        '(info.size_ / BUSTUB_PAGE_SIZE + 1)', 'PageSlotsPreserveOtherRegionsAndReopen')
    add('drop_owned_flush', 'TryPrepare(Resolve(requests), flush_after_writes)',
        'TryPrepare(Resolve(requests), false && flush_after_writes)', 'PageSlotsPreserveOtherRegionsAndReopen')
    add('drop_external_flush', 'TryPrepareExternal(Resolve(requests), leases, flush_after_writes)',
        'TryPrepareExternal(Resolve(requests), leases, false && flush_after_writes)',
        'PageSlotsPreserveOtherRegionsAndReopen')
    add('ignore_geometry', ' || BUSTUB_PAGE_SIZE % info.offset_alignment_ != 0', '',
        'InvalidPagesAndGeometryRejectBeforeIO')
    add('ignore_binding', 'if (region.context_ != context_)', 'if (false && region.context_ != context_)',
        'InvalidPagesAndGeometryRejectBeforeIO', 'region_manager')
    results = []
    for name, content, test, component in mutations:
        cpp, obj, exe = work/(name+'.cpp'), work/(name+'.o'), work/name
        cpp.write_text(content)
        call(flags+['-c', str(cpp), '-o', str(obj)], name+'-compile.log')
        link(exe, obj if component == 'metadata_backend' else metadata_obj,
             obj if component == 'region_manager' else region_obj)
        rc = call([str(exe), '--gtest_filter=MetadataTest.'+test], name+'-run.log', expected=None, timeout=120)
        log = (work/(name+'-run.log')).read_text()
        caught = (rc == 1 and '[  FAILED  ] MetadataTest.'+test in log and
                  not any(x in log for x in ('AddressSanitizer:', 'LeakSanitizer:', 'runtime error:')))
        results.append({'mutation': name, 'test': test, 'returncode': rc, 'caught': caught,
                        'source_sha256': hashlib.sha256(content.encode()).hexdigest()})
        (work/'mutations.json').write_text(json.dumps(results, indent=2)+'\n')
        if not caught:
            raise RuntimeError(name+': not an intended assertion detection; inspect evidence')
    print('F05: 6/6 isolated mutations caught; inspect each failure assertion', flush=True)
