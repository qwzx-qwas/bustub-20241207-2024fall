# F12 测试恢复说明

仅开发期组件集成源码，禁止直接恢复成常驻测试。主线仍为共同 C/P。

1. 校验仓库 test/archives/SHA256SUMS 及结果目录 SHA256SUMS。
2. 使用精确匹配 MANIFEST.production_sha256 的仓库。历史恢复可在仓库外检出基准 3e852f5，覆盖结果包 source/ 的五份生产源码，然后核对哈希；基准本身没有 F12。
3. 需要原 S5-journal-recycling.tar.gz 与 F34-node-lifecycle.tar.gz（哈希见 MANIFEST）。保留原包；runner 直接使用其 fixture/测试，不调用旧包的旧生产哈希检查冒充兼容。
4. Linux、Clang 14、GCC、CMake、Python 3.12+（tar filter）、项目已带的 GTest/fmt。真实 O_DIRECT 文件必须受支持；夹具实时获取偏移对齐，以 lcm(4096,设备对齐) 为测试单位，超出夹具预算直接报错，不回退 Buffered。

在仓库外解包后执行：

```bash
python3 /tmp/F12-data-allocator/tests/run_stage.py --repo /absolute/repo --work /tmp/f12-isolated-run --mutations
```

work 必须位于仓库外。runner 构建 Debug/ASan/UBSan，执行六项 F12、五项 F34、八项 S5（含原旧生产镜像），再对十个指定错误分别编译/运行。只有指定断言失败才算检测；编译错误/崩溃/超时不算。比较 XML 和 mutations.json，不只看 summary.json。测试同进程串行，独立文件；IO 门通过条件变量，10 秒握手和运行时限仅作卡死诊断，不作性能要求。

内存/磁盘：构建 -j3，临时构建及测试约 1 GiB 文件；每场景 8 MiB 镜像，Data 区 2 MiB。每个并发申请只保留范围；测试不是压力基准。完成后核验并压缩结果，删除临时 build/镜像/展开测试。仅最终本模块包需要保留。

范围：真实 F12/B/Journal/F04/F02/F01 Direct 文件，不是完整对象存储、F13/F14 自动回收、SQL/Raft E2E、裸设备或物理掉电。隔离/EIO 包装只在测试链接，不改 production。后续模块沿场景与独立 oracle 接管，不复制同义测试。

2026-09-30 复审：生产不变，碎片场景使用实际对齐允许的较大分配粒度，隔离场景新增 pre-IO 冲突回滚判据；旧 F12 包原位替换，不复用旧 XML 冒充本轮运行。
