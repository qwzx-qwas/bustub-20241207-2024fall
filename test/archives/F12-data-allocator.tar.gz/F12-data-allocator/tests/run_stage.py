#!/usr/bin/env python3
"""F12 component contracts; reuses archived S5/F34 without copying their tests."""
import argparse, hashlib, json, os, pathlib, subprocess, tarfile, time
import xml.etree.ElementTree as ET
p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--work',required=True);p.add_argument('--mutations',action='store_true');a=p.parse_args()
repo=pathlib.Path(a.repo).resolve();work=pathlib.Path(a.work).resolve();src=pathlib.Path(__file__).resolve().parent
assert repo!=work and repo not in work.parents,'work must be outside repository'
work.mkdir(parents=True,exist_ok=True)
manifest=src.parent/'MANIFEST.json'
if manifest.exists():
 m=json.loads(manifest.read_text())
 for field in ('production_sha256','dependency_sha256'):
  for name,h in m[field].items():assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==h,('source drift',name)
env={k:v for k,v in os.environ.items() if not k.startswith('GTEST_')};env.update(S5_WORKDIR=str(work),ASAN_OPTIONS='detect_leaks=1:abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1')
commands=[]
def run(cmd,log,expected=0,timeout=900):
 cmd=list(map(str,cmd));start=time.monotonic()
 with (work/log).open('w') as out:r=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT,env=env,cwd=repo,timeout=timeout)
 commands.append({'command':cmd,'log':log,'seconds':time.monotonic()-start,'exit':r.returncode})
 (work/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 assert r.returncode==expected,(log,r.returncode,expected)
run(['cmake','-S',repo,'-B',work/'build','-DCMAKE_BUILD_TYPE=Debug','-DCMAKE_C_COMPILER=clang-14','-DCMAKE_CXX_COMPILER=clang++-14','-DBUSTUB_SANITIZER=address,undefined','-DCMAKE_EXE_LINKER_FLAGS=-no-pie'],'configure.log')
run(['cmake','--build',work/'build','--target','bustub','gtest_main','-j3'],'build.log')
for name in ['S5-journal-recycling','F34-node-lifecycle']:
 with tarfile.open(repo/('test/archives/'+name+'.tar.gz')) as t:t.extractall(work,filter='data')
dep=work/'S5-journal-recycling/test/storage_redesign'
flags=['clang++-14','-std=c++17','-g','-O0','-Wall','-Wextra','-Werror','-Wno-unused-parameter','-pthread','-fsanitize=address,undefined','-fno-omit-frame-pointer','-I'+str(repo/'src/include'),'-I'+str(repo/'third_party/fmt/include'),'-I'+str(repo/'third_party/googletest/googletest/include'),'-I'+str(dep)]
libs=[work/'build/lib'/('lib'+name+'.a') for name in ['bustub','fmtd','gtest_main','gtest']]
wraps=['-Wl,--wrap=pwrite','-Wl,--wrap=fdatasync']
run(flags+['-c',src/'allocator_test.cpp','-o',work/'allocator-test.o'],'compile.log')
run(flags+['-no-pie',work/'allocator-test.o']+libs+wraps+['-o',work/'allocator_test'],'link.log')
run([work/'allocator_test','--gtest_output=xml:'+str(work/'allocator.xml')],'run.log',timeout=120)
# Private B geometry access must not change its existing recovery/lifecycle contracts.
run(flags+['-no-pie',work/'F34-node-lifecycle/tests/lifecycle_test.cpp']+libs+wraps+['-Wl,--wrap=pread','-Wl,--wrap=close','-o',work/'lifecycle_test'],'f34-compile.log')
run([work/'lifecycle_test','--gtest_output=xml:'+str(work/'lifecycle.xml')],'f34-run.log',timeout=120)
run(['python3',dep/'build_checks.py',repo,work],'s5-regression.log',timeout=180)
for name,n in [('allocator.xml',6),('lifecycle.xml',5),('s5.xml',8)]:
 cases=ET.parse(work/name).getroot().findall('./testsuite/testcase')
 assert len(cases)==n and all(c.get('result')=='completed' and not any(c.find(k) is not None for k in ('failure','error','skipped')) for c in cases),name
mutations=[
 ('leak_rejected_quarantine','auto result = metadata_.Commit(base, mutations);','auto result = [&] { try { return metadata_.Commit(base, mutations); } catch (...) { fence.armed_ = false; throw; } }();','QuarantineCommitExcludesConcurrentReservation','rejected quarantine must release its temporary reservation'),
 ('leak_failed_search','if (selected < need) {','if (selected < need) { c.Change(&c.reserved_, state->ranges_, true);','HierarchicalSearchFragmentationAndBudgets','failed search must not reserve partial result'),
 ('ignore_live_reservations','committed_[word] | reserved_[word] | quarantine_[word]','committed_[word] | quarantine_[word]','ReservationLeaseAndConcurrentOwnership','lease must retain cancelled space through IO'),
 ('lose_recovered_allocation','target[index] = words[i];','target[index] = row.key_.owner_ == COMMITTED ? 0 : words[i];','AtomicAllocationReleaseAndRecovery','recover all committed and quarantined units'),
 ('drop_companion_metadata','std::vector<MetadataMutation> mutations = related;','std::vector<MetadataMutation> mutations;','AtomicAllocationReleaseAndRecovery','r.b.Read().Get(kx)'),
 ('refresh_stale_base','auto result = metadata_.Commit(base, mutations);','auto result = metadata_.Commit(metadata_.Read(), mutations);','AtomicAllocationReleaseAndRecovery','stale companion snapshot accepted'),
 ('lose_other_bits','auto words = value ? DecodeWords(*value, c.options_.bitmap_record_bytes_) : Words(per_record);','auto words = Words(per_record);','AtomicAllocationReleaseAndRecovery','recover all committed and quarantined units'),
 ('remove_quarantine_fence','if (owner == QUARANTINE) {','if (false && owner == QUARANTINE) {','QuarantineCommitExcludesConcurrentReservation','quarantine must exclude range before B IO'),
 ('continue_after_uncertain_commit','c.ready_ = false;','// mutation: keep accepting after uncertain commit','CommitFailureBlocksReuseAndRecoversAtomically','uncertain commit must stop allocator'),
 ('reinterpret_geometry','if (*descriptor != Descriptor(c)) {','if (false && *descriptor != Descriptor(c)) {','OpenNeverFormatsAndChecksGeometry','different unit geometry cannot reinterpret bitmap'),
]
evidence=[]
if a.mutations:
 for name,old,new,test,marker in mutations:
  code=(repo/'src/storage/disk/data_allocator.cpp').read_text();assert code.count(old)==1,(name,old)
  cpp=work/(name+'.cpp');cpp.write_text(code.replace(old,new));obj=work/(name+'.o');exe=work/name
  run(flags+['-c',cpp,'-o',obj],name+'-compile.log',timeout=120)
  run(flags+['-no-pie',work/'allocator-test.o',obj]+libs+wraps+['-o',exe],name+'-link.log',timeout=120)
  run([exe,'--gtest_filter=F12Allocator.'+test,'--gtest_output=xml:'+str(work/(name+'.xml'))],name+'-run.log',expected=1,timeout=120)
  failures=[f.text or '' for f in ET.parse(work/(name+'.xml')).getroot().iter('failure')]
  assert any(marker in f for f in failures),(name,failures)
  evidence.append({'mutation':name,'old':old,'new':new,'test':test,'expected_marker':marker,'failures':failures})
  (work/'mutations.json').write_text(json.dumps(evidence,indent=2)+'\n');print(name+': detected by specified oracle',flush=True)
(work/'summary.json').write_text(json.dumps({'passed':{'allocator.xml':6,'lifecycle.xml':5,'s5.xml':8},'mutations_detected':len(evidence),'scope':'F12 with real B/Journal/Direct file. No F13/F14/GC, business E2E, raw device, physical power loss or performance claim.'},indent=2)+'\n')
print('F12 6 + F34 5 + S5 8 passed; mutations '+str(len(evidence)),flush=True)
