#include "fixture.h"
#include "storage/disk/data_allocator.h"
#include "storage/disk/region_manager.h"
#include "gtest/gtest.h"
#include <chrono>
#include <condition_variable>
#include <cstring>
#include <future>
#include <mutex>
#include <optional>
#include <set>
using namespace std::chrono_literals;
extern "C" ssize_t __real_pwrite(int, const void *, size_t, off_t);
extern "C" int __real_fdatasync(int);
namespace {
enum class Point { None, DataWrite, JournalFlush };
std::mutex gate_mutex;
std::condition_variable gate_cv;
Point point = Point::None;
bool entered = false, released = true, inject = false;
int flush_fd = -1;
void Arm(Point p, bool fail = false) {
  std::lock_guard<std::mutex> lock(gate_mutex);
  point = p;
  entered = false;
  released = false;
  inject = fail;
  flush_fd = -1;
}
void ReleaseGate() {
  std::lock_guard<std::mutex> lock(gate_mutex);
  released = true;
  point = Point::None;
  flush_fd = -1;
  gate_cv.notify_all();
}
struct ReleaseOnExit {
  ~ReleaseOnExit() { ReleaseGate(); }
};
bool WaitEntered() {
  std::unique_lock<std::mutex> lock(gate_mutex);
  return gate_cv.wait_for(lock, 10s, [] { return entered; });
}
bool Pause(std::unique_lock<std::mutex> &lock) {
  entered = true;
  point = Point::None;
  gate_cv.notify_all();
  gate_cv.wait(lock, [] { return released; });
  return inject;
}
} // namespace
extern "C" ssize_t __wrap_pwrite(int fd, const void *buf, size_t n, off_t off) {
  if ((fcntl(fd, F_GETFL) & O_DIRECT) != 0) {
    std::unique_lock<std::mutex> lock(gate_mutex);
    if (point == Point::DataWrite && off >= static_cast<off_t>(6 * s5::MIB)) {
      if (Pause(lock)) {
        errno = EIO;
        return -1;
      }
    }
    if (point == Point::JournalFlush &&
        off > static_cast<off_t>(s5::JOURNAL_START) &&
        off < static_cast<off_t>(6 * s5::MIB))
      flush_fd = fd;
  }
  return __real_pwrite(fd, buf, n, off);
}
extern "C" int __wrap_fdatasync(int fd) {
  {
    std::unique_lock<std::mutex> lock(gate_mutex);
    if (fd == flush_fd) {
      flush_fd = -1;
      if (Pause(lock)) {
        errno = EIO;
        return -1;
      }
    }
  }
  return __real_fdatasync(fd);
}
namespace {
using namespace s5;
using namespace bustub;
struct Rig {
  Stack stack;
  MetadataEngine b;
  RegionManager regions;
  RegionHandle data;
  DataAllocatorOptions opts;
  Rig(const Image &image, bool create, uint64_t multiplier = 1)
      : stack(image.path, create),
        b(stack.boot, stack.jid, stack.journal, stack.metadata),
        regions(stack.boot), data(regions.Region(RegionKind::Data)),
        opts{multiplier * std::lcm<uint64_t>(
                              4096, stack.device.Info().offset_alignment_),
             64,
             MIB,
             2 * MIB,
             8,
             1024,
             4096} {
    if (create)
      b.Create();
    else
      b.Open();
  }
  auto Size() const -> uint64_t { return regions.Describe(data).size_; }
  auto Usable() const -> uint64_t {
    return Size() / opts.allocation_bytes_ * opts.allocation_bytes_;
  }
  auto Write(uint64_t off, const Bytes &bytes) -> IOBatch {
    auto p = regions.TryPrepare({{data, IOOperation::Write, off, bytes.size()}},
                                true);
    Require(p.batch_.has_value(), "data IO prepare");
    auto batch = std::move(*p.batch_);
    std::memcpy(batch.Buffer(0), bytes.data(), bytes.size());
    Require(stack.io.TrySubmit(batch) == IOAdmission::Accepted,
            "data IO submit");
    return batch;
  }
};
void Durable(const JournalResult &r) {
  ASSERT_EQ(r.outcome_, JournalOutcome::Durable);
  ASSERT_FALSE(r.error_);
}
template <class F>
void AllocationFails(F f, AllocationErrorCode code, const char *why) {
  try {
    f();
    ADD_FAILURE() << why;
  } catch (const AllocationError &e) {
    EXPECT_EQ(e.Code(), code) << why;
  }
}
auto Units(const std::vector<StorageByteRange> &ranges, uint64_t a)
    -> std::set<uint64_t> {
  std::set<uint64_t> result;
  for (const auto &r : ranges) {
    EXPECT_EQ(r.Offset() % a, 0U);
    EXPECT_EQ(r.Size() % a, 0U);
    for (uint64_t u = r.Offset() / a; u < (r.Offset() + r.Size()) / a; ++u)
      EXPECT_TRUE(result.insert(u).second) << "returned extents overlap";
  }
  return result;
}
void ExpectBytes(const Image &image, uint64_t off, const Bytes &bytes) {
  auto raw = image.Read(6 * MIB + off, bytes.size());
  ASSERT_EQ(raw.size(), bytes.size());
  for (size_t i = 0; i < bytes.size(); ++i)
    ASSERT_EQ(raw[i], std::to_integer<uint8_t>(bytes[i])) << i;
}

TEST(F12Allocator, ReservationLeaseAndConcurrentOwnership) {
  Image image;
  Rig r(image, true);
  DataAllocator a(r.b, r.opts);
  Durable(a.Create());
  auto unit = r.opts.allocation_bytes_;
  std::optional<DataReservation> owner(a.Reserve(r.Usable()));
  std::optional<DataAllocationLease> lease(owner->Lease());
  const auto bytes = Value(unit, 97);
  Arm(Point::DataWrite);
  auto batch = r.Write(owner->Extents().front().Offset(), bytes);
  ReleaseOnExit cleanup;
  ASSERT_TRUE(WaitEntered());
  owner.reset();
  AllocationFails([&] { a.Reserve(unit); }, AllocationErrorCode::NoSpace,
                  "lease must retain cancelled space through IO");
  ReleaseGate();
  batch.Wait();
  ASSERT_EQ(batch.Phase(), IOBatchPhase::Succeeded);
  ExpectBytes(image, 0, bytes);
  lease.reset();
  // Concurrent callers retain all returned reservations until uniqueness is
  // checked.
  std::vector<std::future<DataReservation>> jobs;
  for (size_t i = 0; i < 32; ++i)
    jobs.push_back(
        std::async(std::launch::async, [&] { return a.Reserve(unit); }));
  std::set<uint64_t> occupied;
  std::vector<DataReservation> reservations;
  for (auto &job : jobs) {
    reservations.push_back(job.get());
    auto units = Units(reservations.back().Extents(), unit);
    ASSERT_EQ(units.size(), 1U);
    EXPECT_TRUE(occupied.insert(*units.begin()).second)
        << "concurrent reservations overlap";
  }
  reservations.clear();
  auto all = a.Reserve(r.Usable());
  EXPECT_EQ(Units(all.Extents(), unit).size(), r.Usable() / unit)
      << "cancel must return entire capacity";
  a.Close();
  AllocationFails([&] { a.Reserve(unit); }, AllocationErrorCode::NotReady,
                  "closed allocator cannot admit");
}

TEST(F12Allocator, HierarchicalSearchFragmentationAndBudgets) {
  Image image;
  Rig r(image, true);
  // Exercise a larger allocation geometry where the real device permits it.
  // This is a test allocation policy, not a fake device alignment capability.
  if ((16 * 1024) % r.opts.allocation_bytes_ == 0)
    r.opts.allocation_bytes_ = 16 * 1024;
  const auto u = r.opts.allocation_bytes_;
  Require(r.Usable() / u >= 66, "fixture needs units 0 through 65");
  {
    DataAllocator a(r.b, r.opts);
    Durable(a.Create());
    Durable(a.SetQuarantine(r.b.Read(), {Range(0, r.Usable())}, true));
    // Early small holes must not hide a later contiguous run crossing unit
    // 63/64.
    Durable(a.SetQuarantine(
        r.b.Read(), {Range(3 * u, u), Range(8 * u, u), Range(62 * u, 4 * u)},
        false));
    auto contiguous = a.Reserve(4 * u);
    ASSERT_EQ(contiguous.Extents().size(), 1U);
    EXPECT_EQ(contiguous.Extents()[0].Offset(), 62 * u)
        << "prefer cross-word contiguous run";
  }
  {
    auto limited = r.opts;
    limited.max_extents_ = 1;
    DataAllocator a(r.b, limited);
    a.Open();
    auto hold = a.Reserve(4 * u);
    AllocationFails([&] { a.Reserve(2 * u); },
                    AllocationErrorCode::ResourceUnavailable,
                    "fragment budget is not physical exhaustion");
    auto one = a.Reserve(u);
    std::optional<DataReservation> two;
    ASSERT_NO_THROW(two.emplace(a.Reserve(u)))
        << "failed search must not reserve partial result";
    auto returned = Units(one.Extents(), u);
    const auto other = Units(two->Extents(), u);
    returned.insert(other.begin(), other.end());
    EXPECT_EQ(returned, (std::set<uint64_t>{3, 8}))
        << "failed search must not reserve partial result";
  }
  {
    auto limited = r.opts;
    limited.max_search_nodes_ = 1;
    DataAllocator a(r.b, limited);
    a.Open();
    AllocationFails([&] { a.Reserve(u); },
                    AllocationErrorCode::ResourceUnavailable,
                    "search work must be bounded");
  }
  {
    DataAllocator a(r.b, r.opts);
    a.Open();
    auto hold = a.Reserve(4 * u);
    auto fragmented = a.Reserve(2 * u);
    EXPECT_EQ(Units(fragmented.Extents(), u), (std::set<uint64_t>{3, 8}))
        << "bounded split must cover exactly remaining holes";
    AllocationFails([&] { a.Reserve(u); }, AllocationErrorCode::NoSpace,
                    "all non-isolated capacity is held");
  }
}

TEST(F12Allocator, AtomicAllocationReleaseAndRecovery) {
  Image image;
  std::vector<StorageByteRange> x, y;
  Bytes payload;
  uint64_t size, u;
  const MetadataKey kx{40, 7, 1}, ky{40, 7, 2};
  auto vx = Value(49, 1), vy = Value(63, 2);
  {
    Rig r(image, true, 3);
    size = r.Usable();
    u = r.opts.allocation_bytes_;
    DataAllocator a(r.b, r.opts);
    Durable(a.Create());
    auto first = a.Reserve(u - 1);
    auto second = a.Reserve(u);
    x = first.Extents();
    y = second.Extents();
    payload = Value(u, 19);
    auto io = r.Write(x.front().Offset(), payload);
    io.Wait();
    ASSERT_EQ(io.Phase(), IOBatchPhase::Succeeded);
    auto base = r.b.Read();
    Durable(a.Commit(base, first, {{kx, vx}}));
    try {
      a.Commit(base, second, {{ky, vy}});
      FAIL() << "stale companion snapshot accepted";
    } catch (const MetadataError &e) {
      EXPECT_EQ(e.Code(), MetadataErrorCode::Conflict);
    }
    EXPECT_FALSE(r.b.Read().Get(ky));
    Durable(a.Commit(r.b.Read(), second, {{ky, vy}}));
    Durable(a.SetQuarantine(r.b.Read(), {Range(5 * u, u)}, true));
    EXPECT_EQ(r.b.Checkpoint(256).outcome_, MetadataCheckpointOutcome::Durable);
  }
  {
    Rig r(image, false, 3);
    DataAllocator a(r.b, r.opts);
    a.Open();
    EXPECT_EQ(r.b.Read().Get(kx), vx);
    EXPECT_EQ(r.b.Read().Get(ky), vy);
    ExpectBytes(image, x.front().Offset(), payload);
    auto rest = a.Reserve(size - 3 * u);
    auto actual = Units(rest.Extents(), u);
    std::set<uint64_t> expected;
    for (uint64_t i = 0; i < size / u; ++i)
      if (i != 0 && i != 1 && i != 5)
        expected.insert(i);
    EXPECT_EQ(actual, expected) << "recover all committed and quarantined "
                                   "units including tail geometry";
    AllocationFails([&] { a.Reserve(u); }, AllocationErrorCode::NoSpace,
                    "unaligned Data tail is unavailable");
    Durable(a.Release(r.b.Read(), x, {{kx, std::nullopt}}));
    EXPECT_FALSE(r.b.Read().Get(kx));
    EXPECT_EQ(r.b.Read().Get(ky), vy);
    auto reused = a.Reserve(u);
    EXPECT_EQ(Units(reused.Extents(), u), (std::set<uint64_t>{0}))
        << "only released allocation can be reused";
    EXPECT_EQ(r.b.Checkpoint(256).outcome_, MetadataCheckpointOutcome::Durable);
  }
  {
    Rig r(image, false, 3);
    DataAllocator a(r.b, r.opts);
    a.Open();
    EXPECT_FALSE(r.b.Read().Get(kx));
    EXPECT_EQ(r.b.Read().Get(ky), vy);
    auto all_free = a.Reserve(size - 2 * u);
    auto units = Units(all_free.Extents(), u);
    EXPECT_EQ(units.count(0), 1U);
    EXPECT_EQ(units.count(1), 0U);
    EXPECT_EQ(units.count(5), 0U);
  }
}

TEST(F12Allocator, QuarantineCommitExcludesConcurrentReservation) {
  Image image;
  Rig r(image, true);
  DataAllocator a(r.b, r.opts);
  Durable(a.Create());
  const auto u = r.opts.allocation_bytes_;
  const auto stale = r.b.Read();
  Arm(Point::JournalFlush);
  auto commit = std::async(std::launch::async, [&] {
    return a.SetQuarantine(r.b.Read(), {Range(0, u)}, true);
  });
  ReleaseOnExit cleanup;
  ASSERT_TRUE(WaitEntered());
  // Handshake at the real Flush; these calls must finish while it is paused.
  auto rest = a.Reserve(r.Usable() - u);
  auto actual = Units(rest.Extents(), u);
  EXPECT_EQ(actual.count(0), 0U) << "quarantine must exclude range before B IO";
  EXPECT_EQ(actual.size(), r.Usable() / u - 1);
  ReleaseGate();
  Durable(commit.get());
  AllocationFails([&] { a.Reserve(u); }, AllocationErrorCode::NoSpace,
                  "quarantine stays excluded after durable");
  Durable(a.SetQuarantine(r.b.Read(), {Range(0, u)}, false));
  try {
    a.SetQuarantine(stale, {Range(0, u)}, true);
    FAIL() << "stale quarantine base must reject before IO";
  } catch (const MetadataError &e) {
    EXPECT_EQ(e.Code(), MetadataErrorCode::Conflict);
  }
  std::optional<DataReservation> recovered;
  ASSERT_NO_THROW(recovered.emplace(a.Reserve(u)))
      << "rejected quarantine must release its temporary reservation";
  EXPECT_EQ(Units(recovered->Extents(), u), (std::set<uint64_t>{0}))
      << "clear quarantine must update summary";
}

TEST(F12Allocator, CommitFailureBlocksReuseAndRecoversAtomically) {
  // Allocation and release have opposite unsafe outcomes; exercise both on
  // separate real images. Flush EIO is not a simulated power cut.
  for (bool releasing : {false, true}) {
    SCOPED_TRACE(releasing);
    Image image;
    const MetadataKey key{40, 9, 1};
    const auto value = Value(87, 35);
    {
      Rig r(image, true);
      DataAllocator a(r.b, r.opts);
      Durable(a.Create());
      auto ticket = a.Reserve(r.Usable());
      if (releasing)
        Durable(a.Commit(r.b.Read(), ticket, {{key, value}}));
      Arm(Point::JournalFlush, true);
      auto commit = std::async(std::launch::async, [&] {
        return releasing ? a.Release(r.b.Read(), ticket.Extents(),
                                     {{key, std::nullopt}})
                         : a.Commit(r.b.Read(), ticket, {{key, value}});
      });
      ReleaseOnExit cleanup;
      ASSERT_TRUE(WaitEntered());
      auto before = r.b.Read().Get(key);
      EXPECT_EQ(before.has_value(), releasing)
          << "metadata cannot publish before durable";
      AllocationFails([&] { a.Reserve(r.opts.allocation_bytes_); },
                      AllocationErrorCode::NoSpace,
                      "pending commit cannot release space");
      ReleaseGate();
      auto result = commit.get();
      EXPECT_NE(result.outcome_, JournalOutcome::Durable);
      EXPECT_TRUE(result.error_);
      AllocationFails([&] { a.Reserve(r.opts.allocation_bytes_); },
                      AllocationErrorCode::NotReady,
                      "uncertain commit must stop allocator");
    }
    {
      Rig r(image, false);
      DataAllocator a(r.b, r.opts);
      a.Open();
      const auto recovered = r.b.Read().Get(key);
      if (recovered) {
        EXPECT_EQ(*recovered, value);
        AllocationFails([&] { a.Reserve(r.opts.allocation_bytes_); },
                        AllocationErrorCode::NoSpace,
                        "recovered companion requires full allocation");
      } else {
        auto free = a.Reserve(r.Usable());
        EXPECT_EQ(Units(free.Extents(), r.opts.allocation_bytes_).size(),
                  r.Usable() / r.opts.allocation_bytes_)
            << "absent companion requires full free capacity";
      }
    }
  }
}

TEST(F12Allocator, OpenNeverFormatsAndChecksGeometry) {
  Image image;
  Rig r(image, true);
  const MetadataKey key{40, 1, 3};
  auto bytes = Value(59, 42);
  Durable(r.b.Commit(r.b.Read(), {{key, bytes}}));
  {
    DataAllocator a(r.b, r.opts);
    AllocationFails([&] { a.Open(); }, AllocationErrorCode::NotInitialized,
                    "Open must never silently create");
  }
  {
    DataAllocator a(r.b, r.opts);
    Durable(a.Create());
  }
  // Check geometry before bitmap records exist: otherwise a different check
  // (tail bits outside the smaller geometry) can conceal a missing descriptor
  // check.
  {
    auto opts = r.opts;
    opts.allocation_bytes_ *= 2;
    DataAllocator a(r.b, opts);
    AllocationFails([&] { a.Open(); }, AllocationErrorCode::Corrupt,
                    "different unit geometry cannot reinterpret bitmap");
  }
  {
    DataAllocator a(r.b, r.opts);
    a.Open();
    auto ticket = a.Reserve(r.Usable());
    Durable(a.Commit(r.b.Read(), ticket, {}));
  }
  {
    DataAllocator a(r.b, r.opts);
    AllocationFails([&] { a.Create(); },
                    AllocationErrorCode::AlreadyInitialized,
                    "Create must not overwrite allocation facts");
  }
  {
    DataAllocator a(r.b, r.opts);
    a.Open();
    AllocationFails([&] { a.Reserve(r.opts.allocation_bytes_); },
                    AllocationErrorCode::NoSpace,
                    "failed open/create must preserve prior allocation");
    EXPECT_EQ(r.b.Read().Get(key), bytes);
  }
}
} // namespace
