# S8 对象三 Store 阶段验证

仅归档，不注册常驻 CMake 测试。保护范围和八项审查见仓库 `docs/storage_redesign/s8_execution_20261003.md`。

## 恢复

需要与 MANIFEST.json 的源码哈希一致的仓库、clang/clang++/clang-format 14、CMake、Python 3（tarfile data filter）、Linux O_DIRECT 文件与本机 TCP。S5-journal-recycling.tar.gz 是现有真实存储 fixture 依赖，保留原哈希。

在独立、显式工作目录解压此包：

```sh
tar -xzf /path/to/repo/test/archives/S8-raft-object-stores.tar.gz -C /path/to/work
cmake -S /path/to/repo -B /path/to/work/build -DCMAKE_BUILD_TYPE=Debug -DCMAKE_C_COMPILER=clang-14 -DCMAKE_CXX_COMPILER=clang++-14 -DBUSTUB_SANITIZER=address,undefined -DCMAKE_EXE_LINKER_FLAGS=-no-pie
cmake --build /path/to/work/build --target bustub gtest_main snapshot_store_test raft_state_machine_test log_store_test stable_store_test raft_node_test -j3
python3 /path/to/work/S8-raft-object-stores/tests/run_stage.py --repo /path/to/repo --build /path/to/work/build --work /path/to/work/evidence --regressions --mutations
```

8 个 S8 场景、58 个相邻回归，10 个隔离变异。每个失败必须分析，不忽略 sanitizer、不自动放宽断言、不能将超时/编译失败当变异命中。需要 LeakSanitizer 进程检查权限；受限沙箱可能不能提供。

测试对象镜像每个逻辑 64 MiB；三节点场景三个文件，业务 BufferPool 每个 64 页。T8 将 Data 区显式限制为 64 个分配单位 u；新内容分 4u 的正式事务写入、累计 56u，旧+新正文超过容量，重开验证新内容及存活快照。实际对齐查询设备；没有硬编码本机观察值。PID/动态临时路径隔离测试，真实 syscall 注入限串行；TCP 端口由 OS 分配，仍可能有外部抢占风险。不是性能基准、裸块设备验证或真实断电。

故障用例只在指定单次 syscall 返回 EIO，其他操作调用真实系统实现；没有生产测试 hook。候选崩溃用子进程 `_exit`；E2E 三节点同进程、独立设备、真实 TCP，包含落后节点的 InstallSnapshot。

阶段风险后续迁入共同 C/P 时保持输入语义与 Oracle，由测试适配层接新接口；不复制三个模块的同义测试。T2 已移除根编码观察，使用公开额度和合法后继请求作为 Oracle。T6 固定 suffix/session 恢复边界，T7 检查真实 TCP 追赶；只有共同 E2E 覆盖同一触发条件/Oracle/故障边界后才接管，不能仅因路径相同删除。

本次复审新增大正文在小元数据预算下分步回收、关闭重开后接续；同一重试 Oracle 覆盖对象与文件 complete 分支。没有修改共同 C/P 内容。

2026-10-04 复审：T8 使用 1 KiB 接收块、64 KiB IO 上限及 16 项元数据批次上限；通过实际 StageChunk/发布/退役验证 F13 单映射裁剪。bytes_only_retired_trim 变异恢复上轮字节裁剪算法，必须被目标测试发现。

2026-10-04 测试契约补齐：T8 不直接调用底层 Reclaim，也不检查 bitmap；使用正式 SubmitObjects、生产后台 GC 和重开后的 ReadObject 验证跨层物理复用。对 NotCommitted/NoSpace 的重试窗口为 10 秒，不打断单次票据 Wait；runner 对整场景进程另设 240 秒超时，超时记失败，其余错误直接失败；不能把 Collect 完成数或 sleep 当作可复用证据。新增 skip_physical_reclaim 变异必须使容量测试失败。T6 去掉重复的重启前 SELECT，恢复值直接对照字面输入。生产代码未为本轮测试修改，未改变共同 C/P。

2026-10-04 再次审查：本次仅更新说明和对应哈希，测试与 runner 未改动，沿用上轮 8/58/10 的实测证据；并非重新运行。
