#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <atomic>
#include <chrono>
#include <thread>
#include "common/byte_codec.h"
#include "distributed/client.h"
#include "distributed/node.h"
#include "distributed/raft_state_machine.h"
#include "distributed/request_fingerprint.h"
#include "fixture.h"
#include "gtest/gtest.h"
#include "raft/log_store.h"
#include "raft/object_storage.h"
#include "raft/persistent_state.h"
#include "raft/snapshot_store.h"
#include "raft/stable_store.h"
using namespace std::chrono_literals;
using namespace bustub;
using namespace s5;
namespace {
std::atomic<bool> fail_data{false}, fail_sync{false};
constexpr uint64_t DATA = 32 * MIB;
}  // namespace
extern "C" ssize_t __real_pwrite(int, const void *, size_t, off_t);
extern "C" int __real_fdatasync(int);
extern "C" ssize_t __wrap_pwrite(int fd, const void *data, size_t size, off_t offset) {
  if ((fcntl(fd, F_GETFL) & O_DIRECT) && offset >= static_cast<off_t>(DATA) && fail_data.exchange(false)) {
    errno = EIO;
    return -1;
  }
  return __real_pwrite(fd, data, size, offset);
}
extern "C" int __wrap_fdatasync(int fd) {
  if ((fcntl(fd, F_GETFL) & O_DIRECT) && fail_sync.exchange(false)) {
    errno = EIO;
    return -1;
  }
  return __real_fdatasync(fd);
}
namespace {
auto Options(const Image &image) -> NodeStorageOptions {
  BlockDevice device(image.path, {});
  const auto u = static_cast<uint32_t>(std::lcm<uint64_t>(4096, device.Info().offset_alignment_));
  BootstrapIdentity id{};
  id.storage_.fill(11);
  id.device_.fill(31);
  JournalIdentity journal{};
  journal.fill(73);
  return {image.path,
          {},
          {3, 2048, 16 * MIB},
          id,
          journal,
          {64ULL * u, u, 8192, MIB, 512, 2 * MIB, 8, 32, 4 * MIB},
          {1024, 4096, 16384, MIB},
          {1, 1ms, 1000ms},
          ObjectStorageOptions{{u, 64, 16 * MIB, 32 * MIB, 32, 4096, 65536},
                               {32, 512, MIB, 4096, 64},
                               {128, 128, 4096, 32, 8 * MIB, 64},
                               2 * MIB,
                               2 * MIB},
          ObjectTransactionOptions{32, 128, MIB, 8 * MIB, 2ms, 10ms}};
}
auto Limits() -> RaftObjectOptions { return {1024, 1024, 2 * MIB, 4096, 64, 128 * 1024, 8 * MIB, 8192}; }
struct Harness {
  Image image;
  NodeStorageOptions options;
  RaftObjectOptions raft_options;
  std::shared_ptr<NodeStorage> node;
  std::shared_ptr<RaftObjectStorage> objects;
  uint64_t space{0};
  explicit Harness(RaftObjectOptions limits = Limits(), size_t data_units = 0)
      : options(Options(image)), raft_options(limits) {
    int fd = open(image.path.c_str(), O_WRONLY);
    Require(fd >= 0, "expand image");
    Require(ftruncate(fd, 64 * MIB) == 0, "image size");
    close(fd);
    node = std::make_shared<NodeStorage>(options);
    node->Create({options.identity_,
                  64 * MIB,
                  {Range(2 * MIB, 4 * MIB), Range(8 * MIB, 8 * MIB),
                   Range(DATA, data_units ? data_units * options.objects_->allocator_.allocation_bytes_ : 32 * MIB)}});
    node->InitializeObjects();
    auto created = node->CreateObjectSpace(node->Objects());
    Require(created.result_.outcome_ == JournalOutcome::Durable && created.space_.has_value(), "space creation");
    space = *created.space_;
    objects = RaftObjectStorage::Create(node, space, raft_options);
  }
  void Close() {
    objects.reset();
    node->Close();
    node.reset();
  }
  void Open() {
    node = std::make_shared<NodeStorage>(options);
    node->Open();
    objects = RaftObjectStorage::Open(node, space, raft_options);
  }
  ~Harness() {
    fail_data = false;
    fail_sync = false;
    if (node) {
      try {
        node->Close();
      } catch (...) {
      }
    }
  }
};
auto Entry(uint64_t index, size_t size, unsigned seed, uint64_t term = 3) -> ReplicatedLogEntry {
  return {1, index, term, EntryType::COMMAND_BATCH, s5::Value(size, seed)};
}
void Put(KvStateMachine &machine, uint64_t index, const std::string &value) {
  machine.Apply(
      {1, index, 3, EntryType::KV_COMMAND, KvCommandCodec::Encode({1, KvOperation::PUT, "account-37", value})});
}
auto SnapshotBytes(KvStateMachine &machine) -> Bytes {
  Bytes out;
  machine.WriteSnapshot([&](const auto &b) { out.insert(out.end(), b.begin(), b.end()); });
  return out;
}
auto Chunk(const Bytes &bytes, uint64_t index, size_t start, size_t count, bool done) -> SnapshotChunk {
  return {"received-" + std::to_string(index),
          index,
          3,
          start,
          bytes.size(),
          Crc32c(bytes),
          done,
          {bytes.begin() + static_cast<ptrdiff_t>(start), bytes.begin() + static_cast<ptrdiff_t>(start + count)}};
}
TEST(S8Objects, CrossSegmentReplacementAndRecoveryKeepExactHistory) {
  Harness h;
  auto log = LogStore::OpenObjects(h.objects, 0, 0, 0);
  auto stable = StableStore::OpenObjects(h.objects);
  std::vector<ReplicatedLogEntry> model{Entry(1, 177, 31), Entry(2, 2741, 72), Entry(3, 555, 12), Entry(4, 1850, 98)};
  log->Append(model);
  EXPECT_EQ(log->EntryAt(2), std::optional<ReplicatedLogEntry>(model[1]));
  stable->Update(3, 2, 2);
  log->AdvanceCommittedIndex(2);
  EXPECT_THROW(log->ReplaceSuffix(2, {Entry(2, 99, 2)}), std::invalid_argument);
  const std::vector<ReplicatedLogEntry> replacement{Entry(3, 3317, 101, 4), Entry(4, 73, 117, 4), Entry(5, 1981, 4, 4)};
  log->ReplaceSuffix(3, replacement);
  model.resize(2);
  model.insert(model.end(), replacement.begin(), replacement.end());
  EXPECT_EQ(log->Entries(1, 5), model);
  stable->Update(4, 1, 3);
  log->AdvanceCommittedIndex(3);
  EXPECT_THROW(stable->Update(4, 2, 3), std::runtime_error);
  EXPECT_THROW(stable->Update(3, 1, 3), std::runtime_error);
  EXPECT_THROW(stable->Update(4, 1, 2), std::runtime_error);
  log.reset();
  stable.reset();
  h.Close();
  h.Open();
  stable = StableStore::OpenObjects(h.objects);
  log = LogStore::OpenObjects(h.objects, 3, 0, 0);
  EXPECT_EQ(log->Entries(1, 5), model);
  EXPECT_EQ(stable->State().current_term_, 4U);
  EXPECT_EQ(stable->State().voted_for_, std::optional<NodeId>(1));
  EXPECT_EQ(stable->State().commit_index_, 3U);
  // Prefix retirement must retain the middle of a physical segment and the following fragments.
  log->InstallSnapshotBase(2, 3, true);
  log.reset();
  stable.reset();
  h.Close();
  h.Open();
  log = LogStore::OpenObjects(h.objects, 3, 2, 3);
  EXPECT_EQ(log->Entries(3, 5), replacement);
  EXPECT_FALSE(log->EntryAt(2));
}
TEST(S8Objects, FinalManifestBudgetRejectsBeforeCreatingCandidates) {
  auto limits = Limits();
  // Enough candidate capacity for the invalid request: it must reach the
  // manifest preflight, rather than fail an unrelated ownership limit first.
  limits.max_owned_objects_ = 10;
  Harness h(limits);
  auto log = LogStore::OpenObjects(h.objects, 0, 0, 0);
  auto prefix = Entry(1, 90, 21);
  log->Append({prefix});
  log.reset();
  h.Close();
  auto limited = h.options;
  limited.transactions_->max_operations_ = 4;
  h.node = std::make_shared<NodeStorage>(limited);
  h.node->Open();
  h.objects = RaftObjectStorage::Open(h.node, h.space, limits);
  log = LogStore::OpenObjects(h.objects, 0, 0, 0);
  // Nine segments cannot fit the final control transaction even though each body chunk fits.
  EXPECT_THROW(log->Append({Entry(2, 8700, 13)}), std::invalid_argument);
  EXPECT_EQ(log->Entries(1, 1), std::vector<ReplicatedLogEntry>{prefix});
  // These valid appends need fresh candidate capacity. A rejected request
  // must not consume it. Observe capacity through real work, without
  // decoding the allocator root, counting objects or running cleanup first.
  std::vector<ReplicatedLogEntry> expected{prefix};
  for (uint64_t index = 2; index <= 5; ++index) {
    const auto accepted = Entry(index, 700, 87 + index);
    ASSERT_NO_THROW(log->Append({accepted}));
    expected.push_back(accepted);
  }
  EXPECT_EQ(log->Entries(1, 5), expected);
  log.reset();
  h.Close();
  h.Open();
  log = LogStore::OpenObjects(h.objects, 0, 0, 0);
  EXPECT_EQ(log->Entries(1, 5), expected);
}
TEST(S8Objects, CompletedUnpublishedCandidateDoesNotBecomeLatestAfterProcessExit) {
  Harness h;
  KvStateMachine first;
  Put(first, 1, "published-account-value");
  auto snapshots = SnapshotStore::OpenObjects(h.objects);
  const auto published = snapshots->Capture(1, 3, first);
  KvStateMachine next;
  Put(next, 1, "initial-account-value");
  Put(next, 2, "unpublished-complete-content-with-distinct-bytes");
  const auto bytes = SnapshotBytes(next);
  snapshots.reset();
  h.Close();
  const auto pid = fork();
  ASSERT_GE(pid, 0);
  if (pid == 0) {
    try {
      h.Open();
      auto s = SnapshotStore::OpenObjects(h.objects);
      auto result = s->StageChunk(Chunk(bytes, 2, 0, bytes.size(), true));
      _exit(result.status_ == SnapshotStageStatus::COMPLETE ? 0 : 2);
    } catch (...) {
      _exit(3);
    }
  }
  int status = 0;
  ASSERT_EQ(waitpid(pid, &status, 0), pid);
  ASSERT_TRUE(WIFEXITED(status));
  ASSERT_EQ(WEXITSTATUS(status), 0);
  h.Open();
  snapshots = SnapshotStore::OpenObjects(h.objects);
  ASSERT_TRUE(snapshots->Latest());
  EXPECT_EQ(snapshots->Latest()->snapshot_id_, published.snapshot_id_);
  KvStateMachine restored;
  restored.LoadSnapshot(snapshots->Input(*snapshots->Latest()), 1);
  EXPECT_EQ(restored.Get("account-37"), std::optional<std::string>("published-account-value"));
  EXPECT_FALSE(snapshots->Staged("received-2"));
  EXPECT_THROW(snapshots->StageChunk(Chunk(bytes, 2, 9, bytes.size() - 9, true)), std::invalid_argument);
  EXPECT_EQ(h.objects->Collect(4), 1U) << "abandoned complete candidate must be recoverably collected";
}
TEST(S8Objects, CompleteRetriesCompareBytesAndTransferSurvivesRetirement) {
  Harness h;
  auto snapshots = SnapshotStore::OpenObjects(h.objects);
  KvStateMachine machine;
  const std::string old_value = "old-object-" + std::string(3307, 'q');
  Put(machine, 1, old_value);
  auto old = snapshots->Capture(1, 3, machine);
  auto session = std::optional<SnapshotInput>(snapshots->Input(old));
  const auto expected = SnapshotBytes(machine);
  EXPECT_EQ(session->Read(0, 1301), Bytes(expected.begin(), expected.begin() + 1301));
  Put(machine, 2, "new-version-which-has-a-different-body");
  auto bytes = SnapshotBytes(machine);
  auto first = Chunk(bytes, 2, 0, 13, false);
  auto last = Chunk(bytes, 2, 13, bytes.size() - 13, true);
  auto check_retries = [&](SnapshotStore &store) {
    EXPECT_EQ(store.StageChunk(first).status_, SnapshotStageStatus::IN_PROGRESS);
    EXPECT_EQ(store.StageChunk(last).status_, SnapshotStageStatus::COMPLETE);
    auto conflict = last;
    conflict.data_[7] ^= std::byte{0x37};
    EXPECT_THROW(store.StageChunk(conflict), std::runtime_error);
    EXPECT_EQ(store.StageChunk(last).status_, SnapshotStageStatus::DUPLICATE_COMPLETE);
    EXPECT_EQ(store.StageChunk(first).status_, SnapshotStageStatus::DUPLICATE_COMPLETE);
  };
  check_retries(*snapshots);
  {
    // The supported file deployment has its own complete-download branch.
    // Reuse the same input/oracle rather than another duplicate test suite.
    struct Cleanup {
      std::filesystem::path path;
      ~Cleanup() { std::filesystem::remove_all(path); }
    } cleanup{h.image.path + "-file-retries"};
    auto files = SnapshotStore::Open(cleanup.path, std::make_shared<PosixDurableStorage>());
    check_retries(*files);
  }
  auto candidate = snapshots->StagedInput("received-2");
  ASSERT_TRUE(candidate);
  machine.ValidateSnapshot(*candidate, 2);
  snapshots->PublishStaged("received-2", false);
  candidate.reset();
  EXPECT_EQ(h.objects->Collect(4), 0U) << "whole transfer, not one IO, holds old body";
  EXPECT_EQ(session->Read(1301, expected.size() - 1301), Bytes(expected.begin() + 1301, expected.end()));
  session.reset();
  EXPECT_EQ(h.objects->Collect(4) + h.objects->Collect(4), 1U);
  EXPECT_THROW(snapshots->Input(old), std::runtime_error);
  snapshots.reset();
  h.Close();
  h.Open();
  snapshots = SnapshotStore::OpenObjects(h.objects);
  KvStateMachine recovered;
  recovered.LoadSnapshot(snapshots->Input(*snapshots->Latest()), 2);
  EXPECT_EQ(recovered.Get("account-37"), std::optional<std::string>("new-version-which-has-a-different-body"));
}
TEST(S8Objects, RetiredMultiRangeBodyReclaimsIncrementallyAcrossRestart) {
  auto limits = Limits();
  limits.segment_bytes_ = 64 * 1024;
  limits.io_chunk_bytes_ = 64 * 1024;
  constexpr size_t data_units = 64;
  Harness h(limits, data_units);
  const auto unit = h.options.objects_->allocator_.allocation_bytes_;
  const auto data_capacity = data_units * unit;
  h.Close();
  // Many small incoming chunks fit individually, but even one IO-sized GC
  // step exceeds the mapping budget. Byte bounds alone are insufficient.
  h.options.objects_->mapping_.max_update_entries_ = 16;
  h.Open();
  // Provision the independent destination before producing retirement work;
  // CreateObjectSpace is an explicit metadata transaction, not a GC barrier.
  auto created = h.node->CreateObjectSpace(h.node->Objects());
  ASSERT_EQ(created.result_.outcome_, JournalOutcome::Durable);
  ASSERT_TRUE(created.space_);
  const ObjectKey target{*created.space_, 1};
  auto snapshots = SnapshotStore::OpenObjects(h.objects);
  KvStateMachine machine;
  Put(machine, 1, "retired-body-" + std::string(10 * unit + 13, 'r'));
  const auto bytes = SnapshotBytes(machine);
  for (size_t start = 0; start < bytes.size(); start += 1024) {
    const auto count = std::min<size_t>(1024, bytes.size() - start);
    const auto complete = start + count == bytes.size();
    ASSERT_EQ(snapshots->StageChunk(Chunk(bytes, 1, start, count, complete)).status_,
              complete ? SnapshotStageStatus::COMPLETE : SnapshotStageStatus::IN_PROGRESS);
  }
  {
    const auto candidate = snapshots->StagedInput("received-1");
    ASSERT_TRUE(candidate);
    machine.ValidateSnapshot(*candidate, 1);
  }
  const auto old = snapshots->PublishStaged("received-1", false);
  Put(machine, 2, "live-body-must-survive-incremental-reclamation");
  snapshots->Capture(2, 3, machine);
  snapshots->RetainOnlyLatest();
  EXPECT_EQ(h.objects->Collect(1), 0U) << "one bounded step cannot remove this large body";
  snapshots.reset();
  h.Close();
  h.Open();
  snapshots = SnapshotStore::OpenObjects(h.objects);
  size_t removed = 0;
  for (size_t step = 0; step < 128 && removed == 0; ++step) {
    removed += h.objects->Collect(1);
  }
  EXPECT_EQ(removed, 1U) << "retired ownership and progress must survive reopen";
  EXPECT_EQ(h.objects->Collect(8), 0U) << "the live snapshot is never eligible";
  EXPECT_THROW(snapshots->Input(old), std::runtime_error);
  KvStateMachine restored;
  restored.LoadSnapshot(snapshots->Input(*snapshots->Latest()), 2);
  EXPECT_EQ(restored.Get("account-37"), std::optional<std::string>("live-body-must-survive-incremental-reclamation"));

  // Public capacity is the oracle: these two payloads cannot coexist in Data.
  // Collect's completed count alone cannot prove that S7/F14/F12 freed bytes.
  const auto replacement = s5::Value(data_capacity - 8 * unit, 137);
  ASSERT_GT(bytes.size() + replacement.size(), data_capacity);
  auto execute = [&](ObjectTransaction transaction) {
    auto submitted = h.node->SubmitObjects(transaction);
    if (submitted.admission_ != IOAdmission::Accepted) {
      throw std::runtime_error("capacity verification request was not admitted");
    }
    submitted.ticket_->Wait();
    return submitted.ticket_->Result();
  };
  ASSERT_EQ(execute({{{ObjectOperation::Create, target, 0, ObjectSizeMode::Variable, {}}}, {}}).outcome_,
            JournalOutcome::Durable);
  // The real background reclaimer is asynchronous. Retry only a definitely
  // uncommitted NoSpace; any other error or uncertainty fails immediately.
  size_t written = 0;
  const auto deadline = std::chrono::steady_clock::now() + 10s;
  do {
    // Keep requests bounded even when free physical space is fragmented.
    // Total retained payload, rather than one huge transaction, proves reuse.
    const auto count = std::min<size_t>(4 * unit, replacement.size() - written);
    Bytes chunk(replacement.begin() + static_cast<ptrdiff_t>(written),
                replacement.begin() + static_cast<ptrdiff_t>(written + count));
    const auto result =
        execute({{{ObjectOperation::Write, target, written, ObjectSizeMode::Variable, std::move(chunk)}}, {}});
    if (result.outcome_ == JournalOutcome::Durable) {
      written += count;
    } else {
      ASSERT_EQ(result.outcome_, JournalOutcome::NotCommitted);
      ASSERT_TRUE(result.error_);
      try {
        std::rethrow_exception(result.error_);
      } catch (const AllocationError &error) {
        ASSERT_EQ(error.Code(), AllocationErrorCode::NoSpace) << error.what();
      }
      std::this_thread::sleep_for(10ms);
    }
  } while (written < replacement.size() && std::chrono::steady_clock::now() < deadline);
  ASSERT_EQ(written, replacement.size())
      << "retired snapshot space did not become usable through the production GC chain";
  snapshots.reset();
  h.Close();
  h.Open();
  auto read = h.node->ReadObject(h.node->Objects(), target, 0, replacement.size());
  read.Wait();
  ASSERT_EQ(read.Size(), replacement.size());
  Bytes actual(replacement.size());
  read.CopyTo(actual.data(), actual.size());
  EXPECT_EQ(actual, replacement);
  snapshots = SnapshotStore::OpenObjects(h.objects);
  KvStateMachine still_live;
  still_live.LoadSnapshot(snapshots->Input(*snapshots->Latest()), 2);
  EXPECT_EQ(still_live.Get("account-37"), std::optional<std::string>("live-body-must-survive-incremental-reclamation"));
}
TEST(S8Objects, DeviceErrorsPreserveAcknowledgedPrefixAndFenceUncertainCommit) {
  Harness h;
  auto log = LogStore::OpenObjects(h.objects, 0, 0, 0);
  const auto prefix = Entry(1, 77, 5);
  log->Append({prefix});
  auto stable = StableStore::OpenObjects(h.objects);
  stable->Update(3, 1, 1);
  log->AdvanceCommittedIndex(1);
  fail_data = true;
  EXPECT_THROW(log->Append({Entry(2, 3000, 8)}), std::exception);
  fail_data = false;
  log.reset();
  stable.reset();
  h.Close();
  h.Open();
  log = LogStore::OpenObjects(h.objects, 1, 0, 0);
  EXPECT_EQ(log->Entries(1, 1), std::vector<ReplicatedLogEntry>{prefix});
  EXPECT_FALSE(log->EntryAt(2));
  stable = StableStore::OpenObjects(h.objects);
  fail_sync = true;
  EXPECT_THROW(stable->Update(4, 2, 1), std::exception);
  fail_sync = false;
  EXPECT_THROW(stable->Update(5, 3, 1), std::exception) << "uncertain result must fence subsequent writes";
  stable.reset();
  log.reset();
  h.Close();
  h.Open();
  stable = StableStore::OpenObjects(h.objects);
  auto state = stable->State();
  EXPECT_EQ(state.commit_index_, 1U);
  EXPECT_TRUE((state.current_term_ == 3 && state.voted_for_ == 1) ||
              (state.current_term_ == 4 && state.voted_for_ == 2));
}
TEST(S8Objects, RealSqlSnapshotAndCommittedSuffixRestoreThroughObjectBackend) {
  Harness h;
  auto files = std::make_shared<PosixDurableStorage>();
  const auto root = std::filesystem::path(h.image.path + "-sql");
  struct Cleanup {
    std::filesystem::path path;
    ~Cleanup() { std::filesystem::remove_all(path); }
  } cleanup{root};
  auto directory = NodeDirectory::Open(root, files);
  auto machine = BusTubRaftStateMachine::Open(directory.get(), files, 64);
  auto log = LogStore::OpenObjects(h.objects, 0, 0, 0);
  auto stable = StableStore::OpenObjects(h.objects);
  auto snapshots = SnapshotStore::OpenObjects(h.objects);
  const std::vector<std::string> sql{"CREATE TABLE accounts(id int PRIMARY KEY, name varchar(64));",
                                     "INSERT INTO accounts VALUES (37, 'real-before');",
                                     "UPDATE accounts SET name = 'real-after' WHERE id = 37;"};
  auto apply = [&](size_t n) {
    auto fingerprint = ComputeWriteIntentFingerprintV1(sql[n]);
    auto command = machine->PrepareSql(sql[n], 71, n + 1, fingerprint);
    ReplicatedLogEntry entry{1, n + 1, 3, EntryType::COMMAND_BATCH, CommandBatchCodec::Encode(command)};
    log->Append({entry});
    stable->Update(3, 1, n + 1);
    log->AdvanceCommittedIndex(n + 1);
    machine->Apply(entry);
  };
  apply(0);
  apply(1);
  auto snapshot = snapshots->Capture(2, 3, *machine);
  log->InstallSnapshotBase(2, 3, true);
  snapshots->RetainOnlyLatest();
  apply(2);
  const auto response = machine->GetLastResponse(71);
  machine.reset();
  snapshots.reset();
  log.reset();
  stable.reset();
  h.Close();
  h.Open();
  machine = BusTubRaftStateMachine::Open(directory.get(), files, 64);
  auto recovered = RecoverRaftPersistentState(h.objects, machine);
  ASSERT_EQ(machine->LastApplied(), 2U);
  machine->Apply(*recovered.log_store_->EntryAt(3));
  const auto query = machine->ExecuteReadSql("SELECT name FROM accounts WHERE id = 37;", 3);
  EXPECT_EQ(ClientQueryResultCodec::Decode(query).rows_, (std::vector<std::vector<std::string>>{{"real-after"}}));
  EXPECT_EQ(machine->GetLastResponse(71), response);
  EXPECT_EQ(machine->ClassifyRequest(71, 3, ComputeWriteIntentFingerprintV1(sql[2])), RequestDisposition::RETRY_LAST);
}

TEST(S8Objects, TcpThreeNodesCommitSnapshotAndRestartFromObjectStores) {
  std::array<std::unique_ptr<Harness>, 3> disks;
  std::array<DistributedNodeConfig, 3> config;
  std::array<std::unique_ptr<DistributedNode>, 3> nodes;
  std::array<TcpEndpoint, 3> raft, client;
  std::vector<int> reservations;
  struct Cleanup {
    std::array<std::unique_ptr<DistributedNode>, 3> &nodes;
    std::vector<int> &fds;
    std::vector<std::filesystem::path> paths;
    ~Cleanup() {
      for (auto &node : nodes) {
        if (node) node->Stop();
      }
      for (auto &node : nodes) node.reset();
      for (auto fd : fds) close(fd);
      for (const auto &path : paths) std::filesystem::remove_all(path);
    }
  } cleanup{nodes, reservations, {}};
  for (size_t n = 0; n < 6; ++n) {
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    ASSERT_GE(fd, 0);
    reservations.push_back(fd);
    sockaddr_in address{};
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    ASSERT_EQ(bind(fd, reinterpret_cast<sockaddr *>(&address), sizeof(address)), 0);
    socklen_t size = sizeof(address);
    ASSERT_EQ(getsockname(fd, reinterpret_cast<sockaddr *>(&address), &size), 0);
    (n < 3 ? raft[n] : client[n - 3]) = {"127.0.0.1", ntohs(address.sin_port)};
  }
  for (size_t i = 0; i < 3; ++i) {
    disks[i] = std::make_unique<Harness>();
    auto &h = *disks[i];
    h.Close();
    std::map<NodeId, DistributedPeerConfig> peers;
    for (size_t j = 0; j < 3; ++j)
      if (i != j) peers.emplace(j + 1, DistributedPeerConfig{raft[j], client[j]});
    const auto root = std::filesystem::path(h.image.path + "-node");
    cleanup.paths.push_back(root);
    config[i] = {i + 1,     "s8-object-production",
                 root,      raft[i],
                 client[i], std::move(peers),
                 1000,      1800,
                 100,       10,
                 6000,      64,
                 3,         RaftObjectDeployment{h.options, h.space, Limits()}};
    nodes[i] = DistributedNode::Open(config[i]);
  }
  for (auto fd : reservations) close(fd);
  reservations.clear();
  for (auto &node : nodes) node->Start();
  uint64_t request = 100;
  auto status = [&](size_t i) {
    auto response = DistributedClient::Send(client[i], ClientStatusRequestV1{request++}, 2000);
    if (response.status_ == ClientResponseStatus::UNAVAILABLE) {
      throw std::runtime_error(
          "production unavailable: " +
          std::string(reinterpret_cast<const char *>(response.payload_.data()), response.payload_.size()));
    }
    return response;
  };
  auto leader = [&]() -> size_t {
    auto deadline = std::chrono::steady_clock::now() + 30s;
    while (std::chrono::steady_clock::now() < deadline) {
      for (size_t i = 0; i < 3; ++i) {
        auto response = status(i);
        if (response.status_ == ClientResponseStatus::OK && response.leader_ready_ && response.leader_id_ == i + 1)
          return i;
      }
      std::this_thread::sleep_for(20ms);
    }
    throw std::runtime_error("no ready object-backed Raft leader in 30s");
  };
  size_t elected = leader();
  const std::vector<std::string> sql{"CREATE TABLE inventory(id int PRIMARY KEY, label varchar(64));",
                                     "INSERT INTO inventory VALUES (71, 'tcp-before');",
                                     "UPDATE inventory SET label = 'tcp-after' WHERE id = 71;"};
  ClientResponseV1 last;
  for (size_t i = 0; i < sql.size(); ++i) {
    last = DistributedClient::Send(client[elected], ClientWriteRequestV1{819, i + 1, sql[i]}, 8000);
    ASSERT_EQ(last.status_, ClientResponseStatus::COMMITTED);
  }
  // Observe all nodes through their production status protocol, not a test getter.
  auto deadline = std::chrono::steady_clock::now() + 30s;
  bool applied = false;
  while (std::chrono::steady_clock::now() < deadline) {
    applied = true;
    for (size_t i = 0; i < 3; ++i) {
      auto response = status(i);
      applied &= response.last_applied_ >= last.commit_index_ && response.snapshot_base_index_ > 0;
    }
    if (applied) break;
    std::this_thread::sleep_for(20ms);
  }
  ASSERT_TRUE(applied);
  const size_t lagging = (elected + 1) % 3;
  const auto lagged_at = status(lagging).last_applied_;
  nodes[lagging]->Stop();
  nodes[lagging].reset();
  std::string final_sql;
  for (uint64_t id = 4; id <= 9; ++id) {
    final_sql = "UPDATE inventory SET label = 'tcp-after-" + std::to_string(id) + "' WHERE id = 71;";
    last = DistributedClient::Send(client[elected], ClientWriteRequestV1{819, id, final_sql}, 8000);
    ASSERT_EQ(last.status_, ClientResponseStatus::COMMITTED);
  }
  ASSERT_GT(status(elected).snapshot_base_index_, lagged_at)
      << "leader must have retired the missing log prefix, requiring InstallSnapshot";
  nodes[lagging] = DistributedNode::Open(config[lagging]);
  nodes[lagging]->Start();
  deadline = std::chrono::steady_clock::now() + 30s;
  applied = false;
  while (std::chrono::steady_clock::now() < deadline) {
    const auto response = status(lagging);
    if (response.last_applied_ >= last.commit_index_ && response.snapshot_base_index_ > lagged_at) {
      applied = true;
      break;
    }
    std::this_thread::sleep_for(20ms);
  }
  ASSERT_TRUE(applied) << "lagging node must install the object snapshot and apply its suffix";
  auto follower_read = DistributedClient::Send(
      client[lagging],
      ClientReadRequestV1{400, ClientReadConsistency::STALE, "SELECT label FROM inventory WHERE id = 71;"}, 8000);
  ASSERT_EQ(follower_read.status_, ClientResponseStatus::OK);
  EXPECT_EQ(ClientQueryResultCodec::Decode(follower_read.payload_).rows_,
            (std::vector<std::vector<std::string>>{{"tcp-after-9"}}));
  for (auto &node : nodes) node->Stop();
  for (auto &node : nodes) node.reset();
  for (size_t i = 0; i < 3; ++i) nodes[i] = DistributedNode::Open(config[i]);
  for (auto &node : nodes) node->Start();
  elected = leader();
  auto read = DistributedClient::Send(
      client[elected],
      ClientReadRequestV1{401, ClientReadConsistency::LINEARIZABLE, "SELECT label FROM inventory WHERE id = 71;"},
      8000);
  ASSERT_EQ(read.status_, ClientResponseStatus::OK);
  EXPECT_EQ(ClientQueryResultCodec::Decode(read.payload_).rows_,
            (std::vector<std::vector<std::string>>{{"tcp-after-9"}}));
  auto retry = DistributedClient::Send(client[elected], ClientWriteRequestV1{819, 9, final_sql}, 8000);
  ASSERT_EQ(retry.status_, ClientResponseStatus::COMMITTED);
  EXPECT_EQ(retry.payload_, last.payload_);
}
}  // namespace
