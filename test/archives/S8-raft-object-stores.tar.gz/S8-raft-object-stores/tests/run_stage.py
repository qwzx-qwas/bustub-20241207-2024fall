#!/usr/bin/env python3
"""Runs real S8 Store -> NodeStorage -> Direct file integration, never a performance score."""
import argparse, pathlib, subprocess, os, json, time, tarfile
import xml.etree.ElementTree as ET
p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--build',required=True);p.add_argument('--work',required=True)
p.add_argument('--mutations',action='store_true');p.add_argument('--regressions',action='store_true')
a=p.parse_args();repo=pathlib.Path(a.repo).resolve();build=pathlib.Path(a.build).resolve();work=pathlib.Path(a.work).resolve();work.mkdir(parents=True,exist_ok=True)
src=pathlib.Path(__file__).resolve().parent
env=dict({k:v for k,v in os.environ.items() if not k.startswith('GTEST_')},S5_WORKDIR=str(work),ASAN_OPTIONS='detect_leaks=1:abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1')
with tarfile.open(repo/'test/archives/S5-journal-recycling.tar.gz') as t:t.extractall(work,filter='data')
commands=[]
def run(cmd,name,expected=0):
 start=time.monotonic()
 with (work/(name+'.log')).open('w') as out:r=subprocess.run(list(map(str,cmd)),env=env,stdout=out,stderr=subprocess.STDOUT,timeout=240)
 commands.append(dict(command=list(map(str,cmd)),exit=r.returncode,seconds=time.monotonic()-start));(work/'commands.json').write_text(json.dumps(commands,indent=2))
 if r.returncode!=expected:raise RuntimeError((name,r.returncode,expected))
flags=['clang++-14','-std=c++17','-g','-O0','-Wall','-Wextra','-Werror','-Wno-unused-parameter','-Wno-attributes','-pthread','-fsanitize=address,undefined','-fno-omit-frame-pointer','-no-pie']
flags+=['-I'+str(x) for x in [repo/'src/include',repo/'src/raft',repo/'src/storage/disk',repo/'third_party',repo/'third_party/libfort/src',repo/'third_party/fmt/include',repo/'third_party/googletest/googletest/include',work/'S5-journal-recycling/test/storage_redesign']]
libs=[build/'lib'/('lib'+n+'.a') for n in ['bustub','bustub_murmur3','duckdb_pg_query','fmtd','fort','gtest_main','gtest']]
run([f for f in flags if f != '-no-pie']+['-c',src/'object_stores_test.cpp','-o',work/'s8-test.o'],'test-compile')
run(flags+[work/'s8-test.o']+libs+['-Wl,--wrap=pwrite','-Wl,--wrap=fdatasync','-o',work/'s8-test'],'compile')
run([work/'s8-test','--gtest_output=xml:'+str(work/'s8.xml')],'run')

if a.regressions:
 for name in ['snapshot_store_test','raft_state_machine_test','log_store_test','stable_store_test','raft_node_test']:
  run([build/'test'/name,'--gtest_output=xml:'+str(work/(name+'.xml'))],name)
mutations=[
 ('skip_physical_reclaim','storage/disk/object_transaction.cpp','references_.Reclaim(mapping_.Read(), object, allocation)',
  '(static_cast<void>(object), static_cast<void>(allocation), ObjectReclaimResult{})',
  'RetiredMultiRangeBodyReclaimsIncrementallyAcrossRestart'),
 ('bytes_only_retired_trim','raft/object_storage.cpp','const auto remaining = storage_->Objects().PlanTailTrim(Key(e.item_), options_.io_chunk_bytes_);',
  'const auto size = storage_->Objects().Describe(Key(e.item_)).size_; const auto remaining = size - std::min(size, options_.io_chunk_bytes_);',
  'RetiredMultiRangeBodyReclaimsIncrementallyAcrossRestart'),
 ('wrong_first_offset','raft/object_log_store.cpp','uint64_t offset = loc.offset_;','uint64_t offset = 0;',
  'CrossSegmentReplacementAndRecoveryKeepExactHistory'),
 ('suffix_cut_plus_one','raft/object_log_store.cpp','it->end_ = cut.offset_;','it->end_ = cut.offset_ + 1;',
  'CrossSegmentReplacementAndRecoveryKeepExactHistory'),
 ('late_manifest_budget','raft/object_log_store.cpp','storage_->Check(Controls(segments, next.size(), base_, base_term_));','/* missed permanent preflight */',
  'FinalManifestBudgetRejectsBeforeCreatingCandidates'),
 ('promote_complete_candidate','raft/object_snapshot_store.cpp','d.complete_ = true;','d.complete_ = true; Publish(d.body_, true);',
  'CompletedUnpublishedCandidateDoesNotBecomeLatestAfterProcessExit'),
 ('skip_duplicate_bytes','raft/object_snapshot_store.cpp','storage_->Read(d.body_.object_, chunk.offset_, chunk.data_.size()) != chunk.data_','false',
  'CompleteRetriesCompareBytesAndTransferSurvivesRetirement'),
 ('file_skip_complete_compare','raft/snapshot_store.cpp','if (chunk.offset_ < download.received_size_ || download.complete_) {',
  'if (download.complete_) { return {SnapshotStageStatus::DUPLICATE_COMPLETE, download.received_size_}; } if (chunk.offset_ < download.received_size_) {',
  'CompleteRetriesCompareBytesAndTransferSurvivesRetirement'),
 ('ignore_whole_use','raft/object_storage.cpp','state_->users_.count(e.item_) != 0','false && state_->users_.count(e.item_) != 0',
  'CompleteRetriesCompareBytesAndTransferSurvivesRetirement'),
 ('ack_uncertain_commit','raft/object_storage.cpp','result.outcome_ != JournalOutcome::Durable','result.outcome_ == JournalOutcome::NotCommitted',
  'DeviceErrorsPreserveAcknowledgedPrefixAndFenceUncertainCommit'),
]
if a.mutations:
 records=[]
 for name,file,old,new,test in mutations:
  original=(repo/'src'/file).read_text(); assert original.count(old)==1,(name,'mutation anchor')
  mutated=work/(name+'.cpp'); mutated.write_text(original.replace(old,new))
  run([f for f in flags if f != '-no-pie']+['-c',mutated,'-o',work/(name+'.o')],name+'-compile')
  run(flags+[work/'s8-test.o',work/(name+'.o')]+libs+['-Wl,--wrap=pwrite','-Wl,--wrap=fdatasync','-o',work/name],name+'-link')
  xml=work/(name+'.xml')
  run([work/name,'--gtest_filter=S8Objects.'+test,'--gtest_output=xml:'+str(xml)],name,expected=1)
  cases=ET.parse(xml).getroot().findall('./testsuite/testcase')
  assert len(cases)==1 and cases[0].find('failure') is not None,(name,'must be assertion failure, not crash/timeout')
  records.append(dict(name=name,test=test,result='killed by test failure'))
 (work/'mutations.json').write_text(json.dumps(records,indent=2)+'\n')
