# F10/F11 B checkpoint 临时集成测试

这是最终六项组件测试和 runner；F11 共用，不重复建立套件。

在与 MANIFEST.json 生产哈希一致的仓库中，解压到独立临时目录，显式指定：

```bash
python3 test/storage_redesign/run_stage.py --repo /absolute/repo --work /absolute/temporary-work --mutations
```

需要 Linux Direct 普通文件支持、Clang/clang-format 14、CMake、仓库自带 googletest/fmt。输入至少 48 MiB 文件；所有测试顺序运行。runner 把生成物写到 --work，不注册生产 CMake 测试目标。不修改生产接口或默认配置。

原 F03/F07/F08/F09 有效归档必须仍在 test/archives；runner 验证其 SHA-256。新 fixture 只复用 F09 受控输入、独立磁盘模型和测试侧 IO 包装，不复制它的用例。MANIFEST 记录具体成员和哈希，不能随意换旧包。

本次复审已删除旧 XML 复用/局部续跑选项。每次重新执行六项新场景和原 26 项回归；--mutations 额外执行九项变异。不能把已有 XML 当作当前生产版本通过。

主方案八项审查、测试局限、接口归属见 docs/storage_redesign/f10_execution_20260926.md。再次复审后的六项基线与九项变异均 ASan+UBSan；不代表掉电、真实块设备、TSAN 或业务 E2E。后续 F34/共同 C/P 接入时优先迁移风险到真实完整链路，勿永久叠加同义小测试。

结果包仅本地保留（test-results 被 .gitignore 忽略）；本源码包不包含设备镜像、二进制、构建缓存或展开回归源。核验后清除临时目录。

本版取代上一版 F10 包。生产六个文件未变；具体断言/输入增强和局限见执行记录 §10。

第二次复审补强 DirectRootAndRepeatedCheckpoints：跟踪一个实际溢出页槽，第二轮核对同槽代次增加且存活。仍六项/原 26 项/九项变异，无生产改动；详见执行记录 §11。
