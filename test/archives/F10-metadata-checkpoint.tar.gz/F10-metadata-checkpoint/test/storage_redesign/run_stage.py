#!/usr/bin/env python3
"""Temporary F10/F11 integration runner; never installs tests in production tree."""
import argparse, hashlib, json, os, pathlib, subprocess, tarfile, time, xml.etree.ElementTree as ET
p = argparse.ArgumentParser()
p.add_argument('--repo', required=True)
p.add_argument('--work', required=True)
p.add_argument('--mutations', action='store_true')
a = p.parse_args()
repo = pathlib.Path(a.repo).resolve(); work = pathlib.Path(a.work).resolve()
work.mkdir(parents=True, exist_ok=True)
tests = pathlib.Path(__file__).resolve().parent
commands = []
env = {k: v for k, v in os.environ.items() if not k.startswith('GTEST_')}
env.update(F03_WORKDIR=str(work), F07_WORKDIR=str(work), F08_WORKDIR=str(work), F09_WORKDIR=str(work), ASAN_OPTIONS='detect_leaks=1:abort_on_error=1', UBSAN_OPTIONS='halt_on_error=1')
def run(cmd, log, expected=0, timeout=600):
    start = time.monotonic()
    with (work / log).open('w') as out:
        r = subprocess.run(list(map(str, cmd)), stdout=out, stderr=subprocess.STDOUT, env=env, timeout=timeout)
    commands[:] = [entry for entry in commands if entry['log'] != log]
    commands.append({'command': list(map(str, cmd)), 'log': log, 'exit': r.returncode,
                     'elapsed_seconds': time.monotonic() - start})
    (work / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
    if r.returncode != expected:
        raise RuntimeError(f'{log}: expected {expected}, got {r.returncode}; see actual log')
def cases(xml, expected):
    cs = ET.parse(work / xml).getroot().findall('./testsuite/testcase')
    assert len(cs) == expected
    assert all(c.get('status') == 'run' and c.get('result') == 'completed' and
               not any(c.find(k) is not None for k in ('failure', 'error', 'skipped')) for c in cs)
archive = repo / 'test/archives/F09-metadata-page-writer.tar.gz'
assert hashlib.sha256(archive.read_bytes()).hexdigest() == 'f64fb7a55b4f13db64673adfce9846091b3638ed240f425821991dd7f5620913'
with tarfile.open(archive) as t:
    old = t.extractfile('F09-metadata-page-writer/test/storage_redesign/metadata_page_writer_test.cpp').read()
prefix = old.decode().split('TEST(MetadataPageWriterTest,', 1)[0]
prefix = prefix[:prefix.index('void ExpectIOError(')]
prefix = prefix.replace('#include <algorithm>', '#include <algorithm>\n#include <atomic>\n#include <thread>')
prefix = prefix.replace('OverflowWrite, Flush', 'OverflowWrite, Flush, AnchorWrite, AnchorFlush')
prefix = prefix.replace('GateKind gate_kind =', 'std::atomic<bool> anchor_written{false};\nsize_t checkpoint_writes = 0;\nGateKind gate_kind =')
prefix = prefix.replace('  gate_kind = kind;', '  checkpoint_writes = 0;\n  gate_kind = kind;')
prefix = prefix.replace('auto WaitOtherWrite()', '[[maybe_unused]] auto WaitOtherWrite()')
prefix = prefix.replace('  if (Enter(GateKind::Flush)) {',
    '  const bool anchor = anchor_written.exchange(false);\n  if ((anchor && Enter(GateKind::AnchorFlush)) || Enter(GateKind::Flush)) {')
prefix = prefix.replace('  bool metadata = offset >=', '''  const bool anchor = size == 65536 && (offset == 0 || offset == static_cast<off_t>(MIB));
  if (anchor && Enter(GateKind::AnchorWrite)) { errno = EIO; return -1; }
  anchor_written.store(anchor);
  bool metadata = offset >=''')
prefix = prefix.replace('  auto result = __real_pwrite(fd, data, size, offset);', '''  auto result = __real_pwrite(fd, data, size, offset);
  if (result > 0 && offset >= 8 * static_cast<off_t>(MIB) && offset < 40 * static_cast<off_t>(MIB) &&
      size >= 96 && std::memcmp(bytes + 80, "BUSTMETA", 8) == 0 &&
      bytes[92] == 0 && bytes[93] == 0 && bytes[94] == 0 && bytes[95] == 2) {
    std::lock_guard<std::mutex> lock(gate_mutex);
    ++checkpoint_writes;
    gate_cv.notify_all();
  }''')
# Standalone includes must make memcmp available before the wrapping functions.
prefix = prefix.replace('#include <cstdlib>', '#include <cstdlib>\n#include <cstring>')
(work / 'f09_fixture.inc').write_text(prefix)
(work / 'fixture-provenance.json').write_text(json.dumps({
    'source_archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
    'source_test_sha256': hashlib.sha256(old).hexdigest(),
    'generated_fixture_sha256': hashlib.sha256(prefix.encode()).hexdigest(),
    'reuse': 'F09 input generation and independent disk model, no copied test cases; link-only checkpoint gates'
}, indent=2) + '\n')
run(['cmake', '-S', repo, '-B', work/'build', '-DCMAKE_BUILD_TYPE=Debug', '-DCMAKE_C_COMPILER=clang-14',
     '-DCMAKE_CXX_COMPILER=clang++-14', '-DBUSTUB_SANITIZER=address,undefined', '-DCMAKE_EXE_LINKER_FLAGS=-no-pie'], 'configure.log')
run(['cmake', '--build', work/'build', '--target', 'bustub', 'gtest_main', '-j3'], 'build.log', timeout=900)
flags = ['clang++-14', '-std=c++17', '-g', '-O0', '-Wall', '-Wextra', '-Werror', '-Wno-unused-parameter',
         '-fsanitize=address,undefined', '-fno-omit-frame-pointer', '-pthread', '-I'+str(repo/'src/include'),
         '-I'+str(repo/'third_party/fmt/include'), '-I'+str(repo/'third_party/googletest/googletest/include'), '-I'+str(work)]
libs = [work/'build/lib/libbustub.a', work/'build/lib/libfmtd.a', work/'build/lib/libgtest_main.a', work/'build/lib/libgtest.a']
wraps = ['-Wl,--wrap=fdatasync', '-Wl,--wrap=pwrite']
run(flags+['-c', tests/'metadata_checkpoint_test.cpp', '-o', work/'test.o'], 'test-compile.log')
run(flags+['-no-pie', work/'test.o']+libs+wraps+['-o', work/'f10-test'], 'test-link.log')
run([work/'f10-test', '--gtest_output=xml:'+str(work/'f10.xml')], 'f10-run.log')
cases('f10.xml', 6)
print('F10/F11: six production integration scenarios passed', flush=True)
# Run unchanged predecessor tests, rather than cloning their matrices.
dependency_hashes = {'F03-bootstrap': '1e58ef0eb395a9b4d951e3eddbd2eb5c345971f1165516b4a76c69fc3be27c60', 'F07-journal-service': '862d2580ae915abb0b6fe0dc691707cc9a89d00fe27102b4b778d19628cfffa4', 'F08-metadata-engine': 'f4441d2ed561ec10006489ed7944e40519b0e987e5ad24a65eddfb6b943d7b84', 'F09-metadata-page-writer': 'f64fb7a55b4f13db64673adfce9846091b3638ed240f425821991dd7f5620913'}
for module, count, archived, cpp in [
        ('f09', 4, 'F09-metadata-page-writer', 'metadata_page_writer_test.cpp'),
        ('f03', 8, 'F03-bootstrap', 'bootstrap_store_test.cpp'),
        ('f08', 6, 'F08-metadata-engine', 'metadata_engine_test.cpp'),
        ('f07', 8, 'F07-journal-service', 'journal_service_test.cpp')]:
    dependency = repo/('test/archives/'+archived+'.tar.gz')
    assert hashlib.sha256(dependency.read_bytes()).hexdigest() == dependency_hashes[archived]
    with tarfile.open(repo/('test/archives/'+archived+'.tar.gz')) as t:
        candidates = [n for n in t.getnames() if n.endswith('/'+cpp)]
        if len(candidates) != 1:
            raise RuntimeError((module, candidates))
        source = t.extractfile(candidates[0]).read()
    (work/(module+'-regression.cpp')).write_bytes(source)
    run(flags+['-c', work/(module+'-regression.cpp'), '-o', work/(module+'.o')], module+'-compile.log')
    regression_wraps = (['-Wl,--wrap=fdatasync'] if module == 'f08' else list(wraps))
    if module == 'f03':
        regression_wraps += ['-Wl,--wrap=pread', '-Wl,--wrap=pthread_cond_clockwait']
    run(flags+['-no-pie', work/(module+'.o')]+libs+regression_wraps+['-o', work/(module+'-test')], module+'-link.log')
    run([work/(module+'-test'), '--gtest_output=xml:'+str(work/(module+'.xml'))], module+'-run.log')
    cases(module+'.xml', count)
    print(module+': unchanged archived regressions passed', flush=True)
# Mutations are defined below after the integration path and test-design review.

if a.mutations:
    definitions = [
        ('publish_without_repair_drain', 'bootstrap_store',
         'void Publish(const MetadataCheckpointRef &checkpoint) {\n    std::lock_guard<std::mutex> update(update_mutex_);',
         'void Publish(const MetadataCheckpointRef &checkpoint) {',
         'RepairCannotOverwriteNewRoot', 'new checkpoint must not publish while an older repair can still write'),
        ('omit_first_full', 'metadata_engine', 'before->lsn_ <= checkpoint_lsn',
         '(before->lsn_ <= checkpoint_lsn && false)', 'FullThenPatchRepairsChangedPages',
         'first changed page in checkpoint cycle must be FULL'),
        ('scan_old_prefix', 'journal_service', 'impl_->Open(begin, inspect, replay);',
         'impl_->Open(0, inspect, replay);', 'DirectRootAndRepeatedCheckpoints', 'missing referenced metadata checkpoint'),
        ('admit_commit_during_checkpoint', 'metadata_engine',
         'if (s.checkpointing_) {\n      throw MetadataError(MetadataErrorCode::ResourceUnavailable, "metadata checkpoint is excluding modifications");',
         'if (false && s.checkpointing_) {\n      throw MetadataError(MetadataErrorCode::ResourceUnavailable, "metadata checkpoint is excluding modifications");',
         'CheckpointGateAndCloseDrain', 'checkpoint must reject new modifications while publishing'),
        ('close_without_drain', 'metadata_engine', 'std::lock_guard<std::mutex> writeback(impl_->writeback_mutex_);',
         '// mutation: omit checkpoint drain', 'CheckpointGateAndCloseDrain', 'Close must drain checkpoint publication'),
        ('hide_page_failure', 'metadata_engine', 'if (written.outcome_ == MetadataWritebackOutcome::Failed) {',
         'if (false && written.outcome_ == MetadataWritebackOutcome::Failed) {', 'FailuresDoNotPublishOrHideCommit',
         'failed.outcome_'),
        ('keep_ready_after_anchor_failure', 'metadata_engine',
         's.ready_ = false;\n    return {MetadataCheckpointOutcome::Indeterminate, std::current_exception()};',
         'return {MetadataCheckpointOutcome::Indeterminate, std::current_exception()};',
         'FailuresDoNotPublishOrHideCommit', 'uncertain storage result must isolate the live engine'),
        ('repair_stale_root', 'bootstrap_store', 'source_image_ = std::move(image);',
         'if (generation_ == 0) { source_image_ = std::move(image); }', 'RepairCannotOverwriteNewRoot', 'background repair failed'),
        ('ignore_checkpoint_page_crc', 'metadata_engine',
         'trailer.ReadU32() == Crc32cExtend(Crc32c(body.data(), BODY), bytes + BODY, 40)',
         '(trailer.ReadU32(), true)', 'FullThenPatchRepairsChangedPages',
         'required checkpoint page corruption must not silently replay old history'),
    ]
    evidence = []
    for name, unit, old, new, test, marker in definitions:
        original = (repo/('src/storage/disk/'+unit+'.cpp')).read_text()
        if original.count(old) != 1:
            raise RuntimeError('mutation source drift: '+name)
        source = original.replace(old, new)
        cpp = work/(name+'.cpp'); cpp.write_text(source)
        run(flags+['-c', cpp, '-o', work/(name+'.o')], name+'-compile.log')
        exe = work/name
        run(flags+['-no-pie', work/'test.o', work/(name+'.o')]+libs+wraps+['-o',exe], name+'-link.log')
        xml = name+'.xml'
        run([exe, '--gtest_filter=MetadataCheckpointTest.'+test, '--gtest_output=xml:'+str(work/xml)],
            name+'-run.log', expected=1, timeout=120)
        cs = ET.parse(work/xml).getroot().findall('./testsuite/testcase')
        failures = [f.text or '' for c in cs for f in c.findall('failure')]
        if len(cs) != 1 or not any(marker in f for f in failures):
            raise RuntimeError(name+': failed outside its intended oracle')
        evidence.append({'name':name, 'test':test, 'marker':marker, 'replacement':{'old':old,'new':new},
                         'source_sha256':hashlib.sha256(source.encode()).hexdigest(), 'exit':1})
        (work/'mutations.json').write_text(json.dumps(evidence,indent=2)+'\n')
        print('mutation caught: '+name, flush=True)
