// Fixture comes from the unchanged F09 archive; runner verifies its hash.
#include "f09_fixture.inc"

auto ReadBytes(const Image &image, uint64_t offset, size_t size) -> std::vector<uint8_t> {
  std::vector<uint8_t> bytes(size);
  int fd = open(image.path.c_str(), O_RDONLY);
  Require(fd >= 0, "cannot open independent disk reader");
  auto count = pread(fd, bytes.data(), bytes.size(), offset);
  close(fd);
  Require(count == static_cast<ssize_t>(size), "short independent disk read");
  return bytes;
}
auto Field(const std::vector<uint8_t> &bytes, size_t offset, size_t width = 8) -> uint64_t {
  Require(offset + width <= bytes.size(), "field outside independent input");
  uint64_t value = 0;
  for (size_t n = 0; n < width; ++n) {
    value = (value << 8) | bytes[offset + n];
  }
  return value;
}
struct RootRef {
  uint64_t generation;
  uint64_t position;
  size_t slot;
};
auto Root(const Image &image) -> RootRef {
  RootRef latest{0, 0, 0};
  for (size_t slot = 0; slot < 2; ++slot) {
    auto bytes = ReadBytes(image, slot * MIB, 65536);
    uint32_t crc = ~0U;
    for (size_t n = 0; n < bytes.size() - 4; ++n) {
      crc ^= bytes[n];
      for (size_t b = 0; b < 8; ++b) {
        crc = (crc >> 1) ^ ((crc & 1U) ? 0x82f63b78U : 0U);
      }
    }
    Require(Field(bytes, 65532, 4) == static_cast<uint32_t>(~crc), "bootstrap oracle checksum mismatch");
    auto format = Field(bytes, 8, 4);
    Require(format == 1 || format == 2, "unexpected bootstrap oracle version");
    if (format == 2) {
      Require(Field(bytes, 12, 4) == 144, "unexpected checkpoint reference length");
      for (size_t n = 128; n < 144; ++n) {
        Require(bytes[n] == 73, "checkpoint reference has wrong Journal identity");
      }
      if (Field(bytes, 112) > latest.generation) {
        latest = {Field(bytes, 112), Field(bytes, 120), slot};
      }
    }
  }
  return latest;
}
void Flip(const Image &image, uint64_t offset) {
  auto bytes = ReadBytes(image, offset, 1);
  bytes[0] ^= 0x40;
  int fd = open(image.path.c_str(), O_RDWR);
  Require(fd >= 0, "cannot open failure injection image");
  auto written = pwrite(fd, bytes.data(), 1, offset);
  auto flushed = fdatasync(fd);
  close(fd);
  Require(written == 1 && flushed == 0, "failure injection did not persist");
}
auto Contents(const MetadataSnapshot &snapshot) -> Model {
  Model result;
  for (const auto &entry : snapshot.Scan({0, 0, 0}, 4096)) {
    result.emplace(Key{entry.key_.category_, entry.key_.owner_, entry.key_.item_}, entry.value_);
  }
  return result;
}
void Checkpoint(MetadataEngine &engine, size_t bound) {
  auto result = engine.Checkpoint(bound);
  Require(result.outcome_ == MetadataCheckpointOutcome::Durable && !result.error_, "checkpoint must publish durably");
}
void CheckEIO(std::exception_ptr error) {
  ASSERT_TRUE(error);
  try {
    std::rethrow_exception(error);
  } catch (const std::system_error &e) {
    EXPECT_EQ(e.code().value(), EIO);
  }
}
void AwaitRepair(BootstrapStore &bootstrap) {
  const auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(10);
  while (std::chrono::steady_clock::now() < deadline) {
    auto status = bootstrap.Status();
    if (status.repair_state_ == BootstrapRepairState::Succeeded) {
      Require(!status.redundancy_lost_, "repair reported success without current redundancy");
      return;
    }
    Require(status.repair_state_ != BootstrapRepairState::Failed, "background repair failed");
    std::this_thread::yield();
  }
  throw std::runtime_error("repair watchdog expired");
}

TEST(MetadataCheckpointTest, DirectRootAndRepeatedCheckpoints) {
  Arm(GateKind::None, false, false);
  Image image;
  Model model;
  RootRef prior{};
  {
    Stack stack(image.path, true);
    MetadataEngine engine(stack.bootstrap, stack.journal_id, stack.journal, stack.options);
    engine.Create();
    Apply(engine, Fill(350, 13), &model);
    auto original = engine.Read();
    auto old_model = model;
    Checkpoint(engine, 7);
    prior = Root(image);
    EXPECT_EQ(prior.generation, 1U);
    const auto first_disk = DiskView(image);
    EXPECT_EQ(first_disk.values, model);
    // Track a concrete live overflow slot, not merely a growing generation
    // somewhere in the file. The next cycle must reuse this same slot.
    auto slot = std::find_if(first_disk.pages.begin(), first_disk.pages.end(),
                             [](const Page &page) { return BE(page, 4044) == 4; });
    ASSERT_NE(slot, first_disk.pages.end());
    const size_t reused_id = static_cast<size_t>(slot - first_disk.pages.begin());
    const auto prior_generation = BE(*slot, 4056, 8);
    // Delete and refill enough data to exercise physical slot reuse across cycles.
    std::vector<MetadataMutation> mutations;
    for (uint64_t n = 0; n < 350; ++n) {
      mutations.push_back({KeyFor(n), std::nullopt});
    }
    auto fresh = Fill(390, 71);
    mutations.insert(mutations.end(), fresh.begin(), fresh.end());
    Apply(engine, mutations, &model);
    Checkpoint(engine, 11);
    EXPECT_EQ(Root(image).generation, 2U);
    const auto second_disk = DiskView(image);
    EXPECT_EQ(second_disk.values, model);
    ASSERT_LT(reused_id, second_disk.pages.size());
    EXPECT_GT(BE(second_disk.pages[reused_id], 4056, 8), prior_generation)
        << "the tracked checkpoint page slot must actually be reused";
    EXPECT_NE(BE(second_disk.pages[reused_id], 4044), 5U)
        << "the tracked slot must contain live data in the new checkpoint";
    EXPECT_EQ(Contents(original), old_model);
    Apply(engine, {{KeyFor(3), Value(17019, 9)}, {KeyFor(90), std::nullopt}}, &model);
  }
  // An obsolete checkpoint itself is damaged: latest direct recovery must not
  // read/replay that prefix. This is NOT a claim about corrupt required history.
  Flip(image, 8 * MIB + prior.position + 70);
  Stack stack(image.path, false);
  MetadataEngine recovered(stack.bootstrap, stack.journal_id, stack.journal, stack.options);
  recovered.Open();
  EXPECT_EQ(Contents(recovered.Read()), model) << "direct recovery must use the latest referenced checkpoint";
  Apply(recovered, {{KeyFor(500), Value(201, 8)}}, &model);
  Checkpoint(recovered, 9);
  EXPECT_EQ(Root(image).generation, 3U);
  EXPECT_EQ(DiskView(image).values, model);
}

TEST(MetadataCheckpointTest, FullThenPatchRepairsChangedPages) {
  Arm(GateKind::None, false, false);
  Image image;
  Model model;
  uint64_t first = 0, second = 0;
  RootRef checkpoint{};
  std::set<uint32_t> touched;
  {
    Stack stack(image.path, true);
    MetadataEngine engine(stack.bootstrap, stack.journal_id, stack.journal, stack.options);
    engine.Create();
    Apply(engine, Fill(250, 7), &model);
    Checkpoint(engine, 32);
    checkpoint = Root(image);
    for (uint64_t *lsn : {&first, &second}) {
      auto key = KeyFor(3);
      auto value = model.at({key.category_, key.owner_, key.item_});
      value[7] ^= lsn == &first ? std::byte{0x21} : std::byte{0x52};
      auto result = engine.Commit(engine.Read(), {{key, value}});
      ASSERT_EQ(result.outcome_, JournalOutcome::Durable);
      *lsn = result.begin_;
      model[{key.category_, key.owner_, key.item_}] = value;
    }
    Drain(engine, 32);
    engine.Close();
    bool found_first = false, found_patch = false;
    // F07 supplies opaque record bytes; expected B record kinds are independent
    // of B's own codec and its checkpoint decision logic.
    JournalService journal(stack.bootstrap, stack.journal_id, stack.journal);
    journal.OpenFrom(checkpoint.position, {}, [&](uint64_t lsn, const JournalRecords &records) {
      if (lsn != first && lsn != second) {
        return;
      }
      for (size_t n = 1; n < records.size(); ++n) {
        std::vector<uint8_t> bytes(records[n].size());
        std::memcpy(bytes.data(), records[n].data(), bytes.size());
        auto kind = Field(bytes, 0, 4);
        touched.insert(static_cast<uint32_t>(Field(bytes, 4, 4)));
        if (lsn == first) {
          EXPECT_EQ(kind, 1U) << "first changed page in checkpoint cycle must be FULL";
          found_first = true;
        } else if (kind == 2) {
          found_patch = true;
        }
      }
    });
    ASSERT_TRUE(found_first);
    ASSERT_TRUE(found_patch) << "small subsequent changes should retain PATCH";
  }
  ASSERT_FALSE(touched.empty());
  Flip(image, META_START + *touched.begin() * 4096ULL + 33);
  {
    Stack stack(image.path, false);
    MetadataEngine recovered(stack.bootstrap, stack.journal_id, stack.journal, stack.options);
    recovered.Open();
    EXPECT_EQ(Contents(recovered.Read()), model) << "FULL must rebuild a changed damaged page";
    Drain(recovered, 32);
  }
  auto disk = DiskView(image);
  uint32_t untouched = 0;
  while (untouched < disk.pages.size() && touched.count(untouched)) {
    ++untouched;
  }
  ASSERT_LT(untouched, disk.pages.size());
  Flip(image, META_START + untouched * 4096ULL + 33);
  Stack stack(image.path, false);
  MetadataEngine damaged(stack.bootstrap, stack.journal_id, stack.journal, stack.options);
  EXPECT_THROW(damaged.Open(), MetadataError)
      << "required checkpoint page corruption must not silently replay old history";
}

TEST(MetadataCheckpointTest, FailuresDoNotPublishOrHideCommit) {
  for (auto failure : {GateKind::PageWrite, GateKind::Flush, GateKind::AnchorWrite, GateKind::AnchorFlush}) {
    Arm(GateKind::None, false, false);
    Image image;
    Model model;
    {
      Stack stack(image.path, true);
      MetadataEngine engine(stack.bootstrap, stack.journal_id, stack.journal, stack.options);
      engine.Create();
      Apply(engine, Fill(80, 1), &model);
      Checkpoint(engine, 32);
      Apply(engine, {{KeyFor(7), Value(14011, 3)}}, &model);
      auto old = engine.Read();
      auto before = Root(image);
      if (failure == GateKind::Flush) {
        Drain(engine, 32);  // Only the checkpoint Journal Flush remains first.
      }
      Arm(failure, false, true);
      auto failed = engine.Checkpoint(1024);
      EXPECT_EQ(failed.outcome_, (failure == GateKind::AnchorWrite || failure == GateKind::AnchorFlush)
                                     ? MetadataCheckpointOutcome::Indeterminate
                                     : MetadataCheckpointOutcome::NotPublished);
      CheckEIO(failed.error_);
      if (failure != GateKind::AnchorFlush) {
        EXPECT_EQ(Root(image).generation, before.generation) << "failed checkpoint must not publish a new root";
      } else {
        // Readable bytes are not proof of durability after a failed Flush.
        EXPECT_EQ(Root(image).generation, before.generation + 1);
      }
      EXPECT_EQ(Contents(old), model);
      if (failure == GateKind::PageWrite) {
        EXPECT_EQ(Contents(engine.Read()), model);
        Checkpoint(engine, 32);
      } else {
        EXPECT_THROW(engine.Read(), MetadataError) << "uncertain storage result must isolate the live engine";
      }
    }
    Arm(GateKind::None, false, false);
    Stack stack(image.path, false);
    MetadataEngine recovered(stack.bootstrap, stack.journal_id, stack.journal, stack.options);
    recovered.Open();
    EXPECT_EQ(Contents(recovered.Read()), model) << "failure cannot revoke previously durable commits";
    Checkpoint(recovered, 32);
  }
}

TEST(MetadataCheckpointTest, CheckpointGateAndCloseDrain) {
  Arm(GateKind::None, false, false);
  Image image;
  Model model;
  {
    Stack stack(image.path, true);
    MetadataEngine engine(stack.bootstrap, stack.journal_id, stack.journal, stack.options);
    engine.Create();
    Apply(engine, Fill(80, 17), &model);
    auto old = engine.Read();
    std::future<MetadataCheckpointResult> checkpoint;
    std::future<void> closing;
    std::promise<void> close_started;
    ReleaseOnExit release;
    Arm(GateKind::AnchorFlush, true, false);
    checkpoint = std::async(std::launch::async, [&] { return engine.Checkpoint(1024); });
    ASSERT_TRUE(WaitEntered());
    EXPECT_EQ(Contents(engine.Read()), model);
    try {
      engine.Commit(old, {{KeyFor(3), Value(31, 8)}});
      FAIL() << "checkpoint must reject new modifications while publishing";
    } catch (const MetadataError &e) {
      EXPECT_EQ(e.Code(), MetadataErrorCode::ResourceUnavailable);
    }
    EXPECT_EQ(checkpoint.wait_for(std::chrono::milliseconds(0)), std::future_status::timeout)
        << "checkpoint must wait for bootstrap Flush";
    closing = std::async(std::launch::async, [&] {
      close_started.set_value();
      engine.Close();
    });
    close_started.get_future().wait();
    EXPECT_EQ(closing.wait_for(std::chrono::milliseconds(100)), std::future_status::timeout)
        << "Close must drain checkpoint publication";
    Release();
    ASSERT_EQ(checkpoint.get().outcome_, MetadataCheckpointOutcome::Durable);
    closing.get();
  }
  Arm(GateKind::None, false, false);
  Stack stack(image.path, false);
  MetadataEngine recovered(stack.bootstrap, stack.journal_id, stack.journal, stack.options);
  recovered.Open();
  EXPECT_EQ(Contents(recovered.Read()), model);
}

TEST(MetadataCheckpointTest, RepairCannotOverwriteNewRoot) {
  Arm(GateKind::None, false, false);
  Image image;
  Model model;
  {
    Stack stack(image.path, true);
    MetadataEngine engine(stack.bootstrap, stack.journal_id, stack.journal, stack.options);
    engine.Create();
    Apply(engine, Fill(90, 19), &model);
    Checkpoint(engine, 32);
    std::future<MetadataCheckpointResult> publishing;
    ReleaseOnExit release;
    Arm(GateKind::AnchorWrite, true, false);
    stack.bootstrap.StartRepair({2, std::chrono::milliseconds(1), std::chrono::milliseconds(1000)});
    ASSERT_TRUE(WaitEntered());
    Apply(engine, {{KeyFor(5), Value(3101, 8)}}, &model);
    publishing = std::async(std::launch::async, [&] { return engine.Checkpoint(1024); });
    {
      std::unique_lock<std::mutex> lock(gate_mutex);
      ASSERT_TRUE(gate_cv.wait_for(lock, std::chrono::seconds(10), [] { return checkpoint_writes > 0; }))
          << "new checkpoint must reach its Journal while old repair is paused";
    }
    // The Journal has progressed, but the old repair still owns a pending slot
    // write. A new root must not be reported durable until that write drains.
    EXPECT_EQ(publishing.wait_for(std::chrono::seconds(1)), std::future_status::timeout)
        << "new checkpoint must not publish while an older repair can still write";
    Release();
    ASSERT_EQ(publishing.get().outcome_, MetadataCheckpointOutcome::Durable);
    ASSERT_EQ(Root(image).generation, 2U);
    // A completed coordinator must be usable for a later publication too.
    stack.bootstrap.StartRepair({2, std::chrono::milliseconds(1), std::chrono::milliseconds(1000)});
    AwaitRepair(stack.bootstrap);
    EXPECT_EQ(ReadBytes(image, 0, 65536), ReadBytes(image, MIB, 65536))
        << "repair must copy the latest root, never its initial source snapshot";
  }
  Arm(GateKind::None, false, false);
  Stack stack(image.path, false);
  MetadataEngine recovered(stack.bootstrap, stack.journal_id, stack.journal, stack.options);
  recovered.Open();
  EXPECT_EQ(Contents(recovered.Read()), model);
}

TEST(MetadataCheckpointTest, DamagedRootAndDamagedTargetDiffer) {
  for (bool damage_root : {true, false}) {
    Arm(GateKind::None, false, false);
    Image image;
    Model model;
    RootRef latest{};
    {
      Stack stack(image.path, true);
      MetadataEngine engine(stack.bootstrap, stack.journal_id, stack.journal, stack.options);
      engine.Create();
      Apply(engine, Fill(90, 29), &model);
      Checkpoint(engine, 32);
      Apply(engine, {{KeyFor(6), Value(19011, 91)}}, &model);
      Checkpoint(engine, 32);
      latest = Root(image);
      ASSERT_EQ(latest.generation, 2U);
    }
    Flip(image, damage_root ? latest.slot * MIB + 120 : 8 * MIB + latest.position + 70);
    Stack stack(image.path, false);
    MetadataEngine recovered(stack.bootstrap, stack.journal_id, stack.journal, stack.options);
    if (damage_root) {
      recovered.Open();
      EXPECT_EQ(Contents(recovered.Read()), model) << "old valid root must still replay every later durable commit";
    } else {
      EXPECT_THROW(recovered.Open(), JournalError) << "valid latest root with corrupt target must not downgrade";
    }
  }
}
}  // namespace
}  // namespace bustub
