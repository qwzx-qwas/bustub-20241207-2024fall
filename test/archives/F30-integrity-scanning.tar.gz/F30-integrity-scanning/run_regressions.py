#!/usr/bin/env python3
"""Adapt frozen F29/S8 workloads; retain byte/capacity/recovery oracles."""
import argparse,pathlib,tarfile,subprocess
p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--build',required=True);p.add_argument('--out',required=True);a=p.parse_args()
r=pathlib.Path(a.repo).resolve();out=pathlib.Path(a.out).resolve();out.mkdir(parents=True,exist_ok=False)
with tarfile.open(r/'test/archives/F29-log-cleaning.tar.gz') as t:t.extractall(out,filter='data')
f=out/'F29-log-cleaning/run_stage.py';s=f.read_text();start=s.index("if (pkg/'MANIFEST.json').exists():");end=s.index('out.mkdir',start);s=s[:start]+s[end:]
s=s.replace("['clang++-14','-std=c++17'", "['/tmp/bustub-gcc16/bin/x86_64-focal-linux-gnu-g++','--sysroot=/','-isystem','/usr/include/x86_64-linux-gnu','-Wno-dangling-else','-std=c++17'")
s=s.replace("ASAN_OPTIONS='detect_leaks=0:abort_on_error=1'", "ASAN_OPTIONS='detect_leaks=1:abort_on_error=1',LD_LIBRARY_PATH='/tmp/bustub-gcc16/native-runtime'")
s=s.replace("a.case or 'F29Cleaning.*'", "a.case or 'F29Cleaning.*:S8Objects.*'").replace('1 if a.case else 10','1 if a.case else 18')
marker="(out/'s8-adapted.cpp').write_text(s)"
s=s.replace(marker,"s=s.replace('const auto count = std::min<size_t>(4 * unit, replacement.size() - written);', 'const auto count = std::min<size_t>(2 * unit, replacement.size() - written);')\n"+marker)
f.write_text(s)
subprocess.run(['python3',str(f),'--repo',str(r),'--build',str(pathlib.Path(a.build).resolve()),'--out',str(out/'results')],check=True)
