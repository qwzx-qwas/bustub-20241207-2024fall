#include "common/byte_codec.h"
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wdangling-else"
#include "f27-adapted.cpp"
#pragma GCC diagnostic pop
#include <atomic>
namespace {
std::atomic<size_t> data_writes{0};
std::mutex read_mutex;
std::condition_variable read_cv;
bool hold_read = false, read_entered = false, read_release = true;
off_t read_begin = 6 * MIB, read_end = INT64_MAX, read_offset = 0;
void ReadGate(bool arm, off_t begin = 6 * MIB, off_t end = INT64_MAX) {
  std::lock_guard lock(read_mutex);
  hold_read = arm;
  read_begin = begin;
  read_end = end;
  read_entered = false;
  read_release = !arm;
  read_cv.notify_all();
}
} // namespace
extern "C" ssize_t __wrap_pwrite(int fd, const void *buf, size_t size,
                                 off_t off) {
  if (Direct(fd) && off >= static_cast<off_t>(6 * MIB))
    ++data_writes;
  return f27_pwrite(fd, buf, size, off);
}
extern "C" ssize_t __wrap_pread(int fd, void *buf, size_t size, off_t off) {
  if (Direct(fd)) {
    std::unique_lock lock(read_mutex);
    if (hold_read && off >= read_begin && off < read_end) {
      hold_read = false;
      read_entered = true;
      read_offset = off;
      read_cv.notify_all();
      read_cv.wait(lock, [] { return read_release; });
    }
  }
  return f27_pread(fd, buf, size, off);
}
namespace {
struct CheckedStore {
  Image image;
  NodeStorageOptions options{Options(image)};
  std::unique_ptr<NodeStorage> node;
  ObjectKey key{};
  uint64_t capacity_units{0};
  explicit CheckedStore(bool scan = false, unsigned factor = 1) {
    options.objects_->allocator_.allocation_bytes_ *= factor;
    options.transactions_->deferred_max_bytes_ = 0;
    options.transactions_->gc_interval_ = scan ? 2ms : 1h;
    options.transactions_->integrity_scan_ = scan;
    options.external_buffer_bytes_ = 2 * MIB;
    options.memory_budget_ = ResourceBudgetOptions{64 * MIB, 4096, 4 * MIB};
  }
  uint64_t Unit() const {
    return options.objects_->allocator_.allocation_bytes_;
  }
  void Create() {
    node = std::make_unique<NodeStorage>(options);
    auto layout = Layout(options);
    if (capacity_units)
      layout.regions_[2] = Range(6 * MIB, capacity_units * Unit());
    node->Create(layout);
    node->InitializeObjects();
    key = New(*node, 17);
  }
  void Reopen() {
    node->Close();
    node.reset();
    node = std::make_unique<NodeStorage>(options);
    node->Open();
  }
  void Put(uint64_t offset, const Bytes &v, bool common = true) {
    auto op = Change(ObjectOperation::Write, key, offset, v);
    op.common_only_ = common;
    Commit(*node, {{op}, {}});
  }
  auto Location(uint64_t offset) -> ObjectDataLocation {
    return *node->Objects().Resolve(key, offset, 1).spans_.front().data_;
  }
  void Flip(uint64_t data_offset) {
    auto b = image.Read(6 * MIB + data_offset, 1);
    b[0] ^= 0x40;
    image.Write(6 * MIB + data_offset, b);
  }
  ~CheckedStore() {
    Reset();
    ReadGate(false);
    if (node)
      try {
        node->Close();
      } catch (...) {
      }
  }
};
template <class F> bool Until(F f) {
  const auto end = std::chrono::steady_clock::now() + 15s;
  do {
    if (f())
      return true;
    std::this_thread::sleep_for(2ms);
  } while (std::chrono::steady_clock::now() < end);
  return f();
}
TEST(F30Integrity, NonzeroSlicesPaddingAndRestartAcrossUnitGeometries) {
  for (auto factor : {1U, 2U}) {
    CheckedStore h(false, factor);
    h.Create();
    auto u = h.Unit();
    auto model = Value(2 * u + 173, 11);
    auto staged = h.node->WriteObjectData(model.data(), model.size());
    staged.Wait();
    Durable(h.node->PublishObjectData(h.node->Objects(), h.key, 3 * u + 79,
                                      staged));
    EXPECT_EQ(Read(*h.node, h.key, 3 * u + 79, model.size()), model);
    auto replacement = Value(509, 41);
    h.Put(4 * u + 127, replacement);
    std::copy(replacement.begin(), replacement.end(), model.begin() + u + 48);
    h.Reopen();
    EXPECT_EQ(Read(*h.node, h.key, 3 * u + 79, model.size()), model);
    EXPECT_EQ(Read(*h.node, h.key, 0, 113), Bytes(113));
  }
}
TEST(F30Integrity,
     StoredExpectedRejectsCorruptionForOwnedFrameAndPrefetchReads) {
  for (int mode = 0; mode < 3; ++mode) {
    CheckedStore h;
    h.Create();
    auto u = h.Unit();
    auto original = Value(u, 31);
    h.Put(2 * u, original);
    const auto where = h.Location(2 * u);
    h.node->Close();
    h.node.reset();
    h.Flip(where.offset_ + u / 2 + 13);
    h.node = std::make_unique<NodeStorage>(h.options);
    h.node->Open();
    if (mode == 0) {
      auto read = h.node->ReadObject(h.node->Objects(), h.key, 2 * u + 97, 73);
      read.Wait();
      Bytes out(73);
      EXPECT_THROW(read.CopyTo(out.data(), out.size()), MetadataError);
    } else {
      const auto alignment = h.node->PageIO().memory_alignment_;
      auto frame = std::make_shared<Bytes>(u + alignment - 1);
      const auto address = reinterpret_cast<uintptr_t>(frame->data());
      auto *p = frame->data() + (alignment - address % alignment) % alignment;
      ObjectReadTarget target{p, static_cast<size_t>(u), frame};
      if (mode == 1) {
        auto read =
            h.node->ReadObjectInto(h.node->Objects(), h.key, 2 * u, u, target);
        EXPECT_THROW(read.Finish(), MetadataError);
      } else {
        auto finished = std::make_shared<std::promise<std::exception_ptr>>();
        auto result = finished->get_future();
        ASSERT_TRUE(h.node->PrefetchObjectInto(
            h.node->Objects(), h.key, 2 * u, u, target,
            [finished](auto e) { finished->set_value(e); }));
        ASSERT_EQ(result.wait_for(15s), std::future_status::ready);
        EXPECT_TRUE(result.get());
      }
    }
    const auto state = h.node->State();
    EXPECT_EQ(state.phase_, NodeStoragePhase::Failed);
    EXPECT_TRUE(state.conditions_ &
                static_cast<uint32_t>(NodeStorageCondition::Corruption));
  }
}
TEST(F30Integrity, ColdScanFindsPersistedDataDamageWithoutClientRead) {
  CheckedStore h;
  h.Create();
  auto u = h.Unit();
  h.Put(5 * u, Value(3 * u, 19));
  auto loc = h.Location(6 * u);
  h.node->Close();
  h.node.reset();
  h.Flip(loc.offset_ + 117);
  h.options.transactions_->integrity_scan_ = true;
  h.options.transactions_->gc_interval_ = 2ms;
  h.node = std::make_unique<NodeStorage>(h.options);
  h.node->Open();
  ASSERT_TRUE(Until(
      [&] { return h.node->State().phase_ == NodeStoragePhase::Failed; }));
  try {
    std::rethrow_exception(h.node->State().error_);
  } catch (const MetadataError &e) {
    EXPECT_NE(std::string(e.what()).find("allocation="), std::string::npos);
    EXPECT_NE(std::string(e.what()).find("expected="), std::string::npos);
  }
}
TEST(F30Integrity, DeferredScansJournalUntilDataCompletionThenVerifiesData) {
  CheckedStore h(true);
  h.options.transactions_->deferred_max_bytes_ = 8 * h.Unit();
  h.Create();
  auto u = h.Unit();
  Arm(Gate::Write);
  const auto body = Value(u + 233, 71);
  h.Put(3 * u + 43, body, false);
  ASSERT_TRUE(Entered());
  EXPECT_EQ(Read(*h.node, h.key, 3 * u + 43, body.size()), body);
  ASSERT_TRUE(
      Until([&] { return h.node->State().integrity_.journal_bytes_ != 0; }));
  EXPECT_EQ(h.node->State().phase_, NodeStoragePhase::Serving);
  Release();
  Settled(*h.node, h.key, 3 * u + 43);
  Reset();
  ASSERT_TRUE(
      Until([&] { return h.node->State().integrity_.data_bytes_ != 0; }));
  const auto loc = h.Location(3 * u + 43);
  h.Flip(loc.offset_ + 11);
  ASSERT_TRUE(Until(
      [&] { return h.node->State().phase_ == NodeStoragePhase::Failed; }));
}
TEST(F30Integrity, SharedUnitsSurvivePartialReleaseAndPhysicalReuse) {
  CheckedStore h;
  h.capacity_units = 3;
  h.Create();
  auto u = h.Unit();
  auto body = Value(3 * u, 12);
  h.Put(2 * u, body);
  const auto loc = h.Location(2 * u);
  const auto shared = New(*h.node, 18);
  Durable(h.node->ResizeObject(h.node->Objects(), shared, u));
  Durable(
      h.node->ShareObjectRange(h.node->Objects(), h.key, shared, 2 * u, u, 0));
  Commit(*h.node, {{Change(ObjectOperation::Remove, h.key, 0)}, {}});
  const auto released =
      h.node->ReclaimObject(h.node->Objects(), h.key, loc.allocation_);
  EXPECT_EQ(released.released_bytes_, 2 * u);
  EXPECT_EQ(Read(*h.node, shared, 0, u), Bytes(body.begin(), body.begin() + u));
  const auto fresh = New(*h.node, 19);
  const auto different = Value(2 * u, 91);
  Commit(*h.node, {{Change(ObjectOperation::Write, fresh, 0, different)}, {}});
  auto freshloc = *h.node->Objects().Resolve(fresh, 0, 1).spans_.front().data_;
  EXPECT_EQ(freshloc.offset_, loc.offset_ + u)
      << "test must prove actual physical reuse";
  h.Reopen();
  EXPECT_EQ(Read(*h.node, shared, 0, u), Bytes(body.begin(), body.begin() + u));
  EXPECT_EQ(Read(*h.node, fresh, 0, 2 * u), different);
}
TEST(F30Integrity,
     ChecksumCapacityRejectsBeforeBodyIOAndReservationRemainsReusable) {
  CheckedStore h;
  h.options.objects_->mapping_.max_update_entries_ = 16;
  h.options.transactions_->deferred_max_bytes_ = 8 * h.Unit();
  h.Create();
  auto u = h.Unit();
  auto before = data_writes.load();
  auto t = Submit(
      *h.node,
      {{Change(ObjectOperation::Write, h.key, 0, Value(20 * u, 53))}, {}});
  EXPECT_EQ(Finish(t).outcome_, JournalOutcome::NotCommitted);
  EXPECT_EQ(data_writes.load(), before);
  EXPECT_EQ(h.node->Objects().Describe(h.key).size_, 0U);
  // Mixed Common + Deferred fits without the task descriptor, but exceeds the
  // same object mutation budget once that required record is counted.
  const auto other = New(*h.node, 18);
  auto common = Change(ObjectOperation::Write, h.key, 0, Value(u, 23));
  common.common_only_ = true;
  auto deferred = Change(ObjectOperation::Write, other, 0, Value(7 * u, 67));
  deferred.common_only_ = false;
  auto mixed = Submit(*h.node, {{common, deferred}, {}});
  EXPECT_EQ(Finish(mixed).outcome_, JournalOutcome::NotCommitted);
  EXPECT_EQ(data_writes.load(), before)
      << "mixed transaction must reject before its Common body IO";
  EXPECT_EQ(h.node->Objects().Describe(h.key).size_, 0U);
  EXPECT_EQ(h.node->Objects().Describe(other).size_, 0U);
  h.Put(3 * u, Value(u, 43));
  EXPECT_EQ(Read(*h.node, h.key, 3 * u, u), Value(u, 43));
}
TEST(F30Integrity, ScannerPinPreventsEarlyReuseAndCloseDrainsAcceptedIO) {
  CheckedStore h;
  h.Create();
  auto u = h.Unit();
  h.Put(0, Value(2 * u, 35));
  auto loc = h.Location(0);
  h.node->Close();
  h.node.reset();
  h.options.transactions_->integrity_scan_ = true;
  h.options.transactions_->gc_interval_ = 2ms;
  ReadGate(true);
  h.node = std::make_unique<NodeStorage>(h.options);
  h.node->Open();
  {
    std::unique_lock lock(read_mutex);
    ASSERT_TRUE(read_cv.wait_for(lock, 15s, [] { return read_entered; }));
  }
  Commit(*h.node, {{Change(ObjectOperation::Remove, h.key, 0)}, {}});
  auto reclaimed =
      h.node->ReclaimObject(h.node->Objects(), h.key, loc.allocation_);
  EXPECT_GT(reclaimed.pinned_bytes_, 0U);
  EXPECT_LT(reclaimed.released_bytes_, 2 * u);
  auto closed = std::async(std::launch::async, [&] { h.node->Close(); });
  EXPECT_TRUE(Until(
      [&] { return h.node->State().phase_ == NodeStoragePhase::Draining; }));
  EXPECT_EQ(closed.wait_for(0ms), std::future_status::timeout);
  ReadGate(false);
  ASSERT_EQ(closed.wait_for(15s), std::future_status::ready);
  EXPECT_NO_THROW(closed.get());
}
TEST(F30Integrity, LegacyWithoutExpectedCRCIsReportedUncovered) {
  CheckedStore h(true);
  h.Create();
  // Explicit legacy image fixture: v4 control and no Data allocations yet.
  ByteWriter w;
  w.PutU64(0x4253544f424a4d50ULL);
  w.PutU64(4);
  w.PutU64(h.key.space_);
  Durable(h.node->Commit(h.node->Read(), {{{13, 0, 0}, w.Take()}}));
  h.Reopen();
  const auto u = h.Unit();
  h.Put(2 * u, Value(u, 62));
  ASSERT_TRUE(
      Until([&] { return h.node->State().integrity_.uncovered_bytes_ >= u; }));
  EXPECT_EQ(h.node->State().integrity_.data_bytes_, 0U);
  EXPECT_EQ(Read(*h.node, h.key, 2 * u, u), Value(u, 62));
  EXPECT_EQ(h.node->State().phase_, NodeStoragePhase::Serving);
}
TEST(F30Integrity, BColdPageDamageIsDetectedOutsideTheMetadataCache) {
  // One admitted scan can be completed by its polling owner, Writeback, or
  // Checkpoint. All must report the damage before accepting further work.
  for (int mode = 0; mode < 3; ++mode) {
    SCOPED_TRACE(mode);
    CheckedStore h(true);
    h.Create();
    h.Put(2 * h.Unit(), Value(h.Unit(), 87));
    ASSERT_TRUE(Until([&] {
      try {
        return h.node->Writeback(256).outcome_ !=
               MetadataWritebackOutcome::Failed;
      } catch (const MetadataError &e) {
        if (e.Code() != MetadataErrorCode::ResourceUnavailable) throw;
        return false;
      }
    }));
    ReadGate(true, 2 * MIB, JOURNAL_START);
    off_t page_offset;
    {
      std::unique_lock lock(read_mutex);
      ASSERT_TRUE(read_cv.wait_for(lock, 15s, [] { return read_entered; }));
      page_offset = read_offset;
    }
    auto byte = h.image.Read(page_offset + 109, 1);
    byte[0] ^= 0x80;
    h.image.Write(page_offset + 109, byte);
    if (mode == 0) {
      ReadGate(false);
      ASSERT_TRUE(Until(
          [&] { return h.node->State().phase_ == NodeStoragePhase::Failed; }));
    } else {
      struct Outcome {
        bool failed;
        std::exception_ptr error;
        NodeStorageView state;
      };
      auto entered = std::make_shared<std::promise<void>>();
      auto started = entered->get_future();
      auto finished = std::make_shared<std::promise<Outcome>>();
      auto result = finished->get_future();
      // Existing Store maintenance runs after ScrubRound on the same owner.
      // It cannot poll the scan again before this callback reports the result.
      h.node->SetStoreMaintenance([node = h.node.get(), mode, entered, finished,
                                   executed = std::make_shared<bool>(false)] {
        if (std::exchange(*executed, true)) return;
        entered->set_value();
        try {
          if (mode == 1) {
            const auto written = node->Writeback(256);
            finished->set_value({written.outcome_ == MetadataWritebackOutcome::Failed,
                                 written.error_, node->State()});
          } else {
            const auto checkpoint = node->Checkpoint(256);
            finished->set_value({checkpoint.outcome_ == MetadataCheckpointOutcome::NotPublished,
                                 checkpoint.error_, node->State()});
          }
        } catch (...) {
          finished->set_exception(std::current_exception());
        }
      });
      ASSERT_EQ(started.wait_for(15s), std::future_status::ready);
      ReadGate(false);
      ASSERT_EQ(result.wait_for(15s), std::future_status::ready);
      h.node->SetStoreMaintenance({});
      std::optional<Outcome> outcome;
      ASSERT_NO_THROW(outcome = result.get())
          << "admitted scan failure must use the writeback/checkpoint result";
      ASSERT_TRUE(outcome->failed);
      ASSERT_TRUE(outcome->error);
      EXPECT_EQ(outcome->state.phase_, NodeStoragePhase::Failed)
          << "handoff must fail the node before another scanner poll";
      EXPECT_EQ(outcome->state.primary_condition_, NodeStorageCondition::Corruption)
          << "handoff must preserve corruption classification";
    }
    const auto state = h.node->State();
    EXPECT_EQ(state.primary_condition_, NodeStorageCondition::Corruption);
    ASSERT_TRUE(state.error_);
    try {
      std::rethrow_exception(state.error_);
    } catch (const MetadataError &e) {
      EXPECT_EQ(e.Code(), MetadataErrorCode::Corrupt);
      EXPECT_NE(std::string(e.what()).find("metadata page"), std::string::npos);
    }
  }
}

TEST(F30Integrity, RetainedJournalDamageIsDetectedWithoutPayloadConsumer) {
  CheckedStore h(true);
  h.Create();
  h.Put(0, Value(h.Unit(), 27));
  // Locate one actual, still-retained Journal write unit; no persistent format
  // mutation API.
  auto bytes = h.image.Read(JOURNAL_START, 2 * MIB);
  const std::string magic = "BUSTJUNT";
  auto it = std::search(bytes.begin(), bytes.end(), magic.begin(), magic.end());
  ASSERT_NE(it, bytes.end());
  const auto off = JOURNAL_START + std::distance(bytes.begin(), it) + 99;
  auto b = h.image.Read(off, 1);
  b[0] ^= 0x40;
  h.image.Write(off, b);
  ASSERT_TRUE(Until(
      [&] { return h.node->State().phase_ == NodeStoragePhase::Failed; }));
  EXPECT_TRUE(h.node->State().conditions_ &
              static_cast<uint32_t>(NodeStorageCondition::Corruption));
}
TEST(F30Integrity, OptionalScanYieldsToMemoryAndReadProtectionPressureAndResumes) {
  CheckedStore h(true);
  h.Create();
  auto u = h.Unit();
  h.Put(4 * u, Value(2 * u, 79));
  ASSERT_TRUE(
      Until([&] { return h.node->State().integrity_.data_bytes_ >= 2 * u; }));
  auto account = ResourceAccount::Create(h.node->MemoryBudget());
  std::vector<ResourceCharge> charges;
  const auto before = h.node->State().integrity_.yielded_;
  ASSERT_TRUE(Until([&] {
    // In-flight IO may return credits after our first admission failure.
    // Keep holding returned credits until the scanner observes the pressure.
    size_t held = 0;
    while (account->Reserve(4096, false))
      held += 4096;
    while (account->Reserve(32, false))
      held += 32;
    if (held)
      charges.push_back(ResourceCharge(account, held, false));
    return h.node->State().integrity_.yielded_ > before;
  }));
  EXPECT_EQ(h.node->State().phase_, NodeStoragePhase::Serving);
  const auto checked = h.node->State().integrity_.data_bytes_;
  charges.clear();
  ASSERT_TRUE(
      Until([&] { return h.node->State().integrity_.data_bytes_ > checked; }));
  EXPECT_EQ(Read(*h.node, h.key, 4 * u, 2 * u), Value(2 * u, 79));

  // A real checkpoint capture may temporarily own every read-protection slot.
  // Use the production capture interface, without a scanner-only test hook.
  h.options.objects_->references_.max_leases_ = 1;
  h.Reopen();
  std::optional<ObjectReadLease> capture;
  ASSERT_TRUE(Until([&] {
    try {
      capture.emplace(h.node->ProtectObject(h.node->Objects(), h.key, 4 * u, 2 * u));
      return true;
    } catch (const ObjectReferenceError &e) {
      if (e.Code() != ObjectReferenceErrorCode::Busy) throw;
    } catch (const ObjectMappingError &e) {
      if (e.Code() != ObjectMappingErrorCode::ResourceUnavailable) throw;
    }
    return false;
  }));
  const auto held_before = h.node->State().integrity_.yielded_;
  EXPECT_TRUE(Until([&] { return h.node->State().integrity_.yielded_ > held_before; }))
      << "scanner must yield when read protections are held";
  EXPECT_EQ(h.node->State().phase_, NodeStoragePhase::Serving);
  const auto held_checked = h.node->State().integrity_.data_bytes_;
  capture.reset();
  EXPECT_TRUE(Until([&] { return h.node->State().integrity_.data_bytes_ > held_checked; }));
}

} // namespace
