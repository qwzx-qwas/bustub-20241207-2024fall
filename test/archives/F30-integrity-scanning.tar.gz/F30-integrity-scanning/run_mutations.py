#!/usr/bin/env python3
import argparse,json,pathlib,subprocess,os,time
p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--build',required=True);p.add_argument('--normal',required=True);p.add_argument('--out',required=True);p.add_argument('--only',help='run one named mutation');a=p.parse_args()
r=pathlib.Path(a.repo).resolve();n=pathlib.Path(a.normal).resolve();o=pathlib.Path(a.out).resolve();o.mkdir(parents=True,exist_ok=True)
normal=json.loads((n/'commands.json').read_text())[0]['command'];flags=normal[:normal.index('-no-pie')]+['-I'+str(r/'src/storage/disk')]
libs=[str(pathlib.Path(a.build).resolve()/'lib'/('lib'+x+'.a')) for x in ['bustub','bustub_lz4','bustub_murmur3','duckdb_pg_query','fmtd','fort','gmock_main','gmock','gtest']]
env=dict(os.environ,S5_WORKDIR=str(o),LD_LIBRARY_PATH='/tmp/bustub-gcc16/native-runtime',ASAN_OPTIONS='detect_leaks=1:abort_on_error=1')
changes=[
 ('data-crc','object_io.cpp','if (actual != e.crc_) {','if (false && actual != e.crc_) {','StoredExpectedRejectsCorruptionForOwnedFrameAndPrefetchReads','Expected:'),
 ('preflight','object_io.cpp','ObjectMappingAccess::Preflight(mapping_, base,','if (false) ObjectMappingAccess::Preflight(mapping_, base,','ChecksumCapacityRejectsBeforeBodyIOAndReservationRemainsReusable','data_writes.load()'),
 ('source','object_mapping.cpp','if (const auto task = base.base_.Get(Key(Deferred, owner, fields[1]))) {','if (const auto task = std::optional<Bytes>{}) {','DeferredScansJournalUntilDataCompletionThenVerifiesData','journal_bytes_'),
 ('shared-crc','object_reference.cpp','Key(Checksum, object, pos / context_->unit_)','Key(Checksum, object, allocation.range_.begin_ / context_->unit_)','SharedUnitsSurvivePartialReleaseAndPhysicalReuse','checksum missing'),
 ('b-crc','metadata_engine.cpp','trailer.ReadU32() == Crc32cExtend(Crc32c(bytes, BODY), bytes + BODY, 40)','(trailer.ReadU32(), true)','BColdPageDamageIsDetectedOutsideTheMetadataCache','Until'),
 ('journal-scan','metadata_engine.cpp','s.scrub_journal_->Verify();','(void)s.scrub_journal_;','RetainedJournalDamageIsDetectedWithoutPayloadConsumer','Until'),
 ('read-protection-busy','object_reference.cpp','ReferenceFail(ObjectReferenceErrorCode::Busy, "object read lease budget full");','Fail(ObjectMappingErrorCode::ResourceUnavailable, "object read lease budget full");','OptionalScanYieldsToMemoryAndReadProtectionPressureAndResumes','scanner must yield when read protections are held'),
 ('deferred-preflight','object_mapping.cpp','changes.Put(Key(Deferred, key, allocation), Encode({range.Offset(), range.Size()}));','if (!preflight) changes.Put(Key(Deferred, key, allocation), Encode({range.Offset(), range.Size()}));','ChecksumCapacityRejectsBeforeBodyIOAndReservationRemainsReusable','mixed transaction must reject before its Common body IO'),
 ('scan-handoff-result', 'metadata_engine.cpp', 'return {MetadataWritebackOutcome::Failed, 0, std::current_exception()};', 'throw;', 'BColdPageDamageIsDetectedOutsideTheMetadataCache', 'admitted scan failure must use the writeback/checkpoint result'),
 ('scan-handoff-condition', 'node_storage.cpp', 'state_.Fail(generation, FailureCondition(error), error);\n  }\n  void Pressure', 'state_.Fail(generation, NodeStorageCondition::IOFault, error);\n  }\n  void Pressure', 'BColdPageDamageIsDetectedOutsideTheMetadataCache', 'handoff must preserve corruption classification'),
]
if a.only:
 changes=[change for change in changes if change[0]==a.only]
 if not changes:p.error('unknown mutation: '+a.only)
commands=[]
def run(cmd,name,code=0):
 start=time.monotonic()
 with (o/(name+'.log')).open('w') as f:x=subprocess.run(list(map(str,cmd)),env=env,stdout=f,stderr=subprocess.STDOUT,timeout=100)
 commands.append(dict(command=list(map(str,cmd)),exit=x.returncode,seconds=time.monotonic()-start,log=name+'.log'));(o/'commands.json').write_text(json.dumps(commands,indent=2))
 if x.returncode!=code:raise RuntimeError((name,x.returncode,code))
run(flags+['-c',normal[normal.index('-no-pie')+1],'-o',o/'tests.o'],'test-compile')
for name,file,old,new,case,oracle in changes:
 s=(r/'src/storage/disk'/file).read_text();assert s.count(old)==1,(name,s.count(old));(o/(name+'.cpp')).write_text(s.replace(old,new))
 run(flags+['-c',o/(name+'.cpp'),'-o',o/(name+'.o')],name+'-compile')
 run(flags+['-no-pie',o/'tests.o',o/(name+'.o'),*libs,'-Wl,--wrap=pread','-Wl,--wrap=pwrite','-Wl,--wrap=fdatasync','-o',o/name],name+'-link')
 run([o/name,'--gtest_filter=F30Integrity.'+case,'--gtest_output=xml:'+str(o/(name+'.xml'))],name,1)
 log=(o/(name+'.log')).read_text();assert oracle in log,(name,log)
 assert '[  FAILED  ] F30Integrity.'+case in log
(o/'summary.json').write_text(json.dumps({'caught':len(changes),'mutations':changes},indent=2))
