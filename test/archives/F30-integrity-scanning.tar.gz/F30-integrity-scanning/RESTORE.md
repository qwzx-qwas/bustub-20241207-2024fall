# F30 阶段证据恢复

测试不进入项目默认目标。先解压此包到仓库外的临时目录；校对 MANIFEST.json 中 production、dependency、test 的 SHA256。历史依赖包保持原样；本包适配器只在临时目录展开它们，不用旧生产哈希伪装当前验证。

本次环境：Linux x86-64，GCC 16.2，ASan/LSan。F26 C++23 库能力检查仍须通过。Direct 文件测试需要支持 O_DIRECT 的文件系统，不要指向真实业务设备。

```sh
cmake -S "$REPO" -B "$BUILD" -DCMAKE_BUILD_TYPE=Debug \
  -DCMAKE_C_COMPILER=/tmp/bustub-gcc16/bin/x86_64-focal-linux-gnu-gcc \
  -DCMAKE_CXX_COMPILER=/tmp/bustub-gcc16/bin/x86_64-focal-linux-gnu-g++ \
  '-DCMAKE_C_FLAGS=--sysroot=/ -isystem /usr/include/x86_64-linux-gnu' \
  '-DCMAKE_CXX_FLAGS=--sysroot=/ -isystem /usr/include/x86_64-linux-gnu'
LD_LIBRARY_PATH=/tmp/bustub-gcc16/native-runtime cmake --build "$BUILD" --target bustub gtest gmock_main -j 3
python3 run_stage.py --repo "$REPO" --build "$BUILD" --out "$NORMAL" --case 'F30Integrity.*:S10Deferred.*'
python3 run_regressions.py --repo "$REPO" --build "$BUILD" --out "$REGRESSION"
python3 run_mutations.py --repo "$REPO" --build "$BUILD" --normal "$NORMAL" --out "$MUTATIONS"
```

上面 REPO/BUILD/NORMAL/REGRESSION/MUTATIONS 是调用者设置的独立目录，不复用业务数据路径。若环境禁止 LSan 访问进程信息，使用允许它运行的执行环境，不把关闭 LSan 的结果标为泄漏检查通过。

预期 11 新场景 + 12 F27 + 10 F29 + 8 S8 正常通过；10 变异预期 GTest exit=1 且特定断言失败。mutation 只修改临时源码副本；不覆盖工作区。

S8 适配：GCC 工具链、原 F29 既有组装适配，以及刻意限制 16 条映射变更的容量场景将每批 4U 改为 2U。v5 四个碎片 extent + CRC 至少需 17 条；正文总量、低元数据预算、实际空间复用及恢复 oracle 不变。F27 仅改 syscall wrapper 符号以组合 F30 的门控，旧 test body 不变。

归档恢复后须删除临时构建、可执行文件、设备和 Python 缓存。论文性能比较、共同 C/P 基线、裸设备与真实断电不在本包证据范围。

最新复核：生产修正 B 扫描由写回/checkpoint 接手时的失败结果，并复用节点错误分类。原 B 冷页测试扩展为扫描器、写回、checkpoint 三种完成入口；正常场景数仍为 41，变异增加 scan-handoff-result 和 scan-handoff-condition，总计 10。

本轮重跑全部 41 个正常场景及 10 个变异，ASan/LSan 开启。结果包 normal、raft-regression、mutations 均为当前代码结果；不再叠放前轮结果目录或错误测试源码。旧 41/8、三场景复验和压力额外十次属于历史审查，不作为本轮新增结果。当前 MANIFEST 对应本包所有源码及五个有效依赖压缩包。

单项变异可使用 --only scan-handoff-result 或 --only scan-handoff-condition。新增变异必须由相应交接断言检出，不能以编译失败、超时或 sanitizer 崩溃代替。
