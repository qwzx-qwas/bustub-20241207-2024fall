#include "fixture.h"
#include "storage/disk/node_storage.h"
#include "gtest/gtest.h"
#include <chrono>
#include <condition_variable>
#include <cstring>
#include <future>
#include <mutex>
#include <optional>
#include <sys/wait.h>
#include <thread>
using namespace std::chrono_literals;
extern "C" ssize_t __real_pread(int, void *, size_t, off_t);
extern "C" ssize_t __real_pwrite(int, const void *, size_t, off_t);
extern "C" int __real_fdatasync(int);
namespace {
using namespace bustub;
using namespace s5;
enum class Gate { None, Write, Flush, Journal, JournalFlush };
std::mutex gate_mutex;
std::condition_variable gate_cv;
Gate gate = Gate::None;
bool entered = false, released = true, fail = false, tracking = false;
int tracked_fd = -1, journal_fd = -1;
bool fail_journal_read = false;
void Arm(Gate point, bool error = false) {
  std::lock_guard<std::mutex> lock(gate_mutex);
  gate = point;
  entered = false;
  released = false;
  fail = error;
  tracked_fd = journal_fd = -1;
  tracking = true;
}
void Release() {
  std::lock_guard<std::mutex> lock(gate_mutex);
  released = true;
  gate_cv.notify_all();
}
void Reset() {
  std::lock_guard<std::mutex> lock(gate_mutex);
  released = true;
  gate = Gate::None;
  tracking = false;
  fail_journal_read = false;
  tracked_fd = journal_fd = -1;
  gate_cv.notify_all();
}
struct Cleanup {
  ~Cleanup() { Reset(); }
};
bool Pause(std::unique_lock<std::mutex> &lock) {
  entered = true;
  gate = Gate::None;
  gate_cv.notify_all();
  gate_cv.wait(lock, [] { return released; });
  return fail;
}
bool Entered() {
  std::unique_lock<std::mutex> lock(gate_mutex);
  return gate_cv.wait_for(lock, 15s, [] { return entered; });
}
bool Direct(int fd) { return (fcntl(fd, F_GETFL) & O_DIRECT) != 0; }
} // namespace
extern "C" ssize_t __wrap_pread(int fd, void *buf, size_t size, off_t off) {
  if (Direct(fd) && off >= static_cast<off_t>(JOURNAL_START) && off < static_cast<off_t>(6 * MIB)) {
    std::lock_guard<std::mutex> lock(gate_mutex);
    if (fail_journal_read) {
      fail_journal_read = false;
      errno = EIO;
      return -1;
    }
  }
  return __real_pread(fd, buf, size, off);
}
extern "C" ssize_t __wrap_pwrite(int fd, const void *buf, size_t size,
                                 off_t off) {
  if (Direct(fd) && off >= static_cast<off_t>(6 * MIB)) {
    std::unique_lock<std::mutex> lock(gate_mutex);
    if (tracking) {
      tracked_fd = fd;
      gate_cv.notify_all();
    }
    if (gate == Gate::Write && Pause(lock)) {
      errno = EIO;
      return -1;
    }
  }
  if (Direct(fd) && off >= static_cast<off_t>(JOURNAL_START) &&
      off < static_cast<off_t>(6 * MIB)) {
    std::unique_lock<std::mutex> lock(gate_mutex);
    if (tracking)
      journal_fd = fd;
    if (gate == Gate::Journal && Pause(lock)) {
      errno = EIO;
      return -1;
    }
  }
  return __real_pwrite(fd, buf, size, off);
}
extern "C" int __wrap_fdatasync(int fd) {
  std::unique_lock<std::mutex> lock(gate_mutex);
  if (tracking && ((gate == Gate::Flush && fd == tracked_fd) ||
                   (gate == Gate::JournalFlush && fd == journal_fd))) {
    if (Pause(lock)) {
      errno = EIO;
      return -1;
    }
  }
  lock.unlock();
  return __real_fdatasync(fd);
}
namespace {
auto Options(const Image &image) -> NodeStorageOptions {
  BlockDevice dev(image.path, {});
  const auto u = static_cast<uint32_t>(
      std::lcm<uint64_t>(4096, 4ULL * std::max(dev.Info().offset_alignment_, dev.Info().memory_alignment_)));
  Require(u <= 16384, "alignment exceeds fixture budget");
  BootstrapIdentity id{};
  id.storage_.fill(11);
  id.device_.fill(31);
  JournalIdentity jid{};
  jid.fill(73);
  return {image.path,
          {},
          {3, 2048, 16 * MIB},
          id,
          jid,
          {4ULL * u, u, 32 * u, MIB, 128, 2 * MIB, 8, 32, 4 * MIB},
          {256, 2048, 16384, 64 * 1024},
          {1, 1ms, 1000ms},
          ObjectStorageOptions{{u, 64, MIB, 2 * MIB, 8, 1024, 4096},
                               {2, 512, 128 * 1024, 256, 32},
                               {64, 64, 1024, 8, 2 * MIB, 16},
                               2 * MIB,
                               2 * MIB},
          ObjectTransactionOptions{16, 16, 32 * u, 4 * MIB, 2ms, 1h, 16 * u,
                                   128 * u, 16}};
}
auto Layout(const NodeStorageOptions &o) -> BootstrapLayout {
  return {o.identity_,
          8 * MIB,
          {Range(2 * MIB, MIB), Range(JOURNAL_START, 2 * MIB),
           Range(6 * MIB, 2 * MIB)}};
}
void Durable(const JournalResult &r) {
  Require(r.outcome_ == JournalOutcome::Durable && !r.error_,
          "required metadata operation is not durable");
}
auto New(NodeStorage &node, uint64_t number) -> ObjectKey {
  const auto space = node.CreateObjectSpace(node.Objects());
  Require(space.result_.outcome_ == JournalOutcome::Durable && space.space_,
          "space durable");
  ObjectKey key{*space.space_, number};
  Require(node.CreateObject(node.Objects(), key, 0, ObjectSizeMode::Variable)
                  .outcome_ == JournalOutcome::Durable,
          "object durable");
  return key;
}
auto Read(NodeStorage &node, ObjectKey key, uint64_t offset, uint64_t length)
    -> Bytes {
  auto read = node.ReadObject(node.Objects(), key, offset, length);
  read.Wait();
  Bytes bytes(read.Size());
  read.CopyTo(bytes.data(), bytes.size());
  return bytes;
}
auto Change(ObjectOperation kind, ObjectKey key, uint64_t offset,
            Bytes data = {}) -> ObjectMutation {
  return {kind, key, offset, ObjectSizeMode::Variable, std::move(data)};
}
auto Submit(NodeStorage &node, ObjectTransaction tx)
    -> ObjectTransactionTicket {
  auto result = node.SubmitObjects(tx);
  Require(result.admission_ == IOAdmission::Accepted && result.ticket_,
          "transaction admission");
  return std::move(*result.ticket_);
}
auto Finish(ObjectTransactionTicket &ticket) -> JournalResult {
  Require(ticket.WaitFor(15s), "transaction completion deadline");
  return ticket.Result();
}
void Commit(NodeStorage &node, ObjectTransaction tx) {
  auto ticket = Submit(node, std::move(tx));
  const auto result = Finish(ticket);
  if (result.error_)
    std::rethrow_exception(result.error_);
  Durable(result);
}

auto Common(ObjectMutation op) -> ObjectMutation {
  op.common_only_ = true;
  return op;
}
void Settled(NodeStorage &node, ObjectKey key, uint64_t offset) {
  const auto deadline = std::chrono::steady_clock::now() + 15s;
  while (std::chrono::steady_clock::now() < deadline) {
    const auto spans = node.Objects().Resolve(key, offset, 1).spans_;
    if (!spans.empty() && !spans[0].journal_)
      return;
    if (node.State().error_)
      std::rethrow_exception(node.State().error_);
    std::this_thread::yield();
  }
  throw std::runtime_error("Deferred completion deadline");
}
TEST(S10Deferred,
     PublishedBytesRemainReadableThroughCheckpointAndSourceSwitch) {
  Image image;
  auto o = Options(image);
  NodeStorage node(o);
  node.Create(Layout(o));
  const auto u = o.objects_->allocator_.allocation_bytes_;
  auto key = New(node, 73);
  auto original = Value(6 * u, 13);
  Commit(node,
         {{Common(Change(ObjectOperation::Write, key, 0, original))}, {}});
  Commit(node, {{Change(ObjectOperation::Resize, key, 9 * u)}, {}});
  original.resize(9 * u);
  auto model = original;
  auto changed = Value(2 * u + 193, 87);
  const auto offset = 2 * u + 117;
  std::copy(changed.begin(), changed.end(), model.begin() + offset);
  Cleanup cleanup;
  Arm(Gate::Write);
  auto ticket =
      Submit(node, {{Change(ObjectOperation::Write, key, offset, changed)},
                    {{key, 19, Value(79, 6)}}});
  Durable(Finish(ticket));
  ASSERT_TRUE(Entered());
  EXPECT_EQ(Read(node, key, u + 91, 7 * u),
            Bytes(model.begin() + u + 91, model.begin() + 8 * u + 91))
      << "published Journal/Data/Hole byte model";
  EXPECT_EQ(node.Objects().Control(key, 19),
            std::optional<Bytes>(Value(79, 6)));
  EXPECT_EQ(node.Checkpoint(8).outcome_, MetadataCheckpointOutcome::Durable);
  EXPECT_EQ(Read(node, key, offset + 37, changed.size() - 73),
            Bytes(model.begin() + offset + 37,
                  model.begin() + offset + changed.size() - 36));
  auto old = std::make_optional(node.Objects());
  Release();
  Settled(node, key, offset);
  EXPECT_EQ(node.Checkpoint(8).outcome_, MetadataCheckpointOutcome::Durable);
  auto read = node.ReadObject(*old, key, offset, changed.size());
  read.Wait();
  Bytes actual(read.Size());
  read.CopyTo(actual.data(), actual.size());
  EXPECT_EQ(actual, changed) << "old published view retains Journal source";
  old.reset();
  Reset();
  node.Close();
  node.Open();
  EXPECT_EQ(Read(node, key, 0, model.size()), model)
      << "completed source survives recovery";
}
TEST(S10Deferred, NewerOverlappingWriteCannotBeReplacedByOldCompletion) {
  Image image;
  auto o = Options(image);
  NodeStorage node(o);
  node.Create(Layout(o));
  auto key = New(node, 97);
  const auto u = o.objects_->allocator_.allocation_bytes_;
  auto first = Value(5 * u, 23);
  Cleanup cleanup;
  Arm(Gate::Write);
  auto abandoned =
      Submit(node, {{Change(ObjectOperation::Write, key, 0, first)}, {}});
  Durable(Finish(abandoned));
  ASSERT_TRUE(Entered());
  auto change = Value(713, 159);
  auto model = first;
  std::copy(change.begin(), change.end(), model.begin() + 2 * u + 53);
  {
    auto ticket = Submit(
        node, {{Change(ObjectOperation::Write, key, 2 * u + 53, change)}, {}});
    Durable(Finish(ticket));
  }
  EXPECT_EQ(Read(node, key, u + 19, 3 * u),
            Bytes(model.begin() + u + 19, model.begin() + 4 * u + 19));
  Release();
  Settled(node, key, 2 * u + 53);
  Reset();
  EXPECT_EQ(Read(node, key, 0, model.size()), model)
      << "late task completion cannot republish old version";
  node.Close();
  node.Open();
  EXPECT_EQ(Read(node, key, 0, model.size()), model);
}
TEST(S10Deferred,
     RestartUsesPreCheckpointPayloadAndResumesWithSelectionDisabled) {
  Image image;
  auto o = Options(image);
  const auto u = o.objects_->allocator_.allocation_bytes_;
  const auto body = Value(9 * u + 131, 71);
  pid_t child = fork();
  ASSERT_GE(child, 0);
  if (child == 0) {
    try {
      NodeStorage node(o);
      node.Create(Layout(o));
      auto key = New(node, 101);
      Arm(Gate::Write);
      Commit(node,
             {{Change(ObjectOperation::Write, key, 3 * u + 29, body)}, {}});
      if (!Entered() ||
          node.Checkpoint(8).outcome_ != MetadataCheckpointOutcome::Durable)
        _exit(2);
      _exit(0); // Real process loss after durable checkpoint, before any final
                // Data write.
    } catch (...) {
      _exit(3);
    }
  }
  int status = 0;
  ASSERT_EQ(waitpid(child, &status, 0), child);
  ASSERT_TRUE(WIFEXITED(status));
  ASSERT_EQ(WEXITSTATUS(status), 0);
  o.transactions_->deferred_max_bytes_ = 0;
  NodeStorage node(o);
  Cleanup cleanup;
  Arm(Gate::Write);
  node.Open();
  ASSERT_TRUE(Entered());
  ObjectKey key{1, 101};
  EXPECT_EQ(Read(node, key, 3 * u + 29, body.size()), body)
      << "checkpoint points to still-retained older payload";
  Release();
  Settled(node, key, 3 * u + 29);
  Reset();
  node.Close();
  node.Open();
  EXPECT_EQ(Read(node, key, 3 * u + 29, body.size()), body);
}
TEST(S10Deferred, DataFailureDoesNotUndoDurableCommitOrLoseRecoveryBody) {
  Image image;
  auto o = Options(image);
  NodeStorage node(o);
  node.Create(Layout(o));
  auto key = New(node, 127);
  auto bytes = Value(7731, 109);
  Cleanup cleanup;
  Arm(Gate::Write, true);
  auto ticket =
      Submit(node, {{Change(ObjectOperation::Write, key, 291, bytes)}, {}});
  Durable(Finish(ticket));
  ASSERT_TRUE(Entered());
  Release();
  const auto end = std::chrono::steady_clock::now() + 15s;
  while (!node.State().error_ && std::chrono::steady_clock::now() < end)
    std::this_thread::yield();
  ASSERT_TRUE(node.State().error_) << "background IO failure is observable";
  EXPECT_EQ(node.State().phase_, NodeStoragePhase::Failed);
  EXPECT_FALSE(node.State().object_transaction_);
  EXPECT_EQ(ticket.Result().outcome_, JournalOutcome::Durable)
      << "published success is not retroactively rolled back";
  Reset();
  node.Close();
  node.Open();
  Settled(node, key, 291);
  EXPECT_EQ(Read(node, key, 291, bytes.size()), bytes);
}
TEST(S10Deferred, PendingTargetCannotBeReusedAndCompletionEnablesReclaim) {
  Image image;
  auto o = Options(image);
  NodeStorage node(o);
  const auto u = o.objects_->allocator_.allocation_bytes_;
  auto layout = Layout(o);
  layout.regions_[2] = Range(6 * MIB, 2 * u);
  node.Create(layout);
  auto key = New(node, 149);
  Cleanup cleanup;
  Arm(Gate::Write);
  Commit(node,
         {{Change(ObjectOperation::Write, key, 4 * u, Value(2 * u, 7))}, {}});
  ASSERT_TRUE(Entered());
  auto span = node.Objects().Resolve(key, 4 * u, 2 * u).spans_.front();
  const auto id = span.data_->allocation_;
  const auto physical = span.data_->offset_;
  span.journal_.reset();
  Commit(node, {{Change(ObjectOperation::Resize, key, u)}, {}});
  auto before = node.ReclaimObject(node.Objects(), key, id);
  EXPECT_EQ(before.released_bytes_, 0U)
      << "pending final writer still owns target";
  Release();
  Reset();
  uint64_t freed = 0;
  const auto end = std::chrono::steady_clock::now() + 15s;
  while (freed == 0 && std::chrono::steady_clock::now() < end) {
    try {
      freed = node.ReclaimObject(node.Objects(), key, id).released_bytes_;
    } catch (const MetadataViewConflict &) {
    }
    std::this_thread::yield();
  }
  EXPECT_EQ(freed, 2 * u) << "completion releases retired physical target";
  auto other = New(node, 151);
  Commit(node,
         {{Common(Change(ObjectOperation::Write, other, 0, Value(2 * u, 181)))},
          {}});
  EXPECT_EQ(node.Objects().Resolve(other, 0, 1).spans_.front().data_->offset_,
            physical)
      << "released target is actually allocatable";
  EXPECT_EQ(Read(node, other, 0, 2 * u), Value(2 * u, 181));
}
TEST(S10Deferred, ReservedJournalSpaceAllowsCompletionUnderForegroundPressure) {
  Image image;
  auto o = Options(image);
  auto layout = Layout(o);
  layout.regions_[1] = Range(JOURNAL_START, 128ULL * o.journal_.unit_bytes_);
  NodeStorage node(o);
  node.Create(layout);
  auto key = New(node, 173);
  Cleanup cleanup;
  Arm(Gate::Write);
  auto body = Value(9173, 47);
  Commit(node, {{Change(ObjectOperation::Write, key, 77, body)}, {}});
  ASSERT_TRUE(Entered());
  bool full = false;
  for (size_t i = 0; i < 256; ++i) {
    auto ticket =
        Submit(node, {{}, {{key, 33, Value(127, static_cast<unsigned>(i))}}});
    const auto r = Finish(ticket);
    if (r.outcome_ != JournalOutcome::Durable) {
      ASSERT_EQ(r.outcome_, JournalOutcome::NotCommitted);
      full = true;
      break;
    }
  }
  ASSERT_TRUE(full) << "workload reached the reserved Journal boundary";
  Release();
  Settled(node, key, 77);
  Reset();
  EXPECT_EQ(node.Checkpoint(8).outcome_, MetadataCheckpointOutcome::Durable);
  Commit(node, {{}, {{key, 33, Value(117, 233)}}});
  EXPECT_EQ(Read(node, key, 77, body.size()), body);
}

TEST(S10Deferred, SourceRemainsJournalUntilFinalFlushCompletes) {
  Image image;
  auto o = Options(image);
  NodeStorage node(o);
  node.Create(Layout(o));
  auto key = New(node, 197);
  auto body = Value(7927, 113);
  Cleanup cleanup;
  Arm(Gate::Flush);
  Commit(node, {{Change(ObjectOperation::Write, key, 137, body)}, {}});
  ASSERT_TRUE(Entered());
  EXPECT_TRUE(
      node.Objects().Resolve(key, 997, 113).spans_.front().journal_.has_value())
      << "write alone is not durability";
  EXPECT_EQ(Read(node, key, 137, body.size()), body);
  Release();
  Settled(node, key, 137);
  Reset();
  EXPECT_EQ(Read(node, key, 137, body.size()), body);
}
TEST(S10Deferred, MissingRequiredJournalBodyIsRecoveryErrorNotOldDataOrZeros) {
  Image image;
  auto o = Options(image);
  auto body = Value(10373, 131);
  {
    NodeStorage node(o);
    node.Create(Layout(o));
    auto key = New(node, 211);
    Cleanup cleanup;
    Arm(Gate::Write, true);
    Commit(node, {{Change(ObjectOperation::Write, key, 257, body)}, {}});
    ASSERT_TRUE(Entered());
    EXPECT_EQ(node.Checkpoint(8).outcome_, MetadataCheckpointOutcome::Durable);
    Release();
    const auto end = std::chrono::steady_clock::now() + 15s;
    while (!node.State().error_ && std::chrono::steady_clock::now() < end)
      std::this_thread::yield();
    ASSERT_TRUE(node.State().error_);
    Reset();
    node.Close();
  }
  auto disk = image.Read(JOURNAL_START, 2 * MIB);
  const auto *needle = reinterpret_cast<const uint8_t *>(body.data());
  auto found = std::search(disk.begin(), disk.end(), needle, needle + 64);
  ASSERT_NE(found, disk.end())
      << "test corruption targets actual submitted body";
  *found ^= 0x80;
  image.Write(JOURNAL_START, disk);
  NodeStorage recovered(o);
  EXPECT_THROW(recovered.Open(), JournalError)
      << "required Journal corruption must fail recovery";
}
TEST(S10Deferred, MixedCommonAndDeferredPublishOneObjectTransaction) {
  Image image;
  auto o = Options(image);
  NodeStorage node(o);
  node.Create(Layout(o));
  auto a = New(node, 229), b = New(node, 233);
  const auto u = o.objects_->allocator_.allocation_bytes_;
  Commit(node, {{Change(ObjectOperation::Resize, a, 30 * u),
                 Change(ObjectOperation::Resize, b, 5 * u)},
                {}});
  auto large = Value(20 * u + 17, 167), small = Value(2 * u + 31, 181);
  Cleanup cleanup;
  Arm(Gate::Write);
  auto ticket =
      Submit(node, {{Change(ObjectOperation::Write, a, u + 43, large),
                     Change(ObjectOperation::Write, b, u + 71, small)},
                    {{a, 91, Value(61, 197)}}});
  ASSERT_TRUE(Entered());
  EXPECT_FALSE(ticket.WaitFor(0ms))
      << "Common dependency must be durable before mixed publication";
  EXPECT_EQ(Read(node, a, u + 43, large.size()), Bytes(large.size()));
  EXPECT_EQ(Read(node, b, u + 71, small.size()), Bytes(small.size()));
  EXPECT_FALSE(node.Objects().Control(a, 91));
  Release();
  Durable(Finish(ticket));
  Reset();
  Settled(node, b, u + 71);
  EXPECT_EQ(Read(node, a, u + 43, large.size()), large);
  EXPECT_EQ(Read(node, b, u + 71, small.size()), small);
  EXPECT_EQ(node.Objects().Control(a, 91),
            std::optional<Bytes>(Value(61, 197)));
  node.Close();
  node.Open();
  EXPECT_EQ(Read(node, a, u + 43, large.size()), large);
  EXPECT_EQ(Read(node, b, u + 71, small.size()), small);
}
TEST(S10Deferred, JournalFailureCannotRecoverHalfAnObjectTransaction) {
  for (auto fault : {Gate::Journal, Gate::JournalFlush}) {
    Image image;
    auto o = Options(image);
    NodeStorage node(o);
    node.Create(Layout(o));
    auto key = New(node, 251);
    const auto original = Value(12317, 197), replacement = Value(8317, 211),
               control = Value(73, 239);
    Commit(node,
           {{Common(Change(ObjectOperation::Write, key, 0, original))}, {}});
    auto expected = original;
    std::copy(replacement.begin(), replacement.end(), expected.begin() + 731);
    Cleanup cleanup;
    Arm(fault, true);
    auto ticket =
        Submit(node, {{Change(ObjectOperation::Write, key, 731, replacement)},
                      {{key, 83, control}}});
    ASSERT_TRUE(Entered());
    EXPECT_FALSE(ticket.WaitFor(0ms))
        << "Journal durability is required before acknowledgment";
    Release();
    auto result = Finish(ticket);
    EXPECT_NE(result.outcome_, JournalOutcome::Durable);
    ASSERT_TRUE(result.error_);
    Reset();
    node.Close();
    try {
      node.Open();
    } catch (const JournalError &e) {
      // Partial pwrite failure may leave a broken committed-batch chain. The
      // storage contract requires refusal, never silently truncating it.
      EXPECT_EQ(fault, Gate::Journal);
      EXPECT_EQ(e.Code(), JournalErrorCode::Corrupt);
      EXPECT_EQ(node.State().phase_, NodeStoragePhase::Failed);
      EXPECT_FALSE(node.State().object_read_);
      continue;
    }
    auto published = node.Objects().Control(key, 83);
    if (published) {
      EXPECT_EQ(*published, control);
      EXPECT_EQ(Read(node, key, 0, expected.size()), expected)
          << "recovered control requires complete new body";
    } else {
      EXPECT_EQ(Read(node, key, 0, original.size()), original)
          << "no publication preserves old body";
    }
    if (result.outcome_ == JournalOutcome::NotCommitted)
      EXPECT_FALSE(published);
  }
}
TEST(S10Deferred, AbandonedJournalReadStillFaultsNode) {
  Image image;
  auto o = Options(image);
  NodeStorage node(o);
  node.Create(Layout(o));
  auto key = New(node, 269);
  const auto body = Value(9173, 113);
  Cleanup cleanup;
  Arm(Gate::Write);
  Commit(node, {{Change(ObjectOperation::Write, key, 379, body)}, {}});
  ASSERT_TRUE(Entered()); // Background already read its body; only foreground will hit the fault.
  {
    std::lock_guard<std::mutex> lock(gate_mutex);
    fail_journal_read = true;
  }
  {
    auto abandoned = node.ReadObject(node.Objects(), key, 419, 1739);
    // Destruction relinquishes observation, never an accepted IO's error report.
  }
  const auto deadline = std::chrono::steady_clock::now() + 15s;
  while (!node.State().error_ && std::chrono::steady_clock::now() < deadline)
    std::this_thread::yield();
  const auto state = node.State();
  ASSERT_TRUE(state.error_) << "abandoned Journal read error must fault the node";
  EXPECT_EQ(state.phase_, NodeStoragePhase::Failed);
  EXPECT_FALSE(state.object_read_);
  EXPECT_FALSE(state.object_transaction_);
  EXPECT_THROW(node.ReadObject(node.Objects(), key, 419, 1739), MetadataError);
  Reset();
  node.Close();
  node.Open();
  EXPECT_EQ(Read(node, key, 379, body.size()), body);
}
TEST(S10Deferred, OversizedMixedReadRejectsInsteadOfReportingTemporaryPressure) {
  Image image;
  auto o = Options(image);
  const auto u = o.objects_->allocator_.allocation_bytes_;
  o.io_.max_buffer_bytes_ = 64 * u;
  o.transactions_->max_request_bytes_ = 128 * u;
  NodeStorage node(o);
  node.Create(Layout(o));
  auto key = New(node, 277);
  auto model = Value(63 * u, 71);
  Commit(node, {{Common(Change(ObjectOperation::Write, key, 0, model))}, {}});
  Cleanup cleanup;
  Arm(Gate::Write);
  const auto body = Value(16 * u, 193);
  Commit(node, {{Change(ObjectOperation::Write, key, 8 * u, body)}, {}});
  ASSERT_TRUE(Entered());
  std::copy(body.begin(), body.end(), model.begin() + 8 * u);
  EXPECT_EQ(Read(node, key, 8 * u, body.size()), body);
  EXPECT_EQ(Read(node, key, u + 11, 719), Bytes(model.begin() + u + 11, model.begin() + u + 730));
  bool rejected = false;
  try {
    auto read = node.ReadObject(node.Objects(), key, 0, model.size());
    read.Wait();
  } catch (const ObjectIOBusy &) {
    FAIL() << "permanently oversized read was misclassified as temporary pressure";
  } catch (const MetadataError &error) {
    EXPECT_EQ(error.Code(), MetadataErrorCode::ResourceUnavailable);
    rejected = true;
  }
  EXPECT_TRUE(rejected) << "combined Data and complete Journal batch exceed configured buffer budget";
  EXPECT_FALSE(node.State().error_) << "capacity rejection is not device failure";
  Release();
  Settled(node, key, 8 * u);
  Reset();
  EXPECT_EQ(Read(node, key, 0, model.size()), model) << "Data-only read fits after source switch";
}
} // namespace
