# F27/S10 阶段验证恢复

只压缩保存；不注册常驻测试。相同业务 C/P 套件不在这里复制。

## 源码与版本

MANIFEST.json 记录本轮生产源、测试源和依赖包 SHA256；基线 2512675，当前新增生产代码在本轮工作区，尚未 commit。请使用包含本轮修改的源码，并通过哈希核对，不要用旧基线的库跑新测试。结果包中保存生产源快照及相对基线 diff。构建与测试只使用仓库外临时目录。

依赖归档保持原内容：S5-journal-recycling、F19-common-pipeline、F26-array-buffer-pool、F36-table-space、S8-raft-object-stores。历史 fixture 还需 Git 对象 cce998a 和 2512675。Runner 对 S5 旧 producer 隔离无关的新对象类型声明；S8 采用已经存在的页后端部署适配，测试输入及 oracle 不改变。

```bash
stage_work=$(mktemp -d /tmp/bustub-f27-XXXXXX)
tar -xzf test/archives/F27-deferred.tar.gz -C "$stage_work"
cmake -S . -B "$stage_work/build" -DCMAKE_BUILD_TYPE=Debug \
  -DCMAKE_C_COMPILER=clang-14 -DCMAKE_CXX_COMPILER=clang++-14 \
  -DBUSTUB_SANITIZER=address,undefined -DCMAKE_EXE_LINKER_FLAGS=-no-pie
cmake --build "$stage_work/build" --target bustub gmock_main gtest_main -j3
python3 "$stage_work/F27-deferred/run_stage.py" --repo "$PWD" \
  --build "$stage_work/build" --out "$stage_work/results" --regressions --mutations
```

共56个不同正常场景（F36文件包含F26，不能重复计数）与8个定向变异。退出码、XML、错误断言和命令在 results。若 LSan 无法枚举线程，需允许相应本地进程检查，不能把 ptrace 失败算通过或悄悄关闭 sanitizer。S8 需要本机 TCP；其余使用临时 Direct 普通文件，需要文件系统支持。

新用例覆盖 Deferred→Journal 来源→后台 Data→完成事务→读取切换/恢复/回收，不代表裸设备、主机掉电、原地写或性能验证。详细独立 oracle、测试兼容/去重、API审查及限制见 docs/storage_redesign/s10_execution_20261005.md。
