#!/usr/bin/env python3
"""S10 real NodeStorage integration; existing workloads are restored, not duplicated."""
import argparse,pathlib,subprocess,tarfile,os,json,time,hashlib,resource,signal
import xml.etree.ElementTree as ET
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--build',required=True);p.add_argument('--out',required=True);p.add_argument('--regressions',action='store_true');p.add_argument('--mutations',action='store_true')
a=p.parse_args();repo=pathlib.Path(a.repo).resolve();build=pathlib.Path(a.build).resolve();out=pathlib.Path(a.out).resolve();pkg=pathlib.Path(__file__).resolve().parent
out.mkdir(parents=True,exist_ok=False)
if (pkg/'MANIFEST.json').exists():
 m=json.loads((pkg/'MANIFEST.json').read_text())
 for base,key in [(repo,'production_sha256'),(repo,'dependency_sha256'),(pkg,'test_sha256')]:
  for f,d in m[key].items():
   if hashlib.sha256((base/f).read_bytes()).hexdigest()!=d:raise SystemExit('source mismatch: '+str(base/f))
for n in ['S5-journal-recycling','F19-common-pipeline','F26-array-buffer-pool','F36-table-space','S8-raft-object-stores']:
 with tarfile.open(repo/f'test/archives/{n}.tar.gz') as t:t.extractall(out,filter='data')
env={k:v for k,v in os.environ.items() if not k.startswith('GTEST_')};env.update(S5_WORKDIR=str(out),ASAN_OPTIONS='detect_leaks=1:abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
flags=['clang++-14','-std=c++17','-pthread','-g','-O0','-Wall','-Wextra','-Werror','-Wno-unused-parameter','-Wno-attributes','-fsanitize=address,undefined','-fno-omit-frame-pointer','-fno-pie']
flags+=['-I'+str(x) for x in [repo/'src/include',repo/'src/buffer',repo/'src/storage/disk',repo/'src/raft',repo/'third_party',repo/'third_party/libfort/src',repo/'third_party/fmt/include',repo/'third_party/googletest/googletest/include',out/'S5-journal-recycling/test/storage_redesign',out/'F26-array-buffer-pool/tests']]
libs=[build/'lib'/('lib'+n+'.a') for n in ['bustub','bustub_murmur3','duckdb_pg_query','fmtd','fort','gmock_main','gmock','gtest']]
wrap=['-Wl,--wrap=pwrite','-Wl,--wrap=fdatasync'];deferred_wrap=wrap+['-Wl,--wrap=pread'];commands=[];counts={};evidence=[]
def run(cmd,name,expected=0,timeout=300):
 start=time.monotonic()
 with (out/(name+'.log')).open('w') as f:
  with subprocess.Popen(list(map(str,cmd)),cwd=repo,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True) as r:
   try:r.wait(timeout=timeout)
   except subprocess.TimeoutExpired:
    # A crash test may fork. Terminate this command's process group, including
    # its fixture children, rather than leaving a blocked device writer behind.
    os.killpg(r.pid,signal.SIGKILL);r.wait()
    commands.append(dict(command=list(map(str,cmd)),exit=r.returncode,timeout=True,seconds=time.monotonic()-start,log=name+'.log'))
    (out/'commands.json').write_text(json.dumps(commands,indent=2));raise
 commands.append(dict(command=list(map(str,cmd)),exit=r.returncode,seconds=time.monotonic()-start,log=name+'.log'));(out/'commands.json').write_text(json.dumps(commands,indent=2))
 if r.returncode!=expected:raise RuntimeError((name,r.returncode,expected))
def check(name,count,failed=False):
 cases=ET.parse(out/(name+'.xml')).getroot().findall('.//testcase')
 assert len(cases)==count and all(c.attrib.get('status')=='run' and c.find('skipped') is None and c.find('error') is None for c in cases),(name,'coverage')
 failures=[f.text or '' for c in cases for f in c.findall('failure')]
 assert bool(failures)==failed,(name,failures)
 if not failed:counts[name]=count
 return failures
def suite(name,source,count,wrappers):
 run(flags+['-c',source,'-o',out/(name+'.o')],name+'-compile')
 run(flags+['-no-pie',out/(name+'.o')]+libs+wrappers+['-o',out/name],name+'-link')
 run([out/name,'--gtest_output=xml:'+str(out/(name+'.xml'))],name)
 check(name,count)
suite('deferred',pkg/'tests/deferred_test.cpp',12,deferred_wrap)
if a.regressions:
 suite('common',out/'F19-common-pipeline/tests/transaction_test.cpp',10,wrap+['-Wl,--wrap=pread'])
 # Old producer's B+Tree includes the modern BufferPool declarations. Isolate
 # unused object declarations at the pre-S10 production version; no fake values
 # or disk bytes are introduced, and the historic B/Journal writer stays intact.
 for header in ['object_mapping.h','data_allocator.h']:
  target=out/'legacy/src/include/storage/disk'/header;target.parent.mkdir(parents=True,exist_ok=True)
  target.write_bytes(subprocess.check_output(['git','show','2512675:src/include/storage/disk/'+header],cwd=repo))
 (out/'build').symlink_to(build,target_is_directory=True)
 # Existing legacy producer + recycling workload, same bodies and assertions.
 run(['python3',out/'S5-journal-recycling/test/storage_redesign/build_checks.py',repo,out],'s5-regression',timeout=300);check('s5',8)
 # F36 source includes the 9 F26 cases; run them once through this combined suite.
 suite('tables',out/'F36-table-space/tests/table_space_test.cpp',18,wrap+['-Wl,--wrap=pread','-Wl,--wrap=madvise'])
 s=(out/'S8-raft-object-stores/tests/object_stores_test.cpp').read_text()
 # Same fixture adaptation already used by F26/e and F36; no workload change.
 for old,new,count in [
 ('ObjectTransactionOptions{32, 128, MIB, 8 * MIB, 2ms, 10ms}};','ObjectTransactionOptions{32, 128, MIB, 8 * MIB, 2ms, 10ms}, 2 * MIB};',1),
 ('RaftObjectDeployment{h.options, h.space, Limits()}','RaftObjectDeployment{h.options, h.space, Limits(), PageCacheDeployment{4U, BufferPoolOptions{8*MIB, 2*MIB, 32, false, 3}}}',1),
 ('BusTubRaftStateMachine::Open(directory.get(), files, 64)','BusTubRaftStateMachine::OpenObjectPages(directory.get(), files, 64, {h.node, {4, {h.space, 5}}, {8*MIB,2*MIB,32,false,3}})',2)]:
  assert s.count(old)==count;s=s.replace(old,new)
 adapted=out/'s8-adapted.cpp';adapted.write_text(s);suite('raft',adapted,8,wrap)
if a.mutations:
 mutations=[
 ('skip-journal-source','object_io.cpp','if (spans[i].journal_) {','if (false && spans[i].journal_) {','PublishedBytesRemainReadableThroughCheckpointAndSourceSwitch',1),
 ('lose-payload-offset','object_mapping.cpp','span.data_->offset_ - fields[0]};','0};','PublishedBytesRemainReadableThroughCheckpointAndSourceSwitch',1),
 ('ignore-payload-retention','journal_service.cpp','checkpoint = std::min(checkpoint, retention_->pins_.begin()->first);','(void)checkpoint;','PublishedBytesRemainReadableThroughCheckpointAndSourceSwitch',1),
 ('free-pending-target','object_reference.cpp','if (base.Get(Key(Deferred, object, allocation_id))) return {};','/* broken: pending target ignored */','PendingTargetCannotBeReusedAndCompletionEnablesReclaim',1),
 ('lose-recovered-payload','metadata_engine.cpp','recovered->payloads_.emplace(PayloadIdentity(key), std::move(payload));','(void)key; (void)payload; /* broken: reference not restored */','RestartUsesPreCheckpointPayloadAndResumesWithSelectionDisabled',1),
 ('lose-read-error','object_io.cpp','[activity](const IOBatchResult &result) { activity->Complete(result); }, ready));','[activity](const IOBatchResult &) {}, ready));','AbandonedJournalReadStillFaultsNode',1),
 ('forget-mixed-budget','object_io.cpp','const auto &spans = activity->read_->Spans();\n  for (size_t i = 0;', 'budget = {}; // broken: forget retained Data results\n  const auto &spans = activity->read_->Spans();\n  for (size_t i = 0;', 'OversizedMixedReadRejectsInsteadOfReportingTemporaryPressure',1),
 ('skip-final-flush','object_io.cpp','auto prepared = regions_.TryPrepare(requests, true);\n  Accepted(prepared.admission_);\n  std::memcpy(prepared.batch_->Buffer(0), body.data(), body.size());','auto prepared = regions_.TryPrepare(requests, false);\n  Accepted(prepared.admission_);\n  std::memcpy(prepared.batch_->Buffer(0), body.data(), body.size());','SourceRemainsJournalUntilFinalFlushCompletes',1),
 ]
 for name,file,old,new,test,count in mutations:
  s=(repo/'src/storage/disk'/file).read_text();assert s.count(old)==count,(name,'anchor',s.count(old))
  cpp=out/(name+'.cpp');cpp.write_text(s.replace(old,new));obj=out/(name+'.o')
  run(flags+['-c',cpp,'-o',obj],name+'-compile')
  run(flags+['-no-pie',out/'deferred.o',obj]+libs+deferred_wrap+['-o',out/name],name+'-link')
  run([out/name,'--gtest_filter=S10Deferred.'+test,'--gtest_output=xml:'+str(out/(name+'.xml'))],name,expected=1,timeout=120)
  failures=check(name,1,True)
  markers={'skip-journal-source':'Read(node, key', 'lose-payload-offset':'Read(node, key', 'ignore-payload-retention':'required Journal payload batch is missing','free-pending-target':'before.released_bytes_', 'lose-recovered-payload':'Entered()', 'skip-final-flush':'Entered()', 'lose-read-error':'state.error_', 'forget-mixed-budget':'misclassified as temporary pressure'}
  assert any(markers[name] in failure for failure in failures),(name,failures)
  evidence.append(dict(mutation=name,file=file,old=old,new=new,test=test,failures=failures))
  (out/'mutations.json').write_text(json.dumps(evidence,indent=2));print(name+': detected',flush=True)
(out/'summary.json').write_text(json.dumps(dict(passed=counts,mutations_detected=len(evidence),scope='Direct file NodeStorage production paths; not physical power loss or performance'),indent=2))
print(counts,flush=True)
