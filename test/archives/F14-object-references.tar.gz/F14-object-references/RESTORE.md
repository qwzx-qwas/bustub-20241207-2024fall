# F14 恢复与验证

1. 核验 test/archives/SHA256SUMS 与本包 MANIFEST；结果目录校验 F14-results.tar.gz。
2. 使用隔离源码树：检出 MANIFEST.source_base_commit（1df3ba1），覆盖结果包 source/ 内本轮八份生产文件；不要覆盖正在工作的源码树。也可直接使用包含本轮改动且全部哈希匹配的后续 commit。
3. 保留原 F13/F12/F34/S5 源码包。本 runner 检查当前生产/依赖哈希，解压并复用原测试内容；不执行这些依赖包面向旧树的 hash 检查 runner。旧对象样本由 git show 1df3ba1 的原 F13 实现生成，旧 Journal 样本由 S5 自己的原生产生成器建立，均不手造编码。
4. 在仓库外解压本包，使用 Linux O_DIRECT 文件系统、Clang 14/CMake/GCC/Python 环境：

```sh
python3 /tmp/F14-object-references/tests/run_stage.py --repo /path/to/isolated/repo --work /tmp/f14-verify --mutations
```

测试应为 F14 6 + F13 6 + F12 6 + F34 5 + S5 8 + A 5，总计 36；8 个变异必须编译成功、退出 1、XML 命中指定断言。ASan/UBSan 开启；不得把崩溃或超时当检出。

测试属于真实组件 integration/regression，ReadLease 仍是测试侧执行已保护范围的适配器，不是已上线的普通对象服务。它的预期正文/容量独立于生产元数据编码。正式 S6 ObjectIO/S7/F26/S11 接入时接管相关风险并替换适配器；不永久增加同义各层测试。未验证 SQL/Raft E2E、真实掉电、裸设备或性能。

复验后保留最终源码/结果压缩包与校验说明，删除工作目录中的 build、镜像、可执行文件、变异版本及展开测试，不增加常驻 CTest 入口。
