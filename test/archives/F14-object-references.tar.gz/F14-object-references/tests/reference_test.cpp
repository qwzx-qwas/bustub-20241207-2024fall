// Original F13/F12 scenarios are reused unchanged, not copied into a new
// matrix.
#include "mapping_test.cpp"
#include "storage/disk/object_reference.h"

extern "C" ssize_t __real_pread(int, void *, size_t, off_t);
namespace {
std::mutex read_mutex;
std::condition_variable read_cv;
bool read_armed = false, read_entered = false, read_released = true;
void ArmRead() {
  std::lock_guard<std::mutex> lock(read_mutex);
  read_armed = true;
  read_entered = false;
  read_released = false;
}
void ReleaseRead() {
  std::lock_guard<std::mutex> lock(read_mutex);
  read_released = true;
  read_armed = false;
  read_cv.notify_all();
}
struct ReadReleaseOnExit {
  ~ReadReleaseOnExit() { ReleaseRead(); }
};
}  // namespace
extern "C" ssize_t __wrap_pread(int fd, void *buf, size_t n, off_t off) {
  if ((fcntl(fd, F_GETFL) & O_DIRECT) != 0 && off >= static_cast<off_t>(6 * s5::MIB)) {
    std::unique_lock<std::mutex> lock(read_mutex);
    if (read_armed) {
      read_armed = false;
      read_entered = true;
      read_cv.notify_all();
      read_cv.wait(lock, [] { return read_released; });
    }
  }
  return __real_pread(fd, buf, n, off);
}
namespace {
auto ReferenceOptions(uint64_t unit) -> ObjectReferenceOptions { return {64, 64, 1024, 8, 64 * unit, 16}; }
template <class F>
void ReferenceFails(F f, ObjectReferenceErrorCode code, const char *why) {
  try {
    f();
    ADD_FAILURE() << why;
  } catch (const ObjectReferenceError &e) {
    EXPECT_EQ(e.Code(), code) << why;
  }
}
auto ReadLease(MappingRig &r, const ObjectReadLease &lease) -> Bytes {
  Bytes result;
  for (const auto &span : lease.Spans()) {
    if (!span.data_) {
      result.resize(result.size() + span.size_, std::byte{0});
      continue;
    }
    const auto align = r.r.regions.Describe(r.r.data).offset_alignment_;
    const auto physical = span.data_->offset_;
    const auto first = physical / align * align;
    const auto stop = (physical + span.size_ + align - 1) / align * align;
    auto prepared = r.r.regions.TryPrepare({{r.r.data, IOOperation::Read, first, stop - first}}, false);
    Require(prepared.batch_.has_value(), "protected actual IO prepare");
    auto batch = std::move(*prepared.batch_);
    Require(r.r.stack.io.TrySubmit(batch) == IOAdmission::Accepted, "protected actual IO submit");
    batch.Wait();
    Require(batch.Phase() == IOBatchPhase::Succeeded, "protected actual IO complete");
    const auto *body = reinterpret_cast<const std::byte *>(batch.Buffer(0)) + physical - first;
    result.insert(result.end(), body, body + span.size_);
  }
  return result;
}
auto ProtectedBody(MappingRig &r, ObjectReferenceManager &refs, const ObjectMappingSnapshot &view, ObjectKey key,
                   uint64_t offset, uint64_t length) -> Bytes {
  const auto lease = refs.ProtectRead(view, key, offset, length);
  return ReadLease(r, lease);
}
void Capacity(MappingRig &r, uint64_t used) {
  const auto free = r.r.Usable() - used;
  auto rest = r.a.Reserve(free);
  EXPECT_EQ(Units(rest.Extents(), r.r.opts.allocation_bytes_).size(), free / r.r.opts.allocation_bytes_);
  AllocationFails([&] { r.a.Reserve(r.r.opts.allocation_bytes_); }, AllocationErrorCode::NoSpace,
                  "capacity must agree with published ownership");
}
auto NewObject(MappingRig &r, uint64_t number) -> ObjectKey {
  ObjectKey key{r.Space(), number};
  Durable(r.objects.CreateObject(r.objects.Read(), key, 0, ObjectSizeMode::Variable));
  return key;
}
TEST(F14References, PartialReusePreservesLiveSidesAndIdentity) {
  Image image;
  MappingRig r(image, true);
  const auto u = r.r.opts.allocation_bytes_;
  ObjectReferenceManager refs(r.objects, ReferenceOptions(u));
  const auto key = NewObject(r, 71);
  const auto origin = 7 * u + 137;
  const auto bytes = Value(6 * u, 31);
  r.Put(key, origin, bytes);
  const auto old = r.objects.Read();
  const auto allocation = old.Resolve(key, origin + 13, 19).spans_.front().data_->allocation_;
  auto left = refs.ProtectRead(old, key, origin + 31, 59);
  const auto patch = Value(2 * u, 137);
  r.Put(key, origin + 2 * u, patch);
  // Fill the remaining free capacity so the next write must use the freed hole.
  auto rest = r.a.Reserve(r.r.Usable() - 8 * u);
  const auto reclaimed = refs.Reclaim(r.objects.Read(), key, allocation);
  ASSERT_TRUE(reclaimed.commit_);
  Durable(*reclaimed.commit_);
  EXPECT_EQ(reclaimed.released_bytes_, 2 * u) << "left reader must not block middle units";
  EXPECT_EQ(reclaimed.pinned_bytes_, 0U);
  EXPECT_EQ(ReadLease(r, left), Bytes(bytes.begin() + 31, bytes.begin() + 90));
  auto expected = bytes;
  std::copy(patch.begin(), patch.end(), expected.begin() + 2 * u);
  EXPECT_EQ(ProtectedBody(r, refs, r.objects.Read(), key, origin, 6 * u), expected)
      << "partial reclaim preserves live sides";
  const auto other = NewObject(r, 72);
  const auto replacement = Value(2 * u, 203);
  r.Put(other, 3 * u + 47, replacement);
  EXPECT_EQ(ProtectedBody(r, refs, r.objects.Read(), other, 3 * u + 47, 2 * u), replacement);
  ReferenceFails([&] { refs.ProtectRead(old, key, origin + 2 * u + 17, 41); }, ObjectReferenceErrorCode::Stale,
                 "released old view must not acquire reused storage");
  const auto again = refs.Reclaim(r.objects.Read(), key, allocation);
  EXPECT_FALSE(again.commit_) << "repeated retirement must not free a new owner";
  EXPECT_EQ(ProtectedBody(r, refs, r.objects.Read(), other, 3 * u + 47, 2 * u), replacement);
}
TEST(F14References, InflightReadRetainsOnlyItsUnits) {
  Image image;
  MappingRig r(image, true);
  const auto u = r.r.opts.allocation_bytes_;
  ObjectReferenceManager refs(r.objects, ReferenceOptions(u));
  const auto key = NewObject(r, 80);
  const auto origin = 5 * u + 73;
  const auto bytes = Value(4 * u, 67);
  r.Put(key, origin, bytes);
  const auto old = r.objects.Read();
  auto lease = refs.ProtectRead(old, key, origin + u + 123, 37);
  const auto allocation = lease.Spans().front().data_->allocation_;
  std::optional<ObjectReadLease> observer(lease);
  ArmRead();
  auto reading = std::async(std::launch::async, [&, keep = std::optional<ObjectReadLease>(std::move(lease))]() mutable {
    auto result = ReadLease(r, *keep);
    keep.reset();  // Actual IO completed, independent of the observer's
                   // lifetime.
    return result;
  });
  ReadReleaseOnExit cleanup;
  {
    std::unique_lock<std::mutex> lock(read_mutex);
    ASSERT_TRUE(read_cv.wait_for(lock, 10s, [] { return read_entered; }));
  }
  observer.reset();
  Durable(r.objects.Remove(r.objects.Read(), key));
  const auto partial = refs.Reclaim(r.objects.Read(), key, allocation);
  ASSERT_TRUE(partial.commit_);
  Durable(*partial.commit_);
  EXPECT_EQ(partial.released_bytes_, 3 * u) << "inflight IO retains exactly its touched allocation unit";
  EXPECT_EQ(partial.pinned_bytes_, u);
  ReferenceFails([&] { refs.ProtectRead(old, key, origin + 31, 11); }, ObjectReferenceErrorCode::Stale,
                 "unprotected old unit must be stale after reclamation");
  ReleaseRead();
  EXPECT_EQ(reading.get(), Bytes(bytes.begin() + u + 123, bytes.begin() + u + 160))
      << "held IO must read its original input";
  const auto last = refs.Reclaim(r.objects.Read(), key, allocation);
  ASSERT_TRUE(last.commit_);
  Durable(*last.commit_);
  EXPECT_EQ(last.released_bytes_, u) << "completion releases the remaining unit";
  Capacity(r, 0);
}
TEST(F14References, SubunitRetirementsAndPaddingRecoverTogether) {
  Image image;
  ObjectKey key{};
  uint64_t u, origin, allocation;
  Bytes expected;
  {
    MappingRig r(image, true);
    u = r.r.opts.allocation_bytes_;
    origin = 4 * u + 91;
    ObjectReferenceManager refs(r.objects, ReferenceOptions(u));
    key = NewObject(r, 91);
    const auto bytes = Value(2 * u + u / 4, 11);
    r.Put(key, origin, bytes);
    allocation = r.objects.Read().Resolve(key, origin + 19, 23).spans_.front().data_->allocation_;
    const auto first = Value(u / 2, 127);
    const auto second = Value(u / 2, 229);
    r.Put(key, origin, first);
    const auto not_yet = refs.Reclaim(r.objects.Read(), key, allocation);
    EXPECT_FALSE(not_yet.commit_) << "a live fraction prevents whole-unit release";
    Capacity(r, 4 * u);
    r.Put(key, origin + u / 2, second);
    const auto united = refs.Reclaim(r.objects.Read(), key, allocation);
    ASSERT_TRUE(united.commit_);
    Durable(*united.commit_);
    EXPECT_EQ(united.released_bytes_, u) << "two subunit retirements must combine";
    Durable(r.objects.Resize(r.objects.Read(), key, origin + 2 * u));
    const auto tail = refs.Reclaim(r.objects.Read(), key, allocation);
    ASSERT_TRUE(tail.commit_);
    Durable(*tail.commit_);
    EXPECT_EQ(tail.released_bytes_, u) << "retired body and padding reclaim their whole unit";
    Durable(r.objects.Resize(r.objects.Read(), key, origin + 3 * u));
    expected = first;
    expected.insert(expected.end(), second.begin(), second.end());
    expected.insert(expected.end(), bytes.begin() + u, bytes.begin() + 2 * u);
    expected.resize(3 * u, std::byte{0});
    EXPECT_EQ(ProtectedBody(r, refs, r.objects.Read(), key, origin, 3 * u), expected);
    EXPECT_EQ(r.r.b.Checkpoint(256).outcome_, MetadataCheckpointOutcome::Durable);
  }
  MappingRig r(image, false);
  ObjectReferenceManager refs(r.objects, ReferenceOptions(u));
  EXPECT_EQ(ProtectedBody(r, refs, r.objects.Read(), key, origin, 3 * u), expected)
      << "reopen preserves live data and zero extension";
  Capacity(r,
           3 * u);  // One original unit plus two independent half-unit replacements.
  EXPECT_FALSE(refs.Reclaim(r.objects.Read(), key, allocation).commit_);
  Durable(r.objects.Remove(r.objects.Read(), key));
  const auto last = refs.Reclaim(r.objects.Read(), key, allocation);
  ASSERT_TRUE(last.commit_);
  Durable(*last.commit_);
  EXPECT_EQ(last.released_bytes_, u) << "reopen must retain only remaining ownership";
  const auto remaining = r.objects.Read().Retired(key, 0);
  for (const auto &entry : remaining.ranges_) {
    const auto result = refs.Reclaim(r.objects.Read(), key, entry.span_.data_->allocation_);
    ASSERT_TRUE(result.commit_);
    Durable(*result.commit_);
  }
  Capacity(r, 0);
}
TEST(F14References, BoundsAndStaleBaseDoNotPartiallyRelease) {
  Image image;
  MappingRig r(image, true);
  const auto u = r.r.opts.allocation_bytes_;
  auto options = ReferenceOptions(u);
  options.max_leases_ = 1;
  options.max_ranges_per_lease_ = 1;
  options.max_reclaim_bytes_ = u;
  options.max_reclaim_ranges_ = 1;
  ObjectReferenceManager refs(r.objects, options);
  const auto key = NewObject(r, 101);
  const auto origin = 3 * u + 37;
  r.Put(key, origin, Value(4 * u, 77));
  const auto old = r.objects.Read();
  MappingFails([&] { refs.ProtectRead(old, key, origin - 7, 19); }, ObjectMappingErrorCode::ResourceUnavailable);
  std::optional<ObjectReadLease> held(refs.ProtectRead(old, key, origin + 17, 11));
  const auto allocation = held->Spans().front().data_->allocation_;
  MappingFails([&] { refs.ProtectRead(old, key, origin + u + 19, 13); }, ObjectMappingErrorCode::ResourceUnavailable);
  Durable(r.objects.Remove(r.objects.Read(), key));
  const auto first = refs.Reclaim(r.objects.Read(), key, allocation);
  ASSERT_TRUE(first.commit_);
  Durable(*first.commit_);
  EXPECT_EQ(first.released_bytes_, u) << "reclaim byte budget bounds a partial transaction";
  EXPECT_EQ(first.pinned_bytes_, u);
  held.reset();
  const auto stale = r.objects.Read();
  Durable(r.r.b.Commit(r.r.b.Read(), {{{77, 3, 9}, Value(23, 1)}}));
  try {
    refs.Reclaim(stale, key, allocation);
    FAIL() << "stale reclamation must reject";
  } catch (const MetadataError &e) {
    EXPECT_EQ(e.Code(), MetadataErrorCode::Conflict);
  }
  Capacity(r, 3 * u);
  for (int i = 0; i < 3; ++i) {
    const auto result = refs.Reclaim(r.objects.Read(), key, allocation);
    ASSERT_TRUE(result.commit_);
    Durable(*result.commit_);
    EXPECT_EQ(result.released_bytes_, u);
  }
  Capacity(r, 0);
  refs.Close();
  MappingFails([&] { refs.ProtectRead(old, key, origin, 19); }, ObjectMappingErrorCode::NotReady);
}
TEST(F14References, FenceAndFailedReleaseRecoverOneWholeState) {
  for (const bool fail : {false, true}) {
    SCOPED_TRACE(fail ? "injected Flush EIO" : "successful Flush");
    Image image;
    ObjectKey key{};
    uint64_t u, origin, allocation;
    Bytes expected;
    {
      MappingRig r(image, true);
      u = r.r.opts.allocation_bytes_;
      origin = 2 * u + 59;
      ObjectReferenceManager refs(r.objects, ReferenceOptions(u));
      key = NewObject(r, 111);
      expected = Value(3 * u, 71);
      r.Put(key, origin, expected);
      const auto old = r.objects.Read();
      allocation = old.Resolve(key, origin + u, u).spans_.front().data_->allocation_;
      const auto patch = Value(u, 131);
      r.Put(key, origin + u, patch);
      std::copy(patch.begin(), patch.end(), expected.begin() + u);
      auto rest = r.a.Reserve(r.r.Usable() - 4 * u);
      const auto base = r.objects.Read();
      Arm(Point::JournalFlush, fail);
      auto releasing = std::async(std::launch::async, [&] { return refs.Reclaim(base, key, allocation); });
      ReleaseOnExit cleanup;
      ASSERT_TRUE(WaitEntered());
      ReferenceFails([&] { refs.ProtectRead(old, key, origin + u + 17, 29); }, ObjectReferenceErrorCode::Busy,
                     "retirement fence must exclude new overlapping readers");
      EXPECT_EQ(ProtectedBody(r, refs, old, key, origin + 23, 31), Bytes(expected.begin() + 23, expected.begin() + 54))
          << "unrelated ranges continue during release IO";
      AllocationFails([&] { r.a.Reserve(u); }, AllocationErrorCode::NoSpace,
                      "release cannot publish free space before durable");
      ReleaseGate();
      const auto result = releasing.get();
      ASSERT_TRUE(result.commit_);
      if (fail) {
        EXPECT_NE(result.commit_->outcome_, JournalOutcome::Durable);
        EXPECT_TRUE(result.commit_->error_);
        EXPECT_EQ(result.released_bytes_, 0U);
        EXPECT_THROW(refs.ProtectRead(old, key, origin + 23, 31), MetadataError);
      } else {
        Durable(*result.commit_);
        EXPECT_EQ(result.released_bytes_, u);
        ReferenceFails([&] { refs.ProtectRead(old, key, origin + u + 17, 29); }, ObjectReferenceErrorCode::Stale,
                       "durable release must revoke old ownership");
        auto reuse = r.a.Reserve(u);
        EXPECT_EQ(Units(reuse.Extents(), u).size(), 1U);
      }
    }
    MappingRig r(image, false);
    ObjectReferenceManager refs(r.objects, ReferenceOptions(u));
    EXPECT_EQ(ProtectedBody(r, refs, r.objects.Read(), key, origin, 3 * u), expected);
    const auto retire = r.objects.Read().Retired(key, 0);
    ASSERT_LE(retire.ranges_.size(), 1U);
    if (!fail) EXPECT_TRUE(retire.ranges_.empty());
    const bool applied = retire.ranges_.empty();
    Capacity(r, (applied ? 3 : 4) * u);
    const auto finish = refs.Reclaim(r.objects.Read(), key, allocation);
    EXPECT_EQ(finish.released_bytes_, applied ? 0U : u) << "recovery resumes only an uncommitted release";
    Capacity(r, 3 * u);
  }
}
TEST(F14References, V1RemainsReadableWritableWithoutImplicitMigration) {
  const auto *legacy = std::getenv("F14_LEGACY_IMAGE");
  ASSERT_NE(legacy, nullptr) << "legacy input must be generated by archived production";
  Image image;
  std::filesystem::copy_file(legacy, image.path, std::filesystem::copy_options::overwrite_existing);
  const ObjectKey key{1, 77};
  Bytes expected;
  uint64_t origin = 0, u = 0;
  {
    MappingRig r(image, false);
    u = r.r.opts.allocation_bytes_;
    origin = 9 * u + 29;
    expected = Value(2 * u - 37, 41);
    EXPECT_EQ(r.ReadBody(r.objects.Read(), key, origin, expected.size()), expected);
    ReferenceFails([&] { ObjectReferenceManager refs(r.objects, ReferenceOptions(u)); },
                   ObjectReferenceErrorCode::UnsupportedFormat, "v1 must not silently enable reclamation");
    const auto patch = Value(u / 2, 151);
    r.Put(key, origin + u / 3, patch);
    std::copy(patch.begin(), patch.end(), expected.begin() + u / 3);
    EXPECT_EQ(r.ReadBody(r.objects.Read(), key, origin, expected.size()), expected);
    EXPECT_EQ(r.Space(), 2U);  // Space creation must preserve the old format number.
    EXPECT_EQ(r.r.b.Checkpoint(256).outcome_, MetadataCheckpointOutcome::Durable);
  }
  MappingRig reopened(image, false);
  EXPECT_EQ(reopened.ReadBody(reopened.objects.Read(), key, origin, expected.size()), expected);
  ReferenceFails([&] { ObjectReferenceManager refs(reopened.objects, ReferenceOptions(u)); },
                 ObjectReferenceErrorCode::UnsupportedFormat, "space creation and reopen preserve v1");
}
}  // namespace
