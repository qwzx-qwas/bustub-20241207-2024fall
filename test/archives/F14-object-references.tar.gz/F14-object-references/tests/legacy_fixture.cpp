// Linked to the ORIGINAL F13 production object/header, never hand-encodes v1.
#include "mapping_test.cpp"
int main(int argc, char **argv) {
  if (argc != 2) return 2;
  try {
    Image image;
    MappingRig r(image, true);
    const auto u = r.r.opts.allocation_bytes_;
    ObjectKey key{r.Space(), 77};
    Require(key.space_ == 1, "legacy space identity");
    Require(
        r.objects.CreateObject(r.objects.Read(), key, 0, ObjectSizeMode::Variable).outcome_ == JournalOutcome::Durable,
        "legacy create object");
    r.Put(key, 9 * u + 29, Value(2 * u - 37, 41));
    Require(r.r.b.Checkpoint(256).outcome_ == MetadataCheckpointOutcome::Durable, "legacy checkpoint");
    std::filesystem::copy_file(image.path, argv[1], std::filesystem::copy_options::overwrite_existing);
    return 0;
  } catch (const std::exception &e) {
    std::cerr << e.what() << '\n';
    return 1;
  }
}
