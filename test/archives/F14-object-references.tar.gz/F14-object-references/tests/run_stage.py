#!/usr/bin/env python3
"""F14 real reclamation/IO/ownership contracts; archived, not registered in CTest."""
import argparse, hashlib, json, os, pathlib, subprocess, tarfile, time
import xml.etree.ElementTree as ET
p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--work',required=True);p.add_argument('--mutations',action='store_true');a=p.parse_args()
repo=pathlib.Path(a.repo).resolve();work=pathlib.Path(a.work).resolve();src=pathlib.Path(__file__).resolve().parent
assert repo!=work and repo not in work.parents,'work must be outside repository'
work.mkdir(parents=True,exist_ok=True)
manifest=src.parent/'MANIFEST.json'
if manifest.exists():
 m=json.loads(manifest.read_text())
 for field in ('production_sha256','dependency_sha256'):
  for name,h in m[field].items():assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==h,('source drift',name)
env={k:v for k,v in os.environ.items() if not k.startswith('GTEST_')};env.update(S5_WORKDIR=str(work),ASAN_OPTIONS='detect_leaks=1:abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1')
commands=[]
def run(cmd,log,expected=0,timeout=900,cwd=None):
 cmd=list(map(str,cmd));start=time.monotonic()
 with (work/log).open('w') as out:r=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT,env=env,cwd=cwd or repo,timeout=timeout)
 commands.append({'command':cmd,'log':log,'seconds':time.monotonic()-start,'exit':r.returncode})
 (work/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 assert r.returncode==expected,(log,r.returncode,expected)
run(['cmake','-S',repo,'-B',work/'build','-DCMAKE_BUILD_TYPE=Debug','-DCMAKE_C_COMPILER=clang-14','-DCMAKE_CXX_COMPILER=clang++-14','-DBUSTUB_SANITIZER=address,undefined','-DCMAKE_EXE_LINKER_FLAGS=-no-pie'],'configure.log')
run(['cmake','--build',work/'build','--target','bustub','gtest_main','b_plus_tree_insert_test','b_plus_tree_delete_test','-j3'],'build.log')
for name in ['S5-journal-recycling','F34-node-lifecycle','F12-data-allocator','F13-object-mapping']:
 with tarfile.open(repo/('test/archives/'+name+'.tar.gz')) as t:t.extractall(work,filter='data')
dep=work/'S5-journal-recycling/test/storage_redesign'
flags=['clang++-14','-std=c++17','-g','-O0','-Wall','-Wextra','-Werror','-Wno-unused-parameter','-pthread','-fsanitize=address,undefined','-fno-omit-frame-pointer','-I'+str(repo/'src/include'),'-I'+str(repo/'third_party/fmt/include'),'-I'+str(repo/'third_party/googletest/googletest/include'),'-I'+str(dep),'-I'+str(work/'F12-data-allocator/tests'),'-I'+str(work/'F13-object-mapping/tests'),'-I'+str(repo/'src/storage/disk')]
libs=[work/'build/lib'/('lib'+name+'.a') for name in ['bustub','fmtd','gtest_main','gtest']]
wraps=['-Wl,--wrap=pwrite','-Wl,--wrap=fdatasync']
legacy=work/'legacy-f13';(legacy/'storage/disk').mkdir(parents=True,exist_ok=True)
for name,target in [('src/include/storage/disk/object_mapping.h',legacy/'storage/disk/object_mapping.h'),('src/storage/disk/object_mapping.cpp',legacy/'object_mapping.cpp')]:
 target.write_bytes(subprocess.check_output(['git','show','1df3ba1:'+name],cwd=repo))
legacyflags=flags[:1]+['-I'+str(legacy)]+flags[1:]
run(legacyflags+['-c',legacy/'object_mapping.cpp','-o',work/'legacy-map.o'],'legacy-production-compile.log')
run(legacyflags+['-no-pie',src/'legacy_fixture.cpp',work/'legacy-map.o']+libs+wraps+['-o',work/'legacy-producer'],'legacy-producer-compile.log')
run([work/'legacy-producer',work/'f13-legacy.img'],'legacy-producer.log',timeout=120)
env['F14_LEGACY_IMAGE']=str(work/'f13-legacy.img')
wraps+=['-Wl,--wrap=pread']
run(flags+['-c',src/'reference_test.cpp','-o',work/'reference-test.o'],'compile.log')
run(flags+['-no-pie',work/'reference-test.o']+libs+wraps+['-o',work/'reference-test'],'link.log')
run([work/'reference-test','--gtest_output=xml:'+str(work/'f14-f13-f12.xml')],'f14-f13-f12.log',timeout=180)
run(flags+['-no-pie',work/'F34-node-lifecycle/tests/lifecycle_test.cpp']+libs+wraps+['-Wl,--wrap=close','-o',work/'lifecycle_test'],'f34-compile.log')
run([work/'lifecycle_test','--gtest_output=xml:'+str(work/'lifecycle.xml')],'f34-run.log',timeout=120)
run(['python3',dep/'build_checks.py',repo,work],'s5-regression.log',timeout=300)
for name in ['insert','delete']:
 run([work/('build/test/b_plus_tree_'+name+'_test'),'--gtest_output=xml:'+str(work/(name+'.xml'))],name+'-run.log',timeout=120,cwd=work)
counts={'f14-f13-f12.xml':18,'lifecycle.xml':5,'s5.xml':8,'insert.xml':3,'delete.xml':2}
for name,n in counts.items():
 cases=ET.parse(work/name).getroot().findall('./testsuite/testcase')
 assert len(cases)==n and all(c.get('result')=='completed' and not any(c.find(k) is not None for k in ('failure','error','skipped')) for c in cases),name
# Only compiled mutants failing the specified behavioral assertion count.
mutations=[
 ('ignore_read_pin','pinned.push_back(range.range_);','/* mutation: omit active reader */','InflightReadRetainsOnlyItsUnits','inflight IO retains exactly its touched allocation unit'),
 ('pin_whole_allocation','pinned.push_back(range.range_);','pinned.push_back(allocation.range_);','PartialReusePreservesLiveSidesAndIdentity','reclaimed.commit_'),
 ('skip_retirement_fence','ReferenceFail(ObjectReferenceErrorCode::Busy, "read range is being retired");','/* mutation: admit retiring range */','FenceAndFailedReleaseRecoverOneWholeState','retirement fence must exclude new overlapping readers'),
 ('trust_old_snapshot','CheckOwnership(current, range, context_->unit_, &lookups, state_->options_.max_scan_entries_);','CheckOwnership(view.base_, range, context_->unit_, &lookups, state_->options_.max_scan_entries_);','PartialReusePreservesLiveSidesAndIdentity','released old view must not acquire reused storage'),
 ('ignore_padding','std::vector<Interval> dead{{allocation.range_.begin_ + allocation.initialized_, allocation.range_.end_}};','std::vector<Interval> dead;','SubunitRetirementsAndPaddingRecoverTogether','tail.commit_'),
 ('ignore_reclaim_byte_budget','auto remaining_bytes = state_->options_.max_reclaim_bytes_;','auto remaining_bytes = allocation.range_.end_ - allocation.range_.begin_;','BoundsAndStaleBaseDoNotPartiallyRelease','reclaim byte budget bounds a partial transaction'),
 ('refresh_stale_base','context_->allocator_.Release(base, ranges, changes.Take())','context_->allocator_.Release(context_->metadata_.Read(), ranges, changes.Take())','BoundsAndStaleBaseDoNotPartiallyRelease','stale reclamation must reject'),
 ('drop_remaining_ownership','Encode({part.end_ - part.begin_, allocation_id})','Encode({o.range_.end_ - part.begin_, allocation_id})','PartialReusePreservesLiveSidesAndIdentity','released old view must not acquire reused storage'),
]
evidence=[]
if a.mutations:
 for name,old,new,test,marker in mutations:
  code=(repo/'src/storage/disk/object_reference.cpp').read_text();assert code.count(old)==1,(name,old)
  cpp=work/(name+'.cpp');cpp.write_text(code.replace(old,new));obj=work/(name+'.o');exe=work/name
  run(flags+['-c',cpp,'-o',obj],name+'-compile.log',timeout=120)
  run(flags+['-no-pie',work/'reference-test.o',obj]+libs+wraps+['-o',exe],name+'-link.log',timeout=120)
  run([exe,'--gtest_filter=F14References.'+test,'--gtest_output=xml:'+str(work/(name+'.xml'))],name+'-run.log',expected=1,timeout=120)
  failures=[f.text or '' for f in ET.parse(work/(name+'.xml')).getroot().iter('failure')]
  assert any(marker in f for f in failures),(name,failures)
  evidence.append({'mutation':name,'old':old,'new':new,'test':test,'expected_marker':marker,'failures':failures})
  (work/'mutations.json').write_text(json.dumps(evidence,indent=2)+'\n');print(name+': detected',flush=True)
(work/'summary.json').write_text(json.dumps({'passed':counts,'mutations_detected':len(evidence),'scope':'F14 real B/F12/Journal/Direct file and actual IO lifetime; no NodeStorage/SQL/Raft E2E, raw device, physical power loss or performance claim.'},indent=2)+'\n')
print('F14 6 + F13 6 + F12 6 + F34 5 + S5 8 + A 5 passed; mutations '+str(len(evidence)),flush=True)
