#include "fixture.h"
#include "storage/disk/node_storage.h"
#include "gtest/gtest.h"
#include <chrono>
#include <condition_variable>
#include <cstring>
#include <future>
#include <mutex>
#include <optional>
#include <thread>
using namespace std::chrono_literals;
extern "C" ssize_t __real_pread(int, void *, size_t, off_t);
extern "C" ssize_t __real_pwrite(int, const void *, size_t, off_t);
extern "C" int __real_fdatasync(int);
namespace {
using namespace bustub;
using namespace s5;
enum class Gate { None, Read, Write, Flush, Journal, CommitFlush };
std::mutex gate_mutex;
std::condition_variable gate_cv;
Gate gate = Gate::None;
bool entered = false, released = true, fail = false, tracking = false;
size_t data_writes = 0, flushes = 0, before_journal_flushes = 0;
bool journal_started = false;
size_t data_read_bytes = 0;
int tracked_fd = -1;
void Arm(Gate point, bool error = false) {
  std::lock_guard<std::mutex> lock(gate_mutex);
  gate = point;
  entered = false;
  released = false;
  fail = error;
  data_writes = flushes = before_journal_flushes = 0;
  journal_started = false;
  data_read_bytes = 0;
  tracked_fd = -1;
  tracking = true;
}
void Release() {
  std::lock_guard<std::mutex> lock(gate_mutex);
  released = true;
  gate_cv.notify_all();
}
void Reset() {
  std::lock_guard<std::mutex> lock(gate_mutex);
  released = true;
  gate = Gate::None;
  tracking = false;
  tracked_fd = -1;
  gate_cv.notify_all();
}
struct Cleanup {
  ~Cleanup() { Reset(); }
};
bool Pause(std::unique_lock<std::mutex> &lock) {
  entered = true;
  gate = Gate::None;
  gate_cv.notify_all();
  gate_cv.wait(lock, [] { return released; });
  return fail;
}
bool Entered() {
  std::unique_lock<std::mutex> lock(gate_mutex);
  return gate_cv.wait_for(lock, 5s, [] { return entered; });
}
bool Direct(int fd) { return (fcntl(fd, F_GETFL) & O_DIRECT) != 0; }
} // namespace
extern "C" ssize_t __wrap_pread(int fd, void *buf, size_t size, off_t off) {
  if (Direct(fd) && off >= static_cast<off_t>(6 * MIB)) {
    std::unique_lock<std::mutex> lock(gate_mutex);
    if (tracking)
      data_read_bytes += size;
    if (gate == Gate::Read && Pause(lock)) {
      errno = EIO;
      return -1;
    }
  }
  return __real_pread(fd, buf, size, off);
}
extern "C" ssize_t __wrap_pwrite(int fd, const void *buf, size_t size,
                                 off_t off) {
  if (Direct(fd) && off >= static_cast<off_t>(6 * MIB)) {
    std::unique_lock<std::mutex> lock(gate_mutex);
    if (tracking) {
      ++data_writes;
      tracked_fd = fd;
      gate_cv.notify_all();
    }
    if (gate == Gate::Write && Pause(lock)) {
      errno = EIO;
      return -1;
    }
  }
  if (Direct(fd) && off >= static_cast<off_t>(JOURNAL_START) &&
      off < static_cast<off_t>(6 * MIB)) {
    std::unique_lock<std::mutex> lock(gate_mutex);
    if (tracking)
      journal_started = true;
    if (gate == Gate::Journal && Pause(lock)) {
      errno = EIO;
      return -1;
    }
  }
  return __real_pwrite(fd, buf, size, off);
}
extern "C" int __wrap_fdatasync(int fd) {
  std::unique_lock<std::mutex> lock(gate_mutex);
  if (tracking && fd == tracked_fd) {
    ++flushes;
    if (!journal_started)
      ++before_journal_flushes;
    if ((gate == Gate::Flush || (gate == Gate::CommitFlush && journal_started)) && Pause(lock)) {
      errno = EIO;
      return -1;
    }
  }
  lock.unlock();
  return __real_fdatasync(fd);
}
namespace {
auto Options(const Image &image) -> NodeStorageOptions {
  BlockDevice dev(image.path, {});
  const auto u = static_cast<uint32_t>(
      std::lcm<uint64_t>(4096, 4 * dev.Info().offset_alignment_));
  Require(u <= 16384, "alignment exceeds fixture budget");
  BootstrapIdentity id{};
  id.storage_.fill(11);
  id.device_.fill(31);
  JournalIdentity jid{};
  jid.fill(73);
  return {image.path,
          {},
          {3, 2048, 16 * MIB},
          id,
          jid,
          {4ULL * u, u, 8192, MIB, 512, 2 * MIB, 8, 32, 4 * MIB},
          {256, 2048, 16384, MIB},
          {1, 1ms, 1000ms},
          ObjectStorageOptions{{u, 64, MIB, 2 * MIB, 8, 1024, 4096},
                               {2, 512, 128 * 1024, 256, 32},
                               {64, 64, 1024, 8, 2 * MIB, 16},
                               2 * MIB,
                               2 * MIB},
          ObjectTransactionOptions{16, 16, 128 * 1024, 4 * MIB, 2ms, 1h}};
}
auto Layout(const NodeStorageOptions &o) -> BootstrapLayout {
  return {o.identity_,
          8 * MIB,
          {Range(2 * MIB, MIB),
           Range(JOURNAL_START, 64ULL * o.journal_.unit_bytes_),
           Range(6 * MIB, 2 * MIB)}};
}
void Durable(const JournalResult &r) {
  Require(r.outcome_ == JournalOutcome::Durable && !r.error_,
          "required metadata operation is not durable");
}
auto New(NodeStorage &node, uint64_t number) -> ObjectKey {
  const auto space = node.CreateObjectSpace(node.Objects());
  Require(space.result_.outcome_ == JournalOutcome::Durable && space.space_,
          "space durable");
  ObjectKey key{*space.space_, number};
  Require(node.CreateObject(node.Objects(), key, 0, ObjectSizeMode::Variable)
                  .outcome_ == JournalOutcome::Durable,
          "object durable");
  return key;
}
auto Read(NodeStorage &node, ObjectKey key, uint64_t offset, uint64_t length)
    -> Bytes {
  auto read = node.ReadObject(node.Objects(), key, offset, length);
  read.Wait();
  Bytes bytes(read.Size());
  read.CopyTo(bytes.data(), bytes.size());
  return bytes;
}
auto Allocation(NodeStorage &node, ObjectKey key, uint64_t offset) -> uint64_t {
  const auto resolved = node.Objects().Resolve(key, offset, 1);
  Require(resolved.spans_.size() == 1 && resolved.spans_.front().data_,
          "setup requires a mapped byte at the requested offset");
  return resolved.spans_.front().data_->allocation_;
}
void AwaitDraining(NodeStorage &node) {
  const auto until = std::chrono::steady_clock::now() + 5s;
  while (node.State().phase_ != NodeStoragePhase::Draining &&
         std::chrono::steady_clock::now() < until)
    std::this_thread::yield();
  Require(node.State().phase_ == NodeStoragePhase::Draining,
          "Close did not enter Draining before the test deadline");
}
auto Change(ObjectOperation kind, ObjectKey key, uint64_t offset,
            Bytes data = {}) -> ObjectMutation {
  return {kind, key, offset, ObjectSizeMode::Variable, std::move(data)};
}
auto Submit(NodeStorage &node, ObjectTransaction tx)
    -> ObjectTransactionTicket {
  auto result = node.SubmitObjects(tx);
  Require(result.admission_ == IOAdmission::Accepted && result.ticket_,
          "transaction admission");
  return std::move(*result.ticket_);
}
auto Finish(ObjectTransactionTicket &ticket) -> JournalResult {
  Require(ticket.WaitFor(5s), "transaction completion deadline");
  return ticket.Result();
}
void Commit(NodeStorage &node, ObjectTransaction tx) {
  auto ticket = Submit(node, std::move(tx));
  const auto result = Finish(ticket);
  if (result.error_)
    std::rethrow_exception(result.error_);
  Durable(result);
}
TEST(S7Common, AtomicRangesControlsAndRecovery) {
  Image image;
  auto options = Options(image);
  NodeStorage node(options);
  node.Create(Layout(options));
  const auto u = options.objects_->allocator_.allocation_bytes_;
  const auto space = node.CreateObjectSpace(node.Objects());
  Require(space.space_.has_value(), "create space");
  const ObjectKey x{*space.space_, 71}, y{*space.space_, 89};
  auto control = Value(47, 3);
  Commit(node, {{Change(ObjectOperation::Create, x, 15 * u),
                 Change(ObjectOperation::Create, y, 12 * u)},
                {{x, 9, control}}});
  Bytes model_x(15 * u), model_y(12 * u);
  for (auto [ox, oy, nx, ny, seed] :
       std::vector<std::tuple<size_t, size_t, size_t, size_t, unsigned>>{
           {3 * u + 137, 7 * u + 59, 2 * u + 113, u + 271, 19},
           {4 * u + 211, 8 * u + 89, 179, 331, 71},
           {11 * u + 57, 5 * u + 117, u + 311, 2 * u + 79, 203}}) {
    const auto bx = Value(nx, seed), by = Value(ny, seed + 11);
    auto old = node.Objects();
    Commit(node, {{Change(ObjectOperation::Write, x, ox, bx),
                   Change(ObjectOperation::Write, y, oy, by)},
                  {{x, 9, Value(43, seed)}}});
    EXPECT_EQ(old.Describe(x).size_, model_x.size());
    auto previous = node.ReadObject(old, x, 3 * u + 19, 8 * u);
    previous.Wait();
    Bytes actual(previous.Size());
    previous.CopyTo(actual.data(), actual.size());
    EXPECT_EQ(actual, Bytes(model_x.begin() + 3 * u + 19,
                            model_x.begin() + 11 * u + 19))
        << "old view keeps old bytes";
    std::copy(bx.begin(), bx.end(), model_x.begin() + ox);
    std::copy(by.begin(), by.end(), model_y.begin() + oy);
    EXPECT_EQ(
        Read(node, x, 3 * u + 29, 10 * u),
        Bytes(model_x.begin() + 3 * u + 29, model_x.begin() + 13 * u + 29))
        << "independent object byte model";
    EXPECT_EQ(
        Read(node, y, 5 * u + 31, 6 * u),
        Bytes(model_y.begin() + 5 * u + 31, model_y.begin() + 11 * u + 31))
        << "independent object byte model";
    EXPECT_EQ(node.Objects().Control(x, 9),
              std::optional<Bytes>(Value(43, seed)));
  }
  Commit(node, {{Change(ObjectOperation::Resize, x, 5 * u + 71)}, {}});
  model_x.resize(5 * u + 71);
  Commit(node, {{Change(ObjectOperation::Resize, x, 15 * u)}, {}});
  model_x.resize(15 * u);
  node.Close();
  node.Open();
  EXPECT_EQ(Read(node, x, 4 * u + 19, 10 * u),
            Bytes(model_x.begin() + 4 * u + 19, model_x.begin() + 14 * u + 19))
      << "truncated bytes do not resurrect";
  EXPECT_EQ(Read(node, y, 5 * u + 31, 6 * u),
            Bytes(model_y.begin() + 5 * u + 31, model_y.begin() + 11 * u + 31));
  Commit(node,
         {{Change(ObjectOperation::Remove, y, 0)}, {{x, 9, std::nullopt}}});
  node.Close();
  node.Open();
  EXPECT_THROW(node.Objects().Describe(y), ObjectMappingError);
  EXPECT_FALSE(node.Objects().Control(x, 9));
  node.Close();
}
TEST(S7Common, HandoffOrdersDependenciesAndLetsIndependentWorkFinish) {
  Image image;
  auto options = Options(image);
  NodeStorage node(options);
  node.Create(Layout(options));
  const auto u = options.objects_->allocator_.allocation_bytes_;
  const auto x = New(node, 101), y = New(node, 102);
  auto a = Value(u, 17), b = Value(u, 101), c = Value(u, 199);
  Cleanup cleanup;
  Arm(Gate::Write);
  auto first = Submit(node, {{Change(ObjectOperation::Write, x, 0, a)}, {}});
  ASSERT_TRUE(Entered());
  auto second = Submit(node, {{Change(ObjectOperation::Append, x, 0, b)}, {}});
  auto independent =
      Submit(node, {{Change(ObjectOperation::Write, y, 0, c)}, {}});
  Durable(Finish(independent));
  EXPECT_FALSE(first.WaitFor(1ms));
  EXPECT_FALSE(second.WaitFor(1ms));
  EXPECT_EQ(node.Objects().Describe(x).size_, 0U)
      << "accepted does not mean published";
  EXPECT_EQ(Read(node, y, 31, u - 31), Bytes(c.begin() + 31, c.end()));
  Release();
  Durable(Finish(first));
  Durable(Finish(second));
  Reset();
  a.insert(a.end(), b.begin(), b.end());
  EXPECT_EQ(Read(node, x, 17, 2 * u), Bytes(a.begin() + 17, a.end()))
      << "dependent append uses published predecessor";
  node.Close();
}
TEST(S7Common, RetainedResultsBoundAdmissionAndDroppedTicketStillDrains) {
  Image image;
  auto options = Options(image);
  options.transactions_->max_requests_ = 2;
  NodeStorage node(options);
  node.Create(Layout(options));
  const auto u = options.objects_->allocator_.allocation_bytes_;
  const auto x = New(node, 111), y = New(node, 112);
  const auto a = Value(u, 27), b = Value(u, 65);
  Cleanup cleanup;
  Arm(Gate::Write);
  std::optional<ObjectTransactionTicket> first(
      Submit(node, {{Change(ObjectOperation::Write, x, 0, a)}, {}}));
  ASSERT_TRUE(Entered());
  first.reset();
  auto second = Submit(node, {{Change(ObjectOperation::Write, y, 0, b)}, {}});
  Durable(Finish(second));
  ObjectTransaction third{
      {Change(ObjectOperation::Append, y, 0, Value(71, 93))}, {}};
  auto rejected = node.SubmitObjects(third);
  ASSERT_EQ(rejected.admission_, IOAdmission::Full)
      << "running and retained results consume admission";
  ASSERT_EQ(third.objects_.size(), 1U);
  EXPECT_EQ(third.objects_.front().bytes_, Value(71, 93))
      << "rejection preserves caller input";
  auto close = std::async(std::launch::async, [&] { node.Close(); });
  Cleanup release_before_join;
  AwaitDraining(node);
  EXPECT_FALSE(node.State().object_transaction_);
  EXPECT_EQ(close.wait_for(20ms), std::future_status::timeout)
      << "close drains handed-off work";
  Release();
  close.get();
  Reset();
  EXPECT_EQ(second.Result().outcome_, JournalOutcome::Durable);
  node.Open();
  EXPECT_EQ(Read(node, x, 0, u), a);
  EXPECT_EQ(Read(node, y, 0, u), b);
  node.Close();
}
TEST(S7Common, SmallAppendsPreservePreviousVersions) {
  Image image;
  auto options = Options(image);
  NodeStorage node(options);
  node.Create(Layout(options));
  BlockDevice dev(image.path, {});
  const auto align = dev.Info().offset_alignment_;
  const auto key = New(node, 131);
  auto model = Value(align, 13);
  Commit(node, {{Change(ObjectOperation::Write, key, 0, model)}, {}});
  auto allocation = Allocation(node, key, 0);
  auto suffix = Value(align + 17, 97);
  Commit(node, {{Change(ObjectOperation::Append, key, 0, suffix)}, {}});
  model.insert(model.end(), suffix.begin(), suffix.end());
  EXPECT_NE(Allocation(node, key, align + 3), allocation)
      << "IO alignment alone must not authorize in-place tail writes";
  EXPECT_EQ(Read(node, key, 31, model.size()),
            Bytes(model.begin() + 31, model.end()));
  const auto old = node.Objects();
  const auto second_allocation = Allocation(node, key, align + 3);
  suffix = Value(113, 211);
  Commit(node, {{Change(ObjectOperation::Append, key, 0, suffix)}, {}});
  model.insert(model.end(), suffix.begin(), suffix.end());
  EXPECT_NE(Allocation(node, key, align + 3), second_allocation)
      << "unaligned tail must COW instead of overwriting old unit";
  auto previous = node.ReadObject(old, key, align + 3, align + 14);
  previous.Wait();
  Bytes saved(previous.Size());
  previous.CopyTo(saved.data(), saved.size());
  EXPECT_EQ(saved,
            Bytes(model.begin() + align + 3, model.end() - suffix.size()));
  const auto retired = node.ReclaimObject(node.Objects(), key, allocation);
  EXPECT_EQ(retired.released_bytes_,
            options.objects_->allocator_.allocation_bytes_)
      << "old COW tail allocation becomes reclaimable";
  node.Close();
  node.Open();
  EXPECT_EQ(Read(node, key, 0, model.size()), model);
  node.Close();
}
TEST(S7Common, MultiObjectDataBatchFlushesOnceBeforeAtomicPublication) {
  Image image;
  auto options = Options(image);
  NodeStorage node(options);
  node.Create(Layout(options));
  const auto u = options.objects_->allocator_.allocation_bytes_;
  const auto x = New(node, 141), y = New(node, 142);
  auto a = Value(u, 113), b = Value(u, 181), control = Value(33, 29);
  Cleanup cleanup;
  Arm(Gate::Write);
  auto ticket = Submit(node, {{Change(ObjectOperation::Write, x, 0, a),
                               Change(ObjectOperation::Write, y, 0, b)},
                              {{x, 5, control}}});
  ASSERT_TRUE(Entered());
  {
    std::unique_lock<std::mutex> lock(gate_mutex);
    ASSERT_TRUE(gate_cv.wait_for(lock, 5s, [] { return data_writes == 2; }));
    EXPECT_EQ(flushes, 0U) << "all batch members precede shared Flush";
    EXPECT_FALSE(journal_started);
  }
  auto before = node.Objects();
  EXPECT_EQ(before.Describe(x).size_, 0U);
  EXPECT_EQ(before.Describe(y).size_, 0U);
  EXPECT_FALSE(before.Control(x, 5));
  Release();
  Durable(Finish(ticket));
  {
    std::lock_guard<std::mutex> lock(gate_mutex);
    EXPECT_EQ(before_journal_flushes, 1U)
        << "one data Flush for the transaction";
  }
  Reset();
  EXPECT_EQ(Read(node, x, 0, u), a);
  EXPECT_EQ(Read(node, y, 0, u), b);
  EXPECT_EQ(node.Objects().Control(x, 5), std::optional<Bytes>(control));
  node.Close();
  node.Open();
  EXPECT_EQ(Read(node, x, 0, u), a);
  EXPECT_EQ(Read(node, y, 0, u), b);
  node.Close();
}
TEST(S7Common, LargeOverwriteReadsOnlySurvivingEdges) {
  Image image;
  auto options = Options(image);
  NodeStorage node(options);
  node.Create(Layout(options));
  const auto u = options.objects_->allocator_.allocation_bytes_;
  const auto x = New(node, 149);
  auto model = Value(12 * u, 71);
  Commit(node, {{Change(ObjectOperation::Write, x, 0, model)}, {}});
  const auto patch = Value(6 * u + 131, 193);
  Cleanup cleanup;
  Arm(Gate::None);
  Commit(node, {{Change(ObjectOperation::Write, x, 2 * u + 73, patch)}, {}});
  {
    std::lock_guard<std::mutex> lock(gate_mutex);
    EXPECT_LE(data_read_bytes, 2 * u)
        << "large overwrite reads only surviving edge units";
  }
  Reset();
  std::copy(patch.begin(), patch.end(), model.begin() + 2 * u + 73);
  EXPECT_EQ(Read(node, x, u + 17, 10 * u),
            Bytes(model.begin() + u + 17, model.begin() + 11 * u + 17));
  node.Close();
}
TEST(S7Common, FailureStagesNeverReportPartialTransactionSuccess) {
  for (auto point : {Gate::Read, Gate::Write, Gate::Flush, Gate::Journal, Gate::CommitFlush}) {
    Image image;
    auto options = Options(image);
    NodeStorage node(options);
    node.Create(Layout(options));
    const auto u = options.objects_->allocator_.allocation_bytes_;
    const auto x = New(node, 151), y = New(node, 152);
    const auto a = Value(2 * u, 71), b = Value(2 * u, 79),
               patch = Value(137, 193), control = Value(31, 97);
    Commit(node, {{Change(ObjectOperation::Write, x, 0, a),
                   Change(ObjectOperation::Write, y, 0, b)},
                  {{x, 7, control}}});
    Cleanup cleanup;
    Arm(point, true);
    auto ticket =
        Submit(node, {{Change(ObjectOperation::Write, x, u + 31, patch),
                       Change(ObjectOperation::Write, y, u + 59, patch)},
                      {{x, 7, Value(39, 203)}}});
    ASSERT_TRUE(Entered());
    Release();
    const auto result = Finish(ticket);
    EXPECT_NE(result.outcome_, JournalOutcome::Durable);
    EXPECT_TRUE(result.error_);
    Reset();
    node.Close();
    node.Open();
    const auto got = node.Objects().Control(x, 7);
    if (point != Gate::Journal && point != Gate::CommitFlush) {
      EXPECT_EQ(result.outcome_, JournalOutcome::NotCommitted);
    }
    if (result.outcome_ == JournalOutcome::NotCommitted) {
      EXPECT_EQ(got, std::optional<Bytes>(control))
          << "definitely uncommitted must recover old control";
    }
    auto expected_a = a, expected_b = b;
    if (got != std::optional<Bytes>(control)) {
      ASSERT_TRUE(point == Gate::Journal || point == Gate::CommitFlush);
      EXPECT_EQ(result.outcome_, JournalOutcome::Indeterminate);
      ASSERT_EQ(got, std::optional<Bytes>(Value(39, 203)));
      std::copy(patch.begin(), patch.end(), expected_a.begin() + u + 31);
      std::copy(patch.begin(), patch.end(), expected_b.begin() + u + 59);
    }
    EXPECT_EQ(Read(node, x, 37, 2 * u),
              Bytes(expected_a.begin() + 37, expected_a.end()))
        << "recovered transaction has one complete outcome";
    EXPECT_EQ(Read(node, y, 43, 2 * u),
              Bytes(expected_b.begin() + 43, expected_b.end()))
        << "recovered transaction has one complete outcome";
    node.Close();
  }
}
TEST(S7Common, CapacityRetryKeepsAcceptedWorkAndOldVersionsConflict) {
  Image image;
  auto options = Options(image);
  options.io_.max_operations_ = 64;
  options.objects_->allocator_.max_reservations_ = 64;
  NodeStorage node(options);
  node.Create(Layout(options));
  const auto u = options.objects_->allocator_.allocation_bytes_;
  const auto x = New(node, 161), y = New(node, 162);
  auto original = Value(3 * u, 31);
  Commit(node, {{Change(ObjectOperation::Write, x, 0, original)}, {}});
  std::vector<ObjectWrite> held;
  for (size_t i = 0; i < options.io_.max_operations_; ++i) {
    auto b = node.WriteObjectData(original.data(), u);
    b.Wait();
    Require(b.Result().writes_durable_, "occupy IO slot");
    held.push_back(std::move(b));
  }
  auto ticket = Submit(
      node, {{Change(ObjectOperation::Write, x, u + 31, Value(93, 43))}, {}});
  EXPECT_FALSE(ticket.WaitFor(20ms))
      << "accepted task remains pending while worker resources are held";
  auto allocation_wait = Submit(
      node, {{Change(ObjectOperation::Write, y, 0, Value(u, 179))}, {}});
  EXPECT_FALSE(allocation_wait.WaitFor(20ms))
      << "accepted task waits for occupied allocator reservation slots";
  held.clear();
  Durable(Finish(ticket));
  Durable(Finish(allocation_wait));
  EXPECT_EQ(Read(node, y, 0, u), Value(u, 179));
  const auto patch = Value(93, 43);
  std::copy(patch.begin(), patch.end(), original.begin() + u + 31);
  EXPECT_EQ(Read(node, x, 0, 3 * u), original);
  Cleanup cleanup;
  Arm(Gate::Write);
  auto stale = Submit(
      node, {{Change(ObjectOperation::Write, x, u + 71, Value(127, 103))}, {}});
  ASSERT_TRUE(Entered());
  Durable(node.ResizeObject(node.Objects(), x, u));
  Release();
  const auto result = Finish(stale);
  EXPECT_EQ(result.outcome_, JournalOutcome::NotCommitted);
  ASSERT_TRUE(result.error_);
  try {
    std::rethrow_exception(result.error_);
  } catch (const MetadataError &e) {
    EXPECT_EQ(e.Code(), MetadataErrorCode::Conflict);
  } catch (...) {
    FAIL() << "expected object version conflict";
  }
  Reset();
  EXPECT_EQ(Read(node, x, 0, 3 * u),
            Bytes(original.begin(), original.begin() + u));
  node.Close();
}
TEST(S7Common, UnsatisfiableRequestsFinishAndLeaveOldStateIntact) {
  // Each limit rejects a different stage that previously could be retried forever:
  // Common's rounded write limit, RMW read limit, executor slots/buffers, and
  // allocator fragmentation/search limits. These are legal independent configs.
  enum class Limit { WriteBytes, ReadBytes, Members, BufferBytes, Fragments };
  for (const auto limit : {Limit::WriteBytes, Limit::ReadBytes, Limit::Members,
                           Limit::BufferBytes, Limit::Fragments}) {
    SCOPED_TRACE(static_cast<int>(limit));
    Image image;
    auto options = Options(image);
    const auto u = options.objects_->allocator_.allocation_bytes_;
    options.transactions_->max_operations_ = 80;
    options.transactions_->max_request_bytes_ = 2 * MIB;
    options.transactions_->max_pending_bytes_ = 8 * MIB;
    if (limit == Limit::WriteBytes) options.objects_->max_write_bytes_ = u;
    if (limit == Limit::ReadBytes) options.objects_->max_read_bytes_ = u / 2;
    if (limit == Limit::Members) options.io_.max_operations_ = 64;
    if (limit == Limit::BufferBytes) options.io_.max_buffer_bytes_ = 256 * 1024;
    if (limit == Limit::Fragments) options.objects_->allocator_.max_extents_ = 1;
    NodeStorage node(options);
    node.Create(Layout(options));
    const auto space = node.CreateObjectSpace(node.Objects());
    Require(space.space_.has_value(), "space created for limit input");
    const size_t count = limit == Limit::Members ? 65 : 1;
    std::vector<ObjectKey> keys;
    ObjectTransaction create, transaction;
    for (size_t i = 0; i < count; ++i) {
      const ObjectKey key{*space.space_, 300 + i};
      keys.push_back(key);
      create.objects_.push_back(Change(ObjectOperation::Create, key, 0));
      const auto size = limit == Limit::BufferBytes ? 384 * 1024 :
                        limit == Limit::Members ? u : 2 * u;
      transaction.objects_.push_back(Change(ObjectOperation::Write, key, 0, Value(size, 37 + i)));
    }
    Commit(node, std::move(create));
    std::vector<ObjectWrite> held;
    Bytes original;
    if (limit == Limit::ReadBytes) {
      original = Value(u, 199);
      Commit(node, {{Change(ObjectOperation::Write, keys.front(), 0, original)}, {}});
      transaction.objects_.front() = Change(ObjectOperation::Write, keys.front(), 31, Value(79, 47));
    }
    if (limit == Limit::Fragments) {
      auto hold = [&](size_t size) {
        const auto bytes = Value(size, 151);
        auto write = node.WriteObjectData(bytes.data(), bytes.size());
        write.Wait();
        Require(write.Result().writes_durable_, "fragmentation setup durable");
        held.push_back(std::move(write));
      };
      hold(2 * MIB - 4 * u);
      for (size_t i = 0; i < 4; ++i) hold(u);
      held.erase(held.begin() + 4);
      held.erase(held.begin() + 2);
    }
    transaction.controls_.push_back({keys.front(), 7, Value(43, 101)});
    auto ticket = Submit(node, std::move(transaction));
    const auto result = Finish(ticket);
    EXPECT_EQ(result.outcome_, JournalOutcome::NotCommitted);
    ASSERT_TRUE(result.error_) << "request limit must produce an explicit failure";
    bool bounded_error = false;
    try {
      std::rethrow_exception(result.error_);
    } catch (const MetadataError &e) {
      bounded_error = e.Code() == MetadataErrorCode::ResourceUnavailable;
    } catch (const AllocationError &e) {
      bounded_error = e.Code() == AllocationErrorCode::ResourceUnavailable;
    }
    EXPECT_TRUE(bounded_error) << "unsatisfiable request is a limit failure, not an IO fault";
    for (const auto key : keys) EXPECT_EQ(node.Objects().Describe(key).size_, original.size());
    EXPECT_FALSE(node.Objects().Control(keys.front(), 7));
    EXPECT_TRUE(node.State().object_transaction_);
    if (!original.empty()) {
      auto old = node.ReadObject(node.Objects(), keys.front(), 31, 79);
      old.Wait();
      Bytes unchanged(79);
      old.CopyTo(unchanged.data(), unchanged.size());
      EXPECT_EQ(unchanged, Bytes(original.begin() + 31, original.begin() + 110));
    }
    held.clear();
    const auto next = Value(u, 79);
    Commit(node, {{Change(ObjectOperation::Write, keys.front(), 0, next)}, {}});
    auto read = node.ReadObject(node.Objects(), keys.front(), 37, 79);
    read.Wait();
    Bytes actual(79);
    read.CopyTo(actual.data(), actual.size());
    EXPECT_EQ(actual, Bytes(next.begin() + 37, next.begin() + 116));
    node.Close();
    node.Open();
    EXPECT_EQ(node.Objects().Describe(keys.front()).size_, u);
    EXPECT_FALSE(node.Objects().Control(keys.front(), 7));
    node.Close();
  }
}
TEST(S7Common, BackgroundReclaimRespectsReadersAndRestartsFromDurableFacts) {
  Image image;
  auto options = Options(image);
  options.transactions_->gc_interval_ = 2ms;
  NodeStorage node(options);
  node.Create(Layout(options));
  const auto u = options.objects_->allocator_.allocation_bytes_;
  const auto x = New(node, 171);
  auto original = Value(4 * u, 181);
  Commit(node, {{Change(ObjectOperation::Write, x, 0, original)}, {}});
  auto old = node.Objects();
  Cleanup cleanup;
  Arm(Gate::Read);
  auto reader = node.ReadObject(old, x, u + 73, 47);
  ASSERT_TRUE(Entered());
  Commit(node, {{Change(ObjectOperation::Remove, x, 0)}, {}});
  Bytes bulk(2 * MIB - u, std::byte{0x37});
  std::optional<ObjectWrite> occupying;
  const auto deadline = std::chrono::steady_clock::now() + 5s;
  while (!occupying && std::chrono::steady_clock::now() < deadline) {
    try {
      occupying.emplace(node.WriteObjectData(bulk.data(), bulk.size()));
    } catch (const AllocationError &e) {
      if (e.Code() != AllocationErrorCode::NoSpace)
        throw;
      std::this_thread::yield();
    }
  }
  ASSERT_TRUE(occupying) << "background GC frees unpinned allocation units";
  occupying->Wait();
  EXPECT_THROW(node.WriteObjectData(original.data(), u), AllocationError)
      << "in-flight reader keeps exactly its physical unit";
  EXPECT_THROW(node.ReadObject(old, x, 31, 47), ObjectReferenceError);
  Release();
  reader.Wait();
  Bytes got(47);
  reader.CopyTo(got.data(), got.size());
  EXPECT_EQ(got, Bytes(original.begin() + u + 73, original.begin() + u + 120));
  Reset();
  occupying.reset();
  node.Close();
  // Produce durable retirement through the supported S6 deployment, which has
  // no background pipeline. This guarantees pending work exists on next Open;
  // merely closing after releasing the reader would allow GC to win that race.
  auto offline_gc_options = options;
  offline_gc_options.transactions_.reset();
  {
    NodeStorage producer(offline_gc_options);
    producer.Open();
    const auto pending_key = New(producer, 172);
    auto write = producer.WriteObjectData(original.data(), u);
    write.Wait();
    Require(write.Result().writes_durable_, "retirement fixture data durable");
    Durable(
        producer.PublishObjectData(producer.Objects(), pending_key, 0, write));
    Durable(producer.RemoveObject(producer.Objects(), pending_key));
    producer.Close();
  }
  node.Open();
  Bytes all(2 * MIB, std::byte{0x53});
  std::optional<ObjectWrite> full;
  const auto until = std::chrono::steady_clock::now() + 5s;
  while (!full && std::chrono::steady_clock::now() < until) {
    try {
      full.emplace(node.WriteObjectData(all.data(), all.size()));
    } catch (const AllocationError &e) {
      if (e.Code() != AllocationErrorCode::NoSpace)
        throw;
      std::this_thread::yield();
    }
  }
  ASSERT_TRUE(full) << "reopened GC resumes persistent retirement facts";
  full->Wait();
  EXPECT_TRUE(full->Result().writes_durable_);
  node.Close();
}
} // namespace
