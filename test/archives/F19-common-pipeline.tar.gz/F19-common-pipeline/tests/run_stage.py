#!/usr/bin/env python3
"""S7 production-path integration checks; isolated build and syscall fault gates."""
import argparse, hashlib, json, os, pathlib, subprocess, tarfile, time
import xml.etree.ElementTree as ET
p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--work',required=True);p.add_argument('--regressions',action='store_true');p.add_argument('--mutations',action='store_true');a=p.parse_args()
repo=pathlib.Path(a.repo).resolve();work=pathlib.Path(a.work).resolve();src=pathlib.Path(__file__).resolve().parent
assert repo!=work and repo not in work.parents
work.mkdir(parents=True,exist_ok=True)
env={k:v for k,v in os.environ.items() if not k.startswith('GTEST_')};env.update(S5_WORKDIR=str(work),F02_WORKDIR=str(work),ASAN_OPTIONS='detect_leaks=1:abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1')
commands=[]
def run(cmd,log,expected=0,timeout=900,cwd=None):
 cmd=list(map(str,cmd));start=time.monotonic()
 with (work/log).open('w') as out:r=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT,env=env,cwd=cwd or repo,timeout=timeout)
 commands.append({'command':cmd,'log':log,'seconds':time.monotonic()-start,'exit':r.returncode});(work/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 assert r.returncode==expected,(log,r.returncode,expected)
run(['cmake','-S',repo,'-B',work/'build','-DCMAKE_BUILD_TYPE=Debug','-DCMAKE_C_COMPILER=clang-14','-DCMAKE_CXX_COMPILER=clang++-14','-DBUSTUB_SANITIZER=address,undefined','-DCMAKE_EXE_LINKER_FLAGS=-no-pie'],'configure.log')
run(['cmake','--build',work/'build','--target','bustub','gtest_main','-j3'],'build.log')
for name in ['S5-journal-recycling','F34-node-lifecycle','F12-data-allocator','F13-object-mapping','F14-object-references','F02-object-io']:
 with tarfile.open(repo/('test/archives/'+name+'.tar.gz')) as t:t.extractall(work,filter='data')
dep=work/'S5-journal-recycling/test/storage_redesign'
flags=['clang++-14','-std=c++17','-g','-O0','-Wall','-Wextra','-Werror','-Wno-unused-parameter','-pthread','-fsanitize=address,undefined','-fno-omit-frame-pointer','-I'+str(repo/'src/include'),'-I'+str(repo/'third_party/fmt/include'),'-I'+str(repo/'third_party/googletest/googletest/include'),'-I'+str(dep),'-I'+str(work/'F12-data-allocator/tests'),'-I'+str(work/'F13-object-mapping/tests'),'-I'+str(repo/'src/storage/disk')]
libs=[work/'build/lib'/('lib'+name+'.a') for name in ['bustub','fmtd','gtest_main','gtest']]
wraps=['-Wl,--wrap=pread','-Wl,--wrap=pwrite','-Wl,--wrap=fdatasync']
run(flags+['-c',src/'transaction_test.cpp','-o',work/'transaction-test.o'],'transaction-compile.log')
run(flags+['-no-pie',work/'transaction-test.o']+libs+wraps+['-o',work/'transaction-test'],'transaction-link.log')
run([work/'transaction-test','--gtest_output=xml:'+str(work/'transaction.xml')],'transaction-run.log',timeout=180)
counts={'transaction.xml':10}
if a.regressions:
 legacy=work/'legacy-f13';(legacy/'storage/disk').mkdir(parents=True,exist_ok=True)
 for name,target in [('src/include/storage/disk/object_mapping.h',legacy/'storage/disk/object_mapping.h'),('src/storage/disk/object_mapping.cpp',legacy/'object_mapping.cpp')]:
  target.write_bytes(subprocess.check_output(['git','show','1df3ba1:'+name],cwd=repo))
 legacyflags=flags[:1]+['-I'+str(legacy)]+flags[1:]
 run(legacyflags+['-c',legacy/'object_mapping.cpp','-o',work/'legacy-map.o'],'legacy-compile.log')
 run(legacyflags+['-no-pie',work/'F14-object-references/tests/legacy_fixture.cpp',work/'legacy-map.o']+libs+wraps[1:]+['-o',work/'legacy-producer'],'legacy-link.log')
 run([work/'legacy-producer',work/'f13-legacy.img'],'legacy-producer.log',timeout=120)
 env['F14_LEGACY_IMAGE']=str(work/'f13-legacy.img')
 for name,source,more,n in [('object',work/'F02-object-io/tests/object_io_test.cpp',[],7),('executor',work/'F02-object-io/tests/io_executor_test.cpp',['-Wl,--wrap=malloc','-Wl,--wrap=_Znwm'],8),('lifecycle',work/'F34-node-lifecycle/tests/lifecycle_test.cpp',['-Wl,--wrap=close'],5),('references',work/'F14-object-references/tests/reference_test.cpp',[],18)]:
  run(flags+['-no-pie',source]+libs+wraps+more+['-o',work/(name+'-test')],name+'-compile.log')
  run([work/(name+'-test'),'--gtest_output=xml:'+str(work/(name+'.xml'))],name+'-run.log',timeout=180,cwd=work)
  counts[name+'.xml']=n
 run(['python3',dep/'build_checks.py',repo,work],'s5-regression.log',timeout=300);counts['s5.xml']=8
for name,n in counts.items():
 cases=ET.parse(work/name).getroot().findall('./testsuite/testcase')
 assert len(cases)==n and all(c.get('result')=='completed' and not any(c.find(k) is not None for k in ('failure','error','skipped')) for c in cases),name
mutations=[
 ('forget_commit_uncertainty','object_transaction.cpp','task->Finish(std::move(result));','if (result.outcome_ == JournalOutcome::Indeterminate) result.outcome_ = JournalOutcome::NotCommitted; task->Finish(std::move(result));','FailureStagesNeverReportPartialTransactionSuccess','definitely uncommitted must recover old control'),
 ('retry_permanent_limit','object_transaction.cpp','} catch (const ObjectIOBusy &) {','} catch (const MetadataError &) {','UnsatisfiableRequestsFinishAndLeaveOldStateIntact','transaction completion deadline'),
 ('drop_allocator_backpressure','object_transaction.cpp','return e.Code() == AllocationErrorCode::Busy;','return false;','CapacityRetryKeepsAcceptedWorkAndOldVersionsConflict','accepted task waits for occupied allocator reservation slots'),
 ('read_overwritten_middle','object_transaction.cpp','change.length_ <= unit_ && (edges[0].second != 0 || edges[1].second != 0)','(edges[0].second != 0 || edges[1].second != 0)','LargeOverwriteReadsOnlySurvivingEdges','large overwrite reads only surviving edge units'),
 ('overtake_object_dependency','object_transaction.cpp','(**prior).step_ != Step::Done && Conflicts(task, **prior)','false && (**prior).step_ != Step::Done && Conflicts(task, **prior)','HandoffOrdersDependenciesAndLetsIndependentWorkFinish','second.WaitFor'),
 ('lose_user_bytes','object_transaction.cpp','std::memcpy(bytes.data() + (target - change.offset_), op.bytes_.data(), op.bytes_.size());','std::memset(bytes.data() + (target - change.offset_), 0, op.bytes_.size());','AtomicRangesControlsAndRecovery','independent object byte model'),
 ('retain_truncated_mapping','object_mapping.cpp','const auto size = remove ? 0 : op.length_;\n      Cut(base.base_, key, size, d.info_.size_, d, changes);','const auto size = remove ? 0 : op.length_;\n      if (remove) Cut(base.base_, key, size, d.info_.size_, d, changes);','AtomicRangesControlsAndRecovery','truncated bytes do not resurrect'),
 ('omit_control_record','object_mapping.cpp','changes.Put(Key(object_mapping_detail::Control, control.owner_, control.item_), control.value_);','(void)control;','AtomicRangesControlsAndRecovery','Control(x, 9)'),
 ('ignore_object_version','object_mapping.cpp','if (d.info_.version_ != op.version_) {','if (false && d.info_.version_ != op.version_) {','CapacityRetryKeepsAcceptedWorkAndOldVersionsConflict','JournalOutcome::NotCommitted'),
 ('exceed_request_budget','object_transaction.cpp','budget_->requests_ == options_.max_requests_','budget_->requests_ == 2 * options_.max_requests_','RetainedResultsBoundAdmissionAndDroppedTicketStillDrains','running and retained results consume admission'),
 ('omit_background_reclaim','object_transaction.cpp','if (gc) {','if (false && gc) {','BackgroundReclaimRespectsReadersAndRestartsFromDurableFacts','background GC frees unpinned allocation units'),
 ('omit_common_data_flush','object_io.cpp','auto prepared = regions_.TryPrepare(requests, true);\n  Accepted(prepared.admission_);\n  data.batch_','auto prepared = regions_.TryPrepare(requests, false);\n  Accepted(prepared.admission_);\n  data.batch_','MultiObjectDataBatchFlushesOnceBeforeAtomicPublication','required metadata operation is not durable'),
]
evidence=[]
if a.mutations:
 for name,file,old,new,test,marker in mutations:
  code=(repo/'src/storage/disk'/file).read_text();assert code.count(old)==1,(name,old)
  cpp=work/(name+'.cpp');cpp.write_text(code.replace(old,new));obj=work/(name+'.o');exe=work/name
  run(flags+['-c',cpp,'-o',obj],name+'-compile.log',timeout=120)
  run(flags+['-no-pie',work/'transaction-test.o',obj]+libs+wraps+['-o',exe],name+'-link.log',timeout=120)
  run([exe,'--gtest_filter=S7Common.'+test,'--gtest_output=xml:'+str(work/(name+'.xml'))],name+'-run.log',expected=1,timeout=120)
  failures=[f.text or '' for f in ET.parse(work/(name+'.xml')).getroot().iter('failure')]
  assert any(marker in f for f in failures),(name,failures)
  evidence.append({'mutation':name,'file':file,'old':old,'new':new,'test':test,'expected_marker':marker,'failures':failures})
  (work/'mutations.json').write_text(json.dumps(evidence,indent=2)+'\n');print(name+': detected',flush=True)
(work/'summary.json').write_text(json.dumps({'passed':counts,'mutations_detected':len(evidence),'scope':'Common production object transactions on Direct files; not SQL/Raft E2E, power loss or performance.'},indent=2)+'\n')
print('passed '+str(counts),flush=True)
