# F19 / S7 恢复与复验

此包仅保存最终阶段测试和运行器，不注册常驻测试目标。需要 Linux 支持 O_DIRECT 的临时文件目录、Clang14/CMake/Python（tarfile data filter）、可用的 ASan/UBSan/LSan 环境；不需要 GPU。

## 1. 准备精确生产版本

源码基准为 `e24b5e65d27526a757ff154c14d0552d8a7b9ade`。在隔离 checkout/worktree 中使用本地 `F19-results.tar.gz` 的 `F19-results/source/` 覆盖该基准，保留其完整 Git 历史和 third_party。回归镜像生成器需要历史提交 `1df3ba1`、`cce998a`，不能使用缺少历史的浅克隆。

恢复后的每个生产/构建文件必须匹配 MANIFEST 的 `production_sha256`；六个原回归档案必须匹配 `dependency_sha256`；本包 tests/ 匹配 `test_sha256`。不要将旧结果当作新源码的测试证明。本次最终源码与完整运行的 `runtime_evidence_production_sha256` 一致；旧版源码和结果包已被替换，不能再沿用旧版通过记录。

## 2. 在仓库外解压、执行

例如将本包解压到 `/tmp/s7-tests`，生产 checkout 位于 `/tmp/s7-source`，构建结果放到独立的 `/tmp/s7-check`：

```bash
python3 /tmp/s7-tests/F19-common-pipeline/tests/run_stage.py --repo /tmp/s7-source --work /tmp/s7-check --regressions --mutations
```

使用全新 work 目录；不要放在源码目录内。运行器从六个准确的原模块包读取回归，而不复制其测试。任何失败须先定位生产逻辑/测试 oracle/环境；不能关闭泄漏检测、跳过测试或把超时算作变异命中。若环境限制 LSan，使用允许其扫描进程的执行环境。

## 3. 判定和退出

预期 56 项无跳过、12 个指定变异正常测试失败（退出1并命中对应 XML 断言），不是崩溃或编译失败。本包并不证明业务 E2E、真实掉电或性能提升。原分配尾部复用未启用，小追加采用 COW。

正式后续入口接入时，复用本包输入/独立字节模型、交接/原子发布/空间寿命风险，只改变测试适配。等价覆盖才能退出旧案例，不为每层建立同义套件。核验并归档最终证据后删除展开测试、构建、镜像和变异二进制，仅保留模块源码包与结果压缩包。
