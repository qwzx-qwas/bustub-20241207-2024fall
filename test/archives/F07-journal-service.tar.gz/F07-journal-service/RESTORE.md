# F07 / S3 测试恢复

仅在仓库外的专用目录解压，不重新加入常驻测试树。先核对 test/archives/SHA256SUMS 和 MANIFEST.json。

生产基准为 `00a8397332408a0bb95f021789a77d78f121135f` 加本轮改动，单独 checkout 基准没有 F07！核对 MANIFEST.json 的 production_sha256；若恢复历史环境，使用本地 F07-results.tar.gz 中 source/ 的实际生产快照覆盖隔离 checkout，再校验全部生产哈希。不要覆盖用户当前工作目录。

依赖 Linux Direct 文件 IO、clang/clang++/clang-format/clang-tidy 14、CMake、Python3、GTest 源码；编译使用 ASan/UBSan。runner 会读取并校验原 F02/F06 源码包，复用原测试，不复制到本包。

```sh
python3 /tmp/restore-F07/F07-journal-service/test/storage_redesign/run_stage.py \
  --repo /absolute/path/to/verified-checkout \
  --work /tmp/verify-F07 --mutations
```

显式工作目录必须在仓库外。runner 清除 GTEST_*，核对完整 XML；超时/编译错误/零用例不是变异捕获。通常预留 0.5 GiB 临时磁盘、两个编译任务、16 MiB 设备文件和有限 IO 内存；实际编译工具资源由运行环境决定，不构成压力基准。

结束后核对日志/哈希并删除工作目录；源码与结果仅压缩保留。八项设计审查见 docs/storage_redesign/f07_execution_20260924.md。组件测试不证明拔电、裸设备、B 原子恢复或共同 E2E。

2026-09-25 复审版：8 项正常用例、原 F02/F06 共 10 项回归通过；13 个故意改坏版本被指定断言发现。旧 CRC 判据已替换，并补强组恢复内容、Flush 等待和失败及时隔离。旧源码包不再保留。
