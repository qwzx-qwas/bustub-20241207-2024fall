#include <fcntl.h>
#include <unistd.h>

#include <algorithm>
#include <atomic>
#include <cerrno>
#include <chrono>
#include <condition_variable>
#include <cstdlib>
#include <cstring>
#include <future>
#include <iostream>
#include <map>
#include <mutex>
#include <numeric>
#include <string>
#include <vector>

#include "storage/disk/io_executor.h"
#include "storage/disk/journal_service.h"
#include "gtest/gtest.h"

extern "C" int __real_fdatasync(int);
extern "C" ssize_t __real_pwrite(int, const void *, size_t, off_t);

namespace {
using namespace std::chrono_literals;
struct Gate {
  bool entered{false};
  bool released{false};
};
std::mutex hook_mutex;
std::condition_variable hook_cv;
std::map<off_t, Gate> gates;
std::map<off_t, size_t> completed_writes;
off_t fail_at{-1};
bool failed_write{false};
bool fail_flush{false};
Gate flush_gate{false, true};
std::atomic<size_t> flushes{0};
std::atomic<size_t> writes{0};
struct ReleaseHooks {
  ~ReleaseHooks() {
    std::lock_guard<std::mutex> lock(hook_mutex);
    for (auto &p : gates) {
      p.second.released = true;
    }
    fail_at = -1;
    fail_flush = false;
    flush_gate.released = true;
    hook_cv.notify_all();
  }
};
void ResetHooks() {
  std::lock_guard<std::mutex> lock(hook_mutex);
  gates.clear();
  completed_writes.clear();
  fail_at = -1;
  failed_write = false;
  fail_flush = false;
  flush_gate = {false, true};
}
void WaitHook(const std::function<bool()> &predicate) {
  std::unique_lock<std::mutex> lock(hook_mutex);
  if (!hook_cv.wait_for(lock, 10s, predicate)) {
    throw std::runtime_error("injection handshake watchdog");
  }
}
void Release(off_t offset) {
  std::lock_guard<std::mutex> lock(hook_mutex);
  gates.at(offset).released = true;
  hook_cv.notify_all();
}
} // namespace
extern "C" ssize_t __wrap_pwrite(int fd, const void *buffer, size_t size,
                                 off_t offset) {
  ++writes;
  {
    std::unique_lock<std::mutex> lock(hook_mutex);
    auto it = gates.find(offset);
    if (it != gates.end()) {
      it->second.entered = true;
      hook_cv.notify_all();
      hook_cv.wait(lock, [&] { return it->second.released; });
    }
    if (offset == fail_at) {
      failed_write = true;
      hook_cv.notify_all();
      errno = EIO;
      return -1;
    }
  }
  const auto result = __real_pwrite(fd, buffer, size, offset);
  {
    std::lock_guard<std::mutex> lock(hook_mutex);
    ++completed_writes[offset];
    hook_cv.notify_all();
  }
  return result;
}
extern "C" int __wrap_fdatasync(int fd) {
  ++flushes;
  {
    std::unique_lock<std::mutex> lock(hook_mutex);
    if (!flush_gate.released) {
      flush_gate.entered = true;
      hook_cv.notify_all();
      hook_cv.wait(lock, [] { return flush_gate.released; });
    }
    if (fail_flush) {
      errno = EIO;
      return -1;
    }
  }
  return __real_fdatasync(fd);
}

namespace bustub {
namespace {
constexpr uint64_t MIB = 1024 * 1024;
constexpr uint64_t CAPACITY = 16 * MIB;
constexpr uint64_t START = 4 * MIB;
using Bytes = std::vector<std::byte>;
auto Range(uint64_t o, uint64_t n) -> StorageByteRange {
  return *StorageByteRange::Create(o, n);
}
auto Payload(size_t n, unsigned seed) -> Bytes {
  Bytes b(n);
  for (size_t i = 0; i < n; ++i)
    b[i] = std::byte((i * 17 + seed * 31 + i / 23) % 251);
  return b;
}
uint64_t Number(const Bytes &b, size_t p, size_t n) {
  uint64_t x = 0;
  for (size_t i = 0; i < n; ++i)
    x = x * 256 + std::to_integer<unsigned>(b.at(p + i));
  return x;
}
void Put(Bytes &b, size_t p, uint64_t x, size_t n) {
  for (size_t i = 0; i < n; ++i) {
    b.at(p + n - i - 1) = std::byte(x & 255);
    x >>= 8;
  }
}
// Independent bit-at-a-time Castagnoli oracle; no production codec used.
uint32_t Checksum(const std::byte *p, size_t n) {
  uint32_t c = ~uint32_t{0};
  for (size_t i = 0; i < n; ++i) {
    c ^= std::to_integer<uint8_t>(p[i]);
    for (unsigned bit = 0; bit < 8; ++bit)
      c = (c >> 1) ^ ((c & 1) ? 0x82f63b78U : 0U);
  }
  return ~c;
}
void Rechecksum(Bytes &b, size_t begin, size_t u) {
  Put(b, begin + u - 4, Checksum(b.data() + begin, u - 4), 4);
}
struct RawFile {
  int fd{-1};
  std::string path;
  RawFile() {
    const char *work = getenv("F07_WORKDIR");
    if (!work)
      throw std::runtime_error("explicit work directory required");
    path = std::string(work) + "/device-XXXXXX";
    fd = mkstemp(path.data());
    if (fd < 0)
      throw std::runtime_error("mkstemp");
    if (ftruncate(fd, CAPACITY) != 0) {
      close(fd);
      unlink(path.c_str());
      throw std::runtime_error("ftruncate");
    }
  }
  ~RawFile() {
    close(fd);
    unlink(path.c_str());
  }
  auto Read(uint64_t begin, size_t size) const -> Bytes {
    Bytes b(size);
    size_t done = 0;
    while (done < size) {
      auto n = pread(fd, b.data() + done, size - done, begin + done);
      if (n < 0 && errno == EINTR)
        continue;
      if (n <= 0)
        throw std::runtime_error("raw read");
      done += n;
    }
    return b;
  }
  void Write(uint64_t begin, const Bytes &b) const {
    size_t done = 0;
    while (done < b.size()) {
      auto n =
          __real_pwrite(fd, b.data() + done, b.size() - done, begin + done);
      if (n < 0 && errno == EINTR)
        continue;
      if (n <= 0)
        throw std::runtime_error("raw write");
      done += n;
    }
    if (__real_fdatasync(fd) != 0)
      throw std::runtime_error("raw sync");
  }
};
struct Fixture {
  RawFile file;
  BlockDevice device{file.path, BlockDeviceOptions{}};
  uint32_t unit;
  uint64_t segment;
  IOExecutor io;
  BootstrapStore bootstrap{io};
  JournalIdentity identity{};
  JournalOptions options;
  BootstrapIdentity root{};
  Fixture(size_t operations = 128, unsigned variant = 0, uint64_t slots = 32)
      : unit(static_cast<uint32_t>(
                 std::lcm<uint64_t>(device.Info().offset_alignment_, 256)) *
             (1 + variant)),
        segment((3 + 2 * variant) * unit),
        io(device, {std::min<size_t>(3, operations), operations, 4 * MIB}),
        options{segment,
                unit,
                static_cast<uint32_t>(8 * segment),
                16 * segment,
                32,
                20 * segment,
                8,
                32,
                60 * segment} {
    if (unit > 65536 || segment * slots > MIB)
      throw std::runtime_error("fixture exceeds geometry budget");
    root.storage_.fill(17);
    root.device_.fill(37);
    identity.fill(59);
    bootstrap.Create({root,
                      CAPACITY,
                      {Range(2 * MIB, MIB), Range(START, slots * segment),
                       Range(8 * MIB, 4 * MIB)}});
    bootstrap.Open(root);
    ResetHooks();
  }
};
void Durable(JournalSubmission &s) {
  if (s.admission_ != JournalAdmission::Accepted || !s.ticket_) {
    throw std::runtime_error(
        "expected accepted Journal submission with a ticket");
  }
  if (!s.ticket_->WaitFor(10s)) {
    throw std::runtime_error("completion watchdog");
  }
  EXPECT_EQ(s.ticket_->Result().outcome_, JournalOutcome::Durable);
}

auto Replay(JournalService &j) -> std::vector<JournalRecords> {
  std::vector<JournalRecords> result;
  j.Open([&](uint64_t, const JournalRecords &r) { result.push_back(r); });
  return result;
}
TEST(JournalServiceTest,
     CrossSegmentRoundTripHasIndependentFormatAndProtectsPrefix) {
  for (unsigned v : {0U, 1U}) {
    SCOPED_TRACE(v);
    Fixture f(128, v);
    std::cout << "geometry memory=" << f.device.Info().memory_alignment_
              << " offset=" << f.device.Info().offset_alignment_
              << " unit=" << f.unit << " segment=" << f.segment << '\n';
    const auto outside = f.file.Read(0, CAPACITY);
    const JournalRecords input{
        Payload(2 * f.segment / f.unit * (f.unit - 84) + 71, 11),
        Payload(23, 19), Payload(f.unit + 37, 43)};
    uint64_t end = 0;
    {
      JournalService j(f.bootstrap, f.identity, f.options);
      j.Create();
      auto s = j.TryAppend(input);
      Durable(s);
      ASSERT_TRUE(s.ticket_);
      end = s.ticket_->Result().end_;
      EXPECT_EQ(s.ticket_->Result().begin_, f.segment);
      j.Close();
    }
    const auto image = f.file.Read(0, CAPACITY);
    EXPECT_TRUE(
        std::equal(image.begin(), image.begin() + START, outside.begin()));
    EXPECT_TRUE(std::equal(image.begin() + START + end, image.end(),
                           outside.begin() + START + end));
    EXPECT_EQ(Number(image, START + 64, 8), f.segment);
    EXPECT_EQ(Number(image, START + 80, 8),
              31U); // reserved segment identity high-water
    std::vector<unsigned> types;
    bool packed_last_then_full = false;
    for (uint64_t p = f.segment; p < end; p += f.unit) {
      const auto o = START + p;
      EXPECT_EQ(Number(image, o + f.unit - 4, 4),
                Checksum(image.data() + o, f.unit - 4));
      EXPECT_EQ(Number(image, o + 32, 8), p / f.segment);
      EXPECT_EQ(Number(image, o + 40, 8), p % f.segment);
      EXPECT_EQ(Number(image, o + 48, 8), f.segment);
      EXPECT_EQ(Number(image, o + 56, 8), 0U);
      size_t q = 64, used = Number(image, o + 12, 4);
      unsigned previous_type = 0;
      while (q < 64 + used) {
        const auto type = Number(image, o + q, 4);
        packed_last_then_full =
            packed_last_then_full || (previous_type == 4 && type == 1);
        previous_type = type;
        types.push_back(type);
        q += 16 + Number(image, o + q + 4, 4);
      }
      EXPECT_EQ(q, 64 + used);
    }
    ASSERT_GT(std::count(types.begin(), types.end(), 3U), 0);
    ASSERT_GT(std::count(types.begin(), types.end(), 4U), 0);
    EXPECT_EQ(types.back(), 5U);
    EXPECT_TRUE(packed_last_then_full);
    JournalService reopened(f.bootstrap, f.identity, f.options);
    EXPECT_EQ(Replay(reopened), std::vector<JournalRecords>{input});
    auto next = reopened.TryAppend({Payload(37, 79)});
    Durable(next);
    ASSERT_TRUE(next.ticket_);
    EXPECT_EQ(next.ticket_->Result().begin_, end);
    EXPECT_EQ(f.file.Read(START, end),
              Bytes(image.begin() + START, image.begin() + START + end));
  }
}
TEST(JournalServiceTest,
     CorruptOrIncompleteHistoryIsRejectedBeforeReplayWithoutRewriting) {
  Fixture f;
  uint64_t begin = 0, end = 0;
  {
    JournalService j(f.bootstrap, f.identity, f.options);
    j.Create();
    auto a = j.TryAppend({Payload(29, 1)});
    Durable(a);
    auto b = j.TryAppend({Payload(2 * f.segment + 57, 7)});
    Durable(b);
    ASSERT_TRUE(b.ticket_);
    begin = b.ticket_->Result().begin_;
    end = b.ticket_->Result().end_;
  }
  const auto good = f.file.Read(START, 32 * f.segment);
  for (unsigned kind = 0; kind < 7; ++kind) {
    SCOPED_TRACE(kind);
    auto damaged = good;
    const auto last = end - f.unit;
    if (kind == 0)
      damaged.at(begin + f.unit - 1) ^=
          std::byte{1}; // Only the unit CRC is wrong.
    if (kind == 1) {
      Put(damaged, begin + 32, 999, 8);
      Rechecksum(damaged, begin, f.unit);
    }
    if (kind == 2) {
      damaged.at(begin + 16) ^= std::byte{1};
      Rechecksum(damaged, begin, f.unit);
    }
    if (kind == 3) {
      Put(damaged, begin + 56, 0, 8);
      Rechecksum(damaged, begin, f.unit);
    }
    if (kind == 4)
      std::fill_n(damaged.begin() + begin + f.unit, f.unit, std::byte{0});
    if (kind == 5)
      std::fill_n(damaged.begin() + last, f.unit, std::byte{0});
    if (kind == 6) {
      const auto used = Number(damaged, last + 12, 4);
      damaged.at(last + 64 + used - 8) ^= std::byte{1};
      Rechecksum(damaged, last, f.unit);
    }
    f.file.Write(START, damaged);
    const auto before = writes.load();
    size_t replayed = 0;
    JournalService bad(f.bootstrap, f.identity, f.options);
    EXPECT_THROW(
        bad.Open([&](uint64_t, const JournalRecords &) { ++replayed; }),
        JournalError);
    EXPECT_EQ(replayed, 0U);
    EXPECT_EQ(writes.load(), before);
    EXPECT_EQ(f.file.Read(START, good.size()), damaged);
  }
  f.file.Write(START, good);
  auto wrong = f.identity;
  wrong[0] ^= 1;
  JournalService identity(f.bootstrap, wrong, f.options);
  EXPECT_THROW(identity.Open({}), JournalError);
  const auto before = writes.load();
  JournalService create(f.bootstrap, f.identity, f.options);
  EXPECT_THROW(create.Create(), JournalError);
  EXPECT_EQ(writes.load(), before);
  JournalService valid(f.bootstrap, f.identity, f.options);
  EXPECT_EQ(Replay(valid).size(), 2U);
}
TEST(JournalServiceTest, GroupFlushWaitsForEveryWriteAndUsesOneBarrier) {
  Fixture f;
  JournalService j(f.bootstrap, f.identity, f.options);
  j.Create();
  const auto a = START + f.segment, b = a + f.unit, c = b + f.unit;
  {
    std::lock_guard<std::mutex> lock(hook_mutex);
    gates.emplace(a, Gate{});
    gates.emplace(b, Gate{});
  }
  ReleaseHooks release;
  const auto before = flushes.load();
  const std::vector<JournalRecords> expected{
      {Payload(17, 3)}, {Payload(19, 5)}, {Payload(23, 11)}};
  auto first = j.TryAppend(expected[0]);
  ASSERT_EQ(first.admission_, JournalAdmission::Accepted);
  WaitHook([&] { return gates.at(a).entered; });
  auto second = j.TryAppend(expected[1]);
  auto third = j.TryAppend(expected[2]);
  ASSERT_EQ(second.admission_, JournalAdmission::Accepted);
  ASSERT_EQ(third.admission_, JournalAdmission::Accepted);
  EXPECT_FALSE(first.ticket_->WaitFor(0ms));
  EXPECT_EQ(flushes.load(), before);
  Release(a);
  Durable(first);
  WaitHook([&] { return gates.at(b).entered && completed_writes[c] != 0; });
  EXPECT_FALSE(second.ticket_->WaitFor(0ms));
  EXPECT_FALSE(third.ticket_->WaitFor(0ms));
  EXPECT_EQ(flushes.load(), before + 1);
  Release(b);
  Durable(second);
  Durable(third);
  EXPECT_EQ(flushes.load(), before + 2);
  EXPECT_EQ(second.ticket_->Result().end_, third.ticket_->Result().begin_);
  j.Close();
  JournalService reopened(f.bootstrap, f.identity, f.options);
  EXPECT_EQ(Replay(reopened), expected);
}
TEST(JournalServiceTest, AdmissionRollsBackAndCompletedResultsStayBounded) {
  Fixture f(2);
  f.options.max_group_batches_ = 2;
  f.options.max_pending_batches_ = 2;
  JournalService j(f.bootstrap, f.identity, f.options);
  j.Create();
  auto held =
      f.io.TryPrepare({{IOOperation::Read, Range(12 * MIB, f.unit)}}, false);
  ASSERT_EQ(held.admission_, IOAdmission::Accepted);
  const auto before = writes.load();
  auto rejected = j.TryAppend({Payload(31, 1)});
  EXPECT_EQ(rejected.admission_, JournalAdmission::Full);
  EXPECT_EQ(writes.load(), before);
  held.batch_.reset();
  auto first = j.TryAppend({Payload(31, 1)});
  Durable(first);
  ASSERT_TRUE(first.ticket_);
  EXPECT_EQ(first.ticket_->Result().begin_, f.segment);
  auto second = j.TryAppend({Payload(33, 5)});
  Durable(second);
  EXPECT_EQ(j.TryAppend({Payload(11, 7)}).admission_, JournalAdmission::Full);
  first.ticket_.reset();
  auto third = j.TryAppend({Payload(11, 7)});
  Durable(third);
  EXPECT_THROW(j.TryAppend({Payload(f.options.max_record_bytes_ + 1, 1)}),
               std::invalid_argument);
}
TEST(JournalServiceTest, WorkBytesAndAppendCapacityNeverOverwriteOldHistory) {
  Fixture f(16, 0, 4);
  f.options.max_group_bytes_ = f.unit;
  f.options.max_pending_bytes_ = f.unit;
  JournalService j(f.bootstrap, f.identity, f.options);
  j.Create();
  const auto at = START + f.segment;
  {
    std::lock_guard<std::mutex> lock(hook_mutex);
    gates.emplace(at, Gate{});
  }
  ReleaseHooks release;
  auto first = j.TryAppend({Payload(17, 1)});
  ASSERT_EQ(first.admission_, JournalAdmission::Accepted);
  WaitHook([&] { return gates.at(at).entered; });
  EXPECT_EQ(j.TryAppend({Payload(19, 2)}).admission_, JournalAdmission::Full);
  Release(at);
  Durable(first);
  first.ticket_.reset();
  const auto prefix = f.file.Read(START, f.segment + f.unit);
  for (size_t i = 1; i < 9; ++i) {
    auto next = j.TryAppend({Payload(19, i)});
    Durable(next);
  }
  const auto before = writes.load();
  EXPECT_EQ(j.TryAppend({Payload(23, 21)}).admission_,
            JournalAdmission::NoSpace);
  EXPECT_EQ(writes.load(), before);
  EXPECT_EQ(f.file.Read(START, prefix.size()), prefix);
}
TEST(JournalServiceTest,
     WriteFailureDrainsOutstandingIOAndFaultsFutureAppends) {
  {
    Fixture f;
    JournalService j(f.bootstrap, f.identity, f.options);
    j.Create();
    auto good = j.TryAppend({Payload(21, 1)});
    Durable(good);
    ASSERT_TRUE(good.ticket_);
    const auto prefix = f.file.Read(START, good.ticket_->Result().end_);
    const auto at = START + good.ticket_->Result().end_;
    {
      std::lock_guard<std::mutex> lock(hook_mutex);
      gates.emplace(at, Gate{});
      fail_at = START + 2 * f.segment;
    }
    ReleaseHooks release;
    auto bad = j.TryAppend({Payload(2 * f.segment + 33, 7)});
    ASSERT_EQ(bad.admission_, JournalAdmission::Accepted);
    WaitHook([&] { return gates.at(at).entered && failed_write; });
    EXPECT_FALSE(bad.ticket_->WaitFor(0ms));
    EXPECT_THROW(bad.ticket_->Result(), std::logic_error);
    auto queued = j.TryAppend({Payload(27, 41)});
    ASSERT_EQ(queued.admission_, JournalAdmission::Accepted);
    // Accepted ownership persists until the blocked write has actually
    // returned.
    Release(at);
    ASSERT_TRUE(bad.ticket_->WaitFor(10s));
    EXPECT_EQ(bad.ticket_->Result().outcome_, JournalOutcome::Indeterminate);
    ASSERT_TRUE(static_cast<bool>(bad.ticket_->Result().error_));
    try {
      std::rethrow_exception(bad.ticket_->Result().error_);
    } catch (const BlockDeviceIOError &error) {
      EXPECT_EQ(error.code().value(), EIO);
      EXPECT_EQ(error.Range().Offset(), START + 2 * f.segment);
    }
    ASSERT_TRUE(queued.ticket_->WaitFor(10s));
    EXPECT_EQ(queued.ticket_->Result().outcome_, JournalOutcome::NotCommitted);
    EXPECT_EQ(j.TryAppend({Payload(17, 19)}).admission_,
              JournalAdmission::Faulted);
    j.Close();
    EXPECT_EQ(f.file.Read(START, prefix.size()), prefix);
    JournalService reopened(f.bootstrap, f.identity, f.options);
    size_t replayed = 0;
    EXPECT_THROW(
        reopened.Open([&](uint64_t, const JournalRecords &) { ++replayed; }),
        JournalError);
    EXPECT_EQ(replayed, 0U);
  }

  {
    SCOPED_TRACE("observed failure must fence admission before group drain");
    Fixture f;
    f.options.max_group_batches_ = 4;
    f.options.max_pending_batches_ = 4;
    JournalService j(f.bootstrap, f.identity, f.options);
    j.Create();
    const auto first_offset = START + f.segment;
    const auto blocked_offset = first_offset + 2 * f.unit;
    {
      std::lock_guard<std::mutex> lock(hook_mutex);
      gates.emplace(first_offset, Gate{});
      gates.emplace(blocked_offset, Gate{});
      fail_at = first_offset + f.unit;
    }
    ReleaseHooks release;
    auto first = j.TryAppend({Payload(17, 3)});
    ASSERT_EQ(first.admission_, JournalAdmission::Accepted);
    WaitHook([&] { return gates.at(first_offset).entered; });
    auto failed = j.TryAppend({Payload(23, 7)});
    auto blocked = j.TryAppend({Payload(29, 11)});
    ASSERT_EQ(failed.admission_, JournalAdmission::Accepted);
    ASSERT_EQ(blocked.admission_, JournalAdmission::Accepted);
    Release(first_offset);
    Durable(first);
    WaitHook([&] { return failed_write && gates.at(blocked_offset).entered; });
    // F02's failing batch can finish even though the next batch is blocked.
    // Use real admission as the observer; never inspect Journal internals.
    const auto deadline = std::chrono::steady_clock::now() + 10s;
    JournalAdmission admission = JournalAdmission::Full;
    std::optional<JournalTicket> pending;
    do {
      auto probe = j.TryAppend({Payload(31, 19)});
      admission = probe.admission_;
      if (admission == JournalAdmission::Accepted) {
        ASSERT_FALSE(pending.has_value()); // At most one remaining result slot.
        pending = std::move(probe.ticket_);
      }
      std::this_thread::yield();
    } while ((admission == JournalAdmission::Full ||
              admission == JournalAdmission::Accepted) &&
             std::chrono::steady_clock::now() < deadline);
    ASSERT_EQ(admission, JournalAdmission::Faulted)
        << "failure isolation watchdog";
    EXPECT_FALSE(failed.ticket_->WaitFor(0ms));
    EXPECT_FALSE(blocked.ticket_->WaitFor(0ms));
    Release(blocked_offset);
    ASSERT_TRUE(failed.ticket_->WaitFor(10s));
    ASSERT_TRUE(blocked.ticket_->WaitFor(10s));
    EXPECT_EQ(failed.ticket_->Result().outcome_, JournalOutcome::Indeterminate);
    EXPECT_EQ(blocked.ticket_->Result().outcome_,
              JournalOutcome::Indeterminate);
    if (pending) {
      ASSERT_TRUE(pending->WaitFor(10s));
      EXPECT_EQ(pending->Result().outcome_, JournalOutcome::NotCommitted);
    }
  }
}
TEST(JournalServiceTest,
     FlushFailureIsIndeterminateAndACompleteBatchCanRecover) {
  Fixture f;
  JournalRecords expected{Payload(f.unit + 57, 13)};
  {
    JournalService j(f.bootstrap, f.identity, f.options);
    j.Create();
    {
      std::lock_guard<std::mutex> lock(hook_mutex);
      fail_flush = true;
      flush_gate = {false, false};
    }
    ReleaseHooks release;
    auto s = j.TryAppend(expected);
    ASSERT_EQ(s.admission_, JournalAdmission::Accepted);
    WaitHook([] { return flush_gate.entered; });
    EXPECT_FALSE(s.ticket_->WaitFor(0ms));
    {
      std::lock_guard<std::mutex> lock(hook_mutex);
      flush_gate.released = true;
      hook_cv.notify_all();
    }
    ASSERT_TRUE(s.ticket_->WaitFor(10s));
    EXPECT_EQ(s.ticket_->Result().outcome_, JournalOutcome::Indeterminate);
    ASSERT_TRUE(static_cast<bool>(s.ticket_->Result().error_));
    try {
      std::rethrow_exception(s.ticket_->Result().error_);
    } catch (const std::system_error &error) {
      EXPECT_EQ(error.code().value(), EIO);
    } catch (const std::exception &error) {
      FAIL() << "expected fdatasync EIO after completion: " << error.what();
    }
    EXPECT_EQ(j.TryAppend({Payload(17, 19)}).admission_,
              JournalAdmission::Faulted);
  }
  JournalService recovered(f.bootstrap, f.identity, f.options);
  EXPECT_EQ(Replay(recovered), std::vector<JournalRecords>{expected});
  auto next = recovered.TryAppend({Payload(23, 17)});
  Durable(next);
}
TEST(JournalServiceTest,
     DroppedTicketAndObserverTimeoutDoNotCancelAcceptedWork) {
  Fixture f;
  f.options.max_group_batches_ = 2;
  f.options.max_pending_batches_ = 2;
  JournalService j(f.bootstrap, f.identity, f.options);
  j.Create();
  const auto at = START + f.segment;
  {
    std::lock_guard<std::mutex> lock(hook_mutex);
    gates.emplace(at, Gate{});
  }
  // The release guard precedes future destruction even on an assertion exit.
  std::future<void> closing;
  ReleaseHooks release;
  const JournalRecords first{Payload(37, 79)}, second{Payload(29, 43)};
  auto a = j.TryAppend(first);
  ASSERT_EQ(a.admission_, JournalAdmission::Accepted);
  WaitHook([&] { return gates.at(at).entered; });
  EXPECT_FALSE(a.ticket_->WaitFor(0ms));
  auto b = j.TryAppend(second);
  ASSERT_EQ(b.admission_, JournalAdmission::Accepted);
  a.ticket_.reset();
  b.ticket_.reset();
  closing = std::async(std::launch::async, [&] { j.Close(); });
  // Both result slots remain owned by accepted work, so this nonempty probe
  // must be Full until Close closes admission, then Stopped; it cannot write.
  const auto deadline = std::chrono::steady_clock::now() + 10s;
  JournalAdmission admission = JournalAdmission::Full;
  while (admission == JournalAdmission::Full &&
         std::chrono::steady_clock::now() < deadline) {
    admission = j.TryAppend(first).admission_;
    std::this_thread::yield();
  }
  ASSERT_EQ(admission, JournalAdmission::Stopped) << "close admission watchdog";
  EXPECT_EQ(closing.wait_for(0ms), std::future_status::timeout);
  Release(at);
  ASSERT_EQ(closing.wait_for(10s), std::future_status::ready);
  closing.get();
  JournalService reopened(f.bootstrap, f.identity, f.options);
  const std::vector<JournalRecords> expected{first, second};
  EXPECT_EQ(Replay(reopened), expected);
}
} // namespace
} // namespace bustub
