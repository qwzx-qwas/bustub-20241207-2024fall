"""Opt-in F07 checks; expanded tests and builds stay outside the repository."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tarfile
import time
import xml.etree.ElementTree as ET

TESTS = {
 'CrossSegmentRoundTripHasIndependentFormatAndProtectsPrefix',
 'CorruptOrIncompleteHistoryIsRejectedBeforeReplayWithoutRewriting',
 'GroupFlushWaitsForEveryWriteAndUsesOneBarrier',
 'AdmissionRollsBackAndCompletedResultsStayBounded',
 'WorkBytesAndAppendCapacityNeverOverwriteOldHistory',
 'WriteFailureDrainsOutstandingIOAndFaultsFutureAppends',
 'FlushFailureIsIndeterminateAndACompleteBatchCanRecover',
 'DroppedTicketAndObserverTimeoutDoNotCancelAcceptedWork',
}
F02_TESTS = {'ParallelMembersDoNotSkipBarrierHoles','BudgetIncludesPreparedRunningAndRetainedResults',
 'RejectionNeverStartsIOOrStealsPreparedBuffers','PartialFailureDrainsRunningIOAndSkipsUnstartedMembers',
 'FlushFailureIsNotDurableAndDoesNotLoseLaterWork','DroppingHandleDoesNotCancelIOAndShutdownDrains',
 'ExternalRoundTripReturnsPermissionsBeforePublishingCompletion','ExternalAdmissionPreservesPermissionsAndRejectsConflictingRAM'}
F06_TESTS = {'SegmentRangesPreserveOtherBytesAndReopen','InvalidGeometryOrMemberRejectsWholePreparation'}


def check_xml(path, suite, names):
    root = ET.parse(path).getroot()
    cases = root.findall('./testsuite/testcase')
    if (len(cases) != len(names) or {(c.get('classname'),c.get('name')) for c in cases} != {(suite,n) for n in names}
        or any(root.get(k) != '0' for k in ('failures','errors','disabled'))
        or any(c.get('status') != 'run' or c.get('result') != 'completed' or
               any(c.find(t) is not None for t in ('failure','error','skipped')) for c in cases)):
        raise RuntimeError(f'{suite}: missing, skipped or failed cases')

parser=argparse.ArgumentParser()
parser.add_argument('--repo',type=Path,required=True)
parser.add_argument('--work',type=Path,required=True)
parser.add_argument('--mutations',action='store_true')
args=parser.parse_args()
repo,work=args.repo.resolve(),args.work.resolve()
if work==repo or repo in work.parents:
    raise RuntimeError('work must be outside the repository')
work.mkdir(parents=True,exist_ok=True)
build=work/'build'
env={k:v for k,v in os.environ.items() if not k.startswith('GTEST_')}
env.update(ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1',
           F07_WORKDIR=str(work),F02_WORKDIR=str(work),F06_WORKDIR=str(work))
(work/'environment.json').write_text(json.dumps({k:v for k,v in env.items() if k.startswith(('ASAN_','UBSAN_','F0'))},indent=2)+'\n')
commands=[]
def call(argv, log, expected=0, timeout=180):
    entry={'command':list(map(str,argv)),'log':log};commands.append(entry);start=time.monotonic()
    try:
        with (work/log).open('w') as f:
            result=subprocess.run(argv,cwd=repo,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
        entry['returncode']=result.returncode
        if expected is not None and result.returncode!=expected:
            raise RuntimeError(f'{log}: exit {result.returncode} expected {expected}')
        return result.returncode
    except subprocess.TimeoutExpired:
        entry['timeout_seconds']=timeout;raise
    finally:
        entry['elapsed_seconds']=time.monotonic()-start
        (work/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')

call(['cmake','-S',str(repo),'-B',str(build),'-DCMAKE_BUILD_TYPE=Debug','-DCMAKE_C_COMPILER=clang-14',
 '-DCMAKE_CXX_COMPILER=clang++-14','-DBUSTUB_SANITIZER=address,undefined','-DCMAKE_EXE_LINKER_FLAGS=-no-pie'],'configure.log')
call(['cmake','--build',str(build),'--target','bustub_storage_disk','gtest_main','-j2'],'build.log')
flags=['clang++-14','-std=c++17','-Wall','-Wextra','-Werror','-Wno-unused-parameter','-pthread','-g','-O0',
 '-fsanitize=address,undefined','-fno-omit-frame-pointer','-I'+str(repo/'src/include'),
 '-I'+str(repo/'third_party/googletest/googletest/include')]
objects=build/'src/storage/disk/CMakeFiles/bustub_storage_disk.dir'
codec=work/'byte-codec.o'
call(flags+['-c',str(repo/'src/common/byte_codec.cpp'),'-o',str(codec)],'codec-compile.log')
base=[str(objects/(n+'.cpp.o')) for n in ('block_device','io_executor','bootstrap_store','region_manager','journal_backend')]
libs=[str(codec),str(build/'lib/libgtest_main.a'),str(build/'lib/libgtest.a')]
source=Path(__file__).with_name('journal_service_test.cpp');test_obj=work/'stage-test.o'
call(flags+['-c',str(source),'-o',str(test_obj)],'test-compile.log')
def link(exe, service):
    call(flags+['-no-pie',str(test_obj),str(service)]+base+libs+
         ['-Wl,--wrap=pwrite','-Wl,--wrap=fdatasync','-o',str(exe)],exe.name+'-link.log')
binary=work/'stage-test';link(binary,objects/'journal_service.cpp.o')
xml=work/'results.xml';xml.unlink(missing_ok=True)
call([str(binary),'--gtest_filter=JournalServiceTest.*','--gtest_repeat=1','--gtest_shuffle=0',
      '--gtest_output=xml:'+str(xml)],'run.log',timeout=120)
check_xml(xml,'JournalServiceTest',TESTS)
print('F07: 8/8 component cases passed',flush=True)

# Use original archived tests, never a rewritten mirror of them.
dependencies={'F02-object-io': ('279c9dff0b193fede4f1072c8ed4d443043173ab6c3b4d2c8edf55c432c6e1ce','IOExecutorTest',F02_TESTS,'io_executor_test.cpp'),'F06-journal-backend': ('6603b4d51f38fbdb8ed72c3f568b2b2cc9385a0c609b20b6021aa2ae8c45827d','JournalTest',F06_TESTS,'journal_backend_test.cpp')}
for name,(sha,suite,names,filename) in dependencies.items():
    archive=repo/'test/archives'/(name+'.tar.gz')
    if hashlib.sha256(archive.read_bytes()).hexdigest()!=sha:raise RuntimeError('regression archive changed: '+name)
    with tarfile.open(archive) as t:
        content=t.extractfile(name+'/test/storage_redesign/'+filename).read()
    cpp=work/(name+'.cpp');cpp.write_bytes(content);obj=work/(name+'.o');exe=work/(name+'-regression')
    call(flags+['-c',str(cpp),'-o',str(obj)],name+'-compile.log')
    wraps=['-Wl,--wrap=pwrite','-Wl,--wrap=pread','-Wl,--wrap=fdatasync']
    if name.startswith('F02'):wraps+=['-Wl,--wrap=malloc','-Wl,--wrap=_Znwm']
    call(flags+['-no-pie',str(obj)]+base+libs+wraps+['-o',str(exe)],name+'-link.log')
    output=work/(name+'.xml');output.unlink(missing_ok=True)
    call([str(exe),'--gtest_filter='+suite+'.*','--gtest_repeat=1','--gtest_shuffle=0','--gtest_output=xml:'+str(output)],name+'-run.log',timeout=120)
    check_xml(output,suite,names);print(name+': unchanged regression passed',flush=True)

if args.mutations:
    original=(repo/'src/storage/disk/journal_service.cpp').read_text()
    mutations=[]
    def add(name,old,new,test,oracle):
        if original.count(old)!=1:raise RuntimeError('mutation source drift: '+name)
        mutations.append((name,original.replace(old,new),test,oracle))
    good='CrossSegmentRoundTripHasIndependentFormatAndProtectsPrefix'
    corrupt='CorruptOrIncompleteHistoryIsRejectedBeforeReplayWithoutRewriting'
    group='GroupFlushWaitsForEveryWriteAndUsesOneBarrier'
    add('omit_group_flush','SubmitAndWait(*group_.front().flush_);','/* mutated: omitted Flush */',group,'flushes.load()')
    add('ignore_unit_crc','      CheckUnitChecksum(unit);',
        '      /* mutated: no unit integrity check */',corrupt,'bad.Open')
    add('skip_flush_completion_wait','SubmitAndWait(*group_.front().flush_);',
        'CheckAdmission(executor_.TrySubmit(*group_.front().flush_)); CheckIO(*group_.front().flush_);',
        'FlushFailureIsIndeterminateAndACompleteBatchCanRecover','expected fdatasync EIO after completion')
    add('wrong_previous','writer.PutU64(previous);','writer.PutU64(previous + 1);',good,'o + 56')
    add('ignore_unit_identity','std::memcmp(identity.data(), identity_.data(), identity_.size()) == 0','true',corrupt,'bad.Open')
    add('ignore_segment_position','header.ReadU64() == position / options_.segment_bytes_','(header.ReadU64(), true)',corrupt,'bad.Open')
    add('ignore_commit_crc','payload.ReadU32() == rolling','(payload.ReadU32(), true)',corrupt,'bad.Open')
    add('release_result_slots_early','budget_->tickets_ == options_.max_pending_batches_','false',
        'AdmissionRollsBackAndCompletedResultsStayBounded','JournalAdmission::Full')
    add('ignore_pending_bytes','bytes > options_.max_pending_bytes_ - budget_->bytes_','false',
        'WorkBytesAndAppendCapacityNeverOverwriteOldHistory','JournalAdmission::Full')
    add('report_sync_error_as_durable','request.ticket_->Complete(outcome, error);',
        'request.ticket_->Complete(JournalOutcome::Durable, error); (void)outcome;',
        'FlushFailureIsIndeterminateAndACompleteBatchCanRecover','JournalOutcome::Indeterminate')
    mutations.append(('admit_after_fault',original.replace('if (faulted_) {','if (false && faulted_) {'),
        'FlushFailureIsIndeterminateAndACompleteBatchCanRecover','JournalAdmission::Faulted'))
    add('discard_pending_on_close','if (queue_.empty()) {','if (queue_.empty() || stopping_) {',
        'DroppedTicketAndObserverTimeoutDoNotCancelAcceptedWork','expected')
    if original.count('ObserveFailure(error);') != 3:
        raise RuntimeError('mutation source drift: delay_failure_isolation')
    delayed = original.replace('ObserveFailure(error);', '/* mutated: delay isolation */')
    delayed = delayed.replace('      // Every submitted IO has drained;',
        '      if (error) { ObserveFailure(error); }\n      // Every submitted IO has drained;')
    mutations.append(('delay_failure_isolation',delayed,
        'WriteFailureDrainsOutstandingIOAndFaultsFutureAppends','failure isolation watchdog'))
    results=[]
    for name,content,test,oracle in mutations:
        cpp,obj,exe=(work/(name+suffix) for suffix in ('.cpp','.o',''))
        cpp.write_text(content)
        call(flags+['-c',str(cpp),'-o',str(obj)],name+'-compile.log');link(exe,obj)
        result_xml=work/(name+'.xml');result_xml.unlink(missing_ok=True)
        call([str(exe),'--gtest_filter=JournalServiceTest.'+test,'--gtest_repeat=1',
              '--gtest_output=xml:'+str(result_xml)],name+'-run.log',expected=1,timeout=120)
        failures=ET.parse(result_xml).getroot().findall('.//failure')
        if not any(oracle in (f.text or '') for f in failures):raise RuntimeError('wrong mutation failure: '+name)
        results.append({'name':name,'test':test,'assertion':oracle,'exit':1})
        (work/'mutations.json').write_text(json.dumps(results,indent=2)+'\n')
    print(f'F07: {len(results)} targeted mutants killed by expected assertions',flush=True)
